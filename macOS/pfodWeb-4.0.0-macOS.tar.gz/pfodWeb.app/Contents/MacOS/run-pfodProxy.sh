#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
"$DIR/pfodProxy"
MY_TTY="$(tty)"
osascript -e "tell application \"Terminal\" to close (first window whose tabs contains (first tab whose tty is \"$MY_TTY\"))" >/dev/null 2>&1
