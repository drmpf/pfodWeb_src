/*   
   webTranslator.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Translates pfod wire-format strings into internal drawing/menu objects.
//
// Exports:    window.translateRawItemsToItemArray(items, parentDwg), translate* helpers
//             used internally and via drawingDataProcessor.translateDwgResponse.
// Depends on: window.JS_VERSION from version.js
// Called by:  drawingDataProcessor.js (translateDwgResponse + translateRaw* item helpers).
//             Menu-shape parsing lives in pfodMenuParser.js (pfodParseMenu) — not here.

 /**
   from Android App these can be 'c' or 'r'
     public void updateColRows(int colPixel, int rowPixel) { // , int rc, int rr) {
        colOffset = setFromVar(colOffset, colOffsetVar, colPixel, rowPixel);// , rc, rr);
        rowOffset = setFromVar(rowOffset, rowOffsetVar, colPixel, rowPixel);// , rc, rr);
        vWidth = setFromVar(vWidth, vWidthVar, colPixel, rowPixel);// , rc, rr);
        vHeight = setFromVar(vHeight, vHeightVar, colPixel, rowPixel);// , rc, rr);
        value = (int) setFromVar((float) value, vValueVar, colPixel, rowPixel);// , rc, rr);
        // sortRect(); // resort after setting
    }
**/

// JS_VERSION is available globally via window.JS_VERSION from pfodWeb.js

// Parse a dwg <colour> wire field (spec 8.11): either a decimal 0-255 palette
// index or a 6-hex-digit RRGGBB string. A bare index is never 6 chars (max
// "255"), so a 6-char run is unambiguously hex here.
// @param {string} s - raw field text (already split out by caller)
// @returns {number|string|undefined} palette index, uppercase RRGGBB string, or undefined if s is ''
function parseDwgColour(s) {
    if (s === '' || s === undefined) return undefined;
    if (/^[0-9A-Fa-f]{6}$/.test(s)) return s.toUpperCase();
    return parseInt(s, 10);
}

function translateRawRectangle(rawRectString,isTouchAction=false) {
    // Parse rectangle type from prefix
    let rectType = '';
    let content = '';
    
    if (rawRectString.startsWith('|RRc')) {
        rectType = 'RRc';
        content = rawRectString.substring(4);
    } else if (rawRectString.startsWith('|RR')) {
        rectType = 'RR';
        content = rawRectString.substring(3);
    } else if (rawRectString.startsWith('|Rc')) {
        rectType = 'Rc';
        content = rawRectString.substring(3);
    } else if (rawRectString.startsWith('|R')) {
        rectType = 'R';
        content = rawRectString.substring(2);
    } else if (rawRectString.startsWith('|rrc')) {
        rectType = 'rrc';
        content = rawRectString.substring(4);
    } else if (rawRectString.startsWith('|rr')) {
        rectType = 'rr';
        content = rawRectString.substring(3);
    } else if (rawRectString.startsWith('|rc')) {
        rectType = 'rc';
        content = rawRectString.substring(3);
    } else if (rawRectString.startsWith('|r')) {
        rectType = 'r';
        content = rawRectString.substring(2);
    } else {
        throw new Error('Invalid rectangle format: must start with |r, |rc, |rr, |rrc, |R, |Rc, |RR, or |RRc');
    }
    
    let idx = 0; // default value
    let parts;
    
    // Check if idx is specified (starts with `)
    if (content.startsWith('`')) {
        // Extract idx and split remaining by ~
        const idxEnd = content.indexOf('~');
        idx = parseInt(content.substring(1, idxEnd));
        parts = content.substring(idxEnd + 1).split('~');
    } else {
        // No idx, split all by ~ and drop leading empty string
        parts = content.split('~');
        if (parts[0] === '') {
            parts = parts.slice(1);
        }
    }
    
    // Parse parts: [colour]~width~height[~colOffset[~rowOffset]]
    const colour = parseDwgColour(parts[0]);
    let xSize = 1;
    let ySize = 1;
    // Handle isTouchAction transformations and invalid inputs
    if (parts.length > 1 && parts[1] !== '') {
        if (isTouchAction && parts[1] === 'c') {
            xSize = 'COL';
        } else if (isTouchAction && parts[1] === 'r') {
            xSize = 'ROW';
        } else if (!isNaN(parseFloat(parts[1]))) {
            xSize = parseFloat(parts[1]);
        } else {
            xSize = 1;
        }
    }
    
    if (parts.length > 2 && parts[2] !== '') {
        if (isTouchAction && parts[2] === 'c') {
            ySize = 'COL';
        } else if (isTouchAction && parts[2] === 'r') {
            ySize = 'ROW';
        } else if (!isNaN(parseFloat(parts[2]))) {
            ySize = parseFloat(parts[2]);
        } else {
            ySize = 1;
        }
    }
    
    
    let xOffset = 0;
    let yOffset = 0;
    
    // Handle isTouchAction transformations and invalid inputs
    if (parts.length > 3 && parts[3] !== '') {
        if (isTouchAction && parts[3] === 'c') {
            xOffset = 'COL';
        } else if (isTouchAction && parts[3] === 'r') {
            xOffset = 'ROW';
        } else if (!isNaN(parseFloat(parts[3]))) {
            xOffset = parseFloat(parts[3]);
        } else {
            xOffset = 0;
        }
    }
    
    if (parts.length > 4 && parts[4] !== '') {
        if (isTouchAction && parts[4] === 'c') {
            yOffset = 'COL';
        } else if (isTouchAction && parts[4] === 'r') {
            yOffset = 'ROW';
        } else if (!isNaN(parseFloat(parts[4]))) {
            yOffset = parseFloat(parts[4]);
        } else {
            yOffset = 0;
        }
    }
    
    // Create rectangle object
    const rectObject = {
        type: "rectangle",
        idx: idx
    };
    
    // Add colour if specified
    if (colour !== undefined && (typeof colour === 'string' || !isNaN(colour))) {
        rectObject.color = colour;
    } else {
      rectObject.color = -1;
    }
    
    // Add dimensions
    rectObject.xSize = xSize;
    rectObject.ySize = ySize;
    
    // Add offsets
    rectObject.xOffset = xOffset;
    rectObject.yOffset = yOffset;
    
    // Add rectangle properties based on type
    if (rectType.includes('R') || rectType.includes('r')) {
        if (rectType.includes('R')) {
            rectObject.filled = "true";
        }
        if (rectType.includes('c')) {
            rectObject.centered = "true";
        }
        if (rectType.includes('r') && !rectType.includes('R')) {
            // lowercase r in rr or rrc means rounded
            if (rectType.includes('rr')) {
                rectObject.rounded = "true";
            }
        } else if (rectType.includes('R')) {
            // uppercase R with additional r means rounded
            if (rectType.includes('RR')) {
                rectObject.rounded = "true";
            }
        }
    }
    
    return rectObject;
}

  
function translateRawLine(rawLineString,isTouchAction=false) {
    // Check if this is a line item
    if (!rawLineString.startsWith('|l')) {
        throw new Error('Invalid line format: must start with |l');
    }
    
    // Remove the |l prefix
    const content = rawLineString.substring(2);
    
    let idx = 0; // default value
    let parts;
    
    // Check if idx is specified (starts with `)
    if (content.startsWith('`')) {
        // Extract idx and split remaining by ~
        const idxEnd = content.indexOf('~');
        idx = parseInt(content.substring(1, idxEnd));
        parts = content.substring(idxEnd + 1).split('~');
    } else {
        // No idx, split all by ~ and drop leading empty string
        parts = content.split('~');
        if (parts[0] === '') {
            parts = parts.slice(1);
        }
    }
    
    // Parse parts: [colour]~colDelta~rowDelta[~colOffset[~rowOffset]]
    const colour = parseDwgColour(parts[0]);
    // colDelta/rowDelta default to 1 (spec) when omitted
    let xSize = 1;
    let ySize = 1;
    if (parts.length > 1 && parts[1] !== '' && !isNaN(parseFloat(parts[1]))) {
        xSize = parseFloat(parts[1]);
    }
    if (parts.length > 2 && parts[2] !== '' && !isNaN(parseFloat(parts[2]))) {
        ySize = parseFloat(parts[2]);
    }
    
    let xOffset = 0;
    let yOffset = 0;
    
    // Handle isTouchAction transformations and invalid inputs
    if (parts.length > 3 && parts[3] !== '') {
        if (isTouchAction && parts[3] === 'c') {
            xOffset = 'COL';
        } else if (isTouchAction && parts[3] === 'r') {
            xOffset = 'ROW';
        } else if (!isNaN(parseFloat(parts[3]))) {
            xOffset = parseFloat(parts[3]);
        } else {
            xOffset = 0;
        }
    }
    
    if (parts.length > 4 && parts[4] !== '') {
        if (isTouchAction && parts[4] === 'c') {
            yOffset = 'COL';
        } else if (isTouchAction && parts[4] === 'r') {
            yOffset = 'ROW';
        } else if (!isNaN(parseFloat(parts[4]))) {
            yOffset = parseFloat(parts[4]);
        } else {
            yOffset = 0;
        }
    }
    
    // Create line object
    const lineObject = {
        type: "line",
        idx: idx
    };
    
    // Add colour if specified
    if (colour !== undefined && (typeof colour === 'string' || !isNaN(colour))) {
        lineObject.color = colour;
     } else {
      lineObject.color = -1;
     }
    
    // Add coordinates
    lineObject.xSize = xSize;
    lineObject.ySize = ySize;
    
    // Add offsets
    lineObject.xOffset = xOffset;
    lineObject.yOffset = yOffset;
    
    return lineObject;
}

function translateRawCircle(rawCircleString,isTouchAction=false) {
    // Parse circle type from prefix
    let circleType = '';
    let content = '';
    
    if (rawCircleString.startsWith('|C')) {
        circleType = 'C';
        content = rawCircleString.substring(2);
    } else if (rawCircleString.startsWith('|c')) {
        circleType = 'c';
        content = rawCircleString.substring(2);
    } else {
        throw new Error('Invalid circle format: must start with |c or |C');
    }
    
    let idx = 0; // default value
    let parts;
    
    // Check if idx is specified (starts with `)
    if (content.startsWith('`')) {
        // Extract idx and split remaining by ~
        const idxEnd = content.indexOf('~');
        idx = parseInt(content.substring(1, idxEnd));
        parts = content.substring(idxEnd + 1).split('~');
    } else {
        // No idx, split all by ~ and drop leading empty string
        parts = content.split('~');
        if (parts[0] === '') {
            parts = parts.slice(1);
        }
    }
    
    // Parse parts: [colour]~dRadius[~colOffset[~rowOffset]]
    const colour = parseDwgColour(parts[0]);
    // dRadius defaults to 1 (spec) when omitted
    let radius = 1;
    if (parts.length > 1 && parts[1] !== '' && !isNaN(parseFloat(parts[1]))) {
        radius = parseFloat(parts[1]);
    }
    
    let xOffset = 0;
    let yOffset = 0;
    
    // Handle isTouchAction transformations and invalid inputs
    if (parts.length > 2 && parts[2] !== '') {
        if (isTouchAction && parts[2] === 'c') {
            xOffset = 'COL';
        } else if (isTouchAction && parts[2] === 'r') {
            xOffset = 'ROW';
        } else if (!isNaN(parseFloat(parts[2]))) {
            xOffset = parseFloat(parts[2]);
        } else {
            xOffset = 0;
        }
    }
    
    if (parts.length > 3 && parts[3] !== '') {
        if (isTouchAction && parts[3] === 'c') {
            yOffset = 'COL';
        } else if (isTouchAction && parts[3] === 'r') {
            yOffset = 'ROW';
        } else if (!isNaN(parseFloat(parts[3]))) {
            yOffset = parseFloat(parts[3]);
        } else {
            yOffset = 0;
        }
    }
    
    // Create circle object
    const circleObject = {
        type: "circle",
        idx: idx
    };
    
    // Add colour if specified
    if (colour !== undefined && (typeof colour === 'string' || !isNaN(colour))) {
        circleObject.color = colour;
     } else {
      circleObject.color = -1;
    }
    
    // Add offsets
    circleObject.xOffset = xOffset;
    circleObject.yOffset = yOffset;
    
    // Add radius
    circleObject.radius = radius;
    
    // Add filled property if it's a filled circle
    if (circleType === 'C') {
        circleObject.filled = "true";
    }
    
    return circleObject;
}

function translateRawArc(rawArcString,isTouchAction=false) {
    // Parse arc type from prefix
    let arcType = '';
    let content = '';
    
    if (rawArcString.startsWith('|A')) {
        arcType = 'A';
        content = rawArcString.substring(2);
    } else if (rawArcString.startsWith('|a')) {
        arcType = 'a';
        content = rawArcString.substring(2);
    } else {
        throw new Error('Invalid arc format: must start with |a or |A');
    }
    
    let idx = 0; // default value
    let parts;
    
    // Check if idx is specified (starts with `)
    if (content.startsWith('`')) {
        // Extract idx and split remaining by ~
        const idxEnd = content.indexOf('~');
        idx = parseInt(content.substring(1, idxEnd));
        parts = content.substring(idxEnd + 1).split('~');
    } else {
        // No idx, split all by ~ and drop leading empty string
        parts = content.split('~');
        if (parts[0] === '') {
            parts = parts.slice(1);
        }
    }
    
    // Parse parts: [colour]~dArcAngle~dStartAngle~dRadius[~colOffset[~rowOffset]]
    const colour = parseDwgColour(parts[0]);
    // dArcAngle/dStartAngle/dRadius default to 90/0/1 (spec) when omitted
    let angle = 90;
    let start = 0;
    let radius = 1;
    if (parts.length > 1 && parts[1] !== '' && !isNaN(parseFloat(parts[1]))) {
        angle = parseFloat(parts[1]);
    }
    if (parts.length > 2 && parts[2] !== '' && !isNaN(parseFloat(parts[2]))) {
        start = parseFloat(parts[2]);
    }
    if (parts.length > 3 && parts[3] !== '' && !isNaN(parseFloat(parts[3]))) {
        radius = parseFloat(parts[3]);
    }
    
    let xOffset = 0;
    let yOffset = 0;
    
    // Handle isTouchAction transformations and invalid inputs
    if (parts.length > 4 && parts[4] !== '') {
        if (isTouchAction && parts[4] === 'c') {
            xOffset = 'COL';
        } else if (isTouchAction && parts[4] === 'r') {
            xOffset = 'ROW';
        } else if (!isNaN(parseFloat(parts[4]))) {
            xOffset = parseFloat(parts[4]);
        } else {
            xOffset = 0;
        }
    }
    
    if (parts.length > 5 && parts[5] !== '') {
        if (isTouchAction && parts[5] === 'c') {
            yOffset = 'COL';
        } else if (isTouchAction && parts[5] === 'r') {
            yOffset = 'ROW';
        } else if (!isNaN(parseFloat(parts[5]))) {
            yOffset = parseFloat(parts[5]);
        } else {
            yOffset = 0;
        }
    }
    
    // Create arc object
    const arcObject = {
        type: "arc",
        idx: idx
    };
    
    // Add colour if specified
    if (colour !== undefined && (typeof colour === 'string' || !isNaN(colour))) {
        arcObject.color = colour;
     } else {
      arcObject.color = -1;
    }
    
    // Add offsets
    arcObject.xOffset = xOffset;
    arcObject.yOffset = yOffset;
    
    // Add arc properties
    arcObject.radius = radius;
    arcObject.start = start;
    arcObject.angle = angle;
    
    // Add filled property if it's a filled arc
    if (arcType === 'A') {
        arcObject.filled = "true";
    }
    
    return arcObject;
}

function translateRawText(rawTextString,isTouchAction=false) {
    // Check if this is a text item
    if (!rawTextString.startsWith('|t')) {
        throw new Error('Invalid text format: must start with |t');
    }
    
    // Remove the |t prefix
    const content = rawTextString.substring(2);
    
    let idx = 0; // default value
    let parts;
    
    // Check if idx is specified (starts with `)
    if (content.startsWith('`')) {
        // Extract idx and split remaining by ~
        const idxEnd = content.indexOf('~');
        idx = parseInt(content.substring(1, idxEnd));
        parts = content.substring(idxEnd + 1).split('~');
    } else {
        // No idx, split all by ~ and drop leading empty string
        parts = content.split('~');
        if (parts[0] === '') {
            parts = parts.slice(1);
        }
    }
    
    // Parse parts: [colour]~text[~colOffset[~rowOffset[~alignment]]]
    const colour = parseDwgColour(parts[0]);
    // text defaults to "" (spec) when omitted
    const rawText = parts[1] !== undefined ? parts[1] : ''; // text with HTML tags
    
    let xOffset = 0;
    let yOffset = 0;
    
    // Handle isTouchAction transformations and invalid inputs
    if (parts.length > 2 && parts[2] !== '') {
        if (isTouchAction && parts[2] === 'c') {
            xOffset = 'COL';
        } else if (isTouchAction && parts[2] === 'r') {
            xOffset = 'ROW';
        } else if (!isNaN(parseFloat(parts[2]))) {
            xOffset = parseFloat(parts[2]);
        } else {
            xOffset = 0;
        }
    }
    
    if (parts.length > 3 && parts[3] !== '') {
        if (isTouchAction && parts[3] === 'c') {
            yOffset = 'COL';
        } else if (isTouchAction && parts[3] === 'r') {
            yOffset = 'ROW';
        } else if (!isNaN(parseFloat(parts[3]))) {
            yOffset = parseFloat(parts[3]);
        } else {
            yOffset = 0;
        }
    }
    
    const alignment = parts.length > 4 && parts[4] !== '' ? parts[4] : 'center';
    
    // Tags are left in the text so the canvas renderer (parsePfodInlineSegments
    // in redraw.js) can apply them inline per segment.
    function parseTextFormatting(text) { return { text: text }; }

    const textInfo = parseTextFormatting(rawText);
    
    // Create text object
    const textObject = {
        type: "label",
        idx: idx
    };
    
    // Add colour if specified
    if (colour !== undefined && (typeof colour === 'string' || !isNaN(colour))) {
        textObject.color = colour;
     } else {
      textObject.color = -1;
    }
    
    // Add offsets
    textObject.xOffset = xOffset;
    textObject.yOffset = yOffset;
    
    // Add text content
    textObject.text = textInfo.text;
    
    // Add formatting properties if they exist
    if (textInfo.fontSize !== undefined) {
        textObject.fontSize = textInfo.fontSize;
    }
    if (textInfo.bold) {
        textObject.bold = "true";
    }
    if (textInfo.italic) {
        textObject.italic = "true";
    }
    if (textInfo.underline) {
        textObject.underline = "true";
    }
    
    // Add alignment if specified
    if (alignment) {
        const alignMap = { 'L': 'left', 'C': 'center', 'R': 'right' };
        textObject.align = alignMap[alignment] || 'center';
    }
    
    return textObject;
}

function translateRawValue(rawValueString,isTouchAction=false) {
    // Check if this is a value item
    if (!rawValueString.startsWith('|v')) {
        throw new Error('Invalid value format: must start with |v');
    }
    
    // Remove the |v prefix
    const content = rawValueString.substring(2);
    
    let idx = 0; // default value
    let parts;
    
    // Check if idx is specified (starts with `)
    if (content.startsWith('`')) {
        // Extract idx and split remaining by ~
        const idxEnd = content.indexOf('~');
        idx = parseInt(content.substring(1, idxEnd));
        parts = content.substring(idxEnd + 1).split('~');
    } else {
        // No idx, split all by ~ and drop leading empty string
        parts = content.split('~');
        if (parts[0] === '') {
            parts = parts.slice(1);
        }
    }
    
    // Rejoin parts and split by backtick to handle the ` separators properly
    const rejoined = parts.join('~');
    const backTickParts = rejoined.split('`');
    
    // Parse initial parts: [colour]~text~colOffset~rowOffset
    const initialParts = backTickParts[0].split('~');
    const colour = parseDwgColour(initialParts[0]);
    const rawText = initialParts[1]; // text with HTML tags
    
    let xOffset = 0; // colOffset - required for values
    let yOffset = 0; // rowOffset - required for values
    
    // Handle isTouchAction transformations and invalid inputs for xOffset
    if (initialParts[2] !== undefined) {
        if (isTouchAction && initialParts[2] === 'c') {
            xOffset = 'COL';
        } else if (isTouchAction && initialParts[2] === 'r') {
            xOffset = 'ROW';
        } else if (!isNaN(parseFloat(initialParts[2]))) {
            xOffset = parseFloat(initialParts[2]);
        } else {
            xOffset = 0;
        }
    }
    
    // Handle isTouchAction transformations and invalid inputs for yOffset
    if (initialParts[3] !== undefined) {
        if (isTouchAction && initialParts[3] === 'c') {
            yOffset = 'COL';
        } else if (isTouchAction && initialParts[3] === 'r') {
            yOffset = 'ROW';
        } else if (!isNaN(parseFloat(initialParts[3]))) {
            yOffset = parseFloat(initialParts[3]);
        } else {
            yOffset = 0;
        }
    }
    
    // Parse value and units: value~units
    // The device always sends a real value here (never blank) — see
    // pfodLabel::send()/sendValue() in pfodParser/src/dwgs/pfodLabel.cpp.
    // A non-numeric result therefore means the wire message was cut short
    // (e.g. the 1024-byte cap), not a legitimately omitted default, so
    // throw rather than silently show a fabricated reading.
    const valueAndUnits = backTickParts[1].split('~');

    let intValue;
    if (isTouchAction && valueAndUnits[0] === 'c') {
        intValue = 'COL';
    } else if (isTouchAction && valueAndUnits[0] === 'r') {
        intValue = 'ROW';
    } else {
        intValue = parseFloat(valueAndUnits[0]);
        if (isNaN(intValue)) {
            throw new Error('Invalid value format: intValue is missing or not a number');
        }
    }

    const units = valueAndUnits[1];

    // Parse max value
    const maxValue = parseInt(backTickParts[2]);
    if (isNaN(maxValue)) {
        throw new Error('Invalid value format: max is missing or not a number');
    }

    // Parse min and display range: min~displaymax~displaymin
    const minAndDisplay = backTickParts[3].split('~');
    const minValue = parseInt(minAndDisplay[0]);
    const displayMax = parseFloat(minAndDisplay[1]);
    const displayMin = parseFloat(minAndDisplay[2]);
    if (isNaN(minValue) || isNaN(displayMax) || isNaN(displayMin)) {
        throw new Error('Invalid value format: min/displayMax/displayMin missing or not numbers');
    }

    // Parse decimals and optional alignment: decimals~alignment
    const decimalsAndAlign = backTickParts[4].split('~');
    const decimals = parseInt(decimalsAndAlign[0]);
    if (isNaN(decimals)) {
        throw new Error('Invalid value format: decimals is missing or not a number');
    }
    const alignment = decimalsAndAlign.length > 1 ? decimalsAndAlign[1] : 'center';
    
    // Tags are left in the text so the canvas renderer (parsePfodInlineSegments
    // in redraw.js) can apply them inline per segment.
    function parseTextFormatting(text) { return { text: text }; }

    const textInfo = parseTextFormatting(rawText);
    
    // Create value object
    const valueObject = {
        type: "value",
        idx: idx
    };
    
    // Add colour if specified
    if (colour !== undefined && (typeof colour === 'string' || !isNaN(colour))) {
        valueObject.color = colour;
     } else {
      valueObject.color = -1;
    }
    
    // Add offsets
    valueObject.xOffset = xOffset;
    valueObject.yOffset = yOffset;
    
    // Add text content
    valueObject.text = textInfo.text;
    
    // Add formatting properties if they exist
    if (textInfo.fontSize !== undefined) {
        valueObject.fontSize = textInfo.fontSize;
    }
    if (textInfo.bold) {
        valueObject.bold = "true";
    }
    if (textInfo.italic) {
        valueObject.italic = "true";
    }
    if (textInfo.underline) {
        valueObject.underline = "true";
    }
    
    // Add value-specific properties
    valueObject.intValue = intValue;
    valueObject.min = minValue;
    valueObject.max = maxValue;
    valueObject.displayMin = displayMin;
    valueObject.displayMax = displayMax;
    valueObject.decimals = decimals;
    valueObject.units = units;
    
    // Add alignment if specified
    if (alignment) {
        const alignMap = { 'L': 'left', 'C': 'center', 'R': 'right' };
        valueObject.align = alignMap[alignment] || 'center';
    }
    
    return valueObject;
}

function translateRawHide(rawHideString) {
    // Check if this is a hide item
    if (!rawHideString.startsWith('|h')) {
        throw new Error('Invalid hide format: must start with |h');
    }
    
    // Remove the |h prefix
    const content = rawHideString.substring(2);
    
    // Create hide object
    const hideObject = {
        type: "hide"
    };
    
    // Check if idx is specified (starts with `) or cmd is specified (starts with ~)
    if (content.startsWith('`')) {
        // Extract idx
        const idx = parseInt(content.substring(1));
        hideObject.idx = idx;
    } else if (content.startsWith('~')) {
        // Extract cmd
        const cmd = content.substring(1);
        hideObject.cmd = cmd;
    } else {
        throw new Error('Invalid hide format: must specify either `idx or ~cmd');
    }
    
    return hideObject;
}

function translateRawUnhide(rawUnhideString) {
    // Check if this is an unhide item
    if (!rawUnhideString.startsWith('|uh')) {
        throw new Error('Invalid unhide format: must start with |uh');
    }
    
    // Remove the |uh prefix
    const content = rawUnhideString.substring(3);
    
    // Create unhide object
    const unhideObject = {
        type: "unhide"
    };
    
    // Check if idx is specified (starts with `) or cmd is specified (starts with ~)
    if (content.startsWith('`')) {
        // Extract idx
        const idx = parseInt(content.substring(1));
        unhideObject.idx = idx;
    } else if (content.startsWith('~')) {
        // Extract cmd
        const cmd = content.substring(1);
        unhideObject.cmd = cmd;
    } else {
        throw new Error('Invalid unhide format: must specify either `idx or ~cmd');
    }
    
    return unhideObject;
}

function translateRawErase(rawEraseString) {
    // Check if this is an erase item
    if (!rawEraseString.startsWith('|e')) {
        throw new Error('Invalid erase format: must start with |e');
    }
    
    // Remove the |e prefix
    const content = rawEraseString.substring(2);
    
    // Create erase object
    const eraseObject = {
        type: "erase"
    };
    
    // Check if idx is specified (starts with `) or cmd is specified (starts with ~)
    if (content.startsWith('`')) {
        // Extract idx
        const idx = parseInt(content.substring(1));
        eraseObject.idx = idx;
    } else if (content.startsWith('~')) {
        // Extract cmd
        const cmd = content.substring(1);
        eraseObject.cmd = cmd;
    } else {
        throw new Error('Invalid erase format: must specify either `idx or ~cmd');
    }
    
    return eraseObject;
}

function translateRawHideDwg(rawHideString) {
    // Check if this is a hide item
    if (!rawHideString.startsWith('|hd')) {
        throw new Error('Invalid hide dwg format: must start with |hd');
    }
    
    // Remove the |h prefix
    const content = rawHideString.substring(3);
    
    // Create hide object
    const hideObject = {
        type: "hide"
    };
    
    // Check if  cmd is specified (starts with ~)
    if (content.startsWith('~')) {
        // Extract cmd
        const cmd = content.substring(1);
        hideObject.cmd = cmd;
        hideObject.drawingName = cmd;
    } else {
        throw new Error('Invalid hide dwg format: must specify ~loadCmd');
    }
    
    return hideObject;
}

function translateRawUnhideDwg(rawUnhideString) {
    // Check if this is an unhide item
    if (!rawUnhideString.startsWith('|uhd')) {
        throw new Error('Invalid unhide dwg format: must start with |uhd');
    }
    
    // Remove the |uh prefix
    const content = rawUnhideString.substring(4);
    
    // Create unhide object
    const unhideObject = {
        type: "unhide"
    };
    
    // Check if cmd is specified (starts with ~)
    if (content.startsWith('~')) {
        // Extract cmd
        const cmd = content.substring(1);
        unhideObject.cmd = cmd;
        unhideObject.drawingName = cmd;
    } else {
        throw new Error('Invalid unhide dwg format: must specify ~loadCmd');
    }
    
    return unhideObject;
}

function translateRawEraseDwg(rawEraseString) {
    // Check if this is an erase item
    if (!rawEraseString.startsWith('|ed')) {
        throw new Error('Invalid erase dwg format: must start with |ed');
    }
    
    // Remove the |e prefix
    const content = rawEraseString.substring(3);
    
    // Create erase object
    const eraseObject = {
        type: "erase"
    };
    
    // Check if cmd is specified (starts with ~)
    if (content.startsWith('~')) {
        // Extract cmd
        const cmd = content.substring(1);
        eraseObject.cmd = cmd;
        eraseObject.drawingName = cmd;
    } else {
        throw new Error('Invalid erase format: must specify ~loadCmd');
    }
    
    return eraseObject;
}


function translateRawZero(rawZeroString) {
    // Check if this is a zero item
    if (!rawZeroString.startsWith('|z')) {
        throw new Error('Invalid zero format: must start with |z');
    }
    
    // Remove the |z prefix
    const content = rawZeroString.substring(2);
    
    // Check if this is a pop (no content) or push (has content)
    if (content === '') {
        // This is a pop operation
        return {
            type: "popZero"
        };
    } else {
        // This is a push operation - parse the parameters
        // Format: ~ col ~ row ~ scaling
        let x = 0;
        let y = 0;
        let scale = 1.0;
        
        if (content.startsWith('~')) {
           //throw new Error('Invalid pushZero format: must start with ~ after |z'); 
          // Split by ~ and remove empty first element
          const parts = content.split('~').slice(1);
          if (parts.length >= 1) { 
            x = parseFloat(parts[0]); // col
          }
          if (parts.length >= 2) { 
            y = parseFloat(parts[1]); // row
          }
          if (parts.length >= 3) { 
            scale = parseFloat(parts[2]); // scaling
          }
          if (parts.length > 3) {
            throw new Error('Invalid pushZero format: must have no more then 3 parameters (col, row, scaling)');
          }
        }
        return {
            type: "pushZero",
            x: x,
            y: y,
            scale: scale
        };
    }
}


function translateRawIndex(rawIndexString) {
    // Check if this is an index item
    if (!rawIndexString.startsWith('|i')) {
        throw new Error('Invalid index format: must start with |i');
    }
    
    // Remove the |i prefix
    const content = rawIndexString.substring(2);
    
    // Create index object
    const indexObject = {
        type: "index"
    };
    
    // Check if idx is specified (must start with `)
    if (content.startsWith('`')) {
        // Extract idx
        const idx = parseInt(content.substring(1));
        indexObject.idx = idx;
    } else {
        throw new Error('Invalid index format: must specify `idx');
    }
    
    return indexObject;
}

function translateRawTouchZone(rawTouchZoneString) {
    // Parse touchZone type from prefix
    let touchZoneType = '';
    let content = '';
    
    if (rawTouchZoneString.startsWith('|xc')) {
        touchZoneType = 'xc';
        content = rawTouchZoneString.substring(3);
    } else if (rawTouchZoneString.startsWith('|x')) {
        touchZoneType = 'x';
        content = rawTouchZoneString.substring(2);
    } else {
        throw new Error('Invalid touchZone format: must start with |x or |xc');
    }
    
    let idx = 0; // default value
    let parts;
    
    // Check if idx is specified (starts with `)
    if (content.startsWith('`')) {
        // Extract idx and split remaining by ~
        const idxEnd = content.indexOf('~');
        idx = parseInt(content.substring(1, idxEnd));
        parts = content.substring(idxEnd + 1).split('~');
    } else {
        // No idx, split all by ~ and drop leading empty string
        parts = content.split('~');
        if (parts[0] === '') {
            parts = parts.slice(1);
        }
    }
    
    // Handle the case where filter is specified with backtick
    // Format: cmd ~ width ~ height [ ~ colOffset [ ~ rowOffset ]] [`filter]
    let filterPart = '';
    const lastPart = parts[parts.length - 1];
    if (lastPart && lastPart.includes('`')) {
        // Extract filter from last part
        const backTickIndex = lastPart.indexOf('`');
        filterPart = lastPart.substring(backTickIndex + 1);
        parts[parts.length - 1] = lastPart.substring(0, backTickIndex);
    }
    
    // Parse parts: cmd~width~height[~colOffset[~rowOffset]]
    const cmd = parts[0]; // cmd
    // width/height default to 1 (spec) when omitted
    let xSize = 1;
    let ySize = 1;
    if (parts.length > 1 && parts[1] !== '' && !isNaN(parseFloat(parts[1]))) {
        xSize = parseFloat(parts[1]);
    }
    if (parts.length > 2 && parts[2] !== '' && !isNaN(parseFloat(parts[2]))) {
        ySize = parseFloat(parts[2]);
    }
    const xOffset = parts.length > 3 && parts[3] !== '' ? parseFloat(parts[3]) : undefined;
    const yOffset = parts.length > 4 && parts[4] !== '' ? parseFloat(parts[4]) : undefined;
    
    // Create touchZone object
    const touchZoneObject = {
        type: "touchZone",
        xSize: xSize,
        ySize: ySize,
        cmd: cmd,
        idx: idx
    };
    
    // Add offsets if they exist
    if (xOffset !== undefined) {
        touchZoneObject.xOffset = xOffset;
    }
    if (yOffset !== undefined) {
        touchZoneObject.yOffset = yOffset;
    }
    
    // Add filter if specified
    if (filterPart !== '') {
        touchZoneObject.filter = parseInt(filterPart);
    }
    
    // Add centered property if it's a centered touchZone
    if (touchZoneType === 'xc') {
        touchZoneObject.centered = "true";
    }
    
    return touchZoneObject;
}

function translateRawInsertDwg(rawInsertDwgString) {
    // Check if this is an insertDwg item
    if (!rawInsertDwgString.startsWith('|d')) {
        throw new Error('Invalid insertDwg format: must start with |d');
    }
    
    // Remove the |d prefix
    const content = rawInsertDwgString.substring(2);
    
    // InsertDwg format: |d ~ loadcmd ~ ~ colOffset ~ rowOffset
    // Note: there's an empty field between loadcmd and colOffset
    if (!content.startsWith('~')) {
        throw new Error('Invalid insertDwg format: must start with ~ after |d');
    }
    
    // Split by ~ and remove empty first element
    const parts = content.split('~').slice(1);
    
    if (parts.length !== 4) {
        throw new Error('Invalid insertDwg format: must have exactly 4 parameters (loadcmd, empty, colOffset, rowOffset)');
    }
    
    // Parse parts: loadcmd ~ ~ colOffset ~ rowOffset
    const drawingName = parts[0]; // loadcmd (drawing name)
    // parts[1] is empty (intentional gap in format)
    const xOffset = parts[2] === '' ? 0 : parseFloat(parts[2]); // colOffset
    const yOffset = parts[3] === '' ? 0 : parseFloat(parts[3]); // rowOffset
    
    // Create insertDwg object
    const insertDwgObject = {
        type: "insertDwg",
        drawingName: drawingName,
        cmd: drawingName,
        cmdName: drawingName,
        xOffset: xOffset,
        yOffset: yOffset
    };
    
    return insertDwgObject;
}

function translateRawTouchActionInput(rawTouchActionInputString) {
    // Check if this is a touchActionInput item
    if (!rawTouchActionInputString.startsWith('|XI')) {
        throw new Error('Invalid touchActionInput format: must start with |XI');
    }
    
    // Remove the |XI prefix
    const content = rawTouchActionInputString.substring(3);
    
    // TouchActionInput format: |XI ~ cmd ~ prompt [`idxOfTextItem]
    if (!content.startsWith('~')) {
        throw new Error('Invalid touchActionInput format: must start with ~ after |XI');
    }
    
    // Split by ~ to get cmd and prompt, then handle backtick separation for textIdx
    const parts = content.split('~').slice(1); // Remove empty first element
    
    if (parts.length < 2) {
        throw new Error('Invalid touchActionInput format: must have at least cmd and prompt');
    }
    
    const cmd = parts[0];
    const promptWithIdx = parts[1]; // This may contain `textIdx at the end
    
    // Check if textIdx is specified (contains `)
    let prompt = promptWithIdx;
    let textIdx = undefined;
    
    if (promptWithIdx.includes('`')) {
        const backTickIndex = promptWithIdx.lastIndexOf('`');
        prompt = promptWithIdx.substring(0, backTickIndex);
        textIdx = parseInt(promptWithIdx.substring(backTickIndex + 1));
    }
    
    // Parse HTML-style formatting tags from prompt.
    //
    // Only <bg N> is extracted here because it controls the dialog title's *element*
    // background — it cannot be rendered inline as a text span.  All other format tags
    // (<b>, <i>, <u>, <+N>, <-N>, <colorCode>, <bw>) are intentionally left in the
    // prompt text and are parsed inline by pfodSetFormattedText() when the dialog
    // renders the prompt, so embedded tags like "A <+3>Large Text" produce mixed-size
    // text rather than re-sizing the whole prompt.
    function parsePromptFormatting(text) {
        const result = {
            text: text,
            backgroundColor: undefined
        };

        const bgColorMatch = text.match(/<bg\s+([0-9A-Fa-f]+)>/);
        if (bgColorMatch) {
            result.backgroundColor = parseDwgColour(bgColorMatch[1]);
            result.text = result.text.replace(/<bg\s+[0-9A-Fa-f]+>/g, '').replace(/<\\bg\s+[0-9A-Fa-f]+>/g, '');
        }

        return result;
    }

    const promptInfo = parsePromptFormatting(prompt);

    // Create touchActionInput object
    const touchActionInputObject = {
        type: "touchActionInput",
        cmd: cmd,
        prompt: promptInfo.text
    };

    // Add textIdx if specified
    if (textIdx !== undefined) {
        touchActionInputObject.textIdx = textIdx;
    }

    if (promptInfo.backgroundColor !== undefined) {
        touchActionInputObject.backgroundColor = promptInfo.backgroundColor;
    }

    return touchActionInputObject;
}

function translateRawTouchAction(rawTouchActionString) {
    // Check if this is a touchAction item
    if (!rawTouchActionString.startsWith('|X')) {
        throw new Error('Invalid touchAction format: must start with |X');
    }
    
    // Remove the |X prefix
    const content = rawTouchActionString.substring(2);
    
    // TouchAction format: |X ~ cmd ~ DrawingPrimitive
    if (!content.startsWith('~')) {
        throw new Error('Invalid touchAction format: must start with ~ after |X');
    }
    
    // Split by ~ and get cmd and the rest
    const firstTildeIndex = content.indexOf('~');
    const secondTildeIndex = content.indexOf('~', firstTildeIndex + 1);
    
    if (secondTildeIndex === -1) {
        throw new Error('Invalid touchAction format: must have cmd and primitive');
    }
    
    const cmd = content.substring(1, secondTildeIndex); // Extract cmd between first ~ and second ~
    const primitiveRaw = '|' + content.substring(secondTildeIndex + 1); // Reconstruct primitive with | prefix
    
    // Use existing translators to parse the drawing primitive
    let drawingPrimitive;
    
    try {
        // Remove the idx from the primitive if it exists, since touchAction primitives don't use idx
        let cleanPrimitiveRaw = primitiveRaw;        
        drawingPrimitive = translateRawItem(cleanPrimitiveRaw,true); // true if touchAction else default false
                
    } catch (error) {
        throw new Error(`Failed to parse touchAction primitive: ${error.message}`);
    }
    
    // Create touchAction object
    const touchActionObject = {
        type: "touchAction",
        cmd: cmd,
        action: [drawingPrimitive]
    };
    
    return touchActionObject;
}

function translateRawItem(rawItemString, isTouchAction = false) {
    // Determine the item type and call appropriate function
    if (rawItemString.startsWith('|l')) {
        return translateRawLine(rawItemString,isTouchAction);
    } else if (rawItemString.startsWith('|r') || rawItemString.startsWith('|R')) {
        return translateRawRectangle(rawItemString,isTouchAction);
    } else if (rawItemString.startsWith('|c') || rawItemString.startsWith('|C')) {
        return translateRawCircle(rawItemString,isTouchAction);
    } else if (rawItemString.startsWith('|a') || rawItemString.startsWith('|A')) {
        return translateRawArc(rawItemString,isTouchAction);
    } else if (rawItemString.startsWith('|t')) {
        return translateRawText(rawItemString,isTouchAction);
    } else if (rawItemString.startsWith('|v')) {
        return translateRawValue(rawItemString,isTouchAction);
// check these first        
    } else if (rawItemString.startsWith('|uhd')) {
        return translateRawUnhideDwg(rawItemString,isTouchAction);
    } else if (rawItemString.startsWith('|hd')) {
        return translateRawHideDwg(rawItemString,isTouchAction);
    } else if (rawItemString.startsWith('|ed')) {
        return translateRawEraseDwg(rawItemString);
// then check these        
    } else if (rawItemString.startsWith('|uh')) {
        return translateRawUnhide(rawItemString,isTouchAction);
    } else if (rawItemString.startsWith('|h')) {
        return translateRawHide(rawItemString,isTouchAction);
    } else if (rawItemString.startsWith('|e')) {
        return translateRawErase(rawItemString);

        
    } else if (rawItemString.startsWith('|z')) {
        return translateRawZero(rawItemString);
    } else if (rawItemString.startsWith('|xc') || rawItemString.startsWith('|x')) {
        return translateRawTouchZone(rawItemString);
    } else if (rawItemString.startsWith('|i')) {
        return translateRawIndex(rawItemString);
    } else if (rawItemString.startsWith('|d')) {
        return translateRawInsertDwg(rawItemString);
    } else if (rawItemString.startsWith('|XI')) {
        return translateRawTouchActionInput(rawItemString);
    } else if (rawItemString.startsWith('|X')) {
        return translateRawTouchAction(rawItemString);
    } else {
        throw new Error('Unknown item type: must start with |l (line), |r/|R (rectangle), |c/|C (circle), |a/|A (arc), |t (text), |v (value), |h (hide), |uh (unhide), |z (push/pop), |x/|xc (touchZone), |e (erase), |i (index), |d (insertDwg), |XI (touchActionInput), or |X (touchAction)');
    }
}


// returns null no not match else returns either start or update with empty itmes
function translateDwgResponse(cmd) {
  let cmdString = cmd.shift();
  if (!cmdString || typeof cmdString !== 'string' || !cmdString.startsWith("{+")) {
      console.error(`Error translating dwg response : "${cmdString}"`);
      const result = {
         error: 'msgType_invalid',
         message: `Expected dwg but received "${cmdString}"`,
         pfodDrawing: 'error'
       };
      return result;
  }
    cmdString.trim();
    
    const updatePattern = /^\{\+(~(m)?)?$/;
    const matchUpdate = cmdString.match(updatePattern);
    if (matchUpdate) {
        return {
            pfodDrawing: "update",
            js_ver: window.JS_VERSION,
            more: matchUpdate[2] === 'm' ? true : false,
            raw_items: []
        };
    }
    // else
    // colorNo accepts a decimal palette index or a 6-char RRGGBB hex string (spec 8.11),
    // or is empty — "{+`<cols>`<rows>..." — meaning no colour was specified,
    // the same "unspecified" form parseDwgColour already reads for item
    // colours and dwgWireEncoder.js's _colour() emits for BLACK_WHITE.
    // Falls through to the same `colorNo ? ... : 0` default an entirely
    // absent header group gets, below.
    const regex = /^\{\+(?:([0-9A-Fa-f]*)`(\d+)`(\d+))?(~(m)?)?(`?(\d+)?~(.*))?$/;
    const match = cmdString.match(regex);

    if (!match) {
        console.error(`Error match failed for dwg response : "${cmdString}"`);
         const result = {
         error: 'dwg_invalid',
         message: `Expected dwg response but received "${cmdString}"`,
         pfodDrawing: 'error'
       };
      return result;
    }

    const [, colorNo, cols, rows, , more, , refreshMs, version] = match;

    return {
        pfodDrawing: "start",
        js_ver: window.JS_VERSION,
        version: version || "",
        x: cols ? parseInt(cols, 10) : undefined,
        y: rows ? parseInt(rows, 10) : undefined,
        color: colorNo ? parseDwgColour(colorNo) : 0,
        refresh: refreshMs ? parseInt(refreshMs, 10) : 0,
        more: more === 'm',
        raw_items: []
    };
}

    
function translateRawItemsToItemArray(rawData) {
    console.log(`Called translateRawItemsToItemArray with `, JSON.stringify(rawData, null, 2));

    const result = {
        pfodDrawing: rawData.pfodDrawing,
        //js_ver: rawData.js_ver,  // rawData does not have js_ver
        js_ver: window.JS_VERSION,  // use pfodWeb.js version
        name: rawData.name,
        version: rawData.version,
        x: rawData.x,
        y: rawData.y,
        color: rawData.color,
        refresh: rawData.refresh,
        items: [],
        // Items that could not be parsed and were left out. Empty on every
        // healthy drawing; non-empty means the drawing on screen is missing
        // something — see the catch below.
        skipped: []
    };

    // Process each raw item
    // upto first }
    let skipRest = false;
    rawData.raw_items.forEach((rawItem, index) => {
        // stop when rawItem is "}" end of pfod cmd
        if (rawItem == '}') {
          if (!skipRest) {
           skipRest = true;
           console.log(`End of cmd "}" at line  ${index + 2}`);
          } else {
           console.log(`Skipping raw_items after "}",  ${index + 2}: "${rawItem}":`);
          }           
        } else {
         if (!skipRest) {
          // Ignore empty items.  A trailing '|' immediately before the closing
          // '}' (e.g. "...|C`41~12~1~~|}") splits into a lone "|" segment — a
          // pipe with no type char.  That is a valid/empty pfod item (pfodApp
          // tolerates it); treat it the same as a blank segment instead of
          // throwing "Unknown item type" and aborting the whole drawing.
          if (rawItem && rawItem.trim() !== '' && rawItem.trim() !== '|') {
            try {
                const translatedItem = translateRawItem(rawItem);
                result.items.push(translatedItem);
            } catch (itemError) {
                // SKIP the item, do not abandon the drawing.
                //
                // Rethrowing here meant one unparseable item cost the user
                // everything: a drawing whose wire message went over the
                // 1024-byte pfod cap is auto-closed mid-item by
                // connectionManager.processReadBuffer, that half item threw,
                // and a chart with 40 lines, labels and 6 plots rendered as
                // an empty canvas — with nothing on screen to say why.
                //
                // Dropping the tail is what the format doc already promises
                // for an over-long message; this makes that true. The item
                // is named in the console, and skipped[] carries the count
                // out for anything that wants to say so on screen.
                console.error(`Error translating raw_items at line ${index + 2}: "${rawItem}":`, itemError.message);
                result.skipped.push({ line: index + 2, raw: rawItem, reason: itemError.message });
            }
          }
         } else {
           console.log(`Skipping raw_items after "}",  ${index + 2}: "${rawItem}":`);
         }
        }
    });
    if (result.skipped.length > 0) {
        // One line the user can actually find, rather than N buried errors.
        // The commonest cause by far is the 1024-byte cap: an over-long
        // drawing arrives auto-closed part way through an item.
        console.error(`[DWG] "${result.name || result.version || 'drawing'}": ` +
            `${result.skipped.length} item(s) could not be read and were left out — ` +
            `the drawing is drawn without them. A wire message over 1024 bytes is ` +
            `cut at the cap, which breaks the item spanning the cut.`,
            result.skipped);
    }
    console.log(`Translated JSON:\n`, JSON.stringify(result,null,2));

    return result;
}

    // Browser environment
window.translateRawItemsToItemArray = translateRawItemsToItemArray;
/*   
   drawingDataProcessor.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Drawing Data Processor — parses incoming pfod JSON drawing responses and populates
// a DrawingManager with items, touchZones, touchActions, and metadata.
//
// Exports:    window.DrawingDataProcessor class, window.TouchZoneFilters constants
// Depends on: webTranslator.js (translateRawRectangle and other item translators),
//             DrawingManager (passed via DrawingViewer.redraw.redrawDrawingManager)
// Called by:  pfodWeb.js constructor (new window.DrawingDataProcessor(this)),
//             drawingProcessing.js processDrawingData (delegates to this.drawingDataProcessor)

// TouchZone filter constants
const TouchZoneFilters = {
    TOUCH: 0,           // Touches blocked if pfodApp busy waiting for response
    DOWN: 1,            // Queued if pfodApp busy waiting for response
    DRAG: 2,            // Queued if pfodApp busy waiting for response
    UP: 4,              // Queued if pfodApp busy waiting for response
    CLICK: 8,           // Queued if pfodApp busy waiting for response
    PRESS: 16,          // Long press - queued if pfodApp busy waiting for response
    ENTRY: 32,          // NEVER sent to pfodApp
    EXIT: 64,           // NEVER sent to pfodApp
    DOWN_DRAG_UP: 256,       // Msg not sent until finger removed (UP) but updates touchAction alias for DOWN_UP
    TOUCH_DISABLED: 512 // Capture touch to prevent scroll but do not send msg
};

// Decode method to convert filter numbers to array of filter names
TouchZoneFilters.decode = function(filterNumber) {
    // Handle TOUCH (value 0) first
    if (filterNumber === 0) {
        return ['TOUCH'];
    }
    
    // TOUCH_DISABLED has special handling - only return itself, no other values
    if (filterNumber === 512) {
        return ['TOUCH_DISABLED'];
    }
    
    const result = [];
    
    // Check each filter value (excluding TOUCH and TOUCH_DISABLED which are handled above)
    for (const [name, value] of Object.entries(TouchZoneFilters)) {
        if (name !== 'decode' && value !== 0 && value !== 512 && (filterNumber & value) === value) {
            result.push(name);
        }
    }
    
    return result;
};

/**
 * Walk drawingsData[].parentDrawing up to the top-level drawing that roots
 * `name`'s merged tree.  Inserted drawings carry their inserting drawing as
 * parentDrawing (DrawingManager.addInsertedDrawing); a drawing reached
 * straight off a menu item has parentDrawing null and is its own root.
 *
 * @param {Object} drawingManager  live DrawingManager
 * @param {string} name            drawing to resolve
 * @returns {string} the root drawing name (may be `name` itself)
 */
function findTreeRootDrawing(drawingManager, name) {
    let current = name;
    let parent = drawingManager.drawingsData[current]?.parentDrawing;
    while (parent) {
        current = parent;
        parent = drawingManager.drawingsData[current]?.parentDrawing;
    }
    return current;
}

/**
 * Find which drawing in the current tree holds an indexed item.
 *
 * An idx is unique across a whole merged drawing tree.  Its transform is
 * captured once — when the idx is first seen — and never changes afterwards;
 * only an erase removes the idx and its transform.  A response can arrive
 * routed to a drawing that does not hold the idx it carries: a touch reply is
 * routed to the drawing owning the touched zone, but the idx it updates may
 * live in an enclosing drawing.  Locating the real holder keeps the update on
 * the single item that idx refers to, so its captured transform stays put.
 *
 * The search is confined to `exceptDrawing`'s OWN tree.  drawingManager.drawings
 * also holds the roots of trees that are no longer displayed — a drawing reached
 * from an earlier menu item is only dropped when a touch switches to an unknown
 * drawing (the [TOUCH_REPLACEMENT] reset), so a plain menu-item change leaves the
 * previous root and its indexedItems registered.  Those idx spaces are entirely
 * separate: every tree numbers its own first indexed item 1, so a stale root
 * would otherwise be reported as the holder of an idx belonging to the drawing
 * now on screen and the item would be written into a collection nothing renders.
 *
 * @param {Object} drawingManager  live DrawingManager holding the per-drawing collections
 * @param {number} idx             index to locate (>= 1)
 * @param {string} exceptDrawing   drawing already known not to hold idx — skipped
 * @returns {string|null} name of the drawing whose indexedItems hold idx, or null if none do
 */
function findIndexOwnerDrawing(drawingManager, idx, exceptDrawing) {
    const treeRoot = findTreeRootDrawing(drawingManager, exceptDrawing);
    for (const name of drawingManager.drawings) {
        if (name === exceptDrawing) continue;
        if (findTreeRootDrawing(drawingManager, name) !== treeRoot) continue;
        const indexed = drawingManager.indexedItems[name];
        if (indexed && indexed[idx] !== undefined) {
            return name;
        }
    }
    return null;
}

// make all cmd: array
class DrawingDataProcessor {
    constructor(pfodWebInstance) {
        this.pfodWeb = pfodWebInstance;
    }
    
    isEmptyCmd(cmd) {
      if (!cmd) {
        return false
      }
      if (cmd.length < 2) {
        return false;
      }
      let cmd0 = cmd[0].trim();
      let cmd1 = cmd[1].trim();
      if ((cmd0 == '{') && (cmd1 == '}')){
        console.log(`[DRAWING_DATA] Received empty cmd response `);
        return true; // Successfully handled - no drawing data to process
      }
      return false;
    }
      
    // Main processing function for drawing data
    processDrawingData(data, drawingManager, savedData, requestType = 'unknown') {
        // Handle empty cmd responses (e.g., from touchZone requests)
        let cmd = data.cmd;
        if (cmd) {
          if (cmd.length < 2) {
            console.log(`[DRAWING_DATA] Received response with less than 2 elements of cmds (requestType: ${requestType})`);
            return; // Successfully handled - no drawing data to process
          }
          if (this.isEmptyCmd(cmd)) {
            console.log(`[DRAWING_DATA] Received empty cmd response - no action needed (requestType: ${requestType})`);
            // need to restore from touchaction
            return; // Successfully handled - no drawing data to process
          }            
          let msgType = cmd[0]; // take top on
          let result = null;
          if (msgType.startsWith("{+")) {
              result = window.translateDwgResponse(cmd);
              result.raw_items = cmd; // the rest of the commands are the raw_items for processing below
              result.name = data.name;
          }
          // Menu shapes ({,/{;}) never reach this path — they're routed to
          // handleNonDwgResponse → processMenuResponse (which calls pfodParseMenu)
          // by the dwg-vs-non-dwg classifier in requestQueue.processRequestQueue.
          // Only {+...} dwg responses arrive here.
          console.log(`[DRAWING_DATA] After tranlation::`, JSON.stringify(result, null, 2));

          // Merge translation output into the original data object rather
          // than reassigning the local variable.  Reassigning would make
          // subsequent writes (e.g. data._pendingInserts further down)
          // invisible to the caller, which still holds the original data
          // reference — Object.assign mutates in place so any later field
          // we set on `data` is visible in requestQueue.processRequestQueue
          // / processPendingResponses for the deferred-insertDwg drain.
          if (result) {
            Object.assign(data, result);
          }
        }
        // then continue to handle json version
         
        // need to handle {"cmd":["{+...", ... ]
        
        console.log(`Processing drawing data: ${data.pfodDrawing} command for ${data.name} (requestType: ${requestType})`);

        const drawingName = data.name;
        // Merged-update flag — set on 'update' responses whose items use the
        // menuDwg's merged idx/cmd space rather than a component drawing's
        // per-drawing-raw collections.  Only touch-style requests
        // (touch/drag/partialSlider) WITHOUT a source dwg take this path now
        // (e.g. touchActionInput submits).  Source-routed touch responses
        // (data._sourceDwgRouted, set in handleDwgResponse) are applied to
        // the source dwg's per-drawing-raw collections like a refresh update
        // and re-merged, so the new state survives later re-merges.
        // The four drawing-fetch types (menuItemDwg/insertDwg/refresh/
        // refresh-insertDwg) write to per-drawing-raw and re-merge.  'start'
        // commands are always per-drawing-raw — they replace a whole drawing
        // rather than patch the merged view.
        const isMergedUpdate =
            (data.pfodDrawing === 'update') &&
            (requestType === 'touch' || requestType === 'drag' || requestType === 'partialSlider') &&
            !data._sourceDwgRouted;
        
        // Check if this is a touch-triggered request that should replace a drawing
        // Only touch-triggered requests can cause complete drawing replacement when data.pfodDrawing === 'start'
        if (requestType === 'touch' && data.pfodDrawing === 'start') {
            console.log(`[TOUCH_REPLACEMENT] Touch request returned start response for "${drawingName}"`);
            
            // Check if drawingName matches any current drawing (main or inserted)
            const drawingIndex = drawingManager.drawings.indexOf(drawingName);
            
            if (drawingIndex >= 0) {
                // Drawing found in current drawings - completely replace that specific drawing
                console.log(`[TOUCH_REPLACEMENT] Found "${drawingName}" at index ${drawingIndex} - completely replacing it`);
                // The drawing data will be updated in the normal processing flow below
            } else {
                // Drawing not found - completely replace main drawing and clear all inserted drawings
                console.log(`[TOUCH_REPLACEMENT] "${drawingName}" not found in current drawings - completely starting fresh`);
                
                // Clear tracking + per-drawing/per-menuDwg cache entries
                // for every drawing in the old tree.  The touch caused the
                // device to switch to a brand-new drawing context, so the
                // old tree's cached state is no longer relevant — leaving
                // the localStorage entries behind would leak quota over
                // long sessions and resurrect stale state if a future
                // navigation happens to reuse one of these drawing names.
                const connId = (typeof getConnectionIdentifier === 'function')
                    ? getConnectionIdentifier(this.pfodWeb.connectionManager) : null;
                drawingManager.drawings.forEach(dwgName => {
                    this.pfodWeb.requestTracker.touchRequests.delete(dwgName);
                    this.pfodWeb.requestTracker.insertDwgRequests.delete(dwgName);
                    if (connId) {
                        localStorage.removeItem(`pfodWeb_dwg_${connId}_${dwgName}`);
                        localStorage.removeItem(`pfodWeb_menuDwg_${connId}_${dwgName}`);
                        console.log(`[TOUCH_REPLACEMENT] Cleared per-drawing + per-menuDwg cache for "${dwgName}" (conn=${connId})`);
                    }
                });
                
                // Wipe the live DrawingManager in place — caller passes the
                // viewer's redraw.redrawDrawingManager, which can't be replaced
                // by reassignment from inside this function.
                console.log(`[TOUCH_REPLACEMENT] Resetting DrawingManager in place`);
                drawingManager.reset();
                drawingManager.initialize(drawingName);

                // Update page title with new main drawing name
                document.title = `pfodWeb ${drawingName}`;

                console.log(`[TOUCH_REPLACEMENT] Started completely fresh with main drawing "${drawingName}"`);
            }
        }
        // Handle error responses first
        if (data.pfodDrawing === 'error') {
            console.log(`[ERROR] Drawing error received for "${drawingName}": ${data.error} - ${data.message}`);
            
            // If drawing not found, clear any saved version to prevent future requests with invalid version
            if (data.error === 'drawing_not_found') {
                console.log(`[ERROR] Clearing saved version for non-existent drawing "${drawingName}"`);
                localStorage.removeItem(`${drawingName}_version`);
                localStorage.removeItem(`${drawingName}_data`);
            }
            
            // Delegate to error handler
            this.pfodWeb.handleDrawingError(data);
            return;
        }
        
        // If this is a start command, initialize with new data
        if (data.pfodDrawing === 'start') {

            // A 'start' response must have a drawingName.  Without one,
            // setDrawingData would push null into drawings[] and corrupt
            // the refresh loop into sending '{null}' on every cycle.
            // This typically signals that a menu-refresh request
            // ({V1:.}) was answered with an unexpected drawing-start
            // payload — drop it rather than silently corrupting state.
            if (!drawingName) {
                console.error(`[DRAWING_DATA] 'start' response with null drawingName — dropping; data=`, JSON.stringify(data).slice(0, 300));
                return;
            }

            // Ensure x and y are within valid range (1-255)
            const x = Math.min(Math.max(data.x || 50, 1), 255);
            const y = Math.min(Math.max(data.y || 50, 1), 255);
        
            // Handle color validation - accept both numbers and string numbers
            let colorValue = data.color;
            if (typeof colorValue === 'string' && !isNaN(colorValue)) {
                console.log(`[COLOR_CONVERSION] Converting string color "${colorValue}" to number ${parseInt(colorValue)}`);
                colorValue = isNaN(parseInt(colorValue))? 0 : parseInt(colorValue);
            }
            const validColor = (typeof colorValue === 'number' && ((colorValue >= 0 && colorValue <= 255) || colorValue === -1)) ? colorValue : 0;
            console.log(`[COLOR_VALIDATION] Original color: ${data.color} (${typeof data.color}) -> Final color: ${validColor}`);

            const drawingData = {
                name: data.name,
                version: data.version,
                x: x,
                y: y,
                color: validColor, // Default to white (15) if invalid
                // Ensure refresh value is properly handled - 0 is a valid value
                refresh: data.refresh !== undefined ? data.refresh : 0
            };
            
            // Set the drawing data in the manager
            drawingManager.setDrawingData(drawingName, drawingData);

            // For touch/drag/partialSlider/unknown, error-log when the menu
            // item identified by the request cmd has no loadCmd — receiving a
            // drawing-shape response for a non-dwg menu item is a device error.
            if (requestType === 'touch' || requestType === 'drag'
             || requestType === 'partialSlider' || requestType === 'unknown') {
                const resolvedLoadCmd = this.pfodWeb._resolveLoadCmdFromRequest(
                    this.pfodWeb.sentRequest);
                if (!resolvedLoadCmd) {
                    console.error(`[QUEUE_MISMATCH] ${requestType} returned a {+ drawing-shape start but the menu item identified by the cmd has no loadCmd — drawingName="${drawingName}"`);
                }
            }

            // Stamp itemRefreshTimes — 'start' responses carry the refresh
            // field in drawingData.refresh.  rate>0 → Date.now(); rate==0 → null.
            this.pfodWeb.itemRefreshTimes.set(
                drawingName,
                drawingData.refresh > 0 ? Date.now() : null);

            console.log(`[REFRESH] Initialized drawing: ${data.name}, size=${x}x${y}, refresh=${drawingData.refresh}ms, version=${data.version}`);
            
            // 'start' replaces the drawing entirely.  Cascade-remove every
            // drawing whose parent is this one — they belonged to the prior
            // version of the drawing and the new version may not reference
            // them.  Iterate a snapshot since removal mutates dm.drawings.
            const childDrawings = drawingManager.drawings.filter(name =>
                drawingManager.drawingsData[name]?.parentDrawing === drawingName);
            for (const insertedDrawingName of childDrawings) {
                console.log(`Removing previously inserted drawing ${insertedDrawingName} as part of start command for ${drawingName}`);
                this.pfodWeb.removeInsertedDrawing(insertedDrawingName);
            }
            
            
            // Initialize or reset arrays for this drawing
            drawingManager.clearItems(drawingName);
            
        // Save the version and data - handle empty/blank/undefined versions
            // If version is undefined, empty or all blanks, set to empty string
            console.log(`[VERSION_DEBUG] Processing start data for ${data.name}:`, data);
            console.log(`[VERSION_DEBUG] data.version = "${data.version}", type = ${typeof data.version}`);
            // Per-drawing cache write happens at the end of this function
            // (after items have been processed into the per-drawing raw
            // collections), so the cache reflects the full populated state.
        }
       // If this is an update, apply changes to existing data
        else if (data.pfodDrawing === 'update') {
            let drawingData;

            if (isMergedUpdate) {
                // Build a virtual drawingData carrying the menuItemDwg's
                // bounds/color so the rest of the update path has
                // dimensions to work with.
                if (!drawingName) {
                  throw new Error('[MERGED_UPDATE] merged update needs an owner drawingName but got none — request must name the menuItemDwg whose merged collections receive the update');
                }
                const ownerForBounds = drawingName;
                console.log(`[MERGED_UPDATE] Getting merged data for ${requestType} update (owner=${ownerForBounds})`);
                drawingData = {
                    items: [], // Will be populated from update
                    x: drawingManager.drawingsData[ownerForBounds].data.x,
                    y: drawingManager.drawingsData[ownerForBounds].data.y,
                    color: drawingManager.drawingsData[ownerForBounds].data.color
                };
            } else {
                // Normal drawing request - get individual drawing data
                drawingData = drawingManager.getDrawingData(drawingName);
            }
            
            if (!drawingData) {
                // If we have saved data, try to use it
                if (savedData) {
                    console.log('No active drawing data, using saved data from localStorage');
                    drawingData = JSON.parse(savedData);
                
                    // Ensure saved data also respects the 1-255 limit
                    drawingData.x = Math.min(Math.max(drawingData.x, 1), 255);
                    drawingData.y = Math.min(Math.max(drawingData.y, 1), 255);
                    console.log(`Restored drawing from localStorage: ${drawingData.name}, size=${drawingData.x}x${drawingData.y}`);
                
                    // Set the loaded data in the manager
                    drawingManager.setDrawingData(drawingName, drawingData);
                } else {                
                    console.error('Received update without initial data');
                    throw new Error('Received update without initial data');
                }
            }  
            // Store original dimensions and color before processing update
            const originalX = drawingData.x;
            const originalY = drawingData.y;
            const originalColor = drawingData.color;
            const originalVer = drawingData.version;
            
            // Create updated drawing data
            const updatedData = { ...drawingData };
            
            // Update refresh interval if provided
            if (data.refresh !== undefined) {
                console.log(`[REFRESH] Updating refresh rate for ${drawingName}: ${updatedData.refresh}ms -> ${data.refresh}ms`);
                updatedData.refresh = data.refresh;
            }
            
            // Preserve dimensions and color
            console.log(`Preserving dimensions (${originalX}x${originalY}) and color (${originalColor}) from previous data`);
            updatedData.x = originalX;
            updatedData.y = originalY;
            updatedData.color = originalColor;
            
            // Handle version updates - preserve existing version if not provided
            console.log(`[VERSION_DEBUG] Processing update data for ${data.name}:`, data);
            console.log(`[VERSION_DEBUG] data.version = "${data.version}", type = ${typeof data.version}`);
            if (data.version !== undefined && data.version !== null) {
                const normalizedVersion = data.version.trim() ? data.version : '';
                console.log(`Updating version from "${originalVer}" to "${normalizedVersion}"`);
                updatedData.version = normalizedVersion;
            } else {
                console.log(`Version not provided in update - keeping existing version "${originalVer}"`);
                updatedData.version = originalVer;
            }
            
            if (isMergedUpdate) {
                // Items have been written straight into the menuDwg's merged
                // collections (allXXX[name]) above.  No individual-drawing
                // update or re-merge needed.
                console.log(`[MERGED_UPDATE] Updated menuDwg merged collections directly, no individual drawing updates, no merge needed`);
            } else {
                // Normal drawing request - update individual drawing data.
                // Per-drawing cache write fires at the end of this function
                // after all items are processed into the raw collections.
                drawingManager.setDrawingData(drawingName, updatedData);
            }

            // Stamp itemRefreshTimes — {+|... and {+} update bodies carry NO
            // refresh field, but DO count as "we got a response".  Use the
            // preserved rate (drawingsData[drawingName].data.refresh, set by
            // the prior 'start') so auto-refresh keeps ticking off the most
            // recent response.  rate>0 → Date.now(); rate==0 → null.
            //
            // For touch/drag/partialSlider, also error-log when the menu item
            // identified by the request cmd has no loadCmd — receiving a
            // drawing-shape response for a non-dwg menu item is a device error.
            if (drawingName) {
                if (requestType === 'touch' || requestType === 'drag'
                 || requestType === 'partialSlider' || requestType === 'unknown') {
                    const resolvedLoadCmd = this.pfodWeb._resolveLoadCmdFromRequest(
                        this.pfodWeb.sentRequest);
                    if (!resolvedLoadCmd) {
                        console.error(`[QUEUE_MISMATCH] ${requestType} returned a {+ drawing-shape update but the menu item identified by the cmd has no loadCmd — drawingName="${drawingName}"`);
                    }
                }
                const preservedRate = drawingManager.drawingsData[drawingName]?.data?.refresh || 0;
                this.pfodWeb.itemRefreshTimes.set(
                    drawingName,
                    preservedRate > 0 ? Date.now() : null);
            }
        }
        else {
           this.pfodWeb.handleDrawingError({
                  error: 'response_invalid',
                  message: `Response to load drawing "${drawingName}" returned neither start or update, returned ${data.pfodDrawing}`,
                  pfodDrawing: 'error'
            });
           return;
       }
       // end if start else update
        
        // Reset the transformation state based on command type
        // Initialize local transform stack
        let transformStack = [];
        let currentTransform; //

        // Set up local collection variables based on request type
        let targetIndexedItems, targetTouchZones, targetTouchActions, targetTouchActionInputs, targetUnindexedItems;

        if (isMergedUpdate) {
            // Merged-update writes go into the menuItemDwg's merged
            // collections (the allXXX[menuItemDwg] entries).  Per the
            // data model, every idx / loadCmd / touchZone cmd key in the
            // merged view is unique across the whole merged tree, so
            // partial updates apply cleanly without needing to know which
            // component drawing each item came from.  Owner = request
            // .drawingName (the menuItemDwg explicitly named on the
            // touch request) — REQUIRED, no fallback.
            if (!drawingName) {
                throw new Error('[drawingDataProcessor] merged update requires an owner drawingName (the menuItemDwg whose allXXX collections receive the merged write)');
            }
            const ownerDrawing = drawingName;
            // Lazy-init each allXXX entry for this menuDwg if the merger hasn't
            // run yet — the merged write must have something to land on.
            if (!drawingManager.allUnindexedItems[ownerDrawing])         drawingManager.allUnindexedItems[ownerDrawing]         = [];
            if (!drawingManager.allIndexedItemsByNumber[ownerDrawing])   drawingManager.allIndexedItemsByNumber[ownerDrawing]   = {};
            if (!drawingManager.allTouchZonesByCmd[ownerDrawing])        drawingManager.allTouchZonesByCmd[ownerDrawing]        = {};
            if (!drawingManager.allTouchActionsByCmd[ownerDrawing])      drawingManager.allTouchActionsByCmd[ownerDrawing]      = {};
            if (!drawingManager.allTouchActionInputsByCmd[ownerDrawing]) drawingManager.allTouchActionInputsByCmd[ownerDrawing] = {};

            console.log(`[MERGED_UPDATE] Routing merged writes to menuDwg "${ownerDrawing}" (requestType=${requestType})`);
            targetIndexedItems      = drawingManager.allIndexedItemsByNumber[ownerDrawing];
            targetTouchZones        = drawingManager.allTouchZonesByCmd[ownerDrawing];
            targetTouchActions      = drawingManager.allTouchActionsByCmd[ownerDrawing];
            targetTouchActionInputs = drawingManager.allTouchActionInputsByCmd[ownerDrawing];
            targetUnindexedItems    = drawingManager.allUnindexedItems[ownerDrawing];
        } else {
            // Normal request - use individual drawing collections
            console.log(`[NORMAL_UPDATE] Using individual drawing collections for drawing: ${drawingName}`);
            if (!drawingManager.unindexedItems[drawingName]) {
                throw new Error(`[drawingDataProcessor] drawing "${drawingName}" not initialized in drawingManager`);
            }
            targetIndexedItems = drawingManager.indexedItems[drawingName];
            targetTouchZones = drawingManager.touchZonesByCmd[drawingName];
            targetTouchActions = drawingManager.touchActionsByCmd[drawingName];
            targetTouchActionInputs = drawingManager.touchActionInputsByCmd[drawingName];
            targetUnindexedItems = drawingManager.unindexedItems[drawingName];
        }

        // Resolve the indexed-items collection that already holds an idx, or
        // null when the idx is genuinely new.  Checks this response's own
        // collection first, then the rest of the tree — see
        // findIndexOwnerDrawing for why a response can be routed to a drawing
        // that doesn't hold the idx it carries.  The merged idx space is a
        // single flat map, so it needs no tree-wide search.
        // Other drawings in the tree whose collections this response wrote to,
        // so their per-drawing caches are saved alongside this drawing's.
        const redirectedOwnerDwgs = new Set();
        const ownerIndexedItemsFor = (idx) => {
            if (targetIndexedItems[idx] !== undefined) return targetIndexedItems;
            if (isMergedUpdate) return null;
            const ownerDwg = findIndexOwnerDrawing(drawingManager, idx, drawingName);
            if (!ownerDwg) return null;
            console.error(`[INDEX_OWNER] idx=${idx} arrived on drawing "${drawingName}" but is held by "${ownerDwg}" - applying to "${ownerDwg}" so the transform captured when idx ${idx} was first seen is not duplicated or changed`);
            redirectedOwnerDwgs.add(ownerDwg);
            return drawingManager.indexedItems[ownerDwg];
        };

        // Set the initial transform
        if (data.pfodDrawing === 'start') {
            // For 'start' commands, reset to initial state
            currentTransform = { x: 0, y: 0, scale: 1.0 };
            console.log(`[TRANSFORM] Using initial transform (0,0,1.0) for drawing start: ${drawingName}`);
        } else if (data.pfodDrawing === 'update' && drawingManager.savedTransforms[drawingName]) {
            // For 'update' commands, use the saved transform if available
            currentTransform = {...drawingManager.savedTransforms[drawingName]};
            console.log(`[TRANSFORM] Using saved transform for update: x=${currentTransform.x}, y=${currentTransform.y}, scale=${currentTransform.scale}`);
        } else {
            // Default fallback
            currentTransform = { x: 0, y: 0, scale: 1.0 };
            console.log(`[TRANSFORM] No saved transform found, using default (0,0,1.0)`);
        }
                
        // Process drawing items if they exist (either items or raw_items)
        let itemsToProcess = [];
        
        if (data.raw_items && Array.isArray(data.raw_items)) {
            console.log(`Processing ${data.raw_items.length} raw drawing items - translating to items format`);
            // Translate raw_items to items format using translator
            try {
                const translatedData = window.translateRawItemsToItemArray(data);
                itemsToProcess = translatedData.items;
                console.log(`Successfully translated ${data.raw_items.length} raw items to ${itemsToProcess.length} processed items`);
                // TEMP DEBUG: dump the fully-parsed dwg JSON for Dwg Controls
                // Panel previews (DWG_PREVIEW_KEY_PREFIX-namespaced names
                // only, to avoid spamming every real menu/drawing response)
                // so it can be diffed against the original DwgLibrary dwg
                // JSON that dwgWireEncoder.js encoded from.
                if (window.DWG_PREVIEW_KEY_PREFIX && data.name && data.name.startsWith(window.DWG_PREVIEW_KEY_PREFIX)) {
                    console.log('[DWG_PREVIEW_DEBUG] parsed dwg for "' + data.name + '":',
                        JSON.stringify({
                            pfodDrawing: data.pfodDrawing, name: data.name, version: data.version,
                            x: data.x, y: data.y, color: data.color, refresh: data.refresh,
                            items: itemsToProcess
                        }, null, 2));
                }
            } catch (error) {
                console.error('Failed to translate raw_items:', error.message);
                throw new Error(`Failed to translate raw_items: ${error.message}`);
            }
        } else if (data.items && Array.isArray(data.items)) {
            console.log(`Processing ${data.items.length} drawing items`);
            itemsToProcess = data.items;
        }
        
        if (itemsToProcess.length > 0) {
            
            // For update commands, if items array is empty, don't process anything (no changes)
            // but still need to redraw to show the restored state
            if (data.pfodDrawing === 'update' && itemsToProcess.length === 0) {
                console.log(`Update command has empty items array - no changes to apply, but triggering redraw`);
                // Still need to trigger redraw and continue with normal flow
            }
            

            itemsToProcess.forEach(item => {
            // Validate and normalize item color to integer (0-255) or RRGGBB hex string
            if (item.color !== undefined) {
                let colorValue = item.color;

                if (typeof colorValue === 'string' && /^[0-9A-Fa-f]{6}$/.test(colorValue)) {
                    // RRGGBB hex color (spec 8.11) - keep as-is
                    item.color = colorValue.toUpperCase();
                } else {
// Handle string numbers (like "9", "82" from ESP32)
                if (typeof colorValue === 'string' && !isNaN(colorValue)) {
                  console.log(`[COLOR_CONVERSION] Converting string color "${colorValue}" to number ${parseInt(colorValue)}`);
                  colorValue = isNaN(parseInt(colorValue))? 0 : parseInt(colorValue);
                }

                if (typeof colorValue === 'number' && ((colorValue >= 0 && colorValue <= 255) || colorValue === -1)) {
                    item.color = Math.floor(colorValue); // Ensure integer (-1 for Black/White mode, 0-255 for regular colors)
                } else {
                    item.color = 0; // Default to black for invalid colors
                }
                }
            }
            
            // Add a processing flag to each item (assume valid by default)
            let skipProcessing = false;
                
            // Validate item
            if (!item.type) {
                console.error('Item missing type property:', item);
                skipProcessing = true;
            }
                
            // Debug log for each item
            console.log(`Processing item: type=${item.type}, properties:`, JSON.stringify(item));
            // Check if hide, unhide, or erase has valid idx or cmd
            if ((item.type === 'hide' || item.type === 'unhide' || item.type === 'erase')) {
                // For erase, allow either idx or cmd
                    if (!item.idx && !item.cmd) {
                        console.error(`Error: ${item.type} item has neither idx nor cmd, ignoring item:`, JSON.stringify(item));
                        skipProcessing = true;
                    } else if (item.idx && (item.idx < 1)) {
                        console.error(`Error: ${item.type} item has idx < 1, ignoring item:`, JSON.stringify(item));
                        skipProcessing = true;
                    }
            }
            
            // Handle push and pop first to maintain transformation state (all local)
                
            // Store a copy of the current transform with the item
            item.transform = {...currentTransform};
            // Set visible property to true by default
            if (item.visible === undefined) {
                item.visible = true;
            }

                
                if (item.type === 'pushZero') {
                // Save current transform to stack
                transformStack.push({...currentTransform});
                    
                 // Default missing properties
                 const x = item.x !== undefined ? parseFloat(item.x) : 0;
                 const y = item.y !== undefined ? parseFloat(item.y) : 0;
                 const scale = item.scale !== undefined ? parseFloat(item.scale) : 1.0;
                    
                 // Apply the push transform to current transform
                 currentTransform.x += x * currentTransform.scale;
                 currentTransform.y += y * currentTransform.scale;
                 currentTransform.scale *= scale;
                    
                 console.log(`[TRANSFORM] Push for ${drawingName}: New transform (${currentTransform.x}, ${currentTransform.y}, ${currentTransform.scale})`);
                    
                 // Skip adding push items to any collection
                 skipProcessing = true;
                 } else if (item.type === 'popZero') {
                 // Get previous transform from stack
                 if (transformStack.length > 0) {
                     const oldTransform = {...currentTransform};
                     currentTransform = transformStack.pop();
                     console.log(`[TRANSFORM] Pop for ${drawingName}: Restored from (${oldTransform.x}, ${oldTransform.y}, ${oldTransform.scale}) to (${currentTransform.x}, ${currentTransform.y}, ${currentTransform.scale})`);
                 } else {
                     // If stack is empty, reset to initial state
                     const oldTransform = {...currentTransform};
                     currentTransform = { x: 0, y: 0, scale: 1.0 };
                     console.warn(`[TRANSFORM] Pop for ${drawingName}: Stack empty, reset to default (0,0,1.0)`);
                 }
                    
                 // Skip adding pop items to any collection
                 skipProcessing = true;
             } // end push pop
                
             // Apply default values based on item type
             if (item.type === 'rectangle') {
                 // Default missing properties
                 item.xOffset = item.xOffset !== undefined ? item.xOffset : 0;
                 item.yOffset = item.yOffset !== undefined ? item.yOffset : 0;
                 item.xSize = item.xSize !== undefined ? item.xSize : 1;
                 item.ySize = item.ySize !== undefined ? item.ySize : 1;
                 item.filled = item.filled === 'true' || item.filled === true;
                 item.rounded = item.rounded === 'true' || item.rounded === true;
                 console.log('Processed rectangle with defaults:', JSON.stringify(item));
                
            } else if (item.type === 'line') {
                // Default missing properties
                item.xOffset = item.xOffset !== undefined ? item.xOffset : 0;
                item.yOffset = item.yOffset !== undefined ? item.yOffset : 0;
                item.xSize = item.xSize !== undefined ? item.xSize : 1;
                item.ySize = item.ySize !== undefined ? item.ySize : 1;
                console.log('Processed line with defaults:', JSON.stringify(item));
                
            } else if (item.type === 'insertDwg' ) { //|| item.type.toLowerCase() === 'insertdwg') {
                // Always ensure insertDwg items have null index - they should NEVER be indexed
                if (item.idx && item.idx !== 'null') {
                    console.warn(`Warning: insertDwg item for "${item.drawingName}" has idx=${item.idx}, nulling it as insertDwg should never be indexed`);
                    item.idx = 'null';
                }                
                // Normalize the type to insertDwg for consistency
                item.type = 'insertDwg';
                
            } else if (item.type === 'touchZone') {
                // Default missing properties
                item.xOffset = item.xOffset !== undefined ? item.xOffset : 0;
                item.yOffset = item.yOffset !== undefined ? item.yOffset : 0;
                item.xSize = item.xSize !== undefined ? item.xSize : 1;
                item.ySize = item.ySize !== undefined ? item.ySize : 1;
                item.filter = item.filter !== undefined ? parseInt(item.filter) : TouchZoneFilters.TOUCH;
                item.centered = item.centered !== undefined ? item.centered : 'false';
                // idx is handled in the touchZone processing logic below, not here
                if (!item.cmd || item.cmd.trim().length === 0) {
                    throw new Error(`[drawingDataProcessor] touchZone has empty or missing cmd in drawing "${data.name}": ${JSON.stringify(item)}`);
                }
                console.log('Processed touchZone with defaults:', JSON.stringify(item));
                
            } else if (item.type === 'touchAction') {
                // Default missing properties
                item.action = item.action !== undefined ? item.action : [];

                if (!item.cmd || item.cmd.trim().length === 0) {
                    throw new Error(`[drawingDataProcessor] touchAction has empty or missing cmd in drawing "${data.name}": ${JSON.stringify(item)}`);
                }
                console.log('Processed touchAction with defaults:', JSON.stringify(item));
                
            } else if (item.type === 'label') {
                // Default missing properties for label
                item.xOffset = item.xOffset !== undefined ? item.xOffset : 0;
                item.yOffset = item.yOffset !== undefined ? item.yOffset : 0;
                item.text = item.text !== undefined ? item.text : '';
                item.fontSize = item.fontSize !== undefined ? item.fontSize : 0;
                item.bold = item.bold === 'true' || item.bold === true;
                item.italic = item.italic === 'true' || item.italic === true;
                item.underline = item.underline === 'true' || item.underline === true;
                item.align = item.align !== undefined ? item.align : 'left'; // default alignment when not specified
                // Handle new optional properties (value, units, decimals) - no defaults needed as they're optional
                if (item.value !== undefined && item.value !== null && item.value !== '') {
                    item.value = parseFloat(item.value);
                }
                if (item.decimals !== undefined && item.decimals !== null && item.decimals !== '') {
                    item.decimals = parseInt(item.decimals);
                }
                // item.units stays as-is (string) - no conversion needed
                console.log('Processed label with defaults:', JSON.stringify(item));
                
            } else if (item.type === 'value') {
                // Default missing properties for value
                item.xOffset = item.xOffset !== undefined ? item.xOffset : 0;
                item.yOffset = item.yOffset !== undefined ? item.yOffset : 0;
                item.text = item.text !== undefined ? item.text : '';
                item.fontSize = item.fontSize !== undefined ? item.fontSize : 0;
                item.bold = item.bold === 'true' || item.bold === true;
                item.italic = item.italic === 'true' || item.italic === true;
                item.underline = item.underline === 'true' || item.underline === true;
                item.align = item.align !== undefined ? item.align : 'left'; // default alignment when not specified
                item.intValue = item.intValue !== undefined ? item.intValue : 0;
                item.max = item.max !== undefined ? item.max : 1;
                item.min = item.min !== undefined ? item.min : 0;
                item.displayMax = item.displayMax !== undefined ? item.displayMax : 1.0;
                item.displayMin = item.displayMin !== undefined ? item.displayMin : 0.0;
                item.decimals = (item.decimals !== undefined && item.decimals !== null && item.decimals !== '') ? parseInt(item.decimals) : 2;
                item.units = item.units !== undefined ? item.units : '';
                console.log('Processed value with defaults:', JSON.stringify(item));
                
            } else if (item.type === 'circle') {
                // Default missing properties for circle
                item.xOffset = item.xOffset !== undefined ? item.xOffset : 0;
                item.yOffset = item.yOffset !== undefined ? item.yOffset : 0;
                item.radius = item.radius !== undefined ? item.radius : 1;
                item.filled = item.filled === 'true' || item.filled === true;
                console.log('Processed circle with defaults:', JSON.stringify(item));
                
            } else if (item.type === 'arc') {
                // Default missing properties for arc
                item.xOffset = item.xOffset !== undefined ? item.xOffset : 0;
                item.yOffset = item.yOffset !== undefined ? item.yOffset : 0;
                item.radius = item.radius !== undefined ? item.radius : 1;
                item.filled = item.filled === 'true' || item.filled === true;
                item.start = item.start !== undefined ? item.start : 0;
                item.angle = item.angle !== undefined ? item.angle : 90;
                
                // Normalize start and angle to be within -360 to +360 range
                item.start = item.start % 360;
                if (item.start > 360) item.start -= 360;
                if (item.start < -360) item.start += 360;
                
                item.angle = item.angle % 360;
                if (item.angle > 360) item.angle -= 360;
                if (item.angle < -360) item.angle += 360;
                
                console.log('Processed arc with defaults:', JSON.stringify(item));
                
            } else if (item.type === 'index') {
                // Check if idx is less than 1 (invalid)
                if (item.idx < 1) {
                    console.error('Error: Index item has idx < 1, ignoring item:', JSON.stringify(item));
                    skipProcessing = true; // Flag to skip adding this item to collections
                } else {
                    const idx = item.idx;
                    if (ownerIndexedItemsFor(idx)) {
                      console.log(`Processing index item with idx=${item.idx} - already have item with that idx so skip processing this`);
                      skipProcessing = true; // Flag to skip adding this item to collections
                    } else {
                      // For valid index items, save transform data
                      console.log(`Processing index item with idx=${item.idx} - saving transform/clipping data for later use`);
                    }
                }
                // Handle index items with cmdName (touchZone items)  
                if (item.cmdName && item.cmdName.trim() !== '') {
                    const cmd = item.cmd || '';
                    if (cmd.trim().length > 0) {
                        // Check if there's already a touchZone with this cmd
                        const existingTouchZone = drawingManager.touchZonesByCmd[drawingName] && 
                                                drawingManager.touchZonesByCmd[drawingName][cmd];
                        if (existingTouchZone) {
                            console.log(`Processing index item with cmdName="${item.cmdName}" cmd="${cmd}" - already exists, skipping`);
                            skipProcessing = true;
                        } else {
                            console.log(`Processing index item with cmdName="${item.cmdName}" cmd="${cmd}" - will be added as touchZone placeholder`);
                        }
                    }
                }
            } // end not hide / unhide / erase
            
            // Process control items (hide, unhide, erase, push, pop) BEFORE checking skipProcessing
            // These should always be processed but never added to item collections
            if (item.type === 'hide' || item.type === 'unhide' || item.type === 'erase') {
                
                if (item.type === 'erase') {
                    // For erase items, handle both idx and cmd
                    if (item.idx) {
                        // Erase by index — the only operation that removes an
                        // indexed item and its captured transform.
                        const idx = item.idx;
                        const indexedItems = ownerIndexedItemsFor(idx);

                        if (indexedItems) {
                            delete indexedItems[idx];
                            console.log(`Erased item with index ${idx}`);
                        } else {
                            console.warn(`Erase operation: No item found with idx=${idx} to erase`);
                        }
                    } else if (item.cmd) {
                        if (item.drawingName !== undefined) {
                         drawingManager.eraseByCmd(drawingName, item.cmd, item.drawingName);
                         console.log(`Erased insertDwg and actions with cmd="${item.cmd}"`);
                       } else {
                        // Erase by cmd - removes touchZone and all associated actions
                        drawingManager.eraseByCmd(drawingName, item.cmd);
                        console.log(`Erased touchZone and actions with cmd="${item.cmd}"`);
                       }
                    }
                    // Skip adding erase items to any collection
                    skipProcessing = true;
                } else {
                    // For hide/unhide, handle both idx and cmd
                    if (item.idx) {
                        // Hide/unhide by index - affects indexed items only (ignore touchZones)
                        const idx = item.idx;
                        const indexedItems = ownerIndexedItemsFor(idx);
                        const targetItem = indexedItems ? indexedItems[idx] : undefined;

                        if (targetItem) {
                            // Set the visible property based on hide/unhide type
                            targetItem.visible = item.type === 'unhide';
                            console.log(`${item.type === 'unhide' ? 'Unhiding' : 'Hiding'} item with index ${idx}`);
                        } else {
                            console.warn(`${item.type} operation: No item found with idx=${idx} to ${item.type === 'unhide' ? 'unhide' : 'hide'}`);
                        }
                    } else if (item.cmd) {
                        // Hide/unhide by cmd - affects touchZones and insertDwg items only
                        if (item.type === 'hide') {
                            if (item.drawingName !== undefined) {
                            drawingManager.hideByCmd(drawingName, item.cmd,item.drawingName);
                            console.log(`Hidden touchZone and insertDwg items with cmd="${item.cmd}"`);
                            } else {
                            drawingManager.hideByCmd(drawingName, item.cmd);
                            console.log(`Hidden touchZone and insertDwg items with cmd="${item.cmd}"`);
                            }
                        } else if (item.type === 'unhide') {
                            if (item.drawingName !== undefined) {
                            drawingManager.unhideByCmd(drawingName, item.cmd,item.drawingName);
                            console.log(`Unhidden touchZone and insertDwg items with cmd="${item.cmd}"`);
                            } else {
                            drawingManager.unhideByCmd(drawingName, item.cmd);
                            console.log(`Unhidden touchZone and insertDwg items with cmd="${item.cmd}"`);
                            }
                        }
                    }
                    // Skip adding hide/unhide items to any collection
                    skipProcessing = true;
                }
            }
                
           // Only proceed with normal item processing if not already marked to skip
           if (!skipProcessing) {
              // The drawing this item belongs to is data.name — the drawing
              // whose response we are processing.  insertDwg items in
              // particular store their entry on this drawing's unindexed
              // items list (the parent), not on the inserted target drawing.
              const itemDrawingName = data.name;
              item.parentDrawingName = itemDrawingName;
              drawingManager.ensureItemCollections(itemDrawingName);

              // Special handling for insertDwg items
              if (item.type === 'insertDwg') { // || (item.type && item.type.toLowerCase() === 'insertdwg')) {
                    // For insertDwg items, we MUST use the current drawing name
                    // NOT the drawingName specified in the item (which is the target drawing to insert)
                    const currentDrawing = data.name;
                    
                    // Ensure the collections exist for the current drawing
                    drawingManager.ensureItemCollections(currentDrawing);
                    
                    // Normalize type to camelCase for consistency
                    item.type = 'insertDwg';                    
                                        
                    // Add to the current drawing's unindexed items
                    targetUnindexedItems.push(item);
                    console.log(`Added insertDwg item for "${item.drawingName}" with transform (${item.transform.x},${item.transform.y},${item.transform.scale}) to drawing=${currentDrawing}, visible=${item.visible}`);
              // Check if this is a touchZone or index item with cmdName
              } else if (item.type === 'touchZone' || (item.type === 'index' && item.cmdName && item.cmdName.trim() !== '')) {
                    // Only process filter for actual touchZone items, not index items
                    if (item.type === 'touchZone') {
                        // Check if there's an associated touchActionInput for this cmd
                        if (item.cmd && item.cmd.trim().length > 0) {
                            const existingTouchActionInput = targetTouchActionInputs[item.cmd];
                            if (existingTouchActionInput) {
                                // If touchActionInput exists, filter can only be TOUCH or TOUCH_DISABLED
                                if (item.filter !== TouchZoneFilters.TOUCH && item.filter !== TouchZoneFilters.TOUCH_DISABLED) {
                                    console.log(`[TOUCH_ZONE] Constraining updated touchZone filter from ${item.filter} to TOUCH for cmd=${item.cmd} due to existing touchActionInput`);
                                    item.filter = TouchZoneFilters.TOUCH;
                                }
                            }
                        }
                    }
                    
                    // Add the touchZone to the target collection.
                    // If a touchZone with this cmd already exists, carry over its transform,
                    // parentDrawingName and clipRegion — the incoming item has no pushZero context
                    // (touch updates never have it; regular {+ updates omit it when the full
                    // drawing was originally loaded with pushZero positioning).
                    const existingTZ = targetTouchZones[item.cmd];
                    if (existingTZ) {
                        item.transform = existingTZ.transform;
                        item.parentDrawingName = existingTZ.parentDrawingName;
                        item.clipRegion = existingTZ.clipRegion;
                    }
                    targetTouchZones[item.cmd] = item;
                    console.log(`Added touchZone: cmd=${item.cmd}, filter=${item.filter}, idx=${item.idx || 0}, drawing=${itemDrawingName}`);
                   // this.drawingManager.unindexedItems[itemDrawingName].push(item);
                   // console.log(`Added unindexed item: type=${item.type}, drawing=${itemDrawingName}, visible=${item.visible !== false}`);
                    
              // Check if this is a touchAction
              } else if (item.type === 'touchAction') {
                    // Add the touchAction to the target collection
                    // Initialize actions array if it doesn't exist for this cmd
                    if (!targetTouchActions[item.cmd]) {
                        targetTouchActions[item.cmd] = [];
                    }
                    // Append the action items to existing actions array instead of replacing
                    if (item.action && Array.isArray(item.action)) {
                        targetTouchActions[item.cmd].push(...item.action);
                    }
                    console.log(`Added touchAction: cmd=${item.cmd}, actions=${(item.action || []).length}, drawing=${itemDrawingName}`);
                    // touchActions are not added to unindexed/indexed items - they're stored separately
                    
              // Check if this is a touchActionInput
              } else if (item.type === 'touchActionInput') {
                    // Add the touchActionInput to the target collection
                    targetTouchActionInputs[item.cmd] = item;
                    console.log(`Added touchActionInput: cmd=${item.cmd}, prompt="${item.prompt}", textIdx=${item.textIdx}, drawing=${itemDrawingName}`);
                    // touchActionInputs are not added to unindexed/indexed items - they're stored separately
                    
              // Normal processing for other items
              } else if (item.idx && item.idx !== 'null') {
                  // For non-touchZone items, handle as regular indexed items.
                  // Write to whichever collection already holds this idx so the
                  // transform captured when the idx was first seen is reused
                  // unchanged; a genuinely new idx captures the transform here.
                  const idx = item.idx;
                  const ownerIndexedItems = ownerIndexedItemsFor(idx) || targetIndexedItems;
                  const existingItem = ownerIndexedItems[idx];
                  const isUpdate = existingItem !== undefined;
                  if (isUpdate) {
                   item.transform = existingItem.transform;
                   item.clipRegion = existingItem.clipRegion;
                   // Preserve visibility state from existing item
                   item.visible = existingItem.visible;
                   // The transform belongs to the drawing that captured it, so
                   // the item stays attributed to that drawing.
                   item.parentDrawingName = existingItem.parentDrawingName;
                  }

                  ownerIndexedItems[idx] = item;

                  console.log(`${isUpdate ? 'Updated' : 'Added'} indexed item: type=${item.type}, drawing=${item.parentDrawingName}, idx=${idx}, visible=${item.visible !== false}`);
              } else {
                  // Unindexed items
                  // For non-touchZone items, add to the drawing's unindexed items array
                  // Ensure the collections exist for the drawing before adding the item
                  // This is especially important for insertDwg items which refer to other drawings
                  // Add to target unindexed items collection
                  targetUnindexedItems.push(item);
                  console.log(`Added unindexed item: type=${item.type}, drawing=${itemDrawingName}, visible=${item.visible !== false}`);
               }
            } // if (!skipProcessing)
        });
        // Log summary of items
        console.log(`Drawing ${data.name} now has ${targetUnindexedItems.length} unindexed items, ${Object.keys(targetIndexedItems).length} indexed items,  ${Object.keys(targetTouchZones).length} touchZones`);
        if (targetUnindexedItems.length > 0) {
            console.log('Unindexed item types:', targetUnindexedItems.map(i => i.type).join(', '));
        }
        if (Object.keys(targetIndexedItems).length > 0) {
            console.log('Indexed item types:', Object.values(targetIndexedItems).map(i => i.type).join(', '));
        }
    } // if (data.items && Array.isArray(data.items))

    if (drawingName !== null) {
        console.log(`Set response status to TRUE for "${drawingName}"`);
        drawingManager.drawingResponseStatus[drawingName] = true;
    } else {
        console.log(`Skipping response status update for touchAction request (null drawingName)`);
    }
        
    // Check for insertDwg items and add them to the request queue
    console.log(`Scanning for insertDwg items in ${targetUnindexedItems.length} unindexed items of drawing ${data.name}`);
    // Debug: full dump of unindexed items array for this drawing
    console.log(`[DEBUG] Raw unindexed items array for ${data.name}:`, JSON.stringify(targetUnindexedItems));
    // Find insertDwg items in unindexed items
    const insertDwgItems = targetUnindexedItems.filter(item =>
        item.type && (
            //item.type.toLowerCase() === 'insertdwg' ||
            item.type === 'insertDwg'
        ));

        // Debugging detailed info about each unindexed item
    console.log(`[DEBUG] Detailed unindexed items for drawing ${data.name}:`);
    targetUnindexedItems.forEach((item, index) => {
        console.log(`- Item ${index}: type=${item.type}, drawingName=${item.drawingName || 'none'}, would match insertDwg filter: ${(item.type === 'insertDwg' || (item.type && item.type.toLowerCase() === 'insertdwg'))}`);
        // Print full item for better debugging
        console.log(`  Full item ${index}:`, JSON.stringify(item));
    });

    const indices = Object.keys(targetIndexedItems);
    indices.forEach(idx => {
        const itemWithIndex = targetIndexedItems[idx];
        const drawingSource = itemWithIndex.parentDrawingName || 'unknown';
        console.log(`[PROCESS_DATA] Drawing indexed item ${idx} of type ${itemWithIndex.type} from ${drawingSource}`);
        if (itemWithIndex.transform) {
            console.log(`[PROCESS_DATA] Indexed item transform: x=${itemWithIndex.transform.x}, y=${itemWithIndex.transform.y}, scale=${itemWithIndex.transform.scale}`);
        } else {
            console.log(`[PROCESS_DATA] Indexed item has no transform!`);
        }
    });
    
    let foundInsertDwgItems = false;

    // Collect THIS response's insertDwg items here — DO NOT call
    // handleInsertDwg inline.
    //
    // Calling handleInsertDwg → addToRequestQueue → processRequestQueue
    // synchronously while we're still mid-response-processing creates a
    // re-entrant path that can pull a child request from the queue and
    // assign it as a new sentRequest while the original response is still
    // being processed.  When the original response's COMPLETED handler
    // subsequently runs `this.sentRequest = null` it then clobbers the
    // child's reference and the queue gets stuck.
    //
    // Stash items on data._pendingInserts.  The caller — requestQueue's
    // processRequestQueue or drawingProcessing.processPendingResponses —
    // drains them via handleInsertDwg AFTER this response's processing is
    // fully finished but BEFORE clearing sentRequest, so each
    // addToRequestQueue's internal processRequestQueue call early-skips
    // (sentRequest still points at the current request) and items pile
    // into the queue without firing timer schedules.  Then sentRequest is
    // cleared and processRequestQueue runs once at the tail to drive the
    // next request.
    //
    // Each response only collects its OWN direct insertDwgs.  Nesting is
    // not expanded here — when c2's response arrives, c2's scan collects
    // c2's own inserts (if any) the same way.
    data._pendingInserts = [];
    if (insertDwgItems.length > 0) {
        foundInsertDwgItems = true;
        console.log(`Collected ${insertDwgItems.length} insertDwg items from drawing ${data.name} for deferred queueing`);
        insertDwgItems.forEach(item => {
            // Check for and null any idx on insertDwg items
            if (item.idx && item.idx !== 'null') {
                console.log(`Warning: insertDwg item for "${item.drawingName}" has idx=${item.idx}, nulling it as insertDwg should not have an idx.`);
                item.idx = 'null';
            }
            console.log(`Deferred insertDwg item for drawing "${item.drawingName}" at offsets (${item.xOffset || 0}, ${item.yOffset || 0})`);
            data._pendingInserts.push(item);
        });
    } else {
        console.log(`No insertDwg items found in unindexed items of drawing ${data.name}`);
    }
        
    // Save the current transform for this drawing at the end of processing
    // This will be used as the starting transform for updates
    if (drawingName !== null) {
        drawingManager.saveTransform(drawingName, currentTransform);
        console.log(`[TRANSFORM] Saved transform for drawing "${data.name}": x=${currentTransform.x}, y=${currentTransform.y}, scale=${currentTransform.scale}`);
    } else {
        console.log(`[TRANSFORM] TouchAction request - no transform save needed for merged data update`);
    }

    // Persist this drawing's per-drawing raw + data + version to the
    // per-drawing cache.  Skipped on merged-update path (touch / null
    // drawingName) — those don't change per-drawing raw, so the per-drawing
    // cache for the involved component drawings is unaffected.
    if (!isMergedUpdate && drawingName) {
        try {
            const connectionId = (typeof getConnectionIdentifier === 'function')
                ? getConnectionIdentifier(this.pfodWeb.connectionManager) : null;
            if (connectionId) {
                drawingManager.saveDrawingDataToStorage(drawingName, connectionId);
                for (const ownerDwg of redirectedOwnerDwgs) {
                    drawingManager.saveDrawingDataToStorage(ownerDwg, connectionId);
                }
            }
        } catch (e) {
            console.warn(`[DRAWING_DATA_PROCESSOR] Could not save per-drawing cache for "${drawingName}":`, e.message);
        }
    }

        // DrawingDataProcessor populates the live redrawDrawingManager's
        // per-drawing raw collections.  The caller (requestQueue or
        // processPendingResponses) runs DrawingMerger + redraw.performRedraw
        // once the response batch settles.

        // If we found insertDwg items, we'll let the queue process them and do the redraw
        // when all items are processed. Otherwise, redraw immediately.
        const _sr = this.pfodWeb.sentRequest;
        const _srDesc = _sr ? `${_sr.cmd}(${_sr.requestType})#${_sr._id}` : 'none';
        console.log(`[REDRAW_DECISION] foundInsertDwgItems=${foundInsertDwgItems}, requestQueue.length=${this.pfodWeb.requestQueue.length}, isProcessingQueue=${this.pfodWeb.isProcessingQueue()}, sentRequest=${_srDesc}, drawingName=${drawingName}`);
        // Defer redraw if there are pending requests in the queue OR if we're actively processing a request OR if there's a sent request
        // This ensures all drawings are processed before attempting a final redraw
        if (this.pfodWeb.requestQueue.length > 0 || this.pfodWeb.isProcessingQueue() || this.pfodWeb.sentRequest) {
            console.log(`[REDRAW_DECISION] Deferring redraw for ${drawingName} - queue length: ${this.pfodWeb.requestQueue.length}, processing: ${this.pfodWeb.isProcessingQueue()}, sentRequest: ${_srDesc}`);
            // We'll still update the state, but defer redraw to the queue completion
        } else {
            // Queue is empty, not processing, and no sent request - redraw now
            console.log(`[REDRAW_DECISION] Queue empty, not processing, no sent request after ${drawingName}, redrawing immediately`);
            drawingManager.allDrawingsReceived = true; // this is not actually used!!
        }

        // Enable updates and start update loop only after complete processing.
        this.pfodWeb.isUpdating = true;
    }
}

// Export for use in other modules
// Make classes available globally for class definition access
// IMPORTANT: Only pfodWeb should create instances of these classes
// Other modules should use the instances provided by pfodWeb
window.DrawingDataProcessor = DrawingDataProcessor;
window.TouchZoneFilters = TouchZoneFilters;/*   
   pfodWebMouse.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Touch and mouse event handling for the drawing canvas.
// Interprets pointer events as pfod touchZone interactions and feeds commands
// to the request queue. Also manages touchAction overlay rendering.
//
// Exports:    window.pfodWebMouse singleton object, window.TouchZoneSpecialValues constants
// Depends on: DrawingViewer instance (drawingViewer global from connectionSetup.js),
//             TouchZoneFilters from drawingDataProcessor.js,
//             redraw.js (pfodWebMouse.redraw set by setupEventListeners)
// Called by:  connectionSetup.js setupEventListeners (wires canvas pointer events),
//             drawingProcessing.js processPendingResponses (calls processPendingResponses
//             indirectly via mouse-up → pfodWebMouse.handleMouseUp),
//             navigationAndQueue.js scheduleNextUpdate (reads touchActionInputOpen),
//             keepAliveAndHttp.js fetchRefresh (reads touchActionInputOpen)

// Sentinel values used when a touch zone's coordinate field refers to the
// pixel row or column of the touch point rather than a fixed offset.
const TouchZoneSpecialValues = {
  TOUCHED_COL: 65534, // Only used in touchZone actions to specify touched col value
  TOUCHED_ROW: 65532, // Only used in touchZone actions to specify touched row value
};

// pfodDevice/pfodParser TouchActionInput dialogs auto-escape/un-escape the 5
// restricted characters { } | ` ~ round-trip (see escapeDocs.txt) — unlike
// plain String Input screens, where the user must escape manually. These two
// helpers implement that round-trip for showTextInputDialog().

// Decode the 5 restricted-char escapes back to their literal characters when
// loading an existing value into the dialog for editing, so the user sees
// (and can freely retype) the true current text rather than escape codes.
// Any literal `\uXXXX` (backslash + 'u' + exactly 4 hex digits) surviving in
// the result is then re-escaped to `&#92;uXXXX` — otherwise it would be
// silently swallowed by the live \uXXXX->Unicode-char conversion on the next
// keystroke, or misread as a real Unicode escape. This mirrors pfodApp's own
// "converts \u.... to &#92;u.... to maintain the text" load-time behaviour.
function _pfodDwgUnescapeRestrictedChars(str) {
  if (!str) return str;
  return str
    .replace(/&#96;/g,  '`')
    .replace(/&#123;/g, '{')
    .replace(/&#124;/g, '|')
    .replace(/&#125;/g, '}')
    .replace(/&#126;/g, '~')
    .replace(/\\u([0-9a-fA-F]{4})/g, '&#92;u$1');
}

// Escape the 5 restricted characters in the user's typed text before sending
// it to the pfodDevice, matching the automatic escaping TouchActionInput
// performs (unlike plain String Input screens, which send raw text and rely
// on the user to escape manually). Order is irrelevant — none of the 5
// replacement sequences contains any of the other 4 source characters.
function _pfodDwgEscapeRestrictedChars(str) {
  if (!str) return str;
  return str
    .replace(/`/g,  '&#96;')
    .replace(/\{/g, '&#123;')
    .replace(/\|/g, '&#124;')
    .replace(/\}/g, '&#125;')
    .replace(/~/g,  '&#126;');
}

// Make pfodWebMouse available globally for browser use
window.pfodWebMouse = {
  // Flag to track if touchActionInput dialog is currently open
  touchActionInputOpen: false,

  // Helper method to calculate scale factors based on actual rendered canvas size
  // This handles layout changes (like raw message view) that affect canvas display
  getCanvasScale: function() {
    const rect = this.canvas.getBoundingClientRect();
    if (!this.redraw) throw new Error('[pfodWebMouse] getCanvasScale: redraw not set');
    // _menuDrawingName is set on the proxy context used for per-item menu canvases
    const currentDrawingName = this._menuDrawingName;
    const drawingData = this.redraw.redrawDrawingManager.drawingsData[currentDrawingName];
    if (!drawingData) throw new Error(`[pfodWebMouse] getCanvasScale: no drawing data for "${currentDrawingName}"`);
    const logicalWidth = drawingData.data.x;
    const logicalHeight = drawingData.data.y;
    return {
      scaleX: rect.width / logicalWidth,
      scaleY: rect.height / logicalHeight,
      rect: rect
    };
  },

  // Wire mouse/touch event listeners on a per-item menu canvas.
  // Creates a proxy context that redirects this.canvas to the per-item canvas and
  // scopes makeBackup() to return only that drawing's touch zones / actions so that
  // findTouchZoneAt and handleTouchZoneActivation operate on the correct drawing.
  // menuItemCmd is the menu item's cmd character (e.g. 'D' for |+D~z) used as the
  // identifier in touch zone commands so each drawing sends its own cmd, not the
  // last one set on the shared drawingViewer.currentIdentifier.
  setupMenuCanvasListeners: function(canvas, drawingName, menuItemCmd, drawingViewer) {
    const self = this;

    // Proxy extends drawingViewer but overrides canvas and drawing name
    const proxy = Object.create(drawingViewer);
    proxy.canvas = canvas;
    proxy._menuDrawingName = drawingName;
    proxy.currentIdentifier = menuItemCmd;

    // Proxy redraw overrides makeBackup to scope to the per-drawing collections
    const origRedraw = drawingViewer.redraw;
    const proxyRedraw = Object.create(origRedraw);
    proxyRedraw.makeBackup = function() {
      const backup = origRedraw.makeBackup.call(origRedraw);
      if (!backup) return null;
      const dm = origRedraw.redrawDrawingManager;
      // No backup.drawingName field — the menuDwg loadCmd is recovered from
      // the request cmd in the response handler via _resolveLoadCmdFromRequest,
      // and from this.<menuDrawingName> in pfodWebMouse handlers.  Snapshot
      // ONLY the touched menuDwg's merged collections (the data that touchAction
      // processing mutates), keyed under [drawingName] so the structure mirrors
      // DrawingManager.allXXX.
      backup.allTouchZonesByCmd[drawingName]        = JSON.parse(JSON.stringify(dm.allTouchZonesByCmd[drawingName]        || {}));
      backup.allTouchActionsByCmd[drawingName]      = JSON.parse(JSON.stringify(dm.allTouchActionsByCmd[drawingName]      || {}));
      backup.allTouchActionInputsByCmd[drawingName] = JSON.parse(JSON.stringify(dm.allTouchActionInputsByCmd[drawingName] || {}));
      backup.allUnindexedItems[drawingName]         = JSON.parse(JSON.stringify(dm.allUnindexedItems[drawingName]         || []));
      backup.allIndexedItemsByNumber[drawingName]   = JSON.parse(JSON.stringify(dm.allIndexedItemsByNumber[drawingName]   || {}));
      return backup;
    };
    proxy.redraw = proxyRedraw;

    // A press means the PRIMARY button.  Without this a right-click ran the
    // whole press path — on a drawing with no touchZones it sent the menu
    // item's cmd and held the display, while the browser opened a context
    // menu over the top.  handleMouseUp already ignores an up it saw no
    // down for, so guarding the down alone is enough.
    const primaryOnly = (fn) => (e) => { if (e.button === 0) fn(e); };
    canvas.addEventListener('mousedown',  primaryOnly((e) => self.handleMouseDown.call(proxy, e)));
    canvas.addEventListener('mouseup',    (e) => self.handleMouseUp.call(proxy, e));
    canvas.addEventListener('mousemove',  (e) => self.handleMouseMove.call(proxy, e));
    canvas.addEventListener('mouseleave', (e) => self.handleMouseLeave.call(proxy, e));
    canvas.addEventListener('click',      (e) => self.handleClick.call(proxy, e));
    // The drawing is not a document: there is nothing on it to copy, save or
    // inspect, and a menu popping up over it is the browser acting on a
    // press the canvas is supposed to own.  Covers the right-click above and
    // the touch long-press that raises the same menu on Android.
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());
    // Gestures are withheld from the browser declaratively — `touch-action:
    // none` on the canvas (pfodCommon.css) — rather than by cancelling
    // touchstart here.  Same effect, said once in one place, and it does not
    // depend on every listener remembering to do it.
    const multiTouch = (e) => e.touches && e.touches.length > 1;
    canvas.addEventListener('touchstart', (e) => {
      // A second finger is never ours: every touchZone is single-finger and
      // these handlers only read touches[0].  Ignoring it stops a zoom
      // being recorded as a press.
      if (multiTouch(e)) return;
      self.handleMouseDown.call(proxy, e.touches[0]);
    }, { passive: false });
    canvas.addEventListener('touchmove', (e) => {
      if (multiTouch(e)) return;
      // Every one-finger drag on a drawing belongs to the drawing.  A drag
      // that starts on empty canvas is NOT diverted into scrolling the menu
      // — that was tried and is not wanted; the menu is scrolled from the
      // strip beside the drawing (pfodMenuDisplay's scroll gutter).
      //
      // Belt and braces to `touch-action: pinch-zoom` (pfodCommon.css),
      // which is what withholds panning from the browser: harmless where
      // the browser was not going to pan anyway, and it costs nothing to be
      // explicit once the gesture is known to be a one-finger drag.
      e.preventDefault();
      self.handleMouseMove.call(proxy, e.touches[0]);
    }, { passive: false });
    canvas.addEventListener('touchend', (e) => {
      self.handleMouseUp.call(proxy, e.changedTouches[0]);
      if (multiTouch(e)) return;   // the tail of a zoom is the browser's
      // handleClick is what carries the CLICK touchZone filter, and it was
      // only ever reached through the mouse `click` event — which a touch
      // device does not deliver here, since the browser's synthesised mouse
      // events are suppressed below.  So a CLICK-filter zone did nothing at
      // all on Android while the same zone worked on Windows.  Run it
      // directly.  Safe to call unconditionally: it checks hasDragged and
      // the long-press timeout itself, exactly as it does for a mouse, and
      // handleMouseUp above handles different filters (UP / DOWN_DRAG_UP),
      // so nothing fires twice.
      self.handleClick.call(proxy, e.changedTouches[0]);
      // THIS is where the cancel belongs.  A browser follows a touch with
      // synthesised mouse events — mousedown, mouseup, click — and this
      // canvas listens for all three, so without it every tap on a drawing
      // would run the handlers a second time.  Cancelling touchend
      // suppresses them, and by then the gesture is over, so no zoom or
      // scroll can be affected by it.
      e.preventDefault();
    }, { passive: false });
  },

  /// End the display hold a press-on-a-touchZone started, and let the
  /// screen catch up: drain anything the hold queued, and re-arm the refresh
  /// timer (processPendingResponses does that itself, on both the empty and
  /// non-empty paths).  Safe to call when no hold is active — it returns
  /// immediately, so every gesture-ending path can call it unconditionally.
  ///
  /// This is the ONLY thing that clears holdingUpdates.  Leaving the canvas
  /// or dragging out of the zone deliberately does not: the button is still
  /// down and the user may drag back in, so the display stays held until the
  /// pointer is genuinely released.
  /// @param {object} viewer — the DrawingViewer (or per-canvas proxy)
  /// @param {string} why — for the log line
  _endTouchHold: function(viewer, why) {
    if (!viewer || !viewer.touchState || !viewer.touchState.holdingUpdates) return;
    console.log(`[TOUCH_HOLD] Released by ${why} — resuming redraws and refresh`);
    viewer.touchState.holdingUpdates = false;
    window.pfodWebMouse._holdViewer = null;
    viewer.processPendingResponses();
  },

  setupEventListeners: function(drawingViewer) {
    // Initialize touchActionBackups on global object only if it doesn't exist to preserve existing backups
    if (window.pfodWebMouse.touchActionBackups === undefined) {
      window.pfodWebMouse.touchActionBackups = null;
    }

    // Canvas-level listeners are wired per-item by setupMenuCanvasListeners().
    // These document-level ones are the safety net for a gesture that ENDS
    // somewhere the canvas never hears about: press on a touchZone, drag off
    // the canvas, release.  Without them the hold started by that press would
    // never be cleared, and the refresh timer — cancelled at mousedown — would
    // stay cancelled, since every path that re-arms it runs off the timer
    // firing, a response arriving, or processPendingResponses.  Registered
    // once for the app, not once per drawing.
    if (!window.pfodWebMouse._documentUpWired) {
      window.pfodWebMouse._documentUpWired = true;
      const release = (why) => () => {
        const held = window.pfodWebMouse._holdViewer || drawingViewer;
        held.touchState.isDown = false;
        window.pfodWebMouse._endTouchHold(held, why);
      };
      document.addEventListener('mouseup', release('document mouseup'));
      document.addEventListener('touchend', release('document touchend'));
      document.addEventListener('touchcancel', release('touchcancel'));
    }
  },

  // Mouse and touch event handlers
  handleMouseDown: function(e) {
    console.info(`[MOUSE_DOWN] called handleMouseDown`);

    // Get canvas-relative coordinates and scale factors
    const scale = window.pfodWebMouse.getCanvasScale.call(this);
    const x = (e.clientX - scale.rect.left) / scale.scaleX;
    const y = (e.clientY - scale.rect.top) / scale.scaleY;

    let minTouch_mm = 9;
    let minPercent = 2 / 100;
    let colPixelsHalf9mm = (96 * minTouch_mm) / (2 * 25.4); // half 9mm to add to both sides
    let rowPixelsHalf9mm = (96 * minTouch_mm) / (2 * 25.4);
    if ((scale.rect.width * minPercent) > colPixelsHalf9mm) {
      colPixelsHalf9mm = scale.rect.width * minPercent;
    }
    if ((scale.rect.height * minPercent) > rowPixelsHalf9mm) {
      rowPixelsHalf9mm = scale.rect.height * minPercent;
    }
    console.log(`DOWN in touchZone: enlarge by ${colPixelsHalf9mm} x ${rowPixelsHalf9mm}`);
    colPixelsHalf9mm = colPixelsHalf9mm / scale.scaleX;
    rowPixelsHalf9mm = rowPixelsHalf9mm / scale.scaleX;
    console.log(`DOWN in touchZone: canvas ${scale.rect.width} x ${scale.rect.height}`);
    console.log(`DOWN in touchZone: enlarge by dwg coords ${colPixelsHalf9mm} x ${rowPixelsHalf9mm}`);

    // Update touch state.  isDown means only "the pointer is down" — it
    // drives drag tracking (handleMouseMove/Up both early-return without it),
    // so it is set for every press, including one that lands on nothing.
    // Whether the press HOLDS the display is decided below, once we know if
    // it hit a touchZone.
    console.info(`[MOUSE_DOWN] Setting touchState.isDown = true`);
    this.touchState.wasDown = this.touchState.isDown;
    this.touchState.isDown = true;

    this.touchState.startX = x;
    this.touchState.startY = y;
    this.touchState.lastX = x;
    this.touchState.lastY = y;
    this.touchState.startTime = Date.now();
    this.touchState.hasDragged = false;
    this.touchState.hasEnteredZones.clear();


    // Find the touchZone at this position
    const foundTouchZone = window.pfodWebMouse.findTouchZoneAt.call(this, x, y, colPixelsHalf9mm, rowPixelsHalf9mm);
    this.touchState.targetTouchZone = foundTouchZone;

    // A drawing with NO touchZones at all is just a picture on a menu item,
    // so pressing it is pressing that item: send the MENU ITEM's cmd, here
    // on the way DOWN.
    //
    // On the way down, not on a click, because "was that a click or a drag"
    // is a question with no good answer on a touchscreen — a finger always
    // moves a little — and there is nothing to decide anyway: a drawing
    // with no active areas has only one thing a press can mean.
    //
    // this.currentIdentifier is that cmd: setupMenuCanvasListeners puts the
    // menu item's own cmd on each per-canvas proxy, so a press reports the
    // item it belongs to rather than whatever was last set on the shared
    // viewer.  pfodMenuDisplay._handleClick is the path every other menu
    // item's press takes, so the menu-version cache applies to this one too.
    const dmDown = this.redraw.redrawDrawingManager;
    const dwgDown = this._menuDrawingName;
    const hasAnyTouchZones =
      Object.keys(dmDown.allTouchZonesByCmd[dwgDown] || {}).length > 0;
    if (!foundTouchZone && !hasAnyTouchZones) {
      const itemCmd = this.currentIdentifier;
      if (itemCmd && window.pfodMenuDisplay) {
        console.info(`[MOUSE_DOWN] No touchZones in "${dwgDown}" — sending menu item cmd "${itemCmd}"`);
        window.pfodMenuDisplay._handleClick(itemCmd);
      } else {
        console.warn(`[MOUSE_DOWN] No touchZones and no menu item cmd for "${dwgDown}"`);
      }
    }

    // What HOLDS the display until the press is released: a press on a live
    // touchZone, and a press on a drawing that has none (which has just sent
    // its menu item's cmd above — the reply to that must not be painted
    // under the finger that asked for it).
    //
    // findTouchZoneAt excludes TOUCH_DISABLED zones, so pressing one of
    // those — or pressing empty canvas on a drawing that HAS zones — holds
    // nothing and auto-refresh carries on: a disabled zone is meant to
    // swallow the touch, not freeze the drawing.  The hold stays set through
    // a drag out of the zone or off the canvas and is cleared only when the
    // gesture ends (_endTouchHold).
    if (foundTouchZone || !hasAnyTouchZones) {
      this.touchState.holdingUpdates = true;
      // Remember WHICH viewer is holding.  Canvas events run against a
      // per-canvas proxy (setupMenuCanvasListeners) carrying that drawing's
      // own canvas/_menuDrawingName/redraw, so the document-level release
      // has to drain through the same one rather than the base viewer.
      window.pfodWebMouse._holdViewer = this;
      if (this.updateTimer) {
        clearTimeout(this.updateTimer);
        this.updateTimer = null;
        console.info(`[MOUSE_DOWN] Cancelled refresh timer`);
      }
    } else {
      console.info(`[MOUSE_DOWN] Outside every touchZone — refresh left running`);
    }

    // Only back up state when this touchZone actually has a touchAction/
    // touchActionInput that will fire and need reverting later — a click
    // outside every touchZone, or on one with neither, never applies any
    // optimistic edit, so there's nothing to back up or later restore.
    // Checked against the LIVE DrawingManager (keyed by cmd, same shape
    // makeBackup's own snapshot uses) rather than any existing backup,
    // since none may exist yet.
    if (foundTouchZone) {
      const dm = this.redraw.redrawDrawingManager;
      const dwg = this._menuDrawingName;
      const hasActions = (dm.allTouchActionsByCmd[dwg]?.[foundTouchZone.cmd]?.length > 0);
      const hasInput = !!dm.allTouchActionInputsByCmd[dwg]?.[foundTouchZone.cmd];
      if (hasActions || hasInput) {
        console.info(`[TOUCH_ACTION] Creating backup using redraw.makeBackup()`);
        window.pfodWebMouse.touchActionBackups = this.redraw.makeBackup();
        if (!window.pfodWebMouse.touchActionBackups) {
          console.info(`[TOUCH_ACTION] Failed to create backup - makeBackup() returned null`);
        }
      }
    }

    // Handle basic TOUCH filter (default if no filter specified)
    if (foundTouchZone && (foundTouchZone.filter === TouchZoneFilters.TOUCH || foundTouchZone.filter === 0)) {
      console.log(`TOUCH in touchZone: cmd=${foundTouchZone.cmd}`);
      window.pfodWebMouse.handleTouchZoneActivation.call(this, foundTouchZone, TouchZoneFilters.TOUCH, x, y);
    } 

    // If we found a touchZone with a DOWN filter, handle it
    if (foundTouchZone && (foundTouchZone.filter & TouchZoneFilters.DOWN)) {
      console.log(`Mouse DOWN in touchZone: cmd=${foundTouchZone.cmd}, filter=${foundTouchZone.filter}`);
      window.pfodWebMouse.handleTouchZoneActivation.call(this, foundTouchZone, TouchZoneFilters.DOWN, x, y);
    }
    // If we found a touchZone with a DOWN_UP / DOWN_DRAG_UP filter, handle it show touchActions but no msg yet
    if (foundTouchZone && (foundTouchZone.filter & TouchZoneFilters.DOWN_DRAG_UP)) {
      console.log(`Mouse DOWN in touchZone: cmd=${foundTouchZone.cmd}, filter=${foundTouchZone.filter}`);
      window.pfodWebMouse.handleTouchZoneActivation.call(this, foundTouchZone, TouchZoneFilters.DOWN, x, y, false);
    }

    // If we found a touchZone with a CLICK filter, handle it
//    if (foundTouchZone && (foundTouchZone.filter & TouchZoneFilters.CLICK)) {
//      console.log(`Mouse DOWN in touchZone: cmd=${foundTouchZone.cmd}, filter=${foundTouchZone.filter}`);
//      window.pfodWebMouse.handleTouchZoneActivation.call(this, foundTouchZone, TouchZoneFilters.DOWN, x, y, false); // show touchActions but no msg
//    }
    
    // If the touchZone supports PRESS (long press), set up a timer
    if (foundTouchZone && (foundTouchZone.filter & TouchZoneFilters.PRESS)) {
      if (this.touchState.longPressTimer) {
        clearTimeout(this.touchState.longPressTimer);
      }

      // Set a timer for long press (700ms is standard)
      this.touchState.longPressTimer = setTimeout(() => {
        if (this.touchState.isDown && this.touchState.targetTouchZone === foundTouchZone) {
          console.log(`Long PRESS in touchZone: cmd=${foundTouchZone.cmd}`);
          window.pfodWebMouse.handleTouchZoneActivation.call(this, foundTouchZone, TouchZoneFilters.PRESS, this.touchState.lastX, this.touchState.lastY);
        }
      }, 700);
    }
  },

  handleMouseMove: function(e) {
    if (!this.touchState.isDown) {
      // console.log(`[MOUSE_MOVE] Ignoring - mouse not down`);
      return;
    }
    // console.log(`[MOUSE_MOVE] Processing mouse move event`);

    // Get canvas-relative coordinates and scale factors
    const scale = window.pfodWebMouse.getCanvasScale.call(this);
    const x = (e.clientX - scale.rect.left) / scale.scaleX;
    const y = (e.clientY - scale.rect.top) / scale.scaleY;

    let minTouch_mm = 9;
    let minPercent = 2 / 100;
    let colPixelsHalf9mm = (96 * minTouch_mm) / (2 * 25.4); // half 9mm to add to both sides
    let rowPixelsHalf9mm = (96 * minTouch_mm) / (2 * 25.4);
    if ((scale.rect.width * minPercent) > colPixelsHalf9mm) {
      colPixelsHalf9mm = scale.rect.width * minPercent;
    }
    if ((scale.rect.height * minPercent) > rowPixelsHalf9mm) {
      rowPixelsHalf9mm = scale.rect.height * minPercent;
    }
    console.log(`DRAG in touchZone enlarge by ${colPixelsHalf9mm} x ${rowPixelsHalf9mm}`);
    colPixelsHalf9mm = colPixelsHalf9mm / scale.scaleX;
    rowPixelsHalf9mm = rowPixelsHalf9mm / scale.scaleX;
    console.log(`DRAG in touchZone canvas ${scale.rect.width} x ${scale.rect.height}`);
    console.log(`DRAG in touchZone enlarge by dwg coords ${colPixelsHalf9mm} x ${rowPixelsHalf9mm}`);

    // Update current position
    this.touchState.lastX = x;
    this.touchState.lastY = y;

    // Calculate distance moved from start point
    const dx = x - this.touchState.startX;
    const dy = y - this.touchState.startY;
    const distance = Math.sqrt(dx * dx + dy * dy);

    // Only consider as drag if moved more than a small threshold
    //
    // No dead zone, deliberately.  A finger wobble on a touchZone whose
    // filter does not include DRAG sends nothing anyway — the filter, not a
    // distance threshold, is what decides whether movement means anything.
    // On one that DOES include DRAG, a wobble is a drag and sending it is
    // correct.  Repeats cannot pile up either: a queued drag cmd for this
    // zone replaces the one already waiting, so there is only ever the
    // latest one outstanding (see addToRequestQueue's type replacement).
    if (distance > 0) {
      console.log(`[MOUSE_DRAG] Distance moved: ${distance.toFixed(2)}, setting hasDragged = true`);
      this.touchState.hasDragged = true;

      // Find touchZone at current position
      const currentTouchZone = window.pfodWebMouse.findTouchZoneAt.call(this, x, y, colPixelsHalf9mm, rowPixelsHalf9mm);
      console.log(`[MOUSE_DRAG] CurrentTouchZone:`, currentTouchZone ? `cmd=${currentTouchZone.cmd}, filter=${currentTouchZone.filter}` : 'null');

      // Handle ENTRY/EXIT events
      if (currentTouchZone !== this.touchState.targetTouchZone) {
        // Handle EXIT from previous touchZone
        if (this.touchState.targetTouchZone && (this.touchState.targetTouchZone.filter & TouchZoneFilters.EXIT)) {
          console.log(`EXIT from touchZone: cmd=${this.touchState.targetTouchZone.cmd}`);
          window.pfodWebMouse.handleTouchZoneActivation.call(this, this.touchState.targetTouchZone, TouchZoneFilters.EXIT, x, y, false);
        }

        // Handle ENTRY to new touchZone
        if (currentTouchZone && (currentTouchZone.filter & TouchZoneFilters.ENTRY)) {
          // Only trigger ENTRY once per touch sequence for this zone
          if (!this.touchState.hasEnteredZones.has(currentTouchZone)) {
            console.log(`ENTRY to touchZone: cmd=${currentTouchZone.cmd}`);
            window.pfodWebMouse.handleTouchZoneActivation.call(this, currentTouchZone, TouchZoneFilters.ENTRY, x, y, false);
            this.touchState.hasEnteredZones.add(currentTouchZone);
          }
        }

        this.touchState.targetTouchZone = currentTouchZone;
      }

      // Handle DRAG events for current touchZone
      if (currentTouchZone && (currentTouchZone.filter & TouchZoneFilters.DRAG)) {
        console.warn(`[MOUSE_DRAG] DRAG filter detected - calling handleTouchZoneActivation for cmd=${currentTouchZone.cmd}`);
        window.pfodWebMouse.handleTouchZoneActivation.call(this, currentTouchZone, TouchZoneFilters.DRAG, x, y);
      } else if (currentTouchZone) {
        console.log(`[MOUSE_DRAG] TouchZone found but no DRAG filter - filter=${currentTouchZone.filter}, DRAG=${TouchZoneFilters.DRAG}`);
        console.log(`[MOUSE_DRAG] Binary check: (${currentTouchZone.filter} & ${TouchZoneFilters.DRAG}) = ${currentTouchZone.filter & TouchZoneFilters.DRAG}`);
      }
      // Handle DRAG events for current touchZone
      if (currentTouchZone && (currentTouchZone.filter & TouchZoneFilters.DOWN_DRAG_UP)) {
        console.log(`[MOUSE_DRAG] DOWN_DRAG_UP filter detected - calling handleTouchZoneActivation for cmd=${currentTouchZone.cmd}`);
        window.pfodWebMouse.handleTouchZoneActivation.call(this, currentTouchZone, TouchZoneFilters.DRAG, x, y,false); // show but not send
      } else if (currentTouchZone) {
        console.log(`[MOUSE_DRAG] TouchZone found but no DOWN_DRAG_UP filter - filter=${currentTouchZone.filter}, DOWN_DRAG_UP=${TouchZoneFilters.DOWN_DRAG_UP}`);
        console.log(`[MOUSE_DRAG] Binary check: (${currentTouchZone.filter} & ${TouchZoneFilters.DOWN_DRAG_UP}) = ${currentTouchZone.filter & TouchZoneFilters.DOWN_DRAG_UP}`);
      }

      // Check if we've left the original touchzone that started the drag
      if (this.touchState.targetTouchZone && !currentTouchZone) {
        console.warn('[MOUSE_DRAG] Left original touchzone area - dropping the drag target');

        // The display stays HELD.  The button is still down and the user may
        // drag back in, so pending responses are deliberately not drained
        // here — draining re-arms the refresh timer, and the screen would
        // start updating under a finger that has not been lifted.  The hold
        // is released when the gesture really ends, by mouse up or by the
        // document-level listener if the release lands off the canvas.
        //
        // Reset mouse state since we've left the drag area
        this.touchState.wasDown = this.touchState.isDown;
        this.touchState.isDown = false;
        this.touchState.targetTouchZone = null;
        this.touchState.hasEnteredZones.clear();
      }
    }
  },

  handleMouseUp: function(e) {
    if (!this.touchState.isDown) return;

    // Get canvas-relative coordinates and scale factors
    const scale = window.pfodWebMouse.getCanvasScale.call(this);
    const x = (e.clientX - scale.rect.left) / scale.scaleX;
    const y = (e.clientY - scale.rect.top) / scale.scaleY;

    // Cancel long press timer if active
    if (this.touchState.longPressTimer) {
      clearTimeout(this.touchState.longPressTimer);
      this.touchState.longPressTimer = null;
    }

    // Handle UP and DOWN_DRAG_UP events for current touchZone
    if (this.touchState.targetTouchZone) {
      // Handle UP filter - Works
      if (this.touchState.targetTouchZone.filter & TouchZoneFilters.UP) {
        console.log(`Mouse UP in touchZone: cmd=${this.touchState.targetTouchZone.cmd}`);
        window.pfodWebMouse.handleTouchZoneActivation.call(this, this.touchState.targetTouchZone, TouchZoneFilters.UP, x, y);
      }

      // Handle DOWN_DRAG_UP filter - only sends on finger up - Works
      if (this.touchState.targetTouchZone.filter & TouchZoneFilters.DOWN_DRAG_UP) {
        console.log(`DOWN_UP in touchZone: cmd=${this.touchState.targetTouchZone.cmd}`);
        window.pfodWebMouse.handleTouchZoneActivation.call(this, this.touchState.targetTouchZone, TouchZoneFilters.DOWN_DRAG_UP, x, y);
      }
    }

    // Reset touch state FIRST to allow final redraw
    console.log(`[MOUSE_UP] Setting touchState.isDown = false`);
    this.touchState.wasDown = this.touchState.isDown;
    this.touchState.isDown = false;

    // Note: touchAction backup is restored on RESPONSE RECEIPT (see
    // requestQueue.js [TOUCH_RESTORE]).  Touch-up itself does not restore.
    if (window.pfodWebMouse.touchActionBackups) {
      const backup = window.pfodWebMouse.touchActionBackups;
      const dwg = this._menuDrawingName;
      console.log(`[MOUSE_UP] TouchAction backup exists for "${dwg}" — restore deferred until response receipt`);
      console.log(`[MOUSE_UP] Backup contains: unindexed=${backup.allUnindexedItems?.[dwg]?.length || 0}, indexed=${Object.keys(backup.allIndexedItemsByNumber?.[dwg] || {}).length}`);
    } else {
      console.log(`[MOUSE_UP] No touchAction backup exists`);
    }

    // THEN release the hold and process any pending responses queued while
    // it was active (_endTouchHold drains them and re-arms the refresh timer).
    // Still call processPendingResponses directly when no hold was active —
    // a press that hit nothing never held anything, but the queue is drained
    // the same way either way.
    if (this.touchState.holdingUpdates) {
      window.pfodWebMouse._endTouchHold(this, 'mouse up');
    } else {
      this.processPendingResponses();
    }
    this.touchState.targetTouchZone = null;
    this.touchState.hasEnteredZones.clear();
  },

  handleMouseLeave: function(e) {
    console.log('[MOUSE_LEAVE] Mouse left canvas area');
    if (this.touchState.isDown) {
      console.log('[MOUSE_LEAVE] Mouse was down - dropping the drag target, display stays held');

      // Same as the drag-out path above: the button is still down, so the
      // display stays held and nothing is drained here.  Release happens on
      // mouse up, or on the document-level mouseup/touchend if the pointer is
      // let go outside the canvas — which is exactly the case this branch is
      // about, and the reason that safety net exists (see setupEventListeners).

      // Reset touch state
      this.touchState.wasDown = this.touchState.isDown;
      this.touchState.isDown = false;
      this.touchState.targetTouchZone = null;
      this.touchState.hasEnteredZones.clear();
    }
  },

  handleClick: function(e) {
    // Check if mouse was held down for longer than PRESS timeout (700ms)
    // If so, ignore this click as it was a long press
    const currentTime = Date.now();
    const pressDuration = currentTime - this.touchState.startTime;
    if (pressDuration >= 700) {
      console.log(`Ignoring click - mouse was held down for ${pressDuration}ms (long press)`);
      this.touchState.hasDragged = false;
      return;
    }

    // Get canvas-relative coordinates and scale factors
    const scale = window.pfodWebMouse.getCanvasScale.call(this);
    const x = (e.clientX - scale.rect.left) / scale.scaleX;
    const y = (e.clientY - scale.rect.top) / scale.scaleY;

    let minTouch_mm = 9;
    let minPercent = 2 / 100;
    let colPixelsHalf9mm = (96 * minTouch_mm) / (2 * 25.4); // half 9mm to add to both sides
    let rowPixelsHalf9mm = (96 * minTouch_mm) / (2 * 25.4);
    if ((scale.rect.width * minPercent) > colPixelsHalf9mm) {
      colPixelsHalf9mm = scale.rect.width * minPercent;
    }
    if ((scale.rect.height * minPercent) > rowPixelsHalf9mm) {
      rowPixelsHalf9mm = scale.rect.height * minPercent;
    }
    console.log(`CLICK in touchZone: enlarge by ${colPixelsHalf9mm} x ${rowPixelsHalf9mm}`);
    colPixelsHalf9mm = colPixelsHalf9mm / scale.scaleX;
    rowPixelsHalf9mm = rowPixelsHalf9mm / scale.scaleX;
    console.log(`CLICK in touchZone: canvas ${scale.rect.width} x ${scale.rect.height}`);
    console.log(`CLICK in touchZone: enlarge by dwg coords ${colPixelsHalf9mm} x ${rowPixelsHalf9mm}`);

    // Find touchZone at click position
    const touchZone = window.pfodWebMouse.findTouchZoneAt.call(this, x, y, colPixelsHalf9mm, rowPixelsHalf9mm);

    // Handle basic CLICK event without drag
    if (!this.touchState.hasDragged) {
      if (touchZone) {
        // Handle CLICK filter
        if (touchZone && (touchZone.filter & TouchZoneFilters.CLICK)) {
          console.log(`CLICK in touchZone: cmd=${touchZone.cmd}`);
          window.pfodWebMouse.handleTouchZoneActivation.call(this, touchZone, TouchZoneFilters.CLICK, x, y, false);
          if (this.touchState.clickTimer) {
           clearTimeout(this.touchState.clickTimer);
          }

          // Set a timer for display of click touchActions (100ms is standard)
          this.touchState.clickTimer = setTimeout(() => {
            window.pfodWebMouse.handleTouchZoneActivation.call(this, touchZone, TouchZoneFilters.CLICK, this.touchState.lastX, this.touchState.lastY);
          }, 100);
          return;
        } 
      } else {
        // Outside every touchZone of a drawing that HAS touchZones: nothing
        // to do.  A drawing with NO touchZones is not handled here at all —
        // its press sends the menu item's cmd on the way DOWN
        // (handleMouseDown), so that a press means the same thing on a
        // touchscreen as under a mouse without having to guess whether the
        // finger that moved two pixels meant a click or a drag.
        console.log("Touch outside defined touchZones - ignoring");
      }
    }

    // Safety net: Restore touchActions and process any pending responses if mouse state got out of sync

    if (this.pendingResponseQueue.length > 0) {
      console.info(`[QUEUE] Safety net: Processing ${this.pendingResponseQueue.length} pending responses in handleClick`);
      this.processPendingResponses();
    }

    // Reset drag state
    this.touchState.hasDragged = false;
  },

  // Find touchZone containing specified coordinates (instance method)
  // touchZone object
  //    touchZoneObject = {
  //        type: "touchZone",
  //        xSize: xSize,
  //        ySize: ySize,
  //        cmd: cmd,
  //        idx: idx
  //        xOffset: xOffset,
  //        yOffset: yOffset,
  //        filter: filter,
  //        centered: "true"
  //    }
  
  // row col extra in dwg coords
  findTouchZoneAt: function(x, y, colExtra, rowExtra) { 
    console.info(`[FIND_TOUCH_ZONE] findTouchZoneAt called with x:${x} y:${y} colExtra:${colExtra} rowExtra:${rowExtra}`);

    // Collect all visible touchZones
    let visibleTouchZones = [];

    // Hit-testing is a query, not a revert operation, so it reads the
    // LIVE DrawingManager rather than touchActionBackups — a backup may
    // legitimately not exist yet (handleMouseDown calls this BEFORE
    // deciding whether one is even needed) or not exist at all (a click
    // whose zone has no touchAction/touchActionInput never gets one — see
    // handleMouseDown). touchZone geometry itself isn't something a
    // touchAction mutates, so the live collections are exactly as stable
    // as a mousedown-time snapshot would be for this purpose.
    const dwg = this._menuDrawingName;
    const allTouchZones = (this.redraw && dwg) ? this.redraw.redrawDrawingManager.allTouchZonesByCmd[dwg] : undefined;
    console.info(`[FIND_TOUCH_ZONE] DEBUG allTouchZonesByCmd["${dwg}"] returned ${Object.keys(allTouchZones || {}).length} touchZones:`, Object.keys(allTouchZones || {}));
    if (allTouchZones === undefined) {
        console.info(`[FIND_TOUCH_ZONE] allTouchZonesByCmd["${dwg}"] returned undefined during ${this.touchState?.isDown ? 'DRAG' : 'NORMAL'} operation`);
        return null;
    }
    for (const cmd in allTouchZones) {
      const zone = allTouchZones[cmd];

      // Only include visible and non-disabled zones
      if (zone.visible !== false && zone.filter !== TouchZoneFilters.TOUCH_DISABLED) {
        visibleTouchZones.push(zone);
      }
    }
    console.info(`[FIND_TOUCH_ZONE] number of visible touchZones ${visibleTouchZones.length}`);

    // Sort by idx (high idx first) last one wins if it over lays earlier one
    //visibleTouchZones.sort((a, b) => (b.idx || 0) - (a.idx || 0));

    // returns -ve if outside rect else min (x-x_middle,y-y_middle)
    // Check if point is inside any touchZone
    let currentZone = null;
    let currentBounds = null;
    let current_colMin = 0;
    let current_rowMin = 0;
    for (const zone of visibleTouchZones) {
      // Calculate touchZone bounds in dwg coords
      let bounds = window.pfodWebMouse.calculateTouchZoneBounds.call(this, zone);
      // apply min extra
      bounds.left -= colExtra;
      bounds.right += colExtra;
      bounds.top -= rowExtra;
      bounds.bottom += rowExtra;
      bounds.width = bounds.right - bounds.left;
      bounds.height = bounds.bottom - bounds.top;
      console.info(`[FIND_TOUCH_ZONE] TouchZone: cmd=${zone.cmd}, left:${bounds.left} right:${bounds.right} top:${bounds.top} bottom:${bounds.bottom}`);
      // Check if point is inside bounds
      let insideZone = (x >= bounds.left && x <= bounds.left + bounds.width &&
        y >= bounds.top && y <= bounds.top + bounds.height);
      if (!insideZone) {
        continue;
      }
      colMin = Math.min(x - bounds.left, bounds.right - x); // closest col to edge
      rowMin = Math.min(y - bounds.top, bounds.bottom - y); // closest row to edge
      if (currentZone == null) {
        // make sure these are set for rect compare on next call
        currentZone = zone;
        current_colMin = colMin;
        current_rowMin = rowMin;
        currentBounds = bounds;
         console.info(`[FIND_TOUCH_ZONE] TouchZone: cmd=${currentZone.cmd}, colMin:${colMin} rowMin:${rowMin})`);
        continue;
      } else { // have current
        let currentIdx = currentZone.idx;
        let thisIdx = zone.idx;
        if (currentIdx != thisIdx) {
          if (currentIdx > thisIdx) {
            // currentZone; // wins
            continue;
          } else if (thisIdx > currentIdx) {
            currentZone = zone;
            current_colMin = colMin;
            current_rowMin = rowMin;
            currentBounds = bounds;
            continue;
          }
        } else { // same idx so compare overlaps  
           console.info(`[FIND_TOUCH_ZONE] TouchZone: cmd=${zone.cmd}, colMin:${colMin} rowMin:${rowMin})`);

          // else // continue to check overlaps
          // Returns true if `a` contains `b`
          // if current contains this return current
          // i.e. larger rect sits over smaller one but only if it completely covers it.
          // used for dragging
          // normally touchZones do not have/need indices
          // this approach allows you to put a whole dwg touchZone over other dwgs and
          // then click and drag them (identified by their position on the dwg)
          // without triggering the underlying dwgs own touchZones.
          //
          // touchZones ordered in the order they (first) arrived
          // if a late touchZone exactly overlays an earlier on the later (higher) touchZone is the active one!!
          // NOTE: rectf can have -ve values It is not limited to screen
          const contains = (a, b) => a.left <= b.left && a.top <= b.top && a.right >= b.right && a.bottom >= b.bottom;
          if (contains(zone, currentZone)) { // later zone contains earlier
            currentZone = zone;
            current_colMin = colMin;
            current_rowMin = rowMin;
            currentBounds = bounds;
            continue;
          } else if (contains(currentZone, zone)) {
            // no change
            continue;
          } else {
            // check overlap for best fit
            // else compare based on min overlap dimension
            // x_overlap = Math.max(0, Math.min(x12,x22) - Math.max(x11,x21));
            // y_overlap = Math.max(0, Math.min(y12,y22) - Math.max(y11,y21));
            // x11 = left y11 = top x12 = right, y12 = bottom
            // MUST overlap since point in both so can skip Math.max(0...
            let colOverlap = Math.min(bounds.right, currentBounds.right) - Math.max(bounds.left, currentBounds.left);
            let rowOverlap = Math.min(bounds.bottom, currentBounds.bottom) - Math.max(bounds.top, currentBounds.top);
            // console.info(`[FIND_TOUCH_ZONE] colOverlap:${colOverlap} rowOverlap:${rowOverlap})`);

            let compareCol = true;
            // need this for long rectangles
            if (colOverlap == rowOverlap) {
              // check both dimensions point in col dimension
              let col_min = Math.min(current_colMin, colMin);
              let row_min = Math.min(current_rowMin, rowMin);
              // console.info(`[FIND_TOUCH_ZONE] col_min:${col_min} row_min:${row_min})`);
              if (col_min < row_min) {
                // since overlap equal then this also implies col_max > row_max
                // closest to col boundry
                // compareCol == true;
              } else {
                compareCol = false;
              }
            } else if (colOverlap < rowOverlap) {
              // compareCol == true;
            } else {
              compareCol = false;
            }
            if (compareCol) {
              // check point in col dimension
              if (current_colMin <= colMin) {
                // nearer edge of current so choose this
                // if equal later ones take precedence
                currentZone = zone;
                current_colMin = colMin;
                current_rowMin = rowMin;
                currentBounds = bounds;
              } else {
                // return current;
              }
            } else {
              // check point in row dimension
              if (current_rowMin <= rowMin) {
                // nearer edge of current so choose this
                currentZone = zone;
                current_colMin = colMin;
                current_rowMin = rowMin;
                currentBounds = bounds;
              } else {
                // return current;
              }
            }
          }
        }
      }
    }
    if (currentZone) {
      console.info(`[FIND_TOUCH_ZONE] returning TouchZone: cmd=${currentZone.cmd}`);
    } else {
      console.info(`[FIND_TOUCH_ZONE] returning TouchZone: null`);
    }
    return currentZone; // the one found
  },

  // Calculate the bounds of a touchZone in canvas coordinates (instance method)
  // left, right, top, bottom
  calculateTouchZoneBounds: function(zone) {
    // Get the transform
    if (!zone.transform) throw new Error(`[pfodWebMouse] calculateTouchZoneBounds: transform missing on zone cmd="${zone.cmd}"`);
    const transform = zone.transform;

    // Get properties with defaults
    const xOffset = parseFloat(zone.xOffset);
    const yOffset = parseFloat(zone.yOffset || 0);
    const xSize = parseFloat(zone.xSize || 1); // min size is 1
    const ySize = parseFloat(zone.ySize || 1);
    const centered = zone.centered === 'true' || zone.centered === true;

    // Apply transform scale
    const scaledXOffset = xOffset * transform.scale;
    const scaledYOffset = yOffset * transform.scale;
    const scaledXSize = xSize * transform.scale;
    const scaledYSize = ySize * transform.scale;

    // Calculate bounds based on centered property
    let x, y, width, height;

    if (centered) {
      // For centered zones, center point is at the offset
      x = transform.x + scaledXOffset - Math.abs(scaledXSize) / 2;
      y = transform.y + scaledYOffset - Math.abs(scaledYSize) / 2;
      width = Math.abs(scaledXSize);
      height = Math.abs(scaledYSize);
    } else {
      // For non-centered zones, handle negative sizes
      if (scaledXSize >= 0) {
        x = transform.x + scaledXOffset;
        width = scaledXSize;
      } else {
        x = transform.x + scaledXOffset + scaledXSize; // Move start point left
        width = Math.abs(scaledXSize);
      }

      if (scaledYSize >= 0) {
        y = transform.y + scaledYOffset;
        height = scaledYSize;
      } else {
        y = transform.y + scaledYOffset + scaledYSize; // Move start point up
        height = Math.abs(scaledYSize);
      }
    }

    //        return { x, y, width, height };
    let left = x;
    let right = x + width;
    let top = y;
    let bottom = y + height;
    return {
      left,
      right,
      top,
      bottom,
      width,
      height
    };
  },

  // Handle touchZone activation by queueing a request (instance method)
  handleTouchZoneActivation: function(touchZone, touchType, x, y, sendMsg = true) {
    if (!touchZone.cmd) throw new Error('[pfodWebMouse] handleTouchZoneActivation: touchZone.cmd is missing or empty');

    // Skip disabled touchZones
    if (touchZone.filter & TouchZoneFilters.TOUCH_DISABLED) return;

    // Calculate touchZone bounds in canvas coordinates left, rigth, top, bottom, width, height
    const bounds = window.pfodWebMouse.calculateTouchZoneBounds.call(this, touchZone);
    // apply min extra
    //    bounds.left -= colHalf9mm;
    //    bounds.right += colHalf9mm;
    //    bounds.top -= rowHalf9mm;
    //    bounds.bottom += rowHalf9mm;
    //    bounds.width = bounds.right - bounds.left;
    //    bounds.height = bounds.bottom - bounds.top;

    // Get the original touchZone dimensions (unscaled)
    const xSize = parseFloat(touchZone.xSize || 1);
    const ySize = parseFloat(touchZone.ySize || 1);

    // Convert global coordinates to touchZone-relative coordinates
    // First, get the position within the rendered (scaled) touchZone
    const relativeX = x - bounds.left;
    const relativeY = y - bounds.top;

    // Scale to original touchZone coordinate system.
    // For negative sizes the zone extends in the negative direction, so the
    // screen-top of the rendered zone maps to the most-negative drawing coord.
    const scaledCol = (relativeX / bounds.width) * Math.abs(xSize);
    const scaledRow = (relativeY / bounds.height) * Math.abs(ySize);

    let col = xSize < 0 ? Math.floor(xSize + scaledCol) : Math.floor(scaledCol);
    let row = ySize < 0 ? Math.floor(ySize + scaledRow) : Math.floor(scaledRow);

    // Clamp to [min, max] where min/max depend on the sign of each size.
    const colMin = Math.min(0, xSize);
    const colMax = Math.max(0, xSize);
    const rowMin = Math.min(0, ySize);
    const rowMax = Math.max(0, ySize);
    if (col < colMin) col = colMin;
    if (col > colMax) col = colMax;
    if (row < rowMin) row = rowMin;
    if (row > rowMax) row = rowMax;

    console.log(`[TOUCH_ZONE} TouchZone activated: cmd=${touchZone.cmd}, touchType=${touchType}`);
    console.log(`Global coords: (${x}, ${y}), TouchZone bounds: (${bounds.left}, ${bounds.top}, ${bounds.width}, ${bounds.height})`);
    console.log(`Original size: ${xSize}x${ySize}, Displayed size: ${bounds.width}x${bounds.height}`);
    console.log(`Relative coords: (${relativeX}, ${relativeY}), Scaled: (${scaledCol}, ${scaledRow})`);
    console.log(`[TOUCH_ZONE]  Cell index: col=${col}, row=${row} (range 0,0 to ${xSize},${ySize})`);

    // Get the drawing name (the menuDwg this touch belongs to) — set on the
    // per-item canvas proxy by setupMenuCanvasListeners.  The backup object
    // deliberately carries no drawingName field (see redraw.makeBackup).
    const drawingName = this._menuDrawingName;

    // Check for touchActionInput first - it runs before other touchActions.
    // touchActionBackups may legitimately be null here — handleMouseDown
    // only creates one when this zone actually has a touchAction/
    // touchActionInput, so "no backup" just means "neither exists".
    const backupForActivation = window.pfodWebMouse.touchActionBackups;
    const touchActionInput = backupForActivation
      ? (backupForActivation.allTouchActionInputsByCmd[drawingName] || {})[touchZone.cmd]
      : undefined;
    if (touchActionInput) {
      console.log(`[TOUCH_ACTION_INPUT] Found touchActionInput for cmd=${touchZone.cmd}`);
      window.pfodWebMouse.executeTouchActionInput.call(this, drawingName, touchZone.cmd, touchActionInput, col, row, touchType);
      return; // touchActionInput handles its own execution flow
    }

    // Execute touchAction if it exists for this cmd clears before starting
    window.pfodWebMouse.executeTouchAction.call(this, drawingName, touchZone.cmd, col, row, touchType);
    if (sendMsg) {
      // Build the command for the touchZone event
      // For touchZone actions, include col, row, touchType inside the command
      // Use dynamic identifier from calling context (this.currentIdentifier)
      const identifier = this.currentIdentifier;
      let touchZoneCmd = `{${identifier}~${touchZone.cmd}\`${col}\`${row}\`${touchType}}`;

      // Add version to command if available
      const savedVersion = localStorage.getItem(`${drawingName}_version`);
      console.log(`[TOUCH_ACTION_QUEUE] drawingName: ${drawingName}, savedVersion: "${savedVersion}"`);
      if (savedVersion !== null) {
        touchZoneCmd = '{' + savedVersion + ':' + touchZoneCmd.substring(1);
        console.log(`[TOUCH_ACTION_QUEUE] Added version to command: ${touchZoneCmd}`);
      }

      console.log(`[TOUCH_ACTION_QUEUE] command: ${touchZoneCmd}`);

      // Set up request options - will be corrected by addToRequestQueue for cross-origin
      const options = {
        headers: {
          'Accept': 'application/json',
          'X-Requested-With': 'XMLHttpRequest'
        },
        mode: 'same-origin',
        credentials: 'same-origin',
        cache: 'no-cache'
      };

      // Add to the request queue with touchZone info for drag optimization.
      // sourceDwgName is the drawing the touched zone belongs to (stamped as
      // parentDrawingName when its drawing's response was processed).  The
      // response's dwg update carries no drawing identity and the cmd only
      // names the menu item, so the request carries the source dwg for the
      // response to be applied to.
      this.addToRequestQueue(touchZoneCmd, options, {
        cmd: touchZone.cmd,
        filter: touchType,
        sourceDwgName: touchZone.parentDrawingName
      }, 'touch');
    }
  },

  // Execute touchAction when touchZone is activated
  executeTouchAction: function(drawingName, cmd, col, row, touchType) {
    console.info(`[TOUCH_ACTION] executeTouchAction Checking for touchAction: drawing=${drawingName}, cmd=${cmd} touchType=${touchType}`);

    // REQUIREMENT: Always start from basic (untouched) drawing
    // Only make backup once - don't restore during drag operations

    // Get the touchAction for this cmd from merged data. touchActionBackups
    // may legitimately be null here — handleMouseDown only creates one
    // when this zone actually has a touchAction/touchActionInput, so "no
    // backup" just means there's nothing to find.
    const touchActionsByCmdForDwg = window.pfodWebMouse.touchActionBackups
      ? (window.pfodWebMouse.touchActionBackups.allTouchActionsByCmd[drawingName] || {})
      : {};
    console.info(`[TOUCH_ACTION] Available touchActions for "${drawingName}":`, Object.keys(touchActionsByCmdForDwg));
    const touchActions = touchActionsByCmdForDwg[cmd];

    if (!touchActions || touchActions.length === 0) {
      console.info(`[TOUCH_ACTION] No touchAction found for cmd=${cmd}, drawing=${drawingName}`);
      return;
    }

    console.info(`[TOUCH_ACTION] Found touchAction with ${touchActions.length} actions for cmd=${cmd}, touchType=${touchType}`);
    console.info(`[TOUCH_ACTION] TouchActions for cmd=${cmd}:`, touchActions);

    

    // Get the backup before creating the pseudo response
    const backup = window.pfodWebMouse.touchActionBackups;
    console.info(`[TOUCH_ACTION] Backup exists:`, !!backup);
    if (backup) {
      const dwg = drawingName;
      console.info(`[TOUCH_ACTION] Backup contains for "${dwg}": unindexed=${backup.allUnindexedItems?.[dwg]?.length || 0}, indexed=${Object.keys(backup.allIndexedItemsByNumber?.[dwg] || {}).length}, touchZones=${Object.keys(backup.allTouchZonesByCmd?.[dwg] || {}).length}`);
    }
    
    // Create a pseudo update response with the touchAction items
    const backupIndexedForDwg = backup.allIndexedItemsByNumber[drawingName] || {};
    const pseudoUpdateResponse = {
      pfodDrawing: 'update',
      name: drawingName,
      items: touchActions.map(actionItem => {
        const item = JSON.parse(JSON.stringify(actionItem));

        if (item.idx !== undefined) {
          const backupIndexedItem = backupIndexedForDwg[item.idx];
          if (!backupIndexedItem) {
            console.info(`[TOUCH_ACTION] Processing touchAction but no dwg item for this index`, JSON.stringify(item,null,2));
            return null; // Return null for invalid items, they'll be filtered out
          }
          console.info(`[TOUCH_ACTION] Processing touchAction to update `, JSON.stringify(backupIndexedItem,null,2));
          
          // Apply special touchZone values if they exist (support both string and numeric formats)
          if (item.xOffset === 'COL' || item.xOffset === TouchZoneSpecialValues.TOUCHED_COL) {
            item.xOffset = col;
            console.info(`[TOUCH_ACTION] Replaced xOffset COL with ${col}`);
          } else if (item.xOffset === 'ROW' || item.xOffset === TouchZoneSpecialValues.TOUCHED_ROW) {
            item.xOffset = row;
            console.info(`[TOUCH_ACTION] Replaced xOffset ROW with ${row}`);
          }
          if (item.yOffset === 'ROW' || item.yOffset === TouchZoneSpecialValues.TOUCHED_ROW) {
            item.yOffset = row;
            console.info(`[TOUCH_ACTION] Replaced yOffset ROW with ${row}`);
          } else if (item.yOffset === 'COL' || item.yOffset === TouchZoneSpecialValues.TOUCHED_COL) {
            item.yOffset = col;
            console.info(`[TOUCH_ACTION] Replaced yOffset COL with ${col}`);
          }

                    // Apply special touchZone values if they exist (support both string and numeric formats)
          if (item.xSize === 'COL' || item.xSize === TouchZoneSpecialValues.TOUCHED_COL) {
            item.xSize = col;
            console.info(`[TOUCH_ACTION] Replaced xSize COL with ${col}`);
          } else if (item.xSize === 'ROW' || item.xSize === TouchZoneSpecialValues.TOUCHED_ROW) {
            item.xSize = row;
            console.info(`[TOUCH_ACTION] Replaced xSize ROW with ${row}`);
          }
          if (item.ySize === 'ROW' || item.ySize === TouchZoneSpecialValues.TOUCHED_ROW) {
            item.ySize = row;
            console.info(`[TOUCH_ACTION] Replaced ySize ROW with ${row}`);
          } else if (item.ySize === 'COL' || item.ySize === TouchZoneSpecialValues.TOUCHED_COL) {
            item.ySize = col;
            console.info(`[TOUCH_ACTION] Replaced ySize COL with ${col}`);
          }

          // Apply special touchZone values for intValue if item is a value type
          if (item.type === 'value' && item.intValue !== undefined) {
            if (item.intValue === 'COL' || item.intValue === TouchZoneSpecialValues.TOUCHED_COL) {
              item.intValue = col;
              console.info(`[TOUCH_ACTION] Replaced intValue COL with ${col}`);
            } else if (item.intValue === 'ROW' || item.intValue === TouchZoneSpecialValues.TOUCHED_ROW) {
              item.intValue = row;
              console.info(`[TOUCH_ACTION] Replaced intValue ROW with ${row}`);
            }
          }

          // Add transform and clipRegion from backup
          item.transform = backupIndexedItem.transform;// || { x: 0, y: 0, scale: 1 };
          item.clipRegion = backupIndexedItem.clipRegion;// || { x: 0, y: 0, width: 100, height: 20 };
          
          console.info(`[TOUCH_ACTION] Processing touchAction as pseudo update `, JSON.stringify(item,null,2));
          return item;
          
        } else {
          console.info(`[TOUCH_ACTION] Processing touchAction but it has no index`, JSON.stringify(item,null,2));
          return null; // Return null for items without index
        }
      }).filter(item => item !== null)
    };

    console.info(`[TOUCH_ACTION] Processing touchAction as pseudo update with ${pseudoUpdateResponse.items.length} items`);

    // Create a working copy of the menuDwg's merged backup to apply touchAction
    // changes, then hand it to the renderer.  Field names match what
    // Redraw.redrawWithWorkingCopy expects (flat allXXX, single drawing).
    const workingCopy = {
      allUnindexedItems:       JSON.parse(JSON.stringify(backup.allUnindexedItems[drawingName]         || [])),
      allIndexedItemsByNumber: JSON.parse(JSON.stringify(backup.allIndexedItemsByNumber[drawingName]   || {})),
      allTouchZonesByCmd:      JSON.parse(JSON.stringify(backup.allTouchZonesByCmd[drawingName]        || {}))
    };
    console.log(`[TOUCH_ACTION_DEBUG] Created working copy for "${drawingName}" - unindexed: ${workingCopy.allUnindexedItems.length}, indexed keys: [${Object.keys(workingCopy.allIndexedItemsByNumber).join(', ')}], touchZones: [${Object.keys(workingCopy.allTouchZonesByCmd).join(', ')}]`);


    // Apply touchAction changes to the working copy using the processed items from pseudoUpdateResponse
    pseudoUpdateResponse.items.forEach(processedItem => {
      console.info(`[TOUCH_ACTION] Applying processed item to working copy:`, JSON.stringify(processedItem, null, 2));

      // Handle hide/unhide items specially - they modify target item visibility instead of replacing the item
      if (processedItem.idx !== undefined) {
        if (processedItem.type === 'hide' || processedItem.type === 'unhide') {
          const targetItem = workingCopy.allIndexedItemsByNumber[processedItem.idx];
          if (targetItem) {
            const newVisible = (processedItem.type === 'unhide');
            console.info(`[TOUCH_ACTION] ${processedItem.type === 'unhide' ? 'Unhiding' : 'Hiding'} item ${processedItem.idx}: setting visible from ${targetItem.visible} to ${newVisible}`);
            targetItem.visible = newVisible;
          } else {
            console.info(`[TOUCH_ACTION] ${processedItem.type} operation: No item found with idx=${processedItem.idx} to ${processedItem.type === 'unhide' ? 'unhide' : 'hide'}`);
          }
        } else {
          // Normal item replacement for non-hide/unhide items
          workingCopy.allIndexedItemsByNumber[processedItem.idx] = processedItem;
          console.info(`[TOUCH_ACTION] Updated working copy indexed item ${processedItem.idx} with processed touchAction item`);
          console.log(`[TOUCH_ACTION_DEBUG] Working copy item ${processedItem.idx} after update:`, JSON.stringify(workingCopy.allIndexedItemsByNumber[processedItem.idx], null, 2));
        }
      }
    });


    // Trigger a redraw to show the touchAction effects using the new direct redraw method
    console.info(`[TOUCH_ACTION] Triggering redraw to display touchAction effects using working copy`);
    console.info(`[TOUCH_ACTION] Working copy contains: unindexed=${workingCopy.allUnindexedItems.length}, indexed=${Object.keys(workingCopy.allIndexedItemsByNumber).length}, touchZones=${Object.keys(workingCopy.allTouchZonesByCmd).length}`);
    this.redraw.redrawWithWorkingCopy(workingCopy, drawingName);
    console.info(`[TOUCH_ACTION] Redraw completed`);
  },

  // Execute touchActionInput - opens text dialog and handles response
  executeTouchActionInput: function(drawingName, cmd, touchActionInput, col, row, touchType) {
    console.log(`[TOUCH_ACTION_INPUT] Executing touchActionInput: cmd=${cmd}, prompt="${touchActionInput.prompt}", textIdx=${touchActionInput.textIdx}`);

    // Get initial text from textIdx if specified
    let initialText = '';
    if (touchActionInput.textIdx !== undefined && touchActionInput.textIdx !== null) {
      const indexedItems = window.pfodWebMouse.touchActionBackups.allIndexedItemsByNumber[drawingName] || {};
      const item = indexedItems[touchActionInput.textIdx];
      if (item && (item.type === 'label' || item.type === 'value')) {
        if (item.type === 'label') {
          // Generate label text using same utility as drawLabel and displayTextUtils
          initialText = addFormattedValueToText(item.text || '', item);
        } else if (item.type === 'value') {
          // For value items, get the displayed text (prefix + scaled value + units)
          const prefix = substituteUnsupportedUnitsGlyphs(item.text || '');
          const intValue = parseFloat(item.intValue || 0);
          const min = parseFloat(item.min || 0);
          const max = parseFloat(item.max || 1);
          const displayMin = parseFloat(item.displayMin || 0.0);
          const displayMax = parseFloat(item.displayMax || 1.0);
          const decimals = parseInt(item.decimals || 2);
          const units = substituteUnsupportedUnitsGlyphs(item.units || '');

          // Calculate scaled value using same logic as drawValue
          let maxMin = max - min;
          if (maxMin === 0) maxMin = 1;
          const scaledValue = (intValue - min) * (displayMax - displayMin) / maxMin + displayMin;

          initialText = prefix + printFloatDecimals(scaledValue, decimals) + units;
        }
        console.log(`[TOUCH_ACTION_INPUT] Retrieved initial text from textIdx ${touchActionInput.textIdx} (${item.type}): "${initialText}"`);
      } else {
        console.log(`[TOUCH_ACTION_INPUT] textIdx ${touchActionInput.textIdx} not found or not label/value, using blank text`);
      }
    }

    // Create and show text input dialog with formatting options
    const formatOptions = {
      fontSize: touchActionInput.fontSize,
      color: touchActionInput.color,
      backgroundColor: touchActionInput.backgroundColor
    };
    console.log(`[TOUCH_ACTION_INPUT] Format options:`, formatOptions);

    // Set flag to indicate touchActionInput dialog is open
    window.pfodWebMouse.touchActionInputOpen = true;
    console.log(`[TOUCH_ACTION_INPUT] Set touchActionInputOpen flag to true`);

    window.pfodWebMouse.showTextInputDialog.call(this, touchActionInput.prompt, initialText, formatOptions, (result, text) => {
      console.log(`[TOUCH_ACTION_INPUT] Dialog result: ${result}, text: "${text}"`);

      // Clear the dialog flag now that dialog has closed and we're processing the result
      window.pfodWebMouse.touchActionInputOpen = false;
      console.log(`[TOUCH_ACTION_INPUT] Cleared touchActionInputOpen flag`);

      if (result === 'ok') {
        // Build command with the edited text included
        // For touchActionInput, include col, row, touchType, and editedText inside the command
        // Use dynamic identifier from calling context (this.currentIdentifier)
        const identifier = this.currentIdentifier;
        let touchZoneCmd = `{${identifier}~${cmd}\`${col}\`${row}\`${touchType}~${text}}`;

        // Add version to command if available
        const savedVersion = localStorage.getItem(`${drawingName}_version`);
        console.log(`[TOUCH_ACTION_INPUT] drawingName: ${drawingName}, savedVersion: ${savedVersion}`);
        if (savedVersion !== null) {
          touchZoneCmd = '{' + savedVersion + ':' + touchZoneCmd.substring(1);
          console.log(`[TOUCH_ACTION_INPUT] Added version to command: ${touchZoneCmd}`);
        }

        console.log(`[TOUCH_ACTION_INPUT] command: ${touchZoneCmd}`);
        console.log(`[TOUCH_ACTION_INPUT] Sending request with edited text: ${touchZoneCmd}`);

        // Queue the request with proper headers
        const options = {
          headers: {
            'Accept': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
          },
          mode: 'same-origin',
          credentials: 'same-origin',
          cache: 'no-cache'
        };
        this.addToRequestQueue(touchZoneCmd, options, {
          cmd: cmd,
          filter: touchType
        }, 'touch');

        // After the text input is confirmed, run any other touchActions for this cmd
        // clears before starting to show actions
        window.pfodWebMouse.executeTouchAction.call(this, drawingName, cmd, col, row, touchType);
      } else {
        console.log(`[TOUCH_ACTION_INPUT] User cancelled text input, no request sent`);
        // Resume refresh after dialog closes if mouse is not down
        // The dialog closure does not trigger a mouse event, so we need to manually resume
        if (!this.touchState.isDown) {
          console.log(`[TOUCH_ACTION_INPUT] Resuming refresh after cancel (mouse not down)`);
          this.scheduleNextUpdate();
        } else {
          console.log(`[TOUCH_ACTION_INPUT] Mouse still down after cancel - refresh will resume on mouse up`);
        }
      }
    });
  },

  // Show text input dialog within canvas bounds
  showTextInputDialog: function(prompt, initialText, formatOptions, callback) {
    // Handle the case where formatOptions is actually the callback (backward compatibility)
    if (typeof formatOptions === 'function') {
      callback = formatOptions;
      formatOptions = {};
    }
    console.log(`[DIALOG] showTextInputDialog called with prompt="${prompt}", formatOptions:`, formatOptions);
    // Remove any existing dialog
    window.pfodWebMouse.hideTextInputDialog.call(this);

    // Get canvas bounds for positioning
    const canvasRect = this.canvas.getBoundingClientRect();

    // Calculate dialog position within canvas bounds - reduced width by half
    const dialogWidth = Math.min(250, canvasRect.width * 0.4);
    const dialogHeight = 'auto'; // Let content determine height
    const dialogX = canvasRect.left + (canvasRect.width - Math.min(250, canvasRect.width * 0.4)) / 2;
    const dialogY = canvasRect.top + (canvasRect.height * 0.3); // Position higher for better visibility

    // Create dialog container
    const dialog = document.createElement('div');
    dialog.style.position = 'fixed';
    dialog.style.left = dialogX + 'px';
    dialog.style.top = dialogY + 'px';
    dialog.style.width = dialogWidth + 'px';
    dialog.style.minWidth = '150px';
    dialog.style.maxWidth = '250px';
    dialog.style.height = 'auto';
    dialog.style.minHeight = '150px';
    dialog.style.backgroundColor = '#f0f0f0';
    dialog.style.border = '2px solid #666';
    dialog.style.borderRadius = '8px';
    dialog.style.padding = '15px';
    dialog.style.boxShadow = '0 4px 8px rgba(0,0,0,0.3)';
    dialog.style.zIndex = '1000';
    dialog.style.fontFamily = "'Roboto', Arial, sans-serif";
    dialog.style.fontSize = '14px';

    // Create title with formatting — inline pfod tags (<b>, <i>, <u>, <+N>, <-N>,
    // <colour>, <bw>) embedded in the prompt are parsed by pfodSetFormattedText so a
    // prompt like "A <+3>Large Text" renders mixed-size text.  Only <bg N> is parsed
    // up-front by webTranslator (it sets the title's element background, which has no
    // inline equivalent) and arrives here as formatOptions.backgroundColor.
    const title = document.createElement('div');
    title.style.padding = '10px';
    title.style.marginBottom = '10px';
    title.style.borderRadius = '4px';
    title.style.wordWrap = 'break-word';
    // title.style.color is set below, once contrastHex is resolved.

    console.log(`[DIALOG] Applying formatting options:`, formatOptions);

    // Resolve title background — default white when no <bg N> was supplied
    let titleBgHex = '#ffffff';
    if (formatOptions.backgroundColor !== undefined) {
      try {
        titleBgHex = convertColorToHex(formatOptions.backgroundColor);
        console.log(`[DIALOG] Setting backgroundColor to ${titleBgHex} (from ${formatOptions.backgroundColor})`);
      } catch (error) {
        console.error(`[DIALOG] Error getting backgroundColor hex for ${formatOptions.backgroundColor}:`, error);
      }
    }
    title.style.backgroundColor = titleBgHex;

    // Base text colour for the prompt (also what any inline <bw> tag in the
    // prompt resolves against). Checked against pfodWebDesigner/src/
    // pfodWebMouse.js:1077-1088 (the reference implementation): use the
    // touchActionInput's own declared colour (formatOptions.color) when
    // specified; when it's not, fall back to BLACK_WHITE — an automatic
    // black/white contrast chosen against the title's own background —
    // rather than a hardcoded black. Matches every other item colour
    // field's "unspecified -> BLACK_WHITE" default (see
    // dwgDesigner/dwgValidate.js's DWG_COLOUR_BLACKWHITE).
    let contrastHex;
    try {
      contrastHex = convertColorToHex(
        formatOptions.color !== undefined ? formatOptions.color : -1, titleBgHex);
    } catch (error) {
      console.error(`[DIALOG] Error getting color hex for ${formatOptions.color}:`, error);
      contrastHex = xtermColorToHex(getBlackWhite(titleBgHex));
    }
    // pfodSetFormattedText only applies contrastHex to text covered by an
    // inline <bw> tag (see its own doc comment) — it does NOT set the
    // container's base colour. Every other caller in this codebase
    // (pfodButtonRenderer.js, e.g. lines 331-332, 387-388, 550, 1018)
    // explicitly sets `el.style.color = contrastHex` itself for exactly
    // this reason; missing that step here is why plain (untagged) prompt
    // text stayed hardcoded black regardless of what contrastHex resolved
    // to — invisible on a black/dark background.
    title.style.color = contrastHex;

    // Dialog font-size resolver: pixel-based, matching the dialog's fixed 14 px chrome.
    // (Buttons use the default vw-scaling resolver inside pfodSetFormattedText.)
    const dialogFontResolver = function(deltaSize) {
      return getActualFontSizeForDialog(deltaSize) + 'px';
    };

    // Render prompt with inline format tag support.  An empty / missing prompt is
    // tolerated — pfodSetFormattedText short-circuits on falsy input.
    pfodSetFormattedText(title, prompt, contrastHex, dialogFontResolver);

    dialog.appendChild(title);

    // Create text input
    const input = document.createElement('input');
    input.type = 'text';
    // Auto-unescape the 5 restricted chars ({ } | ` ~) so the user edits the
    // true current text, not escape codes — see escapeDocs.txt and
    // _pfodDwgUnescapeRestrictedChars's own doc comment.
    input.value = _pfodDwgUnescapeRestrictedChars(initialText);
    input.maxLength = 255;
    input.style.width = '100%';
    input.style.padding = '6px';
    input.style.fontSize = '14px';
    input.style.border = '1px solid #ccc';
    input.style.borderRadius = '4px';
    input.style.marginBottom = '10px';
    input.style.boxSizing = 'border-box';
    dialog.appendChild(input);

    // Live \uXXXX -> Unicode-char conversion as the user types, matching
    // String Input screens (pfodInputDisplay.js's _handleInput) — same
    // regex, same cursor-shift compensation for the 6-char->1-char shrink.
    input.addEventListener('input', () => {
      const selStart = input.selectionStart;
      let cursorShift = 0;
      const val = input.value.replace(/\\u([0-9a-fA-F]{4})/g, (match, hex, offset) => {
        const ch = String.fromCodePoint(parseInt(hex, 16));
        if (offset < selStart - cursorShift) {
          cursorShift += 5; // match.length(6) - ch.length(1)
        }
        return ch;
      });
      if (val !== input.value) {
        input.value = val;
        const newCursor = Math.max(0, selStart - cursorShift);
        input.setSelectionRange(newCursor, newCursor);
      }
    });

    // Create button container
    const buttonContainer = document.createElement('div');
    buttonContainer.style.display = 'flex';
    buttonContainer.style.gap = '10px';
    buttonContainer.style.justifyContent = 'space-between';

    // Create cancel button
    const cancelButton = document.createElement('button');
    cancelButton.textContent = 'Cancel';
    cancelButton.style.padding = '8px 16px';
    cancelButton.style.border = '1px solid #666';
    cancelButton.style.borderRadius = '4px';
    cancelButton.style.backgroundColor = 'white';
    cancelButton.style.color = '#000';
    cancelButton.style.cursor = 'pointer';
    cancelButton.style.fontSize = '10px';

    // Create OK button with tick and blue background
    const okButton = document.createElement('button');
    okButton.textContent = '✓ OK';
    okButton.style.padding = '8px 16px';
    okButton.style.border = '1px solid #0066cc';
    okButton.style.borderRadius = '4px';
    okButton.style.backgroundColor = '#0066cc';
    okButton.style.color = 'white';
    okButton.style.cursor = 'pointer';
    okButton.style.fontSize = '10px';

    buttonContainer.appendChild(cancelButton);
    buttonContainer.appendChild(okButton);
    dialog.appendChild(buttonContainer);

    // Event handlers
    const handleOk = () => {
      // Auto-escape the 5 restricted chars ({ } | ` ~) before sending, per
      // escapeDocs.txt — unlike plain String Input screens, TouchActionInput
      // dialogs escape the user's typed text automatically.
      const text = _pfodDwgEscapeRestrictedChars(input.value);
      window.pfodWebMouse.hideTextInputDialog.call(this);
      callback('ok', text);
    };

    const handleCancel = () => {
      window.pfodWebMouse.hideTextInputDialog.call(this);
      callback('cancel', '');
    };

    okButton.addEventListener('click', handleOk);
    cancelButton.addEventListener('click', handleCancel);

    input.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        handleOk();
      }
    });

    // Add to page and focus.
    //
    // focus() must be deferred out of the current event dispatch.  For a
    // TOUCH/DOWN filtered touchZone this dialog is built on the canvas
    // mousedown call stack (handleMouseDown -> handleTouchZoneActivation ->
    // executeTouchActionInput -> here), and the browser applies its own focus
    // change as that mousedown's default action once the handler returns —
    // taking focus straight back off the input.  select() had still marked the
    // text, so the field looked fully selected while keystrokes went nowhere,
    // and the user's first click in it (landing inside that painted selection,
    // where the collapse is deferred to mouseup for a possible text drag) only
    // placed a caret — the next key was then inserted instead of replacing the
    // apparently selected text.  UP / CLICK / PRESS filtered zones open the
    // dialog after the mousedown default action has already run, so they focus
    // correctly either way and the deferral is a no-op for them.  Same deferral
    // the other dialogs in this codebase use (connectionManager.js:135,
    // messageViewer.js:1020).
    document.body.appendChild(dialog);
    setTimeout(() => {
      input.focus();
      input.select();
    }, 0);

    // Store reference
    this.textInputDialog = dialog;
  },

  // Hide text input dialog
  hideTextInputDialog: function() {
    if (this.textInputDialog) {
      document.body.removeChild(this.textInputDialog);
      this.textInputDialog = null;
    }
    // DO NOT clear touchActionInputOpen flag here - it will be cleared in the callback handler
    // This allows flag to remain true while switching between dialogs
  },


};/*
   pfodMenuParser.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// pfod Menu Parser — parses a pfod menu cmd array into a structured menu object.
//
// Exports:    window.pfodParseMenu(cmdArray) function, window.parsePfodFormatCodes(str) function
// Depends on: pfodColorTagToHex(), PFOD_COLOR_NAME_TO_INDEX from redraw.js (must load first)
// Called by:  responseHandlers.js (processMenuResponse uses window.pfodParseMenu),
//             pfodMenuDisplay.js (show/update use window.pfodParseMenu)

/**
 * Parse pfod format codes from the start of a string.
 * Handles angle-bracket tags: <bg color>, <b>, <i>, <u>, <+N>, <-N>, <colorCode>
 * Also handles bare non-sticky flags after cmd: ! (disable), - (hide), + (flash), @ (sound)
 *
 * @param {string} str - Input string potentially starting with format codes
 * @returns {{bgColor: string|null, textColor: string|null, bold: boolean, italic: boolean,
 *            underline: boolean, fontSize: number, disabled: boolean, hidden: boolean, remaining: string}}
 */
function parsePfodFormatCodes(str) {
    const result = {
        bgColor: null,
        textColor: null,
        bold: false,
        italic: false,
        underline: false,
        fontSize: 0,
        disabled: false,
        hidden: false,
        flash: false,
        sound: false,
        remaining: str
    };

    let s = str;
    let changed = true;
    while (changed && s.length > 0) {
        changed = false;

        if (s.startsWith('<')) {
            // Angle-bracket format code
            const close = s.indexOf('>');
            if (close === -1) break;
            const tag = s.substring(1, close);
            s = s.substring(close + 1);
            changed = true;

            if (tag === 'b') {
                result.bold = true;
            } else if (tag === 'i') {
                result.italic = true;
            } else if (tag === 'u') {
                result.underline = true;
            } else if (tag.startsWith('bg ')) {
                // Background color tag: <bg colorCode>
                const colorStr = tag.substring(3).trim();
                result.bgColor = pfodColorTagToHex(colorStr);
            } else if (/^\+\d+$/.test(tag)) {
                // Font size increase: <+N>
                result.fontSize += parseInt(tag.substring(1), 10);
            } else if (/^-\d+$/.test(tag)) {
                // Font size decrease: <-N>
                result.fontSize -= parseInt(tag.substring(1), 10);
            } else {
                // Try as text color code (named, hex, or palette number)
                const hex = pfodColorTagToHex(tag);
                if (hex) {
                    result.textColor = hex;
                }
                // Unknown tags are silently skipped
            }
        } else if (s.startsWith('!')) {
            // Bare ! after cmd = disabled (non-sticky flag)
            result.disabled = true;
            s = s.substring(1);
            changed = true;
        } else if (s.startsWith('-')) {
            // Bare - after cmd = hidden (non-sticky flag)
            result.hidden = true;
            s = s.substring(1);
            changed = true;
        } else if (s.startsWith('+')) {
            // Bare + after cmd = flash at 1Hz (non-sticky flag)
            result.flash = true;
            s = s.substring(1);
            changed = true;
        } else if (s.startsWith('@')) {
            // Bare @ after cmd = play ping sound on each refresh (non-sticky flag)
            result.sound = true;
            s = s.substring(1);
            changed = true;
        }
    }

    result.remaining = s;
    return result;
}

/**
 * Parse a pfod cmd identifier from the start of a string.
 * A cmd is either '.' or starts with [a-zA-Z_] followed by [a-zA-Z0-9_]*
 *
 * @param {string} str - Input string
 * @returns {{cmd: string, remaining: string}}
 */
function parsePfodCmd(str) {
    if (str.length === 0) {
        return { cmd: '', remaining: str };
    }
    if (str[0] === '.') {
        return { cmd: '.', remaining: str.substring(1) };
    }
    if (!/[a-zA-Z_]/.test(str[0])) {
        return { cmd: '', remaining: str };
    }
    let i = 0;
    while (i < str.length && /[a-zA-Z0-9_]/.test(str[i])) {
        i++;
    }
    return { cmd: str.substring(0, i), remaining: str.substring(i) };
}

/**
 * Parse a single pfod menu item string (must start with '|').
 * Handles all item types: button, label, nav button, drawing item, drawing label,
 * toggle/slider buttons and labels.
 *
 * @param {string} itemStr - Raw item string starting with '|'
 * @param {boolean} [isUpdate=false] - Item belongs to a {;} update rather than a
 *        {,} menu.  In an update a label with no text means "text unchanged"
 *        (pfodMenuDisplay.update merges only non-empty text), so the spacer
 *        rule below must NOT turn it into ' '.
 * @returns {object|null} Parsed item object, or null if invalid
 */
function parsePfodMenuItem(itemStr, isUpdate) {
    if (!itemStr || !itemStr.startsWith('|')) {
        return null;
    }
    let str = itemStr.substring(1); // Remove leading '|'

    // Determine item type from type-prefix characters before the cmd
    let itemType = 'button'; // default

    if (str.startsWith('!+') || str.startsWith('+!')) {
        // Drawing label: non-interactive drawing item
        itemType = 'dwg-label';
        str = str.substring(2);
    } else if (str.startsWith('+')) {
        // Drawing menu item
        itemType = 'dwg';
        str = str.substring(1);
    } else if (str.startsWith('!')) {
        // Label (non-interactive)
        itemType = 'label';
        str = str.substring(1);
    } else if (str.startsWith('^')) {
        // Navigation button
        itemType = 'nav';
        str = str.substring(1);
    }

    // Extract the cmd identifier
    const cmdResult = parsePfodCmd(str);
    const cmd = cmdResult.cmd;
    str = cmdResult.remaining;

    // Drawing items have format: [<format codes>]~loadCmd
    // Format codes (e.g. <bg gy>) may appear between the cmd and the ~loadCmd separator.
    if (itemType === 'dwg' || itemType === 'dwg-label') {
        const fmt = parsePfodFormatCodes(str);
        let remaining = fmt.remaining;
        let loadCmd = '';
        if (!remaining.startsWith('~') && remaining.includes('~')) {
            console.error(`[MENU_PARSER] Unrecognised characters before ~ in dwg item "${itemStr}": "${remaining.substring(0, remaining.indexOf('~'))}"`);
            remaining = remaining.substring(remaining.indexOf('~'));
        }
        if (remaining.startsWith('~')) {
            loadCmd = remaining.substring(1).trim();
        }
        return { type: itemType, cmd: cmd, loadCmd: loadCmd, formats: {
            bgColor: fmt.bgColor,
            textColor: fmt.textColor,
            bold: fmt.bold,
            italic: fmt.italic,
            underline: fmt.underline,
            fontSize: fmt.fontSize,
            disabled: fmt.disabled,
            hidden: fmt.hidden,
            flash: fmt.flash,
            sound: fmt.sound
        }};
    }

    // Parse pre-~ format slot: bare flags and <bg ...> go into slot fmt;
    // ALL other angle-bracket codes (font size, text color, bold/italic/underline)
    // are accumulated into fmt.inlineFmtPrefix, a sticky field (like bgColor)
    // rather than being folded into the text field itself — a {;} update that
    // resends the text but omits these tags must not be read as "clear the
    // formatting" (see the sticky-merge rule in pfodMenuDisplay.js's update()).
    // Renderers prepend inlineFmtPrefix to the first text field themselves, so
    // it still takes effect via pfodSetFormattedText on the text content, not
    // the element container — matching pfodApp behaviour, where <fmt> before ~
    // applies to the text. Only <bg ...> stays a slot attribute because
    // pfodSetFormattedText does not handle it inline.
    const fmt = {
        bgColor: null, textColor: null, bold: false, italic: false,
        underline: false, fontSize: 0, inlineFmtPrefix: '',
        disabled: false, hidden: false, flash: false, sound: false
    };
    while (str.length > 0) {
        if (str[0] === '!') { fmt.disabled = true; str = str.substring(1); }
        else if (str[0] === '-') { fmt.hidden  = true; str = str.substring(1); }
        else if (str[0] === '+') { fmt.flash   = true; str = str.substring(1); }
        else if (str[0] === '@') { fmt.sound   = true; str = str.substring(1); }
        else if (str[0] === '<') {
            const close = str.indexOf('>');
            if (close === -1) break;
            const tag     = str.substring(1, close);
            const fullTag = str.substring(0, close + 1);
            str = str.substring(close + 1);
            if (tag.startsWith('bg ')) {
                fmt.bgColor = pfodColorTagToHex(tag.substring(3).trim());
            } else {
                fmt.inlineFmtPrefix += fullTag;
            }
        } else {
            break;
        }
    }

    // Collect backtick (integer) and tilde (text) fields in the order they appear.
    // Text fields are interpreted positionally regardless of whether they appear before
    // or after backtick fields:
    //   textFields[0] = leading
    //   textFields[1] = trailing
    //   textFields[2] = maxScaleStr
    //   textFields[3] = minScaleStr
    // To omit trailing while still specifying maxScale, the device must emit an empty
    // ~ field for trailing so the positional count stays correct.
    const intFields = [];
    const textFields = [];
    while (str.length > 0) {
        // Skip whitespace before each separator.  pfodDesignerV2 emits
        // e.g. `|OB<bg bk> `<setter>~…` (PulseMsgProcessor.java line
        // 261) where a literal space sits between the format slot and
        // the first backtick.  pfodApp tolerates the space; without
        // this skip pfodWeb would never enter the int-field loop and
        // toggle/slider detection would fail.
        while (str.length > 0 && (str[0] === ' ' || str[0] === '\t')) {
            str = str.substring(1);
        }
        if (str.length === 0) break;
        if (str[0] !== '`' && str[0] !== '~') break;
        const isInt = str[0] === '`';
        str = str.substring(1);
        const end = str.search(/[`~]/);
        const fieldEnd = end === -1 ? str.length : end;
        const field = str.substring(0, fieldEnd);
        // Int field contents get trimmed before consumers parseInt
        // them — Java sometimes emits the int with surrounding
        // whitespace (e.g. PulseMsgProcessor pads via the same
        // formatting helpers it uses for text).  parseInt's own
        // whitespace skipping handles leading-space-then-digits but
        // misses cases where the trim should normalise other
        // consumers reading the raw field too.  Text fields are
        // left intact — spaces inside `~ min~9` etc. are meaningful.
        if (isInt) intFields.push(field.trim());
        else       textFields.push(field);
        str = str.substring(fieldEnd);
    }

    // Spacer rule (spacerChanges.txt): a label item with no visible text —
    // covering all six forms:
    //   |!<cmd>|            |!<cmd><fmt>|
    //   |!<cmd>~|           |!<cmd><fmt>~|
    //   |!<cmd>~<fmt>|      |!<cmd><fmt>~<fmts>|
    // In the last two cases textFields[0] contains only format-code tags
    // (e.g. "<bg gy>") with no actual text remaining after stripping them.
    // All are normalised to a single-space so the element is visible.
    // Without any text pfodApp does not show the label at all.
    // Only applied before toggle/slider promotion so toggle-labels and
    // numeric-slider-labels are unaffected.
    //
    // Never applied to a {;} update: there `|!<cmd>` with no text is the
    // generated sendMainMenuUpdate()'s way of saying "leave the label as it
    // is", and normalising it to ' ' would make the merge replace the real
    // text with a blank.
    if (itemType === 'label' && !isUpdate) {
        const raw = textFields.length > 0 ? textFields[0] : '';
        const hasVisibleText = raw !== '' && parsePfodFormatCodes(raw).remaining !== '';
        if (!hasVisibleText) {
            // Append a space rather than replacing so that any inline format
            // codes already in the field (e.g. <+14> for a large spacer) are
            // preserved.  For an empty field this simply yields ' '.
            if (textFields.length === 0) textFields.push(raw + ' ');
            else textFields[0] = raw + ' ';
        }
    }

    // Detect numeric slider: 2+ backtick fields (currentValue, maxValue [, minValue]).
    // minValue defaults to 0 if omitted.
    // maxScaleStr defaults to String(maxValue) if omitted.
    // minScaleStr defaults to String(minValue) if omitted.
    // Check this before toggle detection — numeric slider requires >= 2 intFields (toggle has 1).
    let numericSliderData = null;
    let toggleData = null;
    if (intFields.length >= 2) {
        const currentValue = parseInt(intFields[0], 10);
        const maxValue     = parseInt(intFields[1], 10);
        const rawMinValue  = intFields.length >= 3 ? parseInt(intFields[2], 10) : 0;
        const computedMaxValue = isNaN(maxValue)    ? 100 : maxValue;
        const computedMinValue = isNaN(rawMinValue) ? 0   : rawMinValue;
        numericSliderData = {
            currentValue: isNaN(currentValue) ? 0 : currentValue,
            maxValue:     computedMaxValue,
            minValue:     computedMinValue,
            leading:      textFields[0] !== undefined ? textFields[0] : '',
            trailing:     textFields[1] !== undefined ? textFields[1] : '',
            maxScaleStr:  textFields[2] !== undefined ? textFields[2] : String(computedMaxValue),
            minScaleStr:  textFields[3] !== undefined ? textFields[3] : String(computedMinValue),
            // 5th tilde field: 's' = slider only, 't' = text only, '' = both
            format:       textFields[4] !== undefined ? textFields[4].trim() : ''
        };
        if (itemType === 'button') itemType = 'numeric-slider-button';
        else if (itemType === 'label') itemType = 'numeric-slider-label';

    // Detect toggle button/label items: have a backtick-integer index field AND at least
    // 3 tilde-text fields (leading, trailing, options-string [, format]).
    } else if (intFields.length >= 1 && textFields.length >= 3) {
        let optStr = textFields[2];
        // Decode pfod pipe escape (&#124;) so the | split works
        optStr = optStr.replace(/&#124;/g, '|');
        // Split options on | (spec separator, after decoding) or \ (used in practice)
        const options = optStr.includes('|') ? optStr.split('|') : optStr.split('\\');
        // Format field: 't' = text only (no slider), 's' = slider only, else both
        const fmtChar = textFields.length >= 4 ? textFields[3].trim() : '';
        const rawIdx = parseInt(intFields[0], 10);
        toggleData = {
            idx: isNaN(rawIdx) ? 0 : Math.max(0, Math.min(rawIdx, Math.max(0, options.length - 1))),
            options,
            format: fmtChar,
            leading: textFields[0],
            trailing: textFields[1]
        };
        if (itemType === 'button') itemType = 'toggle-button';
        else if (itemType === 'label') itemType = 'toggle-label';
    }

    return {
        type: itemType,
        cmd: cmd,
        formats: {
            bgColor: fmt.bgColor,
            textColor: fmt.textColor,
            bold: fmt.bold,
            italic: fmt.italic,
            underline: fmt.underline,
            fontSize: fmt.fontSize,
            inlineFmtPrefix: fmt.inlineFmtPrefix,
            disabled: fmt.disabled,
            hidden: fmt.hidden,
            flash: fmt.flash,
            sound: fmt.sound
        },
        // Primary display text (first text field)
        text: textFields.length > 0 ? textFields[0] : '',
        // Raw integer fields (for toggle/slider current value, max, min)
        intFields: intFields,
        // All text fields (for toggle options, leading/trailing text, etc.)
        textFields: textFields,
        // Parsed toggle data (null for non-toggle items)
        toggleData: toggleData,
        // Parsed numeric slider data (null for non-numeric-slider items)
        numericSliderData: numericSliderData
    };
}

/**
 * Parse the pfod menu header (first element of the cmd array).
 * Header format: {,[<bgColour>][<promptFormat>]~<title>[`<re-requestTime ms>][~<version>]
 *
 * @param {string} headerStr - Header like "{,<bg s><+2><bl>~this is the prompt`0~V1"
 * @returns {{isUpdate: boolean, bgColor: string|null, promptFormat: object,
 *            title: string, reRequestMs: number, version: string}}
 */
function parsePfodMenuHeader(headerStr) {
    let str = headerStr || '';
    const isUpdate = str.startsWith('{;');

    // Remove the leading {, or {; delimiter
    if (str.startsWith('{,') || str.startsWith('{;')) {
        str = str.substring(2);
    }

    // Parse menu-level format codes (before the first '~')
    const fmt = parsePfodFormatCodes(str);
    str = fmt.remaining;

    // Parse title (after '~')
    let title = '';
    let reRequestMs = null; // null = no backtick field present; 0 = explicitly disabled
    let version = '';

    if (str.startsWith('~')) {
        str = str.substring(1);
        const end = str.search(/[`~]/);
        const titleEnd = end === -1 ? str.length : end;
        title = str.substring(0, titleEnd);
        str = str.substring(titleEnd);
    }

    // Extract backtick re-request field from anywhere in the remaining string.
    // The ` delimiter is unique, so it can appear before or after the version ~field.
    const btIdx = str.indexOf('`');
    if (btIdx !== -1) {
        const afterBt = str.substring(btIdx + 1);
        const numEnd = (function() { const e = afterBt.search(/[`~|]/); return e === -1 ? afterBt.length : e; })();
        const ms = parseInt(afterBt.substring(0, numEnd), 10);
        if (!isNaN(ms)) reRequestMs = ms;
        str = str.substring(0, btIdx) + str.substring(btIdx + numEnd + 1);
    }

    // Parse version string (second '~' field, optional — omitted when version is empty).
    // When title is empty the header has '~~V...' — after title extraction str starts with '~~'.
    // Strip one extra leading '~' so '~~V361' yields 'V361' not '~V361'.
    if (str.startsWith('~')) {
        let v = str.substring(1);
        if (v.startsWith('~')) v = v.substring(1);
        version = v.trim();
    }

    return {
        isUpdate: isUpdate,
        bgColor: fmt.bgColor,
        promptFormat: {
            textColor: fmt.textColor,
            bold: fmt.bold,
            italic: fmt.italic,
            underline: fmt.underline,
            fontSize: fmt.fontSize,
            // Non-sticky flags `+` (flash) and `@` (sound) applied to
            // the screen-format prefix.  pfodMenuDisplay uses these:
            // flash → animates the prompt text on/off; sound → plays
            // the ping sound on each menu render.
            flash: fmt.flash,
            sound: fmt.sound
        },
        title: title,
        reRequestMs: reRequestMs,
        version: version
    };
}

/**
 * Parse a complete pfod menu cmd array into a structured menu object.
 * The cmd array is produced by pfodToJson() which splits the raw pfod message on '|' and '}'.
 *
 * Example input (after pfodToJson split):
 *   ["{,<bg s><+2><bl>~this is the prompt`0~V1",
 *    "|A<bg m><b><u><+2><o>~Button one",
 *    "|+D~z",
 *    "}"]
 *
 * @param {string[]} cmdArray - Array of cmd strings (will NOT be modified - uses a copy)
 * @returns {{header: object, items: object[], hasDrawing: boolean, drawingItems: object[]}}
 */
function pfodParseMenu(cmdArray) {
    const arr = cmdArray.slice(); // Work on a copy so original is unchanged

    // First element is the menu header
    const headerStr = arr.shift() || '';
    const header = parsePfodMenuHeader(headerStr);

    const items = [];
    const drawingItems = [];

    // Parse each remaining element as a menu item (skip closing '}')
    while (arr.length > 0) {
        const itemStr = arr.shift();
        if (!itemStr || itemStr === '}' || itemStr.trim() === '') {
            continue;
        }
        if (!itemStr.startsWith('|')) {
            continue;
        }

        const item = parsePfodMenuItem(itemStr, header.isUpdate);
        if (!item) {
            continue;
        }

        if (item.type === 'dwg' || item.type === 'dwg-label') {
            drawingItems.push(item);
        }
        items.push(item);
    }

    return {
        header: header,
        items: items,
        hasDrawing: drawingItems.length > 0,
        drawingItems: drawingItems
    };
}

// Export all functions globally for use by other modules
window.pfodParseMenu = pfodParseMenu;
window.parsePfodFormatCodes = parsePfodFormatCodes;
window.parsePfodMenuItem = parsePfodMenuItem;
window.parsePfodMenuHeader = parsePfodMenuHeader;
window.parsePfodCmd = parsePfodCmd;
/*
   pfodButtonRenderer.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// pfod Button/Label Renderer — renders pfod menu items as HTML DOM elements.
//
// Exports:    window.applyPfodFormats, window.pfodSetFormattedText,
//             window.renderPfodButton, window.renderPfodLabel,
//             window.renderPfodNavButtons (and other renderPfod* functions)
// Depends on: getActualFontSize(), pfodColorTagToHex() from redraw.js (must load first),
//             parsePfodFormatCodes() from pfodMenuParser.js (must load first)
// Called by:  pfodMenuDisplay.js (uses all renderPfod* functions to build menu DOM)

// Scale factor converting pfod font size units (from getActualFontSize) to
// CSS container-query inline-size units (cqi).  getActualFontSize(0) ≈ 2.832
// (58 × 50 / 1024).  At 1.5 cqi/unit → 2.832 * 1.5 ≈ 4.248 cqi.  Inside
// #menu-container (which sets container-type: inline-size), this resolves
// against the menu's own width (capped 500px) so menu text stops growing
// once the window exceeds the cap.  Outside any container-type ancestor,
// cqi falls back to the small viewport per the CSS Containment spec —
// equivalent to the previous vw behaviour — so chart/input/dialog callers
// render at the same size as before.
const PFOD_FONT_VW_SCALE = 1.5;

/**
 * Apply pfod format styles to an HTML element.
 * Sets background colour, text colour, font weight, style, decoration and size
 * based on the parsed format object from parsePfodFormatCodes().
 *
 * @param {HTMLElement} el - Element to style
 * @param {object} formats - {bgColor, textColor, bold, italic, underline, fontSize}
 */
function applyPfodFormats(el, formats) {
    if (!formats) throw new Error('[pfodButtonRenderer] applyPfodFormats: formats is required');
    if (formats.bgColor) {
        el.style.backgroundColor = formats.bgColor;
    }
    if (formats.textColor) {
        el.style.color = formats.textColor;
    }
    if (formats.bold) {
        el.style.fontWeight = 'bold';
    }
    if (formats.italic) {
        el.style.fontStyle = 'italic';
    }
    if (formats.underline) {
        el.style.textDecoration = 'underline';
    }
    // Only apply non-zero relative font sizes; zero means use the default CSS size
    if (formats.fontSize !== 0) {
        const actualSize = getActualFontSize(formats.fontSize);
        el.style.fontSize = (actualSize * PFOD_FONT_VW_SCALE) + 'cqi';
    }
}

/**
 * Internal tag name a Markdown link is rewritten to before the tag scanner
 * runs: `[text](url)` becomes `<\u0001url>text</\u0001>`, which then opens and
 * closes on the style stack like <b> does.  A control character, so nothing a
 * sketch or the designer can type produces it — and pfod's own <a> (aqua)
 * is never involved.
 */
const PFOD_LINK_TAG = '\u0001';

/**
 * Turn a link url from a label/prompt into the href the anchor gets, or null
 * when there is nothing sensible to point at.
 *
 * Full http(s) urls name their own host and are used as written on every
 * connection type.  A url beginning `/` means a page on the device's own web
 * root, and pfodWeb is not always served by the device it is talking to:
 *   - served by the device (the normal http case): HTTPConnection.baseURL is
 *     '' and location.origin IS the device;
 *   - pfodWeb.html opened elsewhere with ?targetIP=: baseURL is the device's
 *     http://ip:port;
 *   - serial / BLE / proxy / designer: there is no device web root — the
 *     link is dropped and only its text shows.
 * new URL() also normalises dot segments (/a/../b → /b) before any request.
 *
 * @param {string} url  as written in the text (already matched by PFOD_MD_LINK_RE)
 * @returns {string|null}
 */
function pfodLinkHref(url) {
    if (/^https?:\/\//i.test(url)) return url;
    const conn = window.pfodConnectionManager && window.pfodConnectionManager.adapter;
    if (!conn || conn.protocol !== 'http') return null;
    return new URL(url, conn.baseURL || window.location.origin).href;
}

/**
 * Preview-only message for a relative link inside the Designer, when
 * pfodLinkHref() above returned null because there's no real device web
 * root to resolve it against. The Designer is always isolated on its own
 * virtual connection (protocol 'designer', see designer/adapter.js) even
 * when the design's own target connection is HTTP, so a relative link can
 * never actually resolve while designing — but the designer still wants to
 * SEE it as a live-looking link rather than plain text, since it will be
 * a real clickable link once deployed to the device. Returns null (render
 * plain, exactly as before) unless the design's chosen target connection
 * is HTTP.
 *
 * @param {string} url  as written in the text (already matched by PFOD_MD_LINK_RE)
 * @returns {string|null}
 */
function pfodDesignerPreviewLinkMessage(url) {
    const conn = window.pfodConnectionManager && window.pfodConnectionManager.adapter;
    if (!conn || conn.protocol !== 'designer') return null;
    const device = conn.device;
    if (!device || !device.state || device.state.connection !== 'http') return null;
    return url + ' needs to be served from the connected pfodDevice';
}

/**
 * Populate a container element with pfod inline-formatted text.
 * Parses <b>, <i>, <u>, <+N>, <-N>, <colorCode>, </tag> tags within the text string.
 * Closing tags terminate their matching open tag and all tags enclosed within it (stack-based).
 * Unrecognised tags (including <bg ...>) are rendered as literal text.
 * All open tags auto-terminate at end of string.
 * Decodes pfod escape sequences in output text: &#96; &#123; &#124; &#125; &#126;
 *   &lt; &#92; &amp; (decoded in that order so &amp;lt; renders as &lt; not <).
 * Markdown links `[text](url)` (PFOD_MD_LINK_RE, redraw.js) render as a native
 *   <a target="_blank"> only when `allowLinks` is true — menu labels and the
 *   prompt bars, none of which has a click handler of its own, so a tap on a
 *   link can never send a cmd.  Everywhere else the text shows as sent.  In
 *   the Designer, a relative link that can't resolve to a real page still
 *   renders as a live-looking link when the design's target connection is
 *   HTTP — tapping it opens a new tab explaining the path needs a real
 *   device to serve it, rather than showing plain text (pfodDesignerPreviewLinkMessage).
 *
 * @param {HTMLElement} container - Element to populate (existing children are cleared first)
 * @param {string} text - Raw text potentially containing inline format tags and escape sequences
 * @param {string} contrastHex - Auto-contrast colour used when an inline <bw> tag is encountered
 * @param {function} [fontResolver] - Optional function(deltaSize) → CSS size string for
 *        rendering inline <+N>/<-N> tags.  When omitted, defaults to container-query
 *        inline-size scaling (getActualFontSize × PFOD_FONT_VW_SCALE in cqi units), which
 *        falls back to viewport sizing when no container-type ancestor is present.
 *        Dialogs override this to use getActualFontSizeForDialog (base 14 px) so inline
 *        sizes match the dialog's fixed-pixel layout.
 * @param {boolean} [allowLinks=false] - Render `[text](url)` as a link.  Pass true only
 *        from a site with no click handler (labels, prompt bars).
 */
function pfodSetFormattedText(container, text, contrastHex, fontResolver, allowLinks) {
    // Default font size resolver: container-query inline-size scaling.  Inside
    // #menu-container this resolves against the menu width (capped 500px); elsewhere
    // it falls back to viewport sizing, matching the previous vw behaviour.
    const resolveFontSize = fontResolver || function(deltaSize) {
        return (getActualFontSize(deltaSize) * PFOD_FONT_VW_SCALE) + 'cqi';
    };
    container.textContent = '';
    if (!text) return;

    // Roboto has no glyphs for U+2103 (℃) / U+2109 (℉); substitute their
    // Unicode NFKD decomposition (°C / °F) so this matches pfodApp's
    // Android rendering instead of falling back to a different system font.
    text = substituteUnsupportedUnitsGlyphs(text);

    // Pick the actual rendering target.  pfodSetFormattedText is the
    // universal pfod-text renderer used for EVERY formatted-text site
    // (button text, menu-prompt, input/numeric/selection prompts,
    // labels, dialog titles, chart titles, message-log entries — any
    // caller passing a container into here).  When the container is
    // itself a flex/grid layout (e.g. #menu-prompt is column-flex for
    // bottom alignment), text appended directly would have its
    // anonymous text-node / span children promoted to flex items
    // with unpredictable line-break behaviour.  Wrap in an inner
    // <div> so the text lives in normal block-inside-flex context.
    // For non-flex containers (the common case — inline spans,
    // block divs) we render directly; an inner wrapper there would
    // either introduce block-inside-inline or add a pointless layer.
    //
    // EXCEPT when the container is currently `display:none` — that
    // happens transiently during back-nav out of input mode for the
    // menu prompt, and getComputedStyle() returns 'none' so the
    // flex-check fails.  Skipping the wrapper there breaks the
    // post-show layout: each styled span / text node becomes a flex
    // item of the (later-shown) flex container, putting "italic
    // phrase" and "the rest of the line" on separate rows.  Treat
    // 'none' as "unknown" and wrap defensively — an extra div in a
    // block/inline parent is harmless, but skipping it in a flex
    // parent is silently broken.  See pfod-messages
    // 2026-05-29T04-35-49.187Z.csv for the original repro.
    let target = container;
    if (container.isConnected) {
        const display = getComputedStyle(container).display;
        if (display === 'flex'  || display === 'inline-flex' ||
            display === 'grid'  || display === 'inline-grid' ||
            display === 'none') {
            target = document.createElement('div');
            container.appendChild(target);
        }
    }

    // `white-space: pre-wrap` on the rendering target makes every
    // `\n` in the source text render as a visible line break —
    // including trailing `\n`s, which the old `<br>`-based mechanism
    // couldn't anchor (browsers collapse a trailing `<br>` to zero
    // visible space).  Spaces and runs of whitespace are also
    // preserved.  Each `\n` sits inside whichever styled span was
    // open at that point in the text, so font-size / colour / bold
    // / italic / underline carry through to the blank line that
    // follows (per the user-stated rule: any tag still open at the
    // END of the text auto-closes there, so trailing `\n`s belong
    // to the last open span).  Applies universally because this
    // is the universal renderer.
    target.style.whiteSpace = 'pre-wrap';

    // Normalise line endings to LF so newline handling is uniform throughout
    text = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

    // Markdown links: where allowed AND the link is actually operational —
    // either resolvable now (pfodLinkHref) or a Designer preview standing in
    // for a real one (pfodDesignerPreviewLinkMessage) — rewrite to the
    // internal link tag so the scanner below handles it as one more entry
    // on the style stack.  A url never sits between < and >, so the rewrite
    // cannot land inside a tag.  Everywhere else — links disallowed, or a
    // relative link with no device web root and no HTTP-targeted Designer
    // preview to stand in for one (e.g. the Designer's target connection is
    // Serial/BLE/TCP) — the match is left exactly as the device sent it:
    // `[..](..)` shows as written, since a link that can't do anything here
    // is more useful shown as-is than silently reduced to its bare text.
    if (allowLinks) {
        text = text.replace(PFOD_MD_LINK_RE, function(match, linkText, url) {
            const href = pfodLinkHref(url);
            const previewMsg = href ? null : pfodDesignerPreviewLinkMessage(url);
            if (!href && !previewMsg) return match;
            return '<' + PFOD_LINK_TAG + url + '>' + linkText + '</' + PFOD_LINK_TAG + '>';
        });
    }

    // decodeEscapes() is shared with redraw.js's parsePfodInlineSegments
    // (dwg canvas text) — defined once in redraw.js, which loads first.

    // Stack of active open tags — each entry describes the style delta that tag contributes.
    // {tag: string, bold: bool, italic: bool, underline: bool, deltaSize: number, textColor: string, href: string}
    const stack = [];

    // Used to detect whether ALL rendered content ended up in font-size-changed spans,
    // with no segment left at the base (unsized) font size.  When true, renderPfodLabel
    // collapses the block container's line-height strut so line spacing scales with the
    // small font.  hasUnsizedText tracks font-size only (not bold/italic/colour) — a
    // segment can be fully styled (e.g. coloured/bold) and still be "unsized", and a
    // multi-line label can have some lines at the base size and others font-sized (e.g.
    // `<g><b>Title</b>\n<y><-1>subtitle`); collapsing the strut in that mixed case would
    // zero out line spacing for the base-size lines too, making them overlap.
    let hasFontSizeSpan = false;
    let hasUnsizedText  = false;

    // Compute cumulative style from all active stack entries.
    function getCurrentStyle() {
        let bold = false, italic = false, underline = false, fontSize = 0, textColor = null, href = null, previewMsg = null;
        for (const e of stack) {
            if (e.bold)                    bold      = true;
            if (e.italic)                  italic    = true;
            if (e.underline)               underline = true;
            if (e.deltaSize !== undefined) fontSize += e.deltaSize;
            if (e.textColor !== undefined) textColor = e.textColor;
            if (e.href !== undefined)      href      = e.href;
            if (e.previewMsg !== undefined) previewMsg = e.previewMsg;
        }
        return { bold, italic, underline, fontSize, textColor, href, previewMsg };
    }

    // Append a text segment to the target, wrapping in a styled span
    // when any style is active.  `\n` characters in `txt` are
    // preserved verbatim in the text node; the target's
    // `white-space: pre-wrap` (set above) renders them as visible
    // line breaks \u2014 including trailing `\n`s, which belong to the
    // styled span that was open over this segment (so the trailing
    // blank line inherits the current font-size / colour / b/i/u).
    // No <br> emission.  U+0080 (pfod spacer) is still rendered as
    // a visibility:hidden space that occupies width and scales with
    // the current font size, so sized empty-label spacers keep
    // working.
    function appendSegment(txt) {
        if (!txt) return;
        const style = getCurrentStyle();
        const hasStyle = style.bold || style.italic || style.underline
                      || style.fontSize !== 0 || style.textColor;

        function appendRun(run) {
            if (!run) return;
            if (style.fontSize === 0) hasUnsizedText = true;
            let node;
            if (!hasStyle) {
                node = document.createTextNode(decodeEscapes(run));
            } else {
                const span = document.createElement('span');
                span.textContent = decodeEscapes(run);
                if (style.bold)      span.style.fontWeight     = 'bold';
                if (style.italic)    span.style.fontStyle      = 'italic';
                if (style.underline) span.style.textDecoration = 'underline';
                if (style.fontSize !== 0) {
                    span.style.fontSize   = resolveFontSize(style.fontSize);
                    span.style.lineHeight = 'normal'; // proportional to span's own font-size
                    hasFontSizeSpan = true;
                }
                if (style.textColor) span.style.color = style.textColor;
                node = span;
            }
            // Inside a link: a native anchor around the run.  New tab, never
            // this one — navigating pfodWeb's own tab away fires {!} on
            // unload and drops the session.  No click listener: the anchor
            // does the work, and the containers that allow links have no
            // handler of their own for it to fall through to.  Styled by the
            // one a.pfod-link rule in pfodCommon.css.
            if (style.href) {
                const a = document.createElement('a');
                a.className = 'pfod-link';
                a.href = style.href;
                a.target = '_blank';
                a.rel = 'noopener noreferrer';
                a.appendChild(node);
                node = a;
            } else if (style.previewMsg) {
                // Designer preview, target connection HTTP, relative link:
                // there's genuinely nothing to navigate to yet (see
                // pfodDesignerPreviewLinkMessage above), so this is the one
                // link case that DOES need its own click handler — a bare
                // href would either 404 against pfodWeb's own origin or
                // reload/drop the session. preventDefault + a fresh blank
                // tab keeps that off this tab entirely.
                const a = document.createElement('a');
                a.className = 'pfod-link';
                a.href = '#';
                const msg = style.previewMsg;
                a.addEventListener('click', function(e) {
                    e.preventDefault();
                    const w = window.open('', '_blank');
                    if (w) {
                        const p = w.document.createElement('pre');
                        p.style.cssText = 'font:14px sans-serif;padding:16px;white-space:pre-wrap;';
                        p.textContent = msg;
                        w.document.body.appendChild(p);
                    }
                });
                a.appendChild(node);
                node = a;
            }
            target.appendChild(node);
        }

        // Split only on the U+0080 sized-spacer character \u2014 newlines
        // are left in the run text and rendered by pre-wrap.
        const parts = txt.split('\u0080');
        for (let pi = 0; pi < parts.length; pi++) {
            if (pi > 0) {
                const spacer = document.createElement('span');
                spacer.style.visibility = 'hidden';
                if (style.bold)   spacer.style.fontWeight = 'bold';
                if (style.italic) spacer.style.fontStyle  = 'italic';
                if (style.fontSize !== 0) {
                    spacer.style.fontSize = resolveFontSize(style.fontSize);
                }
                spacer.textContent = ' ';
                target.appendChild(spacer);
            }
            appendRun(parts[pi]);
        }
    }

    // Parse an opening tag's content (without angle brackets).
    // Returns a style-delta object for recognised inline format tags, null for unrecognised ones.
    function parseOpenTag(tagContent) {
        // The internal link tag from the Markdown pre-pass above.  The
        // stack entry is named PFOD_LINK_TAG (not the full content) so the
        // pre-pass's </\u0001> closes it.  href is null when there is no
        // device web root to resolve a /path against; in the Designer, with
        // the design's own target connection set to HTTP, that still gets a
        // live-looking (but click-intercepted) link via previewMsg — see
        // pfodDesignerPreviewLinkMessage above. Everywhere else previewMsg
        // is also null and the entry adds no style at all: link text
        // renders plain, exactly as the device sent it.
        if (tagContent.charCodeAt(0) === 1) {
            const rawUrl = tagContent.substring(1);
            const href = pfodLinkHref(rawUrl);
            return {
                tag: PFOD_LINK_TAG,
                href: href,
                previewMsg: href ? null : pfodDesignerPreviewLinkMessage(rawUrl)
            };
        }
        if (tagContent === 'b')  return { bold: true };
        if (tagContent === 'i')  return { italic: true };
        if (tagContent === 'u')  return { underline: true };
        if (/^\+\d+$/.test(tagContent)) return { deltaSize:  parseInt(tagContent.substring(1), 10) };
        if (/^-\d+$/.test(tagContent))  return { deltaSize: -parseInt(tagContent.substring(1), 10) };
        if (tagContent.startsWith('bg ')) return null; // background colour only valid before ~
        if (tagContent === 'bw') return { textColor: contrastHex };
        const hex = pfodColorTagToHex(tagContent);
        if (hex) return { textColor: hex };
        return null;
    }

    let i = 0;
    let segStart = 0;

    while (i < text.length) {
        if (text[i] !== '<') { i++; continue; }

        const closeIdx = text.indexOf('>', i + 1);
        if (closeIdx === -1) { i++; continue; } // unclosed '<' — treat as literal

        const tagContent = text.substring(i + 1, closeIdx);

        if (tagContent.startsWith('/')) {
            // Closing tag: find the innermost matching open tag and pop it plus everything after it
            const closingName = tagContent.substring(1).trim();
            let foundIdx = -1;
            for (let j = stack.length - 1; j >= 0; j--) {
                if (stack[j].tag === closingName) { foundIdx = j; break; }
            }
            if (foundIdx !== -1) {
                appendSegment(text.substring(segStart, i));
                segStart = closeIdx + 1;
                stack.splice(foundIdx);
            }
            // no matching open tag: leave the closing tag text in the current literal segment
            i = closeIdx + 1;
        } else {
            // Opening tag
            const parsed = parseOpenTag(tagContent);
            if (parsed !== null) {
                appendSegment(text.substring(segStart, i));
                segStart = closeIdx + 1;
                if (parsed.tag === undefined) parsed.tag = tagContent;
                stack.push(parsed);
            }
            // unrecognised tag: leave it in the current literal segment
            i = closeIdx + 1;
        }
    }

    // Flush any remaining text after the last recognised tag boundary
    appendSegment(text.substring(segStart));
    // Return true when all rendered content is in font-size-changed spans (no segment
    // left at the base font size), so renderPfodLabel can collapse the container's
    // line-height strut.
    return hasFontSizeSpan && !hasUnsizedText;
}

/**
 * Render a pfod plain button menu item as an HTML button element.
 * Clicking sends the item's cmd string to the provided onClick callback.
 * Disabled items render as visually distinct non-clickable buttons.
 *
 * Text colour and border colour default to <bw> (black or white for best contrast)
 * against the effective background when not explicitly specified by the item's formats.
 *
 * @param {object} item - Parsed menu item (type = 'button')
 * @param {function} onClick - Callback(cmd) invoked when the button is clicked
 * @param {string} [menuBgColor='#000000'] - Menu background colour (hex) used when the
 *        item has no explicit bgColor, to determine the <bw> contrast default.
 * @returns {HTMLButtonElement}
 */
function renderPfodButton(item, onClick, menuBgColor) {
    const btn = document.createElement('button');
    btn.className = 'pfod-menu-button';
    btn.style.whiteSpace = 'pre-wrap';
    // Compute contrast colour first so pfodSetFormattedText can resolve inline <bw> tags.
    // Effective background: item bgColor → menu bg → pfod default black.
    const effectiveBg = item.formats.bgColor || menuBgColor || '#000000';
    const contrastHex = xtermColorToHex(getBlackWhite(effectiveBg));

    // Wrap text in a span so flash animation can target only the text,
    // leaving the button border and background permanently visible.
    const textSpan = document.createElement('span');
    textSpan.className = 'pfod-button-text';
    pfodSetFormattedText(textSpan, item.formats.inlineFmtPrefix + item.text, contrastHex);
    btn.appendChild(textSpan);
    applyPfodFormats(btn, item.formats);

    // Apply <bw> defaults: text and border colour contrast against the effective background.
    if (!item.formats.textColor && !(item.formats && item.formats.disabled)) {
        btn.style.color = contrastHex;
    }
    btn.style.borderColor = contrastHex;

    if (item.formats && item.formats.disabled) {
        btn.disabled = true;
    } else {
        btn.addEventListener('click', function() { onClick(item.cmd); });
    }
    if (item.formats && item.formats.flash) {
        btn.classList.add('pfod-flash');
    }
    return btn;
}

/**
 * Render a pfod label (non-interactive) menu item as an HTML div element.
 * Labels look similar to buttons but do not respond to clicks and have no border.
 *
 * Text colour and border colour default to <bw> (black or white for best contrast)
 * against the effective background when not explicitly specified by the item's formats.
 *
 * @param {object} item - Parsed menu item (type = 'label')
 * @param {string} [menuBgColor='#000000'] - Menu background colour (hex) used when the
 *        item has no explicit bgColor, to determine the <bw> contrast default.
 * @returns {HTMLDivElement}
 */
function renderPfodLabel(item, menuBgColor) {
    const div = document.createElement('div');
    div.className = 'pfod-menu-label';
    // Empty-text label: collapse padding + line-height so it
    // renders as a thin separator line proportional to its
    // font-size (matches pfodDesignerV2's designerSpacing
    // convention — empty text + small font = thin spacer).
    // Class drives the collapse via the matching .pfod-menu-
    // label.pfod-empty-label rule in pfodCommon.css.
    if (!item.text) div.classList.add('pfod-empty-label');
    div.style.whiteSpace = 'pre-wrap';
    // Compute contrast colour first so pfodSetFormattedText can resolve inline <bw> tags.
    const effectiveBg = item.formats.bgColor || menuBgColor || '#000000';
    const contrastHex = xtermColorToHex(getBlackWhite(effectiveBg));

    const textSpan = document.createElement('span');
    textSpan.className = 'pfod-button-text';
    // Labels have no click handler, so a [text](url) link in one can be a
    // real link — nothing a tap can send.
    const allFontSized = pfodSetFormattedText(textSpan, item.formats.inlineFmtPrefix + item.text, contrastHex, undefined, true);
    // When every rendered segment is in an explicit font-size span (no bare text
    // nodes), collapse the block container's strut to 0 so line spacing is
    // governed by each span's own font-size rather than the div's default.
    // Without this, `<-5>line1\nline2` renders with the div's full strut
    // (1.2 × default-font) between lines instead of the small font's spacing.
    if (allFontSized) div.style.lineHeight = '0';
    div.appendChild(textSpan);
    applyPfodFormats(div, item.formats);

    // Apply <bw> default for text colour.
    if (!item.formats.textColor) {
        div.style.color = contrastHex;
    }

    if (item.formats && item.formats.flash) {
        div.classList.add('pfod-flash');
    }
    return div;
}

/**
 * Build the 2-option switch row (opt-label / pill-track+thumb / opt-label).
 * Used when td.options.length === 2.
 *
 * @param {object} td - toggleData from the parsed item
 * @param {boolean} disabled - true for labels and disabled buttons
 * @param {string} contrastHex - colour for opt labels
 * @returns {HTMLDivElement}
 */
function _buildToggleSwitchRow(td, disabled, contrastHex) {
    const row = document.createElement('div');
    row.className = 'pfod-toggle-slider-row';
    row.style.color = contrastHex; // opt labels always use contrast colour

    const leftLbl = document.createElement('span');
    leftLbl.className = 'pfod-toggle-opt-label';
    leftLbl.textContent = substituteUnsupportedUnitsGlyphs(td.options[0] || '');

    const track = document.createElement('div');
    track.className = disabled ? 'pfod-toggle-track pfod-toggle-track-disabled'
                               : 'pfod-toggle-track';
    track.style.background = contrastHex;

    const thumb = document.createElement('div');
    // pfod-toggle-thumb-right positions the thumb at the right end (idx != 0)
    thumb.className = td.idx !== 0 ? 'pfod-toggle-thumb pfod-toggle-thumb-right'
                                   : 'pfod-toggle-thumb';
    thumb.style.background = contrastHex;
    thumb.style.border = '2px solid ' + (contrastHex.toLowerCase() === '#ffffff' ? '#000000' : '#ffffff');
    track.appendChild(thumb);

    const rightLbl = document.createElement('span');
    rightLbl.className = 'pfod-toggle-opt-label';
    rightLbl.textContent = substituteUnsupportedUnitsGlyphs(td.options[td.options.length - 1] || '');

    row.appendChild(leftLbl);
    row.appendChild(track);
    row.appendChild(rightLbl);
    return row;
}

/**
 * Build a full-width slider row for items with more than 2 options.
 * Layout: thin track with proportionally positioned thumb, then a label row
 * below showing the first and last option at each end.
 *
 * Thumb position formula: left = calc(-2px + pct * (100% - 28px))
 *   Thumb overhangs -2px at pct=0 and +2px at pct=1, covering both rounded ends.
 *   and interpolates linearly for intermediate indices.
 *
 * @param {object} td - toggleData from the parsed item
 * @param {boolean} disabled - true for labels and disabled buttons
 * @param {string} contrastHex - colour for opt labels
 * @returns {{container: HTMLDivElement, track: HTMLDivElement, thumb: HTMLDivElement}}
 */
function _buildSliderRow(td, disabled, contrastHex) {
    const pct = td.options.length > 1 ? td.idx / (td.options.length - 1) : 0;

    const container = document.createElement('div');
    container.className = 'pfod-slider-container';

    // hitArea is a tall transparent div (track height + 2×thumb-diameter above and below)
    // that provides a large click target without altering the visual track size.
    const hitArea = document.createElement('div');
    hitArea.className = disabled ? 'pfod-slider-hit-area pfod-slider-hit-area-disabled'
                                 : 'pfod-slider-hit-area';

    const track = document.createElement('div');
    track.className = 'pfod-slider-track';
    track.style.background = contrastHex;

    const thumb = document.createElement('div');
    thumb.className = 'pfod-slider-thumb';
    thumb.style.left = 'calc(-2px + ' + pct + ' * (100% - 28px))';
    thumb.style.background = contrastHex;
    thumb.style.border = '2px solid ' + (contrastHex.toLowerCase() === '#ffffff' ? '#000000' : '#ffffff');
    track.appendChild(thumb);
    hitArea.appendChild(track);
    container.appendChild(hitArea);

    const labelsRow = document.createElement('div');
    labelsRow.className = 'pfod-slider-opt-labels-row';
    labelsRow.style.color = contrastHex;

    const leftLbl = document.createElement('span');
    leftLbl.textContent = substituteUnsupportedUnitsGlyphs(td.options[0] || '');
    const rightLbl = document.createElement('span');
    rightLbl.textContent = substituteUnsupportedUnitsGlyphs(td.options[td.options.length - 1] || '');

    labelsRow.appendChild(leftLbl);
    labelsRow.appendChild(rightLbl);
    container.appendChild(labelsRow);

    return { container, hitArea, track, thumb };
}

/**
 * Render a pfod toggle/slider button (interactive) as an HTML div element.
 *
 * 2-option toggle: clicking anywhere toggles idx 0↔1 and sends {<cmd>`<newIdx>}.
 * Multi-option slider (>2 options): clicking on the track maps click position to
 *   the nearest option index and sends {<cmd>`<newIdx>}.
 *
 * In both cases the display updates optimistically before the server responds.
 *
 * toggleData.format controls layout:
 *   '' or ' '  text display above and switch/slider below (default)
 *   't'        text display only (no switch/slider)
 *   's'        switch/slider only (no text display)
 *
 * Disabled items have no border (unlike disabled plain buttons).
 *
 * @param {object} item - Parsed menu item (type = 'toggle-button')
 * @param {function} onClick - Callback(cmd) invoked when state changes
 * @param {string} [menuBgColor='#000000'] - Menu background colour (hex)
 * @returns {HTMLDivElement}
 */
function renderPfodToggleButton(item, onClick, menuBgColor) {
    const td = item.toggleData;
    const isMultiOption = td.options.length > 2;
    const div = document.createElement('div');
    div.className = 'pfod-toggle-button';

    // Apply only backgroundColor to the outer div so that text formats (underline, bold,
    // italic, color, fontSize) do not leak into the switch/slider row via CSS inheritance.
    // Text formats are applied to the text span only.
    if (item.formats.bgColor) div.style.backgroundColor = item.formats.bgColor;

    const effectiveBg = item.formats.bgColor || menuBgColor || '#000000';
    const contrastHex = xtermColorToHex(getBlackWhite(effectiveBg));

    const isDisabled = !!(item.formats && item.formats.disabled);
    if (isDisabled) {
        div.style.border = '2px dashed ' + contrastHex;
        div.style.cursor = 'default';
    } else {
        div.style.borderColor = contrastHex;
    }

    const showText   = (td.format !== 's');
    const showSwitch = (td.format !== 't');

    // Hoist references so click handlers can perform optimistic UI updates
    let textSpan = null;
    let thumb = null;

    if (showText) {
        textSpan = document.createElement('span');
        textSpan.className = 'pfod-button-text pfod-toggle-text';
        pfodSetFormattedText(textSpan, item.formats.inlineFmtPrefix + td.leading + (td.options[td.idx] || '') + td.trailing, contrastHex);
        // Apply text formats (color, bold, italic, underline, fontSize) only to this span
        applyPfodFormats(textSpan, item.formats);
        textSpan.style.backgroundColor = ''; // bgColor belongs to outer div only
        if (!item.formats.textColor) textSpan.style.color = contrastHex;
        div.appendChild(textSpan);
    }

    if (showSwitch) {
        if (isMultiOption) {
            const slider = _buildSliderRow(td, isDisabled, contrastHex);
            thumb = slider.thumb;
            div.appendChild(slider.container);
            if (!isDisabled) {
                // Mousedown+drag: thumb follows mouse smoothly; text updates when
                // entering a new option zone; mouseup snaps thumb to nearest option.
                slider.hitArea.addEventListener('mousedown', function(e) {
                    let hoveredIdx = td.idx;
                    function smooth(clientX) {
                        const rect = slider.track.getBoundingClientRect();
                        const pct = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
                        // Move thumb smoothly at raw position
                        thumb.style.left = 'calc(-2px + ' + pct + ' * (100% - 28px))';
                        // Update text only when crossing into a new option zone
                        const newHoveredIdx = Math.round(pct * (td.options.length - 1));
                        if (newHoveredIdx !== hoveredIdx) {
                            hoveredIdx = newHoveredIdx;
                            if (textSpan) {
                                pfodSetFormattedText(textSpan, item.formats.inlineFmtPrefix + td.leading + (td.options[hoveredIdx] || '') + td.trailing, contrastHex);
                            }
                        }
                    }
                    smooth(e.clientX);
                    e.preventDefault();
                    function onMove(e) { smooth(e.clientX); }
                    function onUp() {
                        document.removeEventListener('mousemove', onMove);
                        document.removeEventListener('mouseup', onUp);
                        // Snap thumb to nearest option on release
                        td.idx = hoveredIdx;
                        const snappedPct = td.options.length > 1 ? td.idx / (td.options.length - 1) : 0;
                        thumb.style.left = 'calc(-2px + ' + snappedPct + ' * (100% - 28px))';
                        onClick(item.cmd + '`' + td.idx);
                    }
                    document.addEventListener('mousemove', onMove);
                    document.addEventListener('mouseup', onUp);
                });
            }
        } else {
            const switchRow = _buildToggleSwitchRow(td, isDisabled, contrastHex);
            thumb = switchRow.querySelector('.pfod-toggle-thumb');
            div.appendChild(switchRow);
        }
    }

    if (!isDisabled && !isMultiOption) {
        // 2-option toggle: click anywhere in the div toggles 0↔1 with optimistic update
        div.addEventListener('click', function() {
            const newIdx = td.idx === 0 ? 1 : 0;
            td.idx = newIdx;
            if (textSpan) {
                pfodSetFormattedText(textSpan, item.formats.inlineFmtPrefix + td.leading + (td.options[td.idx] || '') + td.trailing, contrastHex);
            }
            if (thumb) {
                if (newIdx !== 0) {
                    thumb.classList.add('pfod-toggle-thumb-right');
                } else {
                    thumb.classList.remove('pfod-toggle-thumb-right');
                }
            }
            onClick(item.cmd + '`' + newIdx);
        });
    } else if (!isDisabled && isMultiOption && !showSwitch) {
        // Multi-option text-only toggle (format='t', no slider).
        // The slider-track click handler above sits inside the
        // `if (showSwitch)` block so it's missing here — without
        // this branch the row would render but not respond to
        // taps.  Click anywhere advances to the next option,
        // wrapping around at the end.  Same optimistic-update
        // pattern: cycle locally + send `<cmd>`<newIdx>`.
        div.addEventListener('click', function() {
            const newIdx = (td.idx + 1) % td.options.length;
            td.idx = newIdx;
            if (textSpan) {
                pfodSetFormattedText(textSpan, item.formats.inlineFmtPrefix + td.leading + (td.options[td.idx] || '') + td.trailing, contrastHex);
            }
            onClick(item.cmd + '`' + newIdx);
        });
    }

    if (item.formats && item.formats.flash) {
        div.classList.add('pfod-flash');
    }
    return div;
}

/**
 * Render a pfod toggle/slider label (non-interactive) as an HTML div element.
 * Same layout as renderPfodToggleButton but no click handler, disabled switch/slider, no border.
 *
 * @param {object} item - Parsed menu item (type = 'toggle-label')
 * @param {string} [menuBgColor='#000000'] - Menu background colour (hex)
 * @returns {HTMLDivElement}
 */
function renderPfodToggleLabel(item, menuBgColor) {
    const td = item.toggleData;
    const isMultiOption = td.options.length > 2;
    const div = document.createElement('div');
    div.className = 'pfod-toggle-label';

    // Apply only backgroundColor to the outer div so text formats do not leak into the switch/slider row.
    if (item.formats.bgColor) div.style.backgroundColor = item.formats.bgColor;

    const effectiveBg = item.formats.bgColor || menuBgColor || '#000000';
    const contrastHex = xtermColorToHex(getBlackWhite(effectiveBg));
    // No border — toggle labels are non-interactive, like plain labels

    const showText   = (td.format !== 's');
    const showSwitch = (td.format !== 't');

    if (showText) {
        const textSpan = document.createElement('span');
        textSpan.className = 'pfod-button-text pfod-toggle-text';
        pfodSetFormattedText(textSpan, item.formats.inlineFmtPrefix + td.leading + (td.options[td.idx] || '') + td.trailing, contrastHex);
        // Apply text formats only to this span, not the outer div
        applyPfodFormats(textSpan, item.formats);
        textSpan.style.backgroundColor = '';
        if (!item.formats.textColor) textSpan.style.color = contrastHex;
        div.appendChild(textSpan);
    }

    if (showSwitch) {
        if (isMultiOption) {
            div.appendChild(_buildSliderRow(td, true, contrastHex).container);
        } else {
            div.appendChild(_buildToggleSwitchRow(td, true, contrastHex));
        }
    }

    if (item.formats && item.formats.flash) {
        div.classList.add('pfod-flash');
    }
    return div;
}

/**
 * Render a group of consecutive pfod navigation button items as a D-pad cross.
 *
 * Grid column assignments (fixed): Left=col1, Right=col3, Up/Home/Down=col2.
 * Grid ROW numbers are assigned dynamically so only visible items consume a row:
 *
 *   upRow        — Up cell (flex-col: label/button), only if Up is visible
 *   leftLabelRow — thin row for Left text label,     only if Left is visible
 *   buttonRow    — Left button(col1) + Home(col2) + Right button(col3),
 *                  only if at least one of Left/Right/Home is visible
 *   rightLabelRow— thin row for Right text label,    only if Right is visible
 *   downRow      — Down cell (flex-col: button/label),only if Down is visible
 *
 * Because row numbers are only allocated for visible items, hidden Left/Right/Home
 * produce no gap between Up and Down (upRow and downRow become adjacent rows).
 * Hidden Left/Right/Home still get a zero-height column-width placeholder in the
 * button row so visible neighbours stay in their correct column positions.
 *
 * Text/border colour defaults to <bw> contrast against the effective background.
 *
 * @param {object[]} navItems - Parsed menu items (type='nav'), up to 5
 * @param {function} onClick  - Callback(cmd) on button click
 * @param {string} [menuBgColor='#000000'] - Menu background colour (hex)
 * @returns {HTMLDivElement}
 */
function renderPfodNavButtons(navItems, onClick, menuBgColor) {
    const container = document.createElement('div');
    container.className = 'pfod-menu-nav-row';
    const menuContrastHex = xtermColorToHex(getBlackWhite(menuBgColor || '#000000'));

    function _isHidden(idx) {
        return navItems.length > idx && navItems[idx].formats && navItems[idx].formats.hidden;
    }
    function _isVisible(idx) { return navItems.length > idx && !_isHidden(idx); }

    const leftVisible  = _isVisible(0);
    const rightVisible = _isVisible(1);
    const homeVisible  = _isVisible(4);
    const anyMiddleVisible = leftVisible || rightVisible || homeVisible;

    // Allocate row numbers only for visible items so empty rows never appear.
    let rowCtr = 0;
    const upRow         = _isVisible(2)     ? ++rowCtr : null;
    const leftLabelRow  = (leftVisible || homeVisible)  ? ++rowCtr : null;
    const buttonRow     = anyMiddleVisible               ? ++rowCtr : null;
    const rightLabelRow = (rightVisible || homeVisible)  ? ++rowCtr : null;
    const downRow       = _isVisible(3)     ? ++rowCtr : null;

    // Apply colour formats to a nav button.
    // Button fill: item.formats.bgColor || menuBgColor (never <bw>).
    // Arrow/Home text: <bw> against button fill colour.
    // Border: <bw> against menu background (menuContrastHex).
    function _styleBtn(btn, item) {
        applyPfodFormats(btn, item.formats);
        if (!item.formats.textColor) {
            btn.style.color = xtermColorToHex(getBlackWhite(item.formats.bgColor || menuBgColor));
        }
        btn.style.borderColor = menuContrastHex;
    }

    // Create a text label span.
    // item: the nav item whose formats (textColor, bgColor, etc.) are applied to the label.
    //       Omit for invisible spacer placeholders — no formatting applied.
    // contrastHex passed to pfodSetFormattedText is the DEFAULT color; inline tags can override it.
    function _makeLabel(text, item) {
        const lbl = document.createElement('span');
        lbl.className = 'pfod-menu-nav-label';
        if (item) {
            const contrastHex = xtermColorToHex(getBlackWhite(item.formats.bgColor || menuBgColor));
            pfodSetFormattedText(lbl, item.formats.inlineFmtPrefix + text, contrastHex);
            applyPfodFormats(lbl, item.formats);
            lbl.style.backgroundColor = '';
            if (!item.formats.textColor) lbl.style.color = menuContrastHex;
        }
        return lbl;
    }

    // --- UP (index 2): flex-column wrapper — label above button ---
    if (upRow !== null) {
        const item = navItems[2];
        const w = document.createElement('div');
        w.style.display = 'flex';
        w.style.flexDirection = 'column';
        w.style.alignItems = 'center';
        w.style.gridRow = String(upRow);
        w.style.gridColumn = '2';
        const btn = document.createElement('button');
        btn.className = 'pfod-menu-nav-button';
        btn.textContent = '∧';
        _styleBtn(btn, item);
        btn.style.color = xtermColorToHex(getBlackWhite(item.formats.bgColor || menuBgColor));
        btn.addEventListener('click', function() { onClick(item.cmd); });
        w.appendChild(_makeLabel(item.text, item));
        w.appendChild(btn);
        container.appendChild(w);
    }

    // --- LEFT (index 0): thin label row above button row ---
    if (navItems.length > 0) {
        if (!_isHidden(0)) {
            const item = navItems[0];
            const lblDiv = document.createElement('div');
            lblDiv.style.display = 'flex';
            lblDiv.style.justifyContent = 'center';
            lblDiv.style.gridRow = String(leftLabelRow);
            lblDiv.style.gridColumn = '1';
            lblDiv.appendChild(_makeLabel(item.text, item));
            container.appendChild(lblDiv);
            const btn = document.createElement('button');
            btn.className = 'pfod-menu-nav-button';
            btn.textContent = '❮';
            btn.style.gridRow = String(buttonRow);
            btn.style.gridColumn = '1';
            _styleBtn(btn, item);
            btn.style.color = xtermColorToHex(getBlackWhite(item.formats.bgColor || menuBgColor));
            btn.addEventListener('click', function() { onClick(item.cmd); });
            container.appendChild(btn);
        }
    }

    // --- HOME (index 4): button with text inside ---
    if (navItems.length > 4 && !_isHidden(4)) {
        const item = navItems[4];
        const btn = document.createElement('button');
        btn.className = 'pfod-menu-nav-button';
        btn.style.fontSize = '2.1vw';
        btn.style.gridRow = String(buttonRow);
        btn.style.gridColumn = '2';
        _styleBtn(btn, item);
        pfodSetFormattedText(btn, item.formats.inlineFmtPrefix + item.text,
            xtermColorToHex(getBlackWhite(item.formats.bgColor || menuBgColor)));
        btn.addEventListener('click', function() { onClick(item.cmd); });
        container.appendChild(btn);
    } else if (buttonRow !== null) {
        // Home absent or hidden: hold col 2 space with an invisible placeholder.
        const ph = document.createElement('button');
        ph.className = 'pfod-menu-nav-button';
        ph.style.visibility = 'hidden';
        ph.style.gridRow = String(buttonRow);
        ph.style.gridColumn = '2';
        container.appendChild(ph);
    }

    // --- RIGHT (index 1): thin label row below button row ---
    if (navItems.length > 1) {
        if (!_isHidden(1)) {
            const item = navItems[1];
            const btn = document.createElement('button');
            btn.className = 'pfod-menu-nav-button';
            btn.textContent = '❯';
            btn.style.gridRow = String(buttonRow);
            btn.style.gridColumn = '3';
            _styleBtn(btn, item);
            btn.style.color = xtermColorToHex(getBlackWhite(item.formats.bgColor || menuBgColor));
            btn.addEventListener('click', function() { onClick(item.cmd); });
            container.appendChild(btn);
            const lblDiv = document.createElement('div');
            lblDiv.style.display = 'flex';
            lblDiv.style.justifyContent = 'center';
            lblDiv.style.gridRow = String(rightLabelRow);
            lblDiv.style.gridColumn = '3';
            lblDiv.appendChild(_makeLabel(item.text, item));
            container.appendChild(lblDiv);
        }
    }

    // --- DOWN (index 3): flex-column wrapper — button above label ---
    if (downRow !== null) {
        const item = navItems[3];
        const w = document.createElement('div');
        w.style.display = 'flex';
        w.style.flexDirection = 'column';
        w.style.alignItems = 'center';
        w.style.gridRow = String(downRow);
        w.style.gridColumn = '2';
        if (!anyMiddleVisible && upRow !== null) {
            w.style.marginTop = '4vw';
        }
        const btn = document.createElement('button');
        btn.className = 'pfod-menu-nav-button';
        btn.textContent = '∨';
        _styleBtn(btn, item);
        btn.style.color = xtermColorToHex(getBlackWhite(item.formats.bgColor || menuBgColor));
        btn.addEventListener('click', function() { onClick(item.cmd); });
        w.appendChild(btn);
        w.appendChild(_makeLabel(item.text, item));
        container.appendChild(w);
    }

    // When Home is visible without Left/Right, add invisible label-height spacers so the
    // button row has the same vertical padding as when Left/Right labels are present.
    if (homeVisible) {
        if (!leftVisible && leftLabelRow !== null) {
            const sp = document.createElement('div');
            sp.style.gridRow = String(leftLabelRow);
            sp.style.gridColumn = '2';
            sp.style.visibility = 'hidden';
            sp.appendChild(_makeLabel(' '));
            container.appendChild(sp);
        }
        if (!rightVisible && rightLabelRow !== null) {
            const sp = document.createElement('div');
            sp.style.gridRow = String(rightLabelRow);
            sp.style.gridColumn = '2';
            sp.style.visibility = 'hidden';
            sp.appendChild(_makeLabel(' '));
            container.appendChild(sp);
        }
    }

    return container;
}

/**
 * Compute the display string for a numeric slider item.
 * Formula: minScale + (currentValue - minValue) * (maxScale - minScale) / (maxValue - minValue)
 * Decimal places: max of the precision in each scale string, minimum 1.
 * Prepends '+' when showPlus is active (either scale string starts with '+') and value > 0.
 *
 * @param {object} nsd - numericSliderData from the parsed item
 * @returns {string}
 */
function computeNumericDisplayText(nsd) {
    const range = nsd.maxValue - nsd.minValue;
    const scaleMin = parseFloat(nsd.minScaleStr);
    const scaleMax = parseFloat(nsd.maxScaleStr);
    const val = range === 0 ? scaleMin
              : scaleMin + (nsd.currentValue - nsd.minValue) * (scaleMax - scaleMin) / range;
    const dec = (!isNaN(scaleMin) && !isNaN(scaleMax))
        ? calcDisplayDecimalPlaces(range, scaleMax - scaleMin)
        : 0;
    let formatted = val.toFixed(dec).replace(/\.?0+$/, ''); // trim trailing zeros
    const showPlus = nsd.maxScaleStr.startsWith('+') || nsd.minScaleStr.startsWith('+');
    if (showPlus && val > 0) formatted = '+' + formatted;
    return formatted;
}

/**
 * Build a full-width slider row for a numeric slider item.
 * Reuses all existing .pfod-slider-* CSS classes.
 * Thumb is positioned proportionally: calc(-2px + pct * (100% - 28px)).
 * Labels below show minScaleStr (left) and maxScaleStr (right).
 *
 * @param {object} nsd - numericSliderData from the parsed item
 * @param {boolean} disabled - true for labels and disabled buttons
 * @param {string} contrastHex - colour for scale labels
 * @returns {{container: HTMLDivElement, hitArea: HTMLDivElement, track: HTMLDivElement, thumb: HTMLDivElement}}
 */
function _buildNumericSliderRow(nsd, disabled, contrastHex) {
    const range = nsd.maxValue - nsd.minValue;
    const pct = range === 0 ? 0 : (nsd.currentValue - nsd.minValue) / range;

    const container = document.createElement('div');
    container.className = 'pfod-slider-container';

    const hitArea = document.createElement('div');
    hitArea.className = disabled ? 'pfod-slider-hit-area pfod-slider-hit-area-disabled'
                                 : 'pfod-slider-hit-area';

    const track = document.createElement('div');
    track.className = 'pfod-slider-track';
    track.style.background = contrastHex;

    const thumb = document.createElement('div');
    thumb.className = 'pfod-slider-thumb';
    thumb.style.left = 'calc(-2px + ' + pct + ' * (100% - 28px))';
    thumb.style.background = contrastHex;
    thumb.style.border = '2px solid ' + (contrastHex.toLowerCase() === '#ffffff' ? '#000000' : '#ffffff');
    track.appendChild(thumb);
    hitArea.appendChild(track);
    container.appendChild(hitArea);

    const labelsRow = document.createElement('div');
    labelsRow.className = 'pfod-slider-opt-labels-row';
    labelsRow.style.color = contrastHex;

    const leftLbl = document.createElement('span');
    leftLbl.textContent = substituteUnsupportedUnitsGlyphs(nsd.minScaleStr);
    const rightLbl = document.createElement('span');
    rightLbl.textContent = substituteUnsupportedUnitsGlyphs(nsd.maxScaleStr);

    labelsRow.appendChild(leftLbl);
    labelsRow.appendChild(rightLbl);
    container.appendChild(labelsRow);

    return { container, hitArea, track, thumb };
}

/**
 * Render a pfod numeric slider button (interactive) as an HTML div element.
 * Clicking on the slider hit area maps click x-position to the nearest integer
 * value in [minValue, maxValue] and sends {<cmd>`<newValue>} via onClick.
 * Display text and thumb update optimistically before the server responds.
 *
 * @param {object} item - Parsed menu item (type = 'numeric-slider-button')
 * @param {function} onClick - Callback(cmd) invoked when value changes
 * @param {string} [menuBgColor='#000000'] - Menu background colour (hex)
 * @returns {HTMLDivElement}
 */
function renderPfodNumericSlider(item, onClick, menuBgColor) {
    const nsd = item.numericSliderData;
    const div = document.createElement('div');
    div.className = 'pfod-toggle-button';

    if (item.formats.bgColor) div.style.backgroundColor = item.formats.bgColor;

    const effectiveBg = item.formats.bgColor || menuBgColor || '#000000';
    const contrastHex = xtermColorToHex(getBlackWhite(effectiveBg));

    const isDisabled = !!(item.formats && item.formats.disabled);
    if (isDisabled) {
        div.style.border = '2px dashed ' + contrastHex;
        div.style.cursor = 'default';
    } else {
        div.style.borderColor = contrastHex;
    }

    const showText   = nsd.format !== 's';
    const showSlider = nsd.format !== 't';

    let textSpan;
    if (showText) {
        textSpan = document.createElement('span');
        textSpan.className = 'pfod-button-text pfod-toggle-text';
        pfodSetFormattedText(textSpan, item.formats.inlineFmtPrefix + nsd.leading + computeNumericDisplayText(nsd) + nsd.trailing, contrastHex);
        applyPfodFormats(textSpan, item.formats);
        textSpan.style.backgroundColor = '';
        if (!item.formats.textColor) textSpan.style.color = contrastHex;
        div.appendChild(textSpan);
    }

    let slider;
    if (showSlider) {
        slider = _buildNumericSliderRow(nsd, isDisabled, contrastHex);
        div.appendChild(slider.container);
    }

    if (!isDisabled && showSlider) {
        // smooth: move thumb at raw pixel position; update text only when crossing
        // into a new integer value zone (mirrors multi-option toggle slider behaviour).
        function smooth(clientX) {
            const rect = slider.track.getBoundingClientRect();
            const pct = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
            slider.thumb.style.left = 'calc(-2px + ' + pct + ' * (100% - 28px))';
            const range = nsd.maxValue - nsd.minValue;
            const newValue = Math.max(nsd.minValue, Math.min(nsd.maxValue,
                             Math.round(nsd.minValue + pct * range)));
            if (newValue !== nsd.currentValue) {
                nsd.currentValue = newValue;
                if (textSpan) pfodSetFormattedText(textSpan, item.formats.inlineFmtPrefix + nsd.leading + computeNumericDisplayText(nsd) + nsd.trailing, contrastHex);
            }
        }

        // mousedown starts a drag; mousemove updates live; mouseup snaps thumb to the
        // final integer position and sends the command.
        // Listeners are added to document so dragging outside the hit area still works,
        // and are removed immediately when the drag ends to avoid leaking.
        slider.hitArea.addEventListener('mousedown', function(e) {
            smooth(e.clientX);
            e.preventDefault(); // prevent text selection while dragging

            function onMove(e) { smooth(e.clientX); }
            function onUp() {
                document.removeEventListener('mousemove', onMove);
                document.removeEventListener('mouseup', onUp);
                // Snap thumb to the exact integer position on release
                const range = nsd.maxValue - nsd.minValue;
                const snappedPct = range === 0 ? 0 : (nsd.currentValue - nsd.minValue) / range;
                slider.thumb.style.left = 'calc(-2px + ' + snappedPct + ' * (100% - 28px))';
                onClick(item.cmd + '`' + nsd.currentValue);
            }
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onUp);
        });
    }

    if (item.formats && item.formats.flash) {
        div.classList.add('pfod-flash');
    }
    return div;
}

/**
 * Render a pfod numeric slider label (non-interactive) as an HTML div element.
 * Same layout as renderPfodNumericSlider but no click handler, disabled slider, no border.
 *
 * @param {object} item - Parsed menu item (type = 'numeric-slider-label')
 * @param {string} [menuBgColor='#000000'] - Menu background colour (hex)
 * @returns {HTMLDivElement}
 */
function renderPfodNumericSliderLabel(item, menuBgColor) {
    const nsd = item.numericSliderData;
    const div = document.createElement('div');
    div.className = 'pfod-toggle-label';

    if (item.formats.bgColor) div.style.backgroundColor = item.formats.bgColor;

    const effectiveBg = item.formats.bgColor || menuBgColor || '#000000';
    const contrastHex = xtermColorToHex(getBlackWhite(effectiveBg));

    const showText   = nsd.format !== 's';
    const showSlider = nsd.format !== 't';

    if (showText) {
        const textSpan = document.createElement('span');
        textSpan.className = 'pfod-button-text pfod-toggle-text';
        pfodSetFormattedText(textSpan, item.formats.inlineFmtPrefix + nsd.leading + computeNumericDisplayText(nsd) + nsd.trailing, contrastHex);
        applyPfodFormats(textSpan, item.formats);
        textSpan.style.backgroundColor = '';
        if (!item.formats.textColor) textSpan.style.color = contrastHex;
        div.appendChild(textSpan);
    }

    if (showSlider) {
        div.appendChild(_buildNumericSliderRow(nsd, true, contrastHex).container);
    }

    if (item.formats && item.formats.flash) {
        div.classList.add('pfod-flash');
    }
    return div;
}

// Ping sound: sound.mp3 is embedded as a base64 data URI by the build process.
// The placeholder below is replaced with the actual base64 string by build-bundle.js.
// If the placeholder was not replaced (sound.mp3 missing at build time, or running from
// source without a build), fall back to a programmatically generated WAV tone.
(function() {
    const mp3Base64 = 'SUQzAwAAAAAAXFRJVDIAAAAIAAAASWFwZXR1c1RQRTEAAAABAAAAVFlFUgAAAAUAAAAyMDI0VERSQwAAAAUAAAAyMDI0VEFMQgAAAAEAAABUQ09OAAAAAQAAAFRSQ0sAAAABAAAA//uURAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAABLAABsAAAGCg4SEhcbHx8jJysrLjI2Njk9QEBER0tLTlJVVVhbX19iZWlpbHBzc3Z6fX2BhIeHio6RkZWYm5ufoqWlqaywsLO2ubm8wMPDxsnNzdDT1tba3d3g5Ofp6e3w8/P2+v39//8AAABQTEFNRTMuMTAwBLkAAAAAAAAAADUgJARTjQAB4AAAbADO9y8rAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//vEZAAAASEAS9UAAAgAAA/woAABE8TzLfnKAABKACh7AAAAJbD5W8UACsHwfBw4sHz4IAgGJcHwfwQBB0uD/EAIAgCH/BMPuwIoPAOhPDxB/62NQAgAAAoTkQUGgEVAOazLJmqMKNAYEl7QoFznieNKG4RhcwECgqBBEFzIgoAwkAYHBsAZaIGAEvC3AngW8bQAIkOyF1QHAEBfMDFGBjhkg+ELKxSgNg4cwDCAgoEKx0bQ55osa4esNoosUQMEMIw3Pom9BRseSWcMhyDQ9IwQUdSn7qU+qRggpzn//+hUaf////oCwADAFAHAAAAAAAAAAoEGSz+9AAAAAoB8VbJ4dFAgEAAAAMaQs024y3jGWFrN+h3MwIgFTJFO5NZgLkwMARzRuC1MCADsxAQW5cYFAAhCCeYFACQOAWMDoCUrAHAy6gBgsGHABMBEIEgoBqkDHjgDRYXiKCG6HTkLAACighugOBishq0lsAQOF8hVhjUQmJQc3/FHEJSfD4Q+Uu//iCoYpPkNEFS8d//xzZKxzRzSWJX//y7////+dPAAAACCxKraQAAAAAAAWgKEgAZQdLLBJYl3OhlMqImTpHUzjPPvDY1ohELZ7z0ZF1lQ8q+FXywm////oAAAB0630YABgnAOmAUAuYLQcZjSEGmsoIkaTKGBj7iIGEWB8CAJQcAsYBQC5gKAGiQDrDXiYN3rgOBhPgiLIhMLoEEP4s1KpW9BJdNAk5Akhe6IxExYACzhyGHDQHVcr0/6ftq9X0AgOpZaf0kAB0rBhIEYGHnE7x+a60IWBzAAsZBQqMMppqeLRT7mGhnxULmuaayy5oPBvmBl+ZGJnmOYGRmZGS636/Z/7//+z///UhAAMSWGWf2IAAwNACTARAOBAEoB//ukZNOABTVMzn56hIA7IrnNzZwSDNxrK73kgCEoDuU3trAEEGMttH01egljvDMSVxpVMBBmJFQCLeJpwlgReSVxJvG6GzZkCwfKiYmbxFUCxCHCZIneQCklEqfQoknvdJWO9OoxzXA6EVCiyDqKW1L/+vr0Ntzvfa+VBAxtmz/7IAD0rDEgCFQo8bHNvbgfNRgDHjcCUw0FVRlQMg0nz58PIQ9xC9MTPkt6/EwsJ3Czuh4q/58+e7kHQIen+5NrxVA1qPNQAOLb776sAAiBhDcAAIYclKZecEaTNqDgOMHQBHAEfQwJAVNVi7BqJpzXYaBosTIQPmUS07SqnWAjLKxDaR3ifshtwH7quWegmKbbbuzspSrRyCqKYHvuW4wACQoh2v/bAAXLPo3oJzkTgXjQcCKaLwflIRqOMQwe9HheozJmaRc+XtDRL7T/V4upHv7+ed+/8s8nml8//mkiPdppTooAAAKap4d3dnbauMAAAAAAdBOMFYL4wCAHzHJJQMA4DkxOkETAuBKRFAROjJzBsB7aATBNmBWAmYH4BxgZgRmDsBUAghxCj8A/xTsUKvRyhP18/S6uP1WsUpYLWXUb4kzqDbd8y41rcPtncJMU9AAAAmZiId2dE1qAAAAA//uUZOgAA1ggynvbSVhKZAldbwknCxyFLbXWACEVDyX+tvAEAAUtNuDyoCnU8Lth9gJVFCKhdgSl6AuQJAZgQEXcMDI1wl4eF/VoNRJubZI9TbRGpV655JlokNKREeggACM2mW2/rAAEYKMHhAv8YILps9LGMJcZdGRhEDCIDjQKAAHAwBRhhm05j+yAmHS7YomjMYTTSsoFIt0llSOJhQTOBGJgtmO82uzpP+279MAA0h5lt9oAAHCCoAFQgxEgOzez2QoFBTAmXK2g4ReBYUvAqm7DbwSKlRI2O4u0TPp9JK/lfPZe8ef+V/5YOkZkr2hwgqz9rP1VMAIURIhf/4gADB8CSQFDBAMjF4Xjf5XzgA8zAAAhYAAgEF5FqE4ygApa/sVlD9B4YmsYlCTN+Pq2KUyvLccMUcEccMNnkjmdF3Udrvsrtlq5Css5Gjmv////9bgAKixMJ//WAAuwAGnILAMbaHktGYHA4IYoAX+CCClCli8HAXTFaYFQBo3o//uUZOwAA24dS3554AJJQkl/zbwACfhNL/3EgCkli2W/tvAFuLbsM7xfuQOQdJ6fe9qfl8yHi1kvG4bnzHA/a8Xa33u////6QAEAOQgBAFABAGFROJwuBIiYyiMEF4aCOCZBjsZgHOZCAM2cw6A8xyBo4TUMyIJwwpAclAQyDIMwGCA3qF44BYX/M6CAwaITHEXNzKj/8iBRhoFFgFm+VuDr+Dr7/+DguxZeJpMLmlSAZsIP//+CgmLBN8kk0kzGYGMbjIwoKQSFDB4e////Ugu8SAb+P+08kG4EFAVDBgUJmBgcjJ////7+e0/5O0+TGFQWYQCCPACBZgQCI8Fk/////+TtPfz2nv5JpOYEAiPAOBZgQCIGCwXBwIQN//////+5SXrlJe+kveLApEgtaXqVCj6oEzlUrOv//////////////+9/zsZjU7GY1MwzHpmGZJHwACAKcFcIYGMNIqAIAAAABQKmqaqWAqaoCjdjAAEMHCGmM5gWLCQWTGMo//u0ZPGAAtkgSv11gAhQJDl/rSQBIal7Q/neAgGbEKf/OTJAA9SRhglAoeAQFBgUIYgBZQHTRKETEeDbE5gNIGbIq2UTy2Uq1IwLhqZmS1s1/fqIARA3Dpb/8r/////7VWpAAwAlQARU3gygUDCTHA4NGhIJAmAHnDKAYUu0wAEZAKBBdUJqlBmdUZDRcJ46XiJHx0np0utllRFXZ0dimWCwHtjJEVSXl3nSUOnD52eLx2XD5dLxz/lgbo3BjyKDGByYcgNwtlksf5w+e+czhEDg5505/LpwiY0RzhnSUPnS+SxDhFQ5APuHKhyQfmHLhoINg4BEQE8A0JBogGweBYgXWEXLRFy0W0kAAAADRt+Stj5IX+bkwJ82iP3hz8siwREmQth2sNv26Xg4CPd/ydP/9/0//5luSgIYIsGQMjeABsUwMWGAUwEYMJCTAAZ6BLrHhBjRAIyl9AMDHfgRgIGvAeB3DiDgvDF7tKYmrt4ypNEup0Uklm47CIiMwO+iup0kvl88fnC8eTuYmqT9urqT0ECLE6i3/Ol0hpdz06XhziVHND2Q8hd0Sf/S6T0KQi6QmSEIlS/lv9x9spNRqq2ClBZl3hDwAJK1VRoxDCElZUCh5ZIQICwuF+WJEBazlOI2t2TP9h3FyxoyN0arSMKKRY6N/7f//ThSeTBgBmVCAoD2DBkFDGCGUosQFFFBQTzwcBGCAJUAepKGBsZ5ooYKAkoAEDanLpOm/s7PZU9+nuXpyQ4hpzrUkUhSY2Av//uUZO+ABUBP1n9qYAguoQqP7AABEQUxS+3NM+jrk+l9jJUkiBxiY2CmVVVtUta1KZazpdPHS4cn8vdfutZubFNf/11tW2qs2ODTOHJ47+dni8Xp45PF7rqaozPHTQuG1d1AZILWY4A6BwASprtKRQXcPdaoTLDTN+WBqm2SoGzj1IyUTVRJU2V9pQwsa8vr7TvSZRez/+2z////+1sddcwEkCtMMC2f8F6iKECB4wUPLNmKga6hMnMHBmXkoHdgwhPwUXI233cg6DoJb2V0rdnJdxdDsuVZzzq0s6mm6FJMlCkTQLiKyL8vKk2PPZWJkucTQsVPVXt0G7nlxoeD3//ypblyoeNiSKZ+vVltt/yhUsXGoRBPt0EsBxkdCVQAIEAkqYkQESx5YYEM/xWXGiSnKick9I4rcmO6kUpPDDaSfiKCLPJlRK+m8jxUKie1pBhxumxRwE3oAAYE8Ldv/pqKcEACdFYEt/4MiHlMIE2wYQ4REIvGwmJAdn5VANmP//ukZNCABBFM0PsboXo+geqPYw8LDukzS+3M9mEmjCm9p4mkCIrhw8Ui71K/yrYnJodx3O0ULhUrJ0wLo5pBXSSZjilENNR8gjC0yK9WYoqzFmTaySVFSaKP86XiJniJjnEOPfLpdPeXs6e5fOlwTkx2+pJ2qUug6dJl/56XR3HC+Xj+TASwIyNmPAAAaowVhwKEKwgsiSaWWTZh4WqcUIuPOBciH5ka3UpwrGxXOTmrMUcYuK4DVw8g1igsugeyju4+i/AILDAyFgDDPjBg+NjZkwMANmWIX3aAx4F1LiADmCAEj+LAAKnc42AgMD1MxwAtAlw4OShGglVe4HwnTeO9UNKoPhpaDyU3UWkOTrX8ZZcxniKtADDi1vrGw5GjozjBoeHDx8eMGBwODunlM4uHRYb/9SmerI0xRQHaZU65IZ7eOUCIKJzoCnCJePheZkqQZfkRtpaDICBY90IRR0UUDjHjsoeUATikErJ0cJO2t075sJuY0kVIm3qKml/5wtbtqasA/GKyHq9FHARwQKCgoMaIUCEAVkgE28QPxAIGLzhVgaCEWRgeFnRQ0g+sOFAiTBB+zAAbEmKXh/toL+oFUhr398pn3fPX075GS33CxW8Vlhj218f++PqtcYvq//uUZO2AE/VM0XscgXhN5MovaYV5DuDnQ+48raEuEyk9l4mssvkkfzeb////948neKtTPEOmm//l//nfvZp//NJOpny9o8q7+VGRjBDAjAzb+YABigk0GwPGDgMXaKpxbMEE0VxgGDgr4DmkdAKp3H/Dwlfmfh4RCB72tqS1IU+kn0uf53//9G9JC5yTu79P/9JJD0v1LgG5BAByJK+VgGGQLTgEDs2FQGKBglxZuMYCoDXuDACTBR/3CBSJeKvEj6fTTqgkioTL6V+ii+NHfzr8s79/5p553oM1U/y/vJIGWuH8W9H0z17NO9f99L30sy4YWUjH5/nTT7KRGfnFAVp9WyoUgMsLnvjrrTFEYJggs2aKVIRpYChqWv6t2mFNw+BImSPZDFGJMSyKG2/QTFscca1/dtn3k9COXzp+dneePfPHuf/66moQIAMSMAfNoAxDAAGgIYAhaCDCb0ZAIESOCQyMAFS8MBJvYiwQp0FmPMkA3oUZOXoo15pVS8pq//ukZNQAE5M5z3s8eThNpMn/Y0kpDUzpOa48b+ETkeh9ljXktkaFBfYzCg0zaW1CZW/3jyTSPZ3806nePfO88z1VeeXvn3tnOPnGMQo2oy41QLp0UAalvYV21+hSgbIsd+wAAOHFEywngWEEImZGRFQfgIHAJgICxEmAJcIBEonU8IGljtPvGFpJIiJa0lnpC7CsIv7WbSNAqCcFbJs05y6dns/z3/nzv/ObBgoACKRMt8ABj8QFYAZwBA4iCEDYwNfzXQQCCiMgBYQiBs1NEQxSzZKUCHSHgpVI+9ojqbTy1pq3xbVd32/fA5Ze9nfzS9Wg7evXP4kmqqJ4GD/xmMGCwsGRTlHlThAZhq6YFMDRzSXvAAMMHDB4wDME5HBgEODjMaYTkAUinFtHgD5SsBD72hg7oLAc8OS2Do3c5wdqaj1h7r1pZ0+XzxycP5/zxz+W/5YPWqlgQxiGO+fbAAiUEV1YQSMM9MPAgpSi5gNALdBwGGg2eiocWEwSDQFNJnTgU1zRhNsitTaTvkBC8Rd7kfEiOhMchtZgABggGAAx+RF0nZNq3fNzBi6lojAiFjChnawTISjM3fsAAV/SsuX7Ma2GmEGhYyVmDFCysWIhQKOeWDAZ9AgweFlpGpX9//uUZPoAA3EtzPu5eahQRaoPbS2HDDy3N+49DaEpFqd9pLXcUNC8q3bU1Onfk/mm/m8371oL6DQ6HeeScGNBA4EBRhow2CHHB8aNHB+DgI+yoIgK7vt/zggkWERwAMBFjAAVpoMWSMoQMVUHRAWCaZ8B4hJts+RSiUpgtWVWF7QlmH0hZSF2YUJQo0UeySsJ/F1ViFGGjBbTYQtWtT6XhySeHJAGqdjcjUWeETj4S1Db5cJ9/8QuKq49+hCXB0Y7Z8dNCBjwes6LlSd/iwqVzKrhUhsiASiIJg4kDIN84HrxeVaqe/yzvpehy+0NK+vr7S0NLShqHSqoFi+fzPP+vtDShvQ9p7Qhq80tCHftH69+0dfaF6qmICAEEyZLvAAPfc99goUXKBoSY5g5GhuxAwcLqEISc14yEEAoyvml6uVscergkGxUci5ZHQkSQIQ+CUs1pfG7hItLNqOs/MqszL/RpIBZLokkbv3dC7pJpIehRIUv3J//v7LC6GzlvbRw//uUZPKBEuMtz/tpFEhYhanfaeJ7DUSbQe28zaltFGc9zLwsADmIQiU4CJA5pvOskoSDgGAAhguawMob9SSVI8+PsQCUPOun/SIn6SEgkm07UAkROah2qO11R3////lv4EBFom52wAE3GCAWDgUuGElZZggSHagOEAxUgyCnni4qFA4As8VQgcG5/w2LRZXbh200VHkfOpVqmF9m0aeiEHKf+nNpN/pOdWcmKJcgroJWTMC+/YV6eNecxR5cAcDM1km/YAFiUCTcbdY0XbKVuveFRRi8yorKNtolcLTTe8eWT95OvyfvH0j6eSfv+1hMOnX/4+AwQDH4FxgQwLgsB8HggIcf81WGMCADREjT9AAMXIGCihSPJYCCo5gBIHGgSHABhgqAmhbEQYQ1KARRvohBjIQjR+H5MrHiMa1bO8aZFI+a1e67x7/RWj6p8f4/zj0pndeysasavK8fy8YA6wGCZF37KtABgNGZh8QAA/hytksmJMExLJ4DEnb18ZAb//uUZOMAAw4vzHs8SVhDxaofYSp3C3ibM6zxhSEsluc9h4m0tTNkCChG15DT5Uk7+RHmlOd53ql8980nfoVt1G5oB5lBqCn/Hr////52flhAwAmMSJPCADDkUGgQQAEwGzQRApgXkfkQgQER8C4EjFLAKXDRmgBaerOhh6BvhkRYk5JSKk8lpPeNpprNt9rqdeAAMyoev5JcYpu+IMK31I/ll/kmePp/5IgLDy4hIHTe677f/1bKgEAyKhm3oAB/QmD8gUyAKhmEE+qeMx1dzZ3yqJKJsSNDF9faDjanbUxM13WMa382mVM6ollk7QX0BNVarknl8cMGhyNG8M+Gf//DyqhQYgJDJqfcAACIBQkCiA4EzzADeF8YzYFBogRACKwsHWIQiOTJXnWacVHPV3IonGaWkFyjMGnNjYKTTeO8eNy0Da9HBstjyfz94/fyTP+8l/8///7+TyySTvJHjx/PN2MASBqqS36AAFazUpAggSChCYE0tzfHWIjQC6Cs//uUZOqAAvIkzPs8eUhFhbmvZe1pDNydL+2x7yEzFmb9l5V8NpGbkeL599UqmfWL5nX1P3rx/OjppPO/lVBIGmWfzeAwYOB8EC/gx/4bh2B0AgEEp9AAA95kJYAMtUYyNksL+hmoiFQIWBBIHKDN1SIGEldtKhD1vC05OOWJlzWZmQQtyFxXNhV6ZeavW80h2qdDWnqmRUqZ69llaVI0yzzqqdVvfNK+ml/fzf/5/tnDfRMXIS4KbE4/iAAX48zAYMGmvwmvjrYKyjlDTBlCW1MSBINQKdJFQ7zxQ1Wm+r3TS/fSvVaHSrFd2pGPk2+eS99LKp/PI+lfBoUAXDYUFwwL8K/11e1wcxREOa34AAxrYRGw5UZw4REghAM0A82LDyzbC0utCgcHAiEigMkutmpgYmJDodnGTGGe8KM5wzQ1GY5oMOmQ6XlLzW2jUlLUsbHDhv/28rqFVf9gdAjQm21oAAHKDKaaRpxgCQrljihGVgQoAJeia692xwjhQV4O//uUZOyAAv0uTPs7eThHZKnPYeJfDJy1L+zt5OFJEiY9p5XsoGWn7wRFiGKKArzGuXwRr4g2jhmYFtzayxuoBaP4c+4qEUblviAA0o0lwdCDDgsIFgClFdGLByl6L66rK25Gjy5LBmowPJw4gNqhlJkdctjKjU+911d4cgNQ5Lk4crsnr2ODunS8Xi7Pn50/ZXNCfX08jWSASLMp3T+AACW67i/AA3MZk2B4k8tjapkg3hnnCHSbhxIxGI1rdK11++k6nUk6/3z+bv5Hr14/lMtVyf/gwEGDGAPgQPGg/0ySqzBRA0M1J/AAAG0rsHBUdkgcVhYREJAL4RxCXXJBx59FACMYdNYeMG8cZlvWeJEi7j5gRnKtHdTwefyPpOql8KNUv/155I/ePpn6r77989mVT3zvpJX/ml38Y/3euJsN9nYAnE1c1J4wABpzT5MHGDGYcwYBaloMHnNqVrLxmQ4izZZi8n3ozRRuMLZVbMtFCfL57zsboDQXjp7PHD8v//uUZOsAAp8szntPK2hE42nvRywJCnydM62lsOEoEec9l4l8njnJf9CdlQMRNGOW3nTFIADBkBMYKEHBpEIREHoQYFrDpazkMF3y1xIBcmgmSVNIwjyQaMnbXz52nmNbXbJEb4mtwavUalTtFOcY2fd0DODcTSoCHA8DAQPBe2pUOdUAcmywn+sgAB71BhArpgxZumimIMKNmlB6jiSMAD6Iyh75kZ2FoaVOWP4ljUU76aWaaV5NL5pHzG+Bzup+/98BWAL/e+YqukB1BFRG5/AADiqRI2gIMqulIEAAmOfkITFi5ZhipQE0OGxYOmIwqWyF/nGqwmUPty9TSi/++1ZmhvV92rn87OxgWCz053HexE9GjQJJu6aGAAwHBAwAcaNz0BVh4cHF9GwoNJsjJbfsAAdpkYsXGCwDEgRIUfAiDAYPGQoFBQB/QIkAwgogVT9VSPDiVjW6lm7Q87t27alf1a6/anbVLwPiHSPnsn8GBjQLwPg//xxuBxgfVASw//uEZP2BAwYtS/t4ebpDw8mvbxAfCwyVMe28baEZjSc9rDwMIiPXv8AAeaEGchIXEzDgoxQWCD4VORI2BIOEBYgCSYV2MgqxB4IaYQ+Zl3M2xFNFXKOYZIsKJEkTEtdVxvUCiiB1L08LMCsxJDBBxBqdDCDjg4i3KO/s3tgpLdyUAHAiJGz8wAD2AEwAAbII9j0RAVbCa136EiG8KX6kg3DEd6Zkkiu/X1lFat7HK5rqaptmw9h5U/9bWXx+V82zf1lVFDf/W2GosslVqGCjAjNY7/gACYwSBdQeDEIoIEHJ06i3KOUOtWja1VSINELKrV7EsWzBXpZVVBgwdu4kSNXH95GRXkhHAqVbrMPnM9hW/HS7E8zY5C1VH8vfem7ZpH1lpgwtgI1ONf4AAFvIil5RgRD1AIIvU0FORopHkrIwTJqsOhdEBsTzBhpU/RtK//uUZPGAAwkqy/tJFohShcmfaeJtC9yzNe28bakuk2X9vCwsoEayqhkhaI6/Ut9WH2a/r6gCWs5eMxByYbDoWVfuV+HnvaXczBCk0S2UwQwEarGvwGBdUqgzAAzCEGzDhkmEJqLXd1EGu36Yo3GR6OTXExyYoWlECx5yP2nK9Sz1cfshAJhz5mZHCIyBSrkMKH/a4prxvyD0EOanykB4BlVVd+axTqhYdAQXGbOKSkXjGUREMBYCq9wkuGkASCYD4SSwp1B2+WExql5Wm4dIFYD+toDLKzoaUq4c3UNk0zWTioMW5wYpiyyyMJd7Q7mvb0dULtvYxblgtwRFXSfYAAOiHCGBhRKeoCuSjH4PwuovoiLUGwhyKKyVaZVYwubbdmq/cbL8CO4xH/1mmP3kFqCTPr7zjnAgNCGBNYUKrTW5GQv+EeQoLixm1slQlQJmVu/YAA5AbLGxgIeJBw5IaTapipMqoM5eGoD+O02qHAd6kVLKu2Kdkkre0a0K94Os//uURPABErotzPsvM2pVpdmPZSZ7SeSrM+0wbalqFmZ9l5m1az8QHnB1eNrGecIGhjAmggodWhSWlr/I9l12V6uAZwRXW6f8AC69UQNBTM4C5kBF0s4txW5J3imydcDsxi5COVRrSGJYcsViNliw/cLCllyJh2zFDkBKJdSbSX1MYu0BU4qZByaemRk7UBchCxSoUGUDNVcXxENEsQaUhLh0qAk7KDjTEnG4xAL4mR1lCa6fSN5Y7+R66rO6j0gX7kzyvPv4hz0FoxX/f8eQEMHGl0OIoJRJbLSwNcZH+hXbYJcER1tf3AASpHkuKOTMw0QktEuRYAUFHA5dZVUoOhXGHxQazKxFY/f5CPZhotLiCLxX0zwNBecKvXUG1NN7HDZ5qHvf+tPgapGKdi9WN5ASwKqtZPuAA06lZgWmEipMRQm6YhLYYU8bsISUp2jGMtHNDdvucJVvL0nrG3Era99f6y+wxBzu7ff0KpCA6gA63c51/Oeeg/dA/4aCplVU//uURPKAEqAtzPsPGvpRBHmvZeNfSkC3Newwb2E1EeY9l419EQCq6uX/MANXaq/wk4AqByR0TBxZCBmaj7wBnTAVwGYhpLX75SmPI8xaHHx93rWaFJ91zusVcDgj43XOoJzlMMUkDQOkwUIuROi1QGL2Mr5LLYLYCN2sv2AAU5RUaZJRoNWIkAHlRMkGAKZI/5IfuGa0qoeqfa+c7g6g6YXKJfG2qDvUXM+sZdYRZAo8Wvzpq4+UQ84RnmhHfOH7W5dCPQqqUJcCN1kv1AAf1pyhoMHDhU9SQgTHFSgYKY44Qc2gKJKx+HK3pp+qUafrEf7p1EtPEg2jK2PmlI3viErl2PPeqZzxZA1d3rVdwSuZ5NfKbeuD6VZtgpQV1NI+sACDoNL6IEBJSmHIBYFSxnLOl70yaJdpVivHkcTkCIS97T72pr7UYyjCt1J60A3WRSu5w8fOHpzl65iYzjAM1kcrJf////9cQgMQCRm2vGABQKKLiLrDyN5h1EHniy4c//uERP4AAnstTXsPQ5pPBcmvYeNfSkyJNew8a+E+lqZ9l420PWBZVERgiqs2rBWp60DjIhJogUeSJVU5JsDLnoZ/m1E5WUIxPe+JasrWmEe9mfu5vJ64n2EwcFgOMmwocFiQt///V01DhTAbO+1/yAFyy7xKJPczLJYQSgODlRpEuwSc9DHMthE+HaS5OyraXjuoj+r2ncNT+a/99TtTEE22PL4xWkzOTZ81YYAA4A2h5qQKI1qHM+iJUGUEUkcPsAAgJTy7ANKRMDQqwQ28mGpyqjZi4WJYSD5PLnA3nHdbxCfMt38GefWnsKr3NposCPJQW+JX+/Ya4m1bxoOZxVoRzp7tbeLfPLGNQZ6v////pmUB0BERbZ9QAJUp5DAGgUOEIxVwutGqD2DseogsVIk6ydE6K2Cn3jM6ebVMfb05lXrR6WbXuXs14EDJ7gjS//uURPOAAp4ry/svGvpO5FlvZS15C4CLJ+0l7yFFkSZ9h418pd51mu6ysGrelJNPOk+Ro+k4t6X46YOzDhDCxutk+oADt2llFCyY7TXnH5oJxJzC063CIdmwxjETUaakBIHFRwKKEAknNdEGTSIUqqRypMWrET43EtjNY98RosrP3sup96lvNNG8AqLKfDPbEzdqnCFAkVZH8v9WFQZZRfERGlRAfrfNAmmWrFhHgUQ/zBMV2v7dsUmeCHAySIKglQoeXSJxmUFzQBojapXNFrnzs8x0xejPKSngiku/5D0A2XmrcLYFVG2v2AAf31zqKFzAsR3x/QcoARGBxXsEjYQgD9t/EWJyIslKJZJJDg+TESxLGDTkW9o++jC+h7tetpcQMlZKX71NZ1un4TZNicatypgVkbVfUAD38fMuS6grFLUrkDqIBGyKU4KLrgZewSgeHBWw+6chQPc84Rpoj84dOnM6uKNZ3pA6WZ8svfn/l/d5+VkOquAiARYe6/wA//uURPmAEsYsyvsvG3hVpZl/YeNvCtyLLewl7ylCkmW9kzYdCLsVasAYFlR3AqspePLekUqKC67wllNNWprw7DxIlJBGElipemJY4tjID0EWHkDWXoVwOCRG597ZdyNKnQ44YcyBwySO3NgSipkacGal32sAAg2DnyAJSJaabOEoCsiizdmn5qpuQsIu1b7ZYFoBcEBYEX6zX4je8Quehd3I+ifmEDfU0msu9Epsup1UIYtwhAVVR5/QACpH0EYGQOGamWDriBBXMkyrZSpQNQUmpQqIbD2vdPXHTiXavI8xqE1o/1m1cbrVDErud+TQ/nVhWTlLRjHrTa+Yxfe9Q5uD4hQVQN2S7fQACCY89IyY5ZaYdzDrgcXbQsLQLkO4UAdxQqxKrx/xdMqjge130Nbiv3jLRegVht/wrDlDvOBbxFbY8lhIhL3rnWCmniQCReOhc48QP/2RCkzgjmra9uNndEQjLasuCl4kXqakzRCKyI5BxUzlrLCAc4L721gG//uEZPyAAm4bzPsJfDpGgvmPYS13SiiLMewwb2EVDGZ9hL4cPIEaJVeEEjxyENlG9ug0gR7l6quUuc/vSaPqYoa2cFDjDShOAgG7/////a8MDoAmauXy5JmlDJYeOl2BFVREAo12mcIDMyUk09ftHemaC5o8bWGjyATttLtKkxQijqkb+tMID7DiPfB3BvAxe0zRPFBGJw4QYchy9QgAADd/7P//+5W7gWYGVW1XwYAQLaBFC0xWFVjWCKCKsESdHDFO5ZrzJys4CpICSLOdQtoyiSZZggamMVULWxqUCDmZUOAcGjJ8gNKCcswS/6Li5pbFXcAxiTI12+DACBbP2QlphgqZoxkP4NIa47DQPEcAAFBDPRxJA4K31rJSfhTzjTbTLpTUWp1WnVtuBjKiPEz941vw9g8NGvaEwwNGM/3ph94pb//oqJGpBFVtX9EG//uERP0BEoIky3sMM9pWJMlvZeNfCmCbK+wkT6Fbj+U9pL3km4ChRoIytdY+EdIp2IzLueBrOiCjVLmD5Ms07ECAIGoxPvkrSVO29appeg6kzDo1TnvYsPPSi6gGUFNmunkAAVIzZeChyRAFFZST0CwkQQ5OTXT0Wmqi4kQDikHEJcGTT20KTaFVAsxKKy5tfWVFQMoUt/2urA4QSLuWrRy4ciiJYJQyZFf2sAAoHz9SbNxGtbJFAOSHJWJGH5ZeXngVnEDDg0aq12J7abEb68TyF3ESFJJ7IYYnjW7nnnff7ghwMBAyYcyYW/MnCov////6muAmAR2bW/YAAr/DgWzDKkpB/pNRVAZMFT4t2RiUqXbhBzOnsR6gxySJPEWRJUsvGqNjFMWc/9vTJKbcdtebRv3n+/DOzy7BDgRozj9bqzaaLOpYrEWoR1Zi4Agk//uEROqBAmEYS/sJQ7hT47l/YY9dB/BhMew9KmEljuX9lI3s7PdDQmfv08hAUZPTGGjIlghNyl5njyzMIXOi8aCLbhx1n5j7tqt3mpwqAVBoAG3Gi5FqEspb////1xLBSAZqsb8YADx5p2MoR4MQUZeB5IAQBCCXyC/CEAWuQhX/Ve6zKACEpIhJVxuNfBBGPe2zlSPCSNby+s1ZJqT2tfU4VcgOm3P9KP//////r/RVmICFBWZ7d9QAKZs0gIhl+hcIhSIwEBqwyTkntqdjzbarzXDENBygzrtPWVlXiqeT7aot4UJ/7/Er8fAOBLY1bWyDQHTx6ROi0w3rop8GpHGPMGifS9MDqCoj6z6gAZdeBMBFBGcgIjmIyLIFEGXclYNNUi9ISvOGrs3ZnJWNsJ8zM235UrKiI1cLNpLiIfJrz/dy0Nam9nNjObGYi54M//uUROwBAnocy3sJe8hFoxmfBwYPSiB9K+wl7yFJD6U9kz4c68jIvXvySYB1AlRHp6wAP26AOVFREEQ6gToEozMlVmD08CIxP2z+WhcBC5MwtLsUl28pS2Hz1+/eSyPspgTda1veN5mp9WrCnMtQJQg0RJ3kI4zp2/9q1QUos0vs/mAA/qmBxRllsOHw1RLnVvh7CEKrLVhlkiqrRpCeTJiF6SfeKTpId5Iif//36kJEm/Cvv+RvF4MCUJBsKnE7mpX+jQANqPtAAM+ZOzoxQUsQaOSGAMEiEUwZMlfVFCBo5XFR/pNnoIjThQwyWKScywxiCBngqXrCA+Hb/0th7372eWWR/5tliEDMYPFFKeob1V+UuyFK1PUGCdmyRYnUuboHcDaG1n2YAv31GRIARUrAxkncHPZGiCrBgsjBqFV/micFcAcE+dFffjRSsSrp0d7KYgEiSFwsVWHCbTYwoorraAkjhpUwlfY5iplgVANEaTewACLxKKDxX2GDkBA4//uERP2AAqUsy3svG9hQZIlvYelNShR9K+yl7uEbj6X8HKQ8aE5cLjsWnV4EQ1iw4/bvxqI2YyhwYOceNSsxcTVUpylwD8Bisq63W0a3+MSxL2l5mDo81o5PXaJN1rNzMAqAhs0k9gADsu8xEdEWGjAhm4KUPHeNoCxKzoBx1uKmseJQ+i5QUoh3XsssqmTQdKFwhjXeaNDk1ffP7OWhdKWaBhCzAuFkrFSCRc0FbPR///uVhmB0ARRXH4wAICW7cS/DCEIBRMNjhgDHW3Rjf53EtjjRLgd0jYhcFh0vklUT+jk+q2HXGkj3tmm33MAHW/h23i0r6fsr933s8uiiBCw8QdcPNgIcv7v///XUuDKKOzXz6gAMIgaVjhGQkpCWIehMW6jYpaVg3DoXhgWRxNEE/bdhKqlqsC+kUBTVv1opcq2uooEOv+GsfKYoLnzx//uURPUAAvQgyWsmfDhLgymPYSh3Cex/K+wZ8OlPj+V9hhnUjXPlf7DC6DneREBCCKKst9gAFmB4DBhhCWhgOrC8aCQiDUTj7gJCrBlPD2nX2o8OFLESkSF3u6x1XNlXTQ2+K3zvmAQiWkH/xZQPFAgR05V4RISSgyYMismJxxT////rmZBkBFVtZ9SAH7l8CKDF2Rx4YJKcQRC8JwXFiElQCqPI6rEmcB/dfLZVxexrkGvGCyt5irtXesDMAO+CW7NoVQZMkSVdTG3aeNuZxfcFAlct60AA1p14sxlDsECUFyN8hHD4gBpUOZ9jfLgtmqay8lXjezPzqLCuGl7D/gx21pa+8lYZGZVHIP8pUPaGFVPTQxEriDgcGCgPiwCUscsZcKArS/M7nv2dFC9927vd659pauuIkGQCN1m/sAAZZA7YIHBgQsWygjtFgHqUSgOKWJAEuQtWXlWEcumZ+x6mmtD/o+0/YPaLvLklSjBfxos8O7g0VykFBkMAcUBU//uERPwAAskgyXsaeThMA9l/YYhdStydKey8baEuC+W9l7DlUAalDBZ14oDf//9MzASyGirffYABCncfUVGQ7iRAy+TjEgbORwNrjjBYUGiN6/McLAyEsyZCsS5AeZYfHli7UjX2lKuKxW9NWiQYWMWvTw6zsiIXGn9x6Vv/UE0oQgKjJtvWBVGklu1wLHGDg8UKAJoMic+mX44a7leygGaHXCKerzzJljKAs+3eK05roakGjRKXeNPrmeud1byyzuV9TMCQ7jT+a4QtZlEqioCGAzZf97WAL0ggICIgkJHQgnHrgwJR1VVLi03NSYKkV+ohOU9dQxWMbohsWLjAv0BybB+KeNDYSFO+8hO1IyeoIE3b0m0etm410U4538d8XRduJEMDMCErTfSIAXncsMAb8QCkFhMy0jgVEQvgBAUTPtJVhbA3GFZMjkkBcFDb//uURO4AEzgeyOtPGvhUo9lfZeNfCfCDK+yh7yk8EGV9lOHlDDMNXia6A7Gl5vaS3AmydLevhvpbGs21eLGBcBRyDKQ2bAbzxxZ88+p0kgLjRJr/0fpmoCGI4eLt8/zzRMCkGiqUFTKXQWSnW3FSPuy6zQ5RCHjYMkKKKwXISupNX7VgYOPbQbCCtYBOnTNWsNyJ7a7yRJXO4k7UR6WnAN1y9uXX9YfMuEuRo63b6sAU8VlbcUzEfR10yyRYVQJQJwLoH8kSFPJpE6wv5IbbjGcWrbtT62JcSavRWNYVz+DExrToilPO9AxUM2E2EGyH6ivR3xS67a3bK+sMmoCnFlZrt9AAH1jTihCUmkEBDNGghKhG/gQSWwekEwppr+Q9ForoMzGoLO6F8tl0oWj97XsIvSLSutf2zWs2bVj8EpqRXFQj1e+/6WiAhhU2W2atADV6QugtQqjHUERzOBFNna62AGcVI3xIxmsSrm25R/LG1C8Sj5qzArGvE1vG7wRq//uURO6BAqUcyvssSzpeo/k/ZS+HChxjLewl7ylTk2W9h419Qc3vvfTlMeKSbH60wcE4DB9Lmpral0KMtmXpwpRNYffe0ADk42UmkmohKHEj7AyjOlbGzRuHRIbUYN6JRUOS4eKag6dfZM9uyoVvUt9LrXILCIpLGvoOHBw+302ay9b4meeP/Xx4kKgXWHu3tQA7q3MiQGMJSIxEWmfiIbz5NkVjSeZGzaH34lMglsff0SaQrDUmkHQSi9mKR3CKF/mJ0iIkByBCpoWEMw4TFyxTF1PTd0VoYIQENl9ujAA7yKl+VA0x0lR8ArwwABDxpscoBoMOAtqHsq/FZFzWIzwav6sz3sEs+cy53HpHYngNE4Ma1miO+eQc4v8vh2ix15Fx8BsZ/9P/7eR/+mJsJYFWI33sQAj/Ik7RoKOFSkTyUEXYu2R3GiKiZg1lp8P52x5IkgFzdyib9RxBJSevaTY/ESTZAaCIKJMmxHLsIn1iFK3l0C/9nGO7hKgrPN38//uERPAAAmAgy3sGfDpRxKlPYeNfCWhjLewx7yk2jOW9gz5UoAGMnwUHTARncApoHiaQgAkNLkUFLvrNZdt/I2SVyQRZpludgp0a2NNivawL90m4s0us2xfetS2Fy/uy//1E551bwSHoKgEWX+/lIAmauEdEZC+6UxEsBIW4W7Q29gahTlMCru7NyqPVqWctQjDDCw7HY7EpNl3PlTDOkjsVBBmW/Z7rtaOWgOc0T1q3GRiteWIRhgW96pmQpRN5rW/VACpXpG8JRUf0PCuQBAD8Gk02M0vRTqdpUBwrCPXuZSlbGbFWlLMfDRzJgpffuEHufnxfbsdQxrOA9BKGfeZ699P/VzQWqG0xtfqwBEnfpLhMFHdbRFMaE7a85qNJCv8zarfh2exk0SpHcABHyXM3BiqQftDJpD4CEsbNQqRe7luhsMWygFppon305W+n//uUROqAArIkyftPG2hLYwlvYM+HCVR7K+yZ8OlMl2V9gYtE4M//NWcQiqCFKKZ998g0iBIoyEDjyBInJS5Zoh88/rzHi2/QRpWvtKVh7YSnBMrvByscLnnk3uZBYqJAAZp8u3RiSALiMiLJIoCwRc8IEmxYi//+hpkIYod32nsAAy9+mcteWXfG1yYJeIyKtaDGAiyaWydbLQDDaHQy00JjNwuJm2pya3fKqKGygF5JaXMTdE5NHBYQIFImMBUJjXBAk2LEP9P+moiAhgRXi3+wACNTdLIEHUJpYkH0S7jCh0ZRHN41Y1+NYiVDBKSRLxQEiA8zqjsEz1ZSvZeMK4/GJmk3PBpmbd67hbjEkpesE+lbc1y2qHdwhAR4j7+wgCbz+NuY2qDZTMRTId1UYEuP8zdli6YRQiB0kMwnyRAJWUcNXVQkc0Sfp6qlM0E4hq3mFqFWP90tvUIRhgGBUQhFYYcOeVFRtHU/oRESEKJs77b2gASG/KEXy6yWpJUL//uERPiBAlMZS/svYdpQo8l/YM2VSdBxLeHlAeFEDyV9lLXkSt0LoLBJr1BwFpTJcrL4tfJixDUoOudacpDW1urb25VNuklxl3s4jNDKqbHmywihPdaL5/3qBgAJGp////+iYgKUVV433tAAci/fbxnoiMLCY2EZ7JhjqUrgby6rIsK6NGOgICfkjxk4sxNWfRLP1w5R92j6gdbgJwOXLvELGiNmLQ2TyVLnG0NLef4rEBsJhD/reJB1Nmd7t7EAMrFWNETC+iTRQhWxijtK1SYdFa+j/IIcKrg9LaF80K0U49ZR+tvWyswxbAwtA3rX23Tc2XfEiYOMA4nPBOPLKCSGiM2tX1sV///S8MEojqz232AAZ0E3AEmICCWNAcZ56O7yKsRhriaF6du51MzWeS0TzJMxR9TfxN0tbUuLagvh5QNarnEmykuMSNi4DE5o//uURPEAAnAfyvspe8pUY+lfZS95Cky1K+ywb2FRFeV9l418+ocWWFktFTH//W8yEsJq8XT2SZFB+hjYiBIbnrQvZXKkar7SWaKx56ASqaJrW9RQ/Fab27EcP1n3KvXaDF6L9NBKQgjBLS0xp87eyZ72vkeICVB0Z5v4wAJTcplsAwmHirSEeAAtg6DiTF19UmH5ViZeKTCmMqtDRm3xlCGpuRLw+VI6tGmh1S/7nvIA4VKggHSVLUNjzt4yQ////VWHkJgkmJ+vtAApu7zTEDgisGpmM6+2nDysIUpqGY5NCSfmSY/MYgHGKp72LX002G2Wh2VyKwszdN91mW2IUn67hZlP7K1aqn6Z5CVJ3eN97QALncmQILjA5OgDiEblgHUsNbS5TFaDsHgWExp5d+CQfvFIRuFtn2Jp10E0IfdmpfaUjOCeVv3zK2CX2lq1VL6ibCJF2ltt9UALuGbahFy/C2kmi9zB4BR64wG8ntHHVMB6WtPEmixR+Vtt6MR7//uERPqBAp8fSvssG9hPg+lfZeNfCKRjK+flg2k3jeU9lLHk87S708XQMJkVM/D4mxoZb5pixg0YAwu9k8AUDmK/FnmAhyWHf7e6tP45w0K1KBBuEIYaIOjNPn2stIZu9Lyt0axGcaI5JmO3DvbqveIWZytLrjKN+Q9mDEnqTmW+bcKHHpokLo2CfRz61ViBmAVoj/+0AD+RuFN0sNgKHlu0kkdVA7lZRhoE3FByWvIDLbnrIteYrqwtVeYb7pq9LoG20e5Wm7LsRA553AZ8uXkfzWvFrn47Dl++sYAH7lDd5E0sULEYEv4qoo8xObWUiyYZvuz/ZKWjN8q60qYlt3Y3s1GaaaaZ2/kncAlDrWI9qTo/sL21OVh1DWBFGw2NEISbq15HbtR//jPrZ9m/K4c219aAAklTQ2kCNASKR+/rA1tUiAgaKOhoVrs/NmK+//uERPUAEkIby3sMa1pIA7lvBykNSZiNLewwb2EpFeV9lI4lkfocrXTlZ9/1U8h1+t1tFVTIUqC8B81AsJmCA0YaRIua4m970qB5TUXaf/1+7/rZ/Q9WEqL07/fasAa20xd4CQIYkkiNIKQsIspk9VsCkS6ivlXxdvmm3hMmJwz4ZRwEWdrqpqlPtQR+aF5IGW5TYPx58jF+3pe8xjPzv9ZJX5J0yjeDhwNVazRoAD++zsxiRBRTfN11KbiaEaVWZoiLKLgki0SzxZnCQgQwRsPdb3+zL/mQTvghzQ9n/n7OS7byad37YRO5/3V5FWJClJFh/d6wANbki8XzEKJJQJImI0XoZUjHtDwvg3rJaZSNojg6O4EaG/b5/zpaiqnFUy7hFHapSmPAqDkKGIKgMYEgZCxDqUXR//ku+v8XZoR3BmaProyAO6xnFYSEo51p//uERPcAAj4fyvsMG9pYJOktaeJtCnBpI6fh4yFADOW9gz4dMPwl8Vi5M+d1SD0w8KRGXL0lELyYT1rL6tjaNdFd/GaWo1inyvLXvne9Yp8wt6iI0VefbdWsL6Ip/2q/9LQwOwI6td60ABXtt2TnLcDoEloNLWg7DfERbB0EaUBsExQBpWXK4m7kCtos19u5XZ9ZZx1PuXNgKlOPHr9+KDBMk2QrIARTz7JraEPp6q/cnq/qv3du2reLknvrNIgBELNZ0xbQqVP0oHKJUlett32RLuX9UnYyydtFm9gSJLhuaf8CU4hn5zFWza4cDPq9b5tWNXFZXmsRNJDwhi48Hx7TUGAVeTdZ6XiAhiZnn7a0ACUaru7Aa+SpUPBrqfxuaLVCzJHBUcTexoqQLKwNAwuYbZm3Sr4v1K7jaSBkDmJc8t2VZl6DoZloZb7sgDdl//uUROsAAj4ayXsMe8pQQ3lPZY13CeR9J+wx7yFZjSR9pj3kPDoj5FWAl0dnf/awADfd+xCLwalGDQL+Xm3euFFRpgzQ1LTpBVI+vdYpmfq/vGFoXrLZzDrYQNprxbasqGyWFVKqdg+PNlgGLlFi7CJf7f/pZoB2JUZtvYwAJdeuPihKSFC+xSepczNHcOGnWUI0CNFqpy/OLNDgt7m+cJ/rLFiRdOEsavkxmWV0EwdqNaJH76Skz29UhanaHzEh3kwg0+KCtxxHVqZb1792veq1K9sNzH/d62AAJpPbVHRvWTrksYEY21oR0CqqRDWobSHnMrlQ+LolsLtH6N8gvX9et+WDUeQsHU/1MU2WyxgH0zImcHTwCPtCoRJMWD/9P/p/6d3S7yEyjtEf/WAAQJlfkLBUfSo4nGqd7iW4d5+yUyRaNiXDXjgBS0PLcgc0O5qE3cPU7yUcERptYQG2C5UwCqVmQ2eB0PFz7AqFCDFAt93q//+h3kIcFZ4++kAA//uERPoAAoggx+sMe8BLBBlPZS15SaCRKewwb2F4EuR9l420zsalCeyOjdytawTLUQ3JwZApypg3tMOhVEg20IDATSaeNH5MoJNbK43OEugbsePHBUeCqUuDIxQZWCsuKi5YQOcPnv+/t6v3+///Q7wEIKI8ffRzoAaw5P8dQU7iz6sbhV9YCNCEUhKKrliowdwplOQw8tmyctp9R32j93lwGzpetu2EwOByYdDIXhgUBlhAVFy4gc4fPf93s/4t/3/9NXeAmDd4f/a1ADDHUmVXYQo+ROVRZaXlVWnVrI/NBUEa6vICCiOJLCxza3bgq48h0pk7KzbYCTlu79JXPO5zX83F30Zqe6F1LToPCiRDl2b0f/+n/q/q341M/23sgAEqz1EGgM/JCCOdm14hDXtQFgQKgLGA4EVskuzDRS/S/xWeOTa9MgyOXXC6AFe1//uUROyAEpcayOk4YNhQ4xlPYQl5CpxlJ+wl7yFPDST8jDBkbX3etlNpvgs0tx1ZoeyBOvRYyOO7P/2f93/+x7DdOa26ogAa+vFlhpUVRkYnUtoNooT4kCDl4z02FSXtSRptwqNwhBRa2MenOXUPCknDCBppijjiXjogMXMPsWlvvw6zwEqTs7XfNAAXLNK+qB8dYET1h0TfkIcalKZDypE0MXJBAPtRE7oGPV1HDrE1JvUnDk+0mDBUbqJEY87xatqUpaQiKDn7fuw12//pZ/261U4LTK5JI0ABvX3lVehYKYQ4NryVK9GiBUSAR/1musyp3oHWrkQRFlyTfSALGF5U9EtxeCq1vv+n0jan6WhGKMuAjBgbW45HNj29HaglvoXsr/R/RsMXfrZ5CFJpd//7AAN7prreslniuNk8TTvmMFVYzy0GcSpLo9n83ysZ9n+NRKXngz304xaRXoZzFqbWrhWHMGHRgM50yPNxG47pMP3X+qk2I0Y25GkQBvCU//uERPQAArAuynsMG9hRhYktZYNfCHR/Iawkb2E8j+S9lL3kxpi8kFCFoCJDcGCUTcHoQltOhbkAgOikovjSjCHHbUnThiWEUNXM9gFikLxNxEpMR2G055h7aT5Hjg3IFj6zwSCcMIAjgYIFhTZ/sprp7+jsv9WpngIUmZo32kQA3jZh1na7EnyutmzoovvxFO07DqJedSSbJbb1i0STc2N4u4Q2/DdNfVcS4Bsw6535TcjzU5ttZPThMRmNckWOKPBIfDiAI4GA8VZtQj/6f/1qZpB4JXdt/pAAM3cJAiE4NgEqXhyPwsbxwAYXF4GqRhU7eG7/dPX3GGlTT23u9Z/LEFO9j6/XfTDYMFbCu6wiuI80LBBIEUBEM/0f3//1M0BCpDO+90gAG7Nq7MJoDJ5O2XTZGn6xCeepWsB6ssCpcZK6w11tifpuJuevXa3Z//uUROyAArwfRmsGZDBLRJlPZeNfS8ClF6wkb0FmlCT9l418uxq4dl1cr2quufjWwpokIr3HND9qigyCIe//7v+plcHgkZnu1jIAp7/aNk88SAK0M1nE7m3li8H5fx1fDg8mQwp6RjGt33C9umrY+oJxHjSd7l5spERkpchQPcVnfGvZuZVjn9U+ffHiQljaHjf6xADO9L5Y0suQS5G5B00T0tUYc4FXW1+b2CRAgydOc3jS++lqVtqrpLU1mxKZqty4ROZEisXIEh3UiMCiQVaNIGBo7S4ojr//VXiAqChof76wACIcwfxcj/khFEAdhBhD5p9lfVZgCVD1SwERODJK1bQXCGJNdtan8uQEhocCsO/1VLVoiUNvh4qbghyMUAeYE6//7/9ur/QrwEqLRD7fSAAXMBvMIBCraNJAkNLtpKtGb4OcsZlS/l2u9cjUcp9EA/ei4Yxmq3rv6kBKmZeIKUb++HhoylYRGDQARixTNCdf/9P//0O0BEEzxG+9//uERO0AAnEpyfnsGvhNpZk/ZYNtCUCPJewkb2k/k2U9hI3soIEvx12H2elhS/WINib8ONVborWwt+IpIDRqatVQk/bltlV0fa+6pi+8CepZNsFk6UVGiiEEjvsZKRZ8pw+m+IQWsj/6Or8a8SEKcO8f/2oAGnA5ymI6QsZYgzPB5FaKtRkzJX3fyeh6g9/C6yc2OSi5b5mZHYUc1IH0+3TO9NSN3KDUau6JpOg/SPYb//77ZXCHFHZrvY0AKTPLBZTSyxZSbSF0MPKDddxkzjw7hJqSVBkMpj0epmFTHQj1W67F2ewqgiCKBQJEmguoAhkJIC0A21UEHJHtFiJQQCn0fv//9uhlcIUGeFv9jQAu5VcaMdCGIw9AaNdAKgJnwDHIWjZFQ0qFSPWCdv39R8JJlKoo0hIk6LVNJg6HwmJQuOKHDAMDWmGJOL2xpphg//uUROgAAnkmynsGQ8hNg9k/CyYfCei3Kewsb2EgkGV8bBh1XWKQuFmdX6f0xn1hEhDHEPH/9gAHu3ZQ/Kqhqa/rKq6r77vrfTXg6H4s61DRVIHMpVi5tMWIyXMl0g1SQAIoaPyBm8Oq08FmHDA0suABA5wEsUdAf///9iPQQptDx//qABeLVhL1JOlfiIEEKJSHTd2yKX17cTbPKKq3Ng9rGSj3C1EXaj1OBeDuIxtx4MdINRhNOYMBvej+3DkiCJB3OXiP/7UAK2CgyE0qjD4bBqoySmfm4CLaaysknjU5kNOLIF4Nbg1ELFuGW1FIowCYukzVtSJLQUlUtJTykvxfpV1UPU9DQkVOt9OTaICFV3d9v7CAJcYA5pWOHCOEScZ4h9XiY6Oiir5p0DyeXyEbFkA3Z75lCK6fhdlESwABpzK1uLuk1JKF5CwEXLRhQ2bFwiYETQgux/21/R9f/UrOEIERD7+xoAXO/SxR5V5EYcMHqrpP0eFK2eDIqryD//uERPwAApgZSXsDfDhUYzkvZeZJCZh/KeBhAeEOC+V8LCB1IYf0mWGIFns9HS9BHvmlUq/jBMo2s0iWJh40WCY0PnDJ97SjUTzlgYjHqx48WBpG7///rVoCGSHZ9vpEANd+VsoTnHBiM0MIXIOgLvoRwtvlMGfPJLLcJa7gZyoGEuHhJnphDksO2171i2zu8CDC9r5gAoBEAVK1ha8QpQQFXIYykmKCJjv//9v/9K5VgFQ2ZXt9bAAyy3gEAy9iM42aSikpUA0UNOGjwrBF5bFZZyZhAhgih6QkW8V3cFvO8DUyqqTzOsMBUQAFVSpJZ4Nh01epYRYL+tGmn2/9zv/b/pd6CmSYeP/7UAMs7kE0RfckQPJASEKFpMnutxZo1uSQcGMPdmR9HylbxWY55e6+Vu5JsRGOaVPho+21qz4iKgU0hFgNi9lWcf//97/y//uURPYAAnAtSngZQHhSZBk/GygdCmxrJe0Z8OFgECT9kb4czvQM7RMR//awBUDjLNEAhKKPhLvriAlHGnLTp6sPfqo/jmzDjIYsUmpYumHs6uRdDYZAjE+e42oOZC3hqnKYj+nY9IGtIXiupEic56QBzQR0ru4S6PERWgNY2ptsjRyVjwp7SZgw8elTLV6DwMmBLSp2IXXG4XuybOt1YvlqbmbSCWjrhjAsCGjj1VQJwN0/aHUi+33CBYv1U5MYCB7vv/+6//61V4B2V3Z9/o0APBoMmmMAKrRbTd4HUpTgmywUt4JGilBPySdWot7q2o9VOMKVeCno5AOJd2sd1USisNsTnQ1HjypbMKoTF4WFjYo8VYA/s/SjuEOLu7b/RoAfjVpcmAksCK6ETAxvh60VJLCgMRhYWJwYg6mqqa4ZDJotOCTrHqAmgp1QsLUVEqrDrPWo2hrTpxqXCLHEToFB0QDRDFCp31+jMe5ngIYoZ3jAHNW5ZKRQRVnHk7YD//uERP4AIpwbSPtIfDhM4xlfYM95CiB3KeHlA6lNDCU9hj2tcVWnBQ1szEYFgF9ucDsdUX2oKM6MB9Y326QKOFCBMkLFgcBADAQukhKhAyBwkJwwXADwIFhQTvaCLQYAxlX+z/1usBMGzu//9sIHce/AzyKLFZ012lp2wFQv+wVvHpnpBD/AqlXlkrZiCwUUm1cXESaA9hMWCAEU4xltYCIrp6AZwweplTQW5iDZDB77//f/7/zqeJCZSId/99WAJ0InBQ6FQ7NFeQepgPUtrzZKy2Dpa8lqqkW3Kvi2Uessea7QMHJj82isVQSrwvJxRKcbH+zTTqfJw3k0/O6nmSOrhUJDu/++qAGafVXj4HUBbE/IKfEpumoQ5GMAKBGdrfd9yIdlSp7PJYK+3v833rWlcuVnWZBENiLYMGGB6zrf0S8ez23b1okD9cwizxED//uURPGCAoEfyfjYQOhT5AkvYehHCoxjJ+wN8OFFDCU9gaYdSMDQWcMwc2RNzTAZ3OvlLvsJOdWrkU6zy3pQ8UaJwkEzum4BGAKaOggqAAyTssfZY924mdNixqpar3XnXD6VdjLLY2Pi8/ST+IgAGytLboo+RGanPpUqQr0CJDftniL9OXGbojHV6ld3gcYBHAIOCAQQABQAEKQoh4aFhVbK1UyCXSD2KIZoqssjY4VU8sMFXFcyBmnzYuhNfrp7o2qSG4W2W2RtAKhZ4MFDEIvYyV8kJiXOLTV0sCh1rQSC4QoWZFJO6js8mCLn5Wx6Cdzftff7aab8ijVjqGDuLcV1aUsL9xIPmpvvA3/t9/53/03BKpHI5GkQGUILirRSEsPhWZAghEzqL7XY8z7xRBcJXqTS5PFXX4ufqe0vcSuwzLZ6ljonfMiFxx4IAE8G4CUH7RENDtwSB8ioUNLOTVflUv/+hH/6aKNDdbd7bEAovn66ySdq6NN25aZEwRiL//uERPqAAk0nyvj4GOpBRGlfPGZ5CixrJawFMGFoDWQ0HAh0I6XORw5PWrHdr03ufls5jMh0qCFWnhZ0zmM/7okToeFRdh14PEwTaBhFcRICxJ6odeZ/1pVXhVuSxtACcok+Iw8Ti+F9FZ0iECQ1FgQIAhERf57PHLO7ZnAIYeLONhPBdq80XcQWIFPxCNSqv0/u0w1O1u22tCFW/y6+j4x0WjGbiiaJTcKUZt3kB2bVJzGcxCtVKbfFqXePCfWfdVuWoymhoa+TWSXMi2IWeGEwKXFzAVFmEwmEWhQRgp/9H6fe7x67k7dXUAMfvywIeVKVQ1eamVuP4+5j9V0k0589YbNImOHUYALsqD0crlLNY5bXrXv14wuGQAIT4O2uXR////62YXDGZJGwQBvLnwO2EVKPVXdefZ0qBGZCCBnxZcbH3V/0WK66LEeuwxqV//uEZPUAAoMjR2kZQUJV5GjNDygaCXR/IaFgw4DsjCP0HAxY4xdfCBfIqQyJBB3unuvxzBDiqP7bjSdNP06qN32fR/zlXtDkkehN3wB8qp2Fjk02F6UkWp24uUjQoe0l/JNSXlpvXoi2u5C3wJSSRELKBSkiEBCWDG+dW5pE2jfvT6r8qORbv9/Rs9U1XjIOBsySSRtgAZTL0LJHUo11pRPzFC4CoI9H3Mo5DZgo0QOINITwZSkHCvYbxmsFGtbSRBgiD8RFiASFxGCoSPCcHgT2r//dZ7fWj9y/ZqUHRbNbbdJCAOldCBdxynjqJcQS6n8aJ/IU1J+8JaOjWSZbiSFHrA4pFugkBWqwYxCxx4UFBCIhKNLiMSgYQiAHQswTB8I7e9P/3f/92tGBxVouVpIgV1HR/BpwV8sxZtDaPpJryGr4IHrdfJJWivSwZYoS//uEZPSAAocnyGsPQbBBpUkNPCWGCaCVF6wkb0EhDCMwDAg4RDLQATSVOGKIBc8CDFriw5zzay54iGnArspXY9+7+2ny19TwRwhndVi32IgCvZVYDhyPWYdEpK1l1HqRz7BCsnwMGMAAmpMtsi2uYwEBAQBgwEZ3ZnpmEOCSohHnwCMesOImxZTGlGgKisXP9O/qV++qmhMNr5I5YkABwv0/CH5Qds77tzfh910rwfZ9G/BiXPdKU9kks1UMg4gNlnEEPUSFchF2CyBWJI69SlXiZ55d1cFVSlQsCuDwrwqzXOEkf+iPMIKGhBjI8eghkQkJUFq7ZDDUr9gfaNFPiGVg0IKLDJ0nWzCm5PXueWRnMy2ewpZtRGJrGP//oJ6f3FOZzy4M4ft3uao4fpkEs71NgzgzHDu92zhAGmgQEuBDw0pbnfnBXBaI0grDPM8F//uERPaAAnEaxmgYGHBNI1jtBegcCShhG6i8RsE8EGR8B4w0VwiqUhmRG5szkmqEFPQ86SoRqag69SU1z63gkoJjgGHyGqPsQmw44pHJEkAPUWgDDEw3lLQLQajBjXFtx6GY/cZ0uqkD4juYerYYrmrfQQJC33NpdWvA1V0IUMnFOAk0NClK3qQKGxWz0OqX/dzFrs56qgVQZ1hmb/61gDoJsEuIGrEDoMGRIDMuiSe3O78be2dUOaQR5Pkr0vvwY/qmY+en883OzNb5FVVY3dZWTSem61knJGA+iEkAE+cY3/0/9QBIO7w7R99awRJVhp0oQ9ksZhZpnCUSyaVFdjcbueW/IepPZ67eN+VAlJlxO+/TNfnPkvb5Ox7mu/+TT3mvZQsbAb3lWIBcupH/V9ndtTtxd/r7tm0AFYgJ3XSIEtCx5AK3XKVUVkf+BIZC//uERPKAAh8XSGg4ENhXRbkvPCOFSFCBJei8ZyE2kCM0bCCgNI6vQhjzpuSSKOpIpFQywrQ2HHvYwbLzMkNFSMeG3upo3FPKYaJ6k5nRnacBFzc//1/66zMDQ7qrXfNoAY58u0kKQ4FLWoRwdI7zsKqCQXBf+XAwlyImNZaUQg1MhZ1lumGa9x2jFW4o8o69jd33tAAupJ4DTygIVKuInmgkwJrAAIjv/Z+qvdt/pr+N99vttYkBYQA77CECMCTM63jFYg0Uoa8+UTqSp1PGsy12Ye91BfSJQxgXjbi0mkZXeaqGcuy1KZ6prFeh5f2Ea76HqLpqun6rcjS/keKit5Fbzbt////zrA4Q7uzPv9YkQpWTpPhJA8l8PwRYp10J2nT4u6KBrrIyijhCzIcMIYGaUleBzowvOP0JDKixBkSkiGbkPiEG2lSAaJKIlkIf//uURPKAAnEuSfosMbhORblPAwYbCgiHI6HhA2lckCR9gbHkEkdSh9jxhuGKutwe1S8Xzf/f6VAih3i8FDIZnZuGp3IpR3cMESmMO5M90ZSgCGSIoYmFiDEARA1LDX2pKFTjFXNfzY1RNoGJVQqocFQEQO0a/Xf7Pl8vZFCsWc79ANAQ8O6vv/KgRndeJkJYInCxCINyX+7zOUYSwFY8xJ9/fNd/lNtHkbmNRxFIa5CFvf5zEvSZjn5rR2rt/9vbmSco5kXBzBvNEwmkjqb/X53OqrYdUSRVVnB5aFd//nQQJIly3hQRUtDMG0KTKbhLYjGosnVOb3iM29MCaRVb5X9RbpgcDjAgKilyOUwTJEA4VKOEJ3/7v2QyNx9db7tXEQMK8MNjLCI7AVh51vylhbJRIFQsy26ihisSkbsEI9QxQOGRokOq+svkP7/vUocu8apwCK/1dNj9TmO/J/3k17+O0f7W3bWNADhuwGskiZFbSqkCwYzthAQJUJjWx9/z//uERP6AAssmyWh4QNpUhOk/ReM3ChC/J6C8YyFXFyT8DBgsx4s1Ei1qjTobD9Iw0ikqg9PC/pJFU0OXPHK47jz0ecgnVkO57/////b/6DQDQzwzf/WNAbgrQnIJIDmnsBVhlVnFGroUq5XUGyPvaQ7KNKM7BhWEVGJJ4EJumQ/uXaRgEuWWFYv3mJc7DNWQbljMuLX6nTrP3N/8RXCHJmZt/ZCSJGT+xKcKIL9fRWZ+fjDmhjbNa8192feFTKHNQDuYQjrooFXdkFQAA+JAI5yC4UQABGFwmRC5kVaFgQ+d9F8d1oo7btj2KF43f2220hIG6MdIa4KiR8EF2TbChPpeXVLqMkMxG2CVUwGBxZ6j9RTBkpFsweIb4Cf+zTQxAjOBcmDhgUaLCTudtRNJZTotZnB3aGZ9/7WCPzz3RxJqhM2khhO535UjM0wsYINt//uEROoAAg8YSfgvMNhHgvktAwMLSShdI6HgxOk1iqT8B4g9vnn6uYq4bVn5ltOrZQpUx7o0E7RWEPR7KDNBRL7marcoC6HGg+CYOHhOGQScAzALA2//962Zwhnhmff+1kCERS+EM+KLsnfdRuXSpQJsUMQTUdLevmVhnWQgdqDqFGUwNlrix2cG9FLFgOyDE1N/Yg7vMxMgNB0GAWOiANA2DTgOCpxz+jdZqXeAd5h3j/+0gCA2fTOWQJRk5GFtEE1E/Y2FRMZm9nI5yn1EqFTcNl69RwDn6F1pc9cwboYPh5zjAQSOKRqxMoIs0v9f/qdmCGd3Zt/pAAIlWgFOTWWO5bCbFVYV4aGGM6AjHbMz4QnQmVRRIEEupgWZgTki0EQADx8Nmh7gmaWA4GGCijx7//+v/kQdgh3hmf7+xoD/ddvxTASp0Rhdku1ClkiW//uERPAAAnYayXg4MMhHRLktTeM3ClixJ+wsbaFMFST8HAxs4JyarJHQnjCKDjJ5oTR4JDmdWvkk6WXibtTK5TO/7Zqr35NqNcsH6iDgBiCPUh2C7v/V/+gHgIiHZn+/sYIh2XzkI2B6OdXhAS8Kc6wy3J0yaHOmxaMKkqKep2my4mwCMUEQE4IGFFSrfBCiSposlwaCQiYsHUEw+CIwmbMiGCH/8pUmjVaqBYB4iHePtrWkOaGYDuFDBnIEeUE6wf8jkqRYivxqaq0X3i2lhMtgRc6h7ltQcyJyfXSyuau0VUr+wlxYSOcqKDFDRif2z9S9TrSSqVAjgrwzM1tsiAHU+3ZO1Z1LaVVatMBRZTajypAMTLx6bMyom0tb8nyLjcIUULeZZE5oXbElHjJFWyAxkE+OLg+ZYWFixwFgk///VxGrqGwn3+2+siJH+6u4//uEROgAAiwfSngvMNhFQ0k/CwMpCcibJ+eMzylEkOT8B4w0gO4VFuQJBMZYjWNx2/PLpx2TytTcaGIblyehwxbB3fHOsJz+5sx5GjwzRme/XIibhGPrgjbzRc2CB8E74/os9duSv6SSlDmtkuskaIx4NlSkASZj43KlHwm5uoFVv09Msr40RL4/t5cFMRaUOTvZJXclO/nMtDdoZv6TxLkRoOQcVmnGy4YBhoNuf086yn+Q6xIJ5KJZrZEh/6WyFCA8zQBFgnn6cIdAcuMEP/52VEJZ35xt4DRt1L9aFXjtB8HwZYPOCgweOYPeGguXjigZDQGhUoPLPVv/+pWhOhyphxyRsAXDI4MKp49eyooRPrNIxgkoxH/97ZWJ/yh7EZDPOlh0yQbiMrhkjjwusILYPW8LFo4sGQ2BIXKAUs////839P6wIIjGpJJGiBZg//uUROiAAmUtSngvGNhNJdkfBwMbCfy/Jaegb2ExleO08w3gsqGcGDJy/P3npanK8MMSnPMor0yJUd/dcioMZjXVUIx1yVfOtSGAAQAwjEJAJCUiJh4jp1Xmm82x+9y7Lf+77GIG3ZLbbawhLrGBwmq4a3Xpcrm+aLjMhb6Q65kTsj6E8RlolyapJmSbmfnk2ZozMsPYGS2Emwsw4NbehJE3/9CLltN34cez/qoSjSySXa2RIbuzN4ghrpdWzu2QT0ohenGzI4ZXbJWHUsKgJ0IFi3BmCizeIho1gOw7ArwPwSg8OLhlDB7BoUJHTA46HAizud/VX7ekOBqNty2RtEaUKGGu9i13psGyTpBp2N3N75j+881Uw5RdteFloxw3f/20ztwzqdsdzrIKYMAzABGoGFRCKAMkYEpY2LLiqsocPR+mp+3u/930iMKOuS3SRoDGkhOhVY3BZmAgZ/o+Iz2+v5+Y1/IivvjUTKeL5VjZLSB4AieB2gyAhGDTACZN//t0RPuAAk4eR+njS8BHxCjdBwMYCTCPGaBgY0EiF2O0F4xoB0oHmnAuBHgUNrCR4NmWCrVnGLyyKWf///0FoByRuSNtEihDIIO1B/3mdinnSp2rZIVFjd/qH6RE6s2jWiVfGFHtjDCJ06gKCIOCwaCqACGQNBkcVKkg2SDbxMWEQBHqCOrXfytMmn/76bU99SWa4knLZGiBNbVV9hca46eV9uJlwB7qRfw4dd4jHmGDGHhJRhMIYABk7EFc6ER+CFxzKnQDCB9gLAmEaQZIIilZeI+Y7WnFELfXVX/6UEpJxpOWyNEC0RssJTiu50vKBlLLCbxNa//15h7ja7yZUO/OTKA0dL/N1wzPDXUuycMqSoUAzRqmgUEgk1IUTidS//uUROeAAl4nR+gPGFBRZJjdBeYYCghpHaC8xQFIDWM0F6CgjCCXe17mT6w/731q9VP6AoHXE5ZZGgR1FwokqC+nyiVVx3oe+ewsqR+7qj5h0BqU8epRzVgVCkQhxQHB0kZAhYJAopR1pN7FmV6uVARxn/5LShnNJa023G0SBX0gQRGTT2WOWIfPoVpNmRGzMPq+zkvMmYDFihQ5YUPiIGDps28GBOeOCaUTSiR33yYnWeTW549GhJtq+/u1tbQ9/5QRiW2STWxtAY2Y4oPe8hnumsSErWBcTFRTzPfJxmn+6ICij7OJVLNsVn1FLabZ8xPnGW4Pmw+VtsuC9VKBYgE1oNuoora3////qP439yNpEjDCrTELV2Z5c+4qrTnDhJVcmJTTLhpvhnLW4knUwRwUa0krsxMTDCcNl4XIgkwNmWlGiAEwgZFhCwKnzrqf1US5vaLPuuokX3P+68ndR79NrdZEQMWzQtm2hba17Y1kDwsNnk3FB6xLMneQYozE//uERPWAAm8jRmg4GMBQZGjNBwYmCJxlG6i8ZsEnjWLpMI3IXGu8IkIywEKYLrHd6ZqHJKnmRqaZPBeGQMTOCUHBZwNreeay1bHzVnfenVipKVFX9AH99x5A2QamttSpiRBuLjfxn3FNGwy4yXbW1V5vKwY8R5R0zeQPwj2vN7Rnkxoe3nKypn5toveXNf09KJ9emi/Z9QTfbp+nb0onW/pB2dTMiklHJGm5I2iBAiMikABWIyleQDRSKEyPAzN79i184TkpuhsjwYoiU8XFGspjpFa0ujQCcCwcSEQ8LiYJmbDs+GgxXNnrfwL0N0X2/16rCCEqmY5G2CBXqODdB5iknbCRDL64QQxfixax8qbuZuTpBsc5QzWWr2w96zyFwcoJlxE4AiZYqDpL/5Wr+ev9b0f+zatLbX3I2iACcwYgw6uHcq8eZWlw6TKjsT1w//uERPUAAk4jR2gvMUBSZFi6AwMKCdC1I6G8ZSFULSJk8wo4RvUhQkMOMLxcEZVHCCk0dRDigYWGyps5DPKA0DDgo4GgdUSa1G92pNFQR0P8VrxVHIOOHpmIUIBN8Yy8gAg5EnJLJEQLStgOl08fQYKUQFVn+W+eHN2y5G7eTlY91MYCH6kZieyeybJHmzbU2RG5rRcpkNrJtbkQgkJADctFLkTCHPs109///9kvAaBjSbkbJAEVwLDkIP/C0/0Vk4WtA7Yv+kdd1677h6zDYKlA36Rl2br2z2hJKvNGNG3sOtdbJ3K5WeJMWSwi7dp2qdryZTqUM5o3N//TUFD37ibJAFIIUAFb7PhkA0EFj7JK8w2xkj7mboulJJGKcnv/926CRkVtXWGoqxeaoRwCdFLC6pHI45+9lNlb9Wgv6x6GXGpkU//KkFExJv/pAtRS//uUROsAAmokRmgvGUBDxJi9QeM0CrSRFUFgZME1FeM0B5hgWyXOGu124Mqcm4TasttSSljxc1eZmTFY+O16+3cZrMk24xQnIiyZdQgOj1qDRgABQ0y8/rMb/LPtzD3IcwlL5BDG/KO6tqldff/6QLccZQWFM6vdSFK/gs0feDIKOqiojlk4d0R5qPDc0M0jpSgKhcFCaAwLnyQsKiJAXeSJaDaWoYiiuuHnv0j0zC2uur7fh30KBRTjabjaJAG4BEErcswqy7qYTYhAoSECVV2pnWQnwyUKYdQNAuokMeBAPAkLgqeDzTxQ0IFRcptuRYljFH12MoMK/d2/6LdvXXUA4Y223ZEkQN8K5AZ2Y4WFamdRtmJvM+5iou9b5L6pAkaljskU3RRhVSxGJgoMPYoQIWGlJ99DEh8HxQOFAdFmUmlrs2v2er0yXrqqQJRN6LY7WyANqPGD4c6bho9HQhcxtPz4cndjK4L8vy5z2qpFIjJIqJ5m5GwKNYJRdFSR//uERP8AAnUnxWgYMMBKhLiqAegSCfR9FYDgxMEuj+KkF4yglZAgQGMz6RqV1PqWq5AarMFk9izQKRVhSv+QNMhDAka8ebvui+heudylu+XTr2+pL8OLnR4mzB/LWU+I3c30cxiE7GgoxK6AMpTSSVt3oV+LK5b3f+a/+iqCi/zW7atkkfP9ZBBp9YjG2yivlwl3i+ef5qLEuvHRYh0g4IOixoUq8QkYO9LvcpP5tNVV3gt6aUWqrSBufWbSzXJzI9nQCwlUm5LG0iOpI4EQKTrW6A7RAEOtLa+swl3OrlRdNd2eSGxJyTpidJ1ijSmuXCKpKX5XYuXywcucHLMyCSzBRxPKSCgD2KGRoh9/9/00pDoe0o12traHOPBDaNe2T/S0EwToLNXX/Bx1DMWyxQ1jAg4xhVjpyKoUqlHwYAe2gQAwK2Qq6VgAoRrbq//e//t0RPqAAlEYRWg4GTBMg+i9BwYSCOCXIaC8YyEOkmLwHAyg/9e3z/9+XUv//v/s5jf7BKJiYjkjZIHUpgawb1T36HgGvOC1/5HUMR5JFKiGw+YYNGtbpDIZDGR6xXKwpYZTOM1BTINlQQQh4ppRmGyW1bTTOjU82iZtHV7Pcy0BEqIk39AFSyskJB/f7m61lVFOcOMq2337aqjHZJIyhlOxgEyEUGSCj5p5KKAwOgIUUhBNddCvZdvdYlWAKdXUkzFU2P0+rFQCiYUT/0AazZEJn1vPLNk7A3OtS++X7GVMMTmZrjVhDmEzKXIkBI0484VQLhEbGtKlktHV6/9L3WIVUBKK/VfFU7tNOUxcNCSRSS2RpIdbRrBSLel1640i//uUROeAAi8vyOnjE3hO5ejNNMOkCahfH6C8Ywk0FWL1Bg0IFIbJxnl1S+5vvtuGT+M5ctdFW1VGeE/+7NysepzKxygkZFK0XdYf60MOmBzDFAmAbXiBSpXD6gxpUtv/fQggAQXGEnI0iiPePsK7rXOLlQiggVvfMr2uh3hhCkRgoNpFgdEYwWFj7I4EnpuPM0zi6FBvrS0+bHsN0iABXklrlcMrDNCFroS762pvfQCEo0pJI0iR1VD6Be+rcCUdg3NcrlcvUHQJU3Xc7uClU1CmhDHh5QwCrVAEiJQwZEAZBd2WSWxrERrlF3IeivRkRdinfctFgp76yVk31qIQKkKkcjSJFfQDvgvOsxPOLwi5IrNbqvqDoAqarvnrc0Cu5qWHHaUMwRq7T3TI4kV5/kdmW29N90fWRNgtNWnJC7Vu+5SLRf9beY6gG0okE7G0gBS1EJ5Na1yr8Ev5EaofT/4eefiLRIchTpBKEgfmpG/EJbIs2q6A0EAnIrsvCR4g//uERP4AAj4ZxWA4EMBGA9isAwMYCiSXG6gwxoEvCuL1B4kIRQ5I9ctt//1vZemr+rrIYdrQctkbAFdaidlrbSlWI5nDUjHr//66biln4sKkiCGDWo9vQQfHNCBJZRAVAjGSD2xOUvNomBQhOVf////t7AEwYyl/9KN2OBcKAzq84sgMEI6jb1LIs2czCo8OPm6PpFbRTVghbqGkKrvYxFWDoiDZspHdJDnI4Y5efGX6Dr0kJ6Z7H2IR7f/c5g+NkhkVedEDW1utHN7WIlgEEY0m5I0iRrDw+RtzYzp+USXQm38lxmDEZKlSzDESjtilHZwN1ct0eQcE+GkQyiEgGiAVfKrXYbFBRQiPLUEgHS4nZK2LINxsmOijzwgY1/YNb9EuCWVCSm42kQN2ZIJQsso7idBZbJVbbedfZpOTnmvMtLNRMwkXeEMaNyidaJto//t0RP6AAnQfxeoMGbBMBzi9QGKaCJiRF6BgYwEDDmN0F4xgzXejDspeSL5VktK83vknhbllSJlFZ8iWjRanI1uR0bnVfzayOigBNKEJyOSEgMkCCw0o9MWWSgo9f6FNENzEqGhClRqV95TIyOuxuBNmqV1R1YSasZk0J1RWU2FoI0Y6107JdaUOJ1d2zZ//t0IrPq5JG0kNOmiEMBbautJAJNXjMZzt+vmRvWZK0KxUE7CxFSodUEbiUkJzQ1e545lPLggsIDJFPklha5mEJh93WPbHHnSYhBbGWwi38sm5Rf////qwSoTSTkkbSQ0qbghIMt8yALEW1qUjmykUc81ZnJQVRq9MeOHR2SEWGdRLWC8wiqYFAj180gMULqvL//uUROyAAtZHxWIsGiBVJNi9CeMmCmTpFaiYcwEelyL0CQx4tMmOrrGAxXTeX2RZe8NMsexk1/0bPqp///m/////d/QheUr6QP8eBDPQLe2YN2CRDoUl2yo391LU6CZr3IYDLYQ2MWKcUcrhgdgcClwyFwUBgMuBwGwVkdgox+9zCJqjShW9dWlahbP0fxRV1axNfa7/VK1qsEcrJ+xtSGb1Hic5F8zMxMPiGU+HnMjev0jrUkihVYt2OVpxXcjfZBBQSDdvrUzahrfVINr7sPsKinDN7U9OfcuOj+nZG2iKWtASIGa66nJs00xct6om4CFFQxQSQ7Aw6sEAeDxgHgu4UCRaCigGScEFlDBMPiYGgsGTjA8sKjH3HJB4EWj+jT/06NQUNQ39SHrSBPxSmgyzQtiSCxevTkwSQ3IoLcaAkBUmBgCYAYsxQPhA8JAGQCgPgSwOAyBwsDoPCgEUl4oGCMoUjzKYv0/Z/9vopAi2pSJIkD6hqA9s6kikXpR0//uERPUAAqUoRdIJGhJZJBi9RSNCScCBEyeEboEhFqKlBg0Q6vN/KEyutdXAWZIY8/uUljmv20KY1oayetq3bhr0yxZY1gqv5tf//o6ABcGvlQPkSEraUtSj4xvP+/FvvfzsNQhKhWAKvXoqvcSo70QAn45BzZqIERWzU7s2tv0ub1r/ZomtSAsIFb5QPRMhrAXLXdA3/69E6oLjTJg0JkMvUT1CNKIUyYB1xQKhoNpfnmUGrbHKjk99v7ujP/RV+1mgHSVS+ECmGcg5I1WMKWtLSrZ0/lrahYRyHcMPIgMSGgqIDIwOnS4QK/5F5MqmOL/W7/Rtr+9f6QcUf/wAHQSA2vb1rI4JmqqWTFD6TUY0cyJuiCoUEwTnf7/60f7v//sR//qEd+IoBstVfv8/rMwWsMqEQcaOIkP///6f6v6dv0bK9n01TEFNRTMuMTAw//uEROkAAlcYxlIBG0BJ4yipSCNoB1hrFUkEbQDqDaJkB4xgVVVVVVVMQU1FMy4xMDBVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//tURPoAUdYgRMpBG1A3Q4iZAgISBWhzFSAUY4CEi6IUcAzqVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV//sUROGP8AAAf4AAAAgAAA/wAAABAAABpAAAACAAADSAAAAEVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV';
    if (mp3Base64 !== '__SOUND_MP3_BASE64__') {
        // Placeholder was replaced by the build — use the embedded MP3
        window._pfodPingAudio = new Audio('data:audio/mpeg;base64,' + mp3Base64);
        return;
    }
    // Fallback: generate an 880 Hz ping with two echo repeats as a WAV data URI.
    // 8-bit unsigned PCM mono at 8000 Hz, 300 ms total duration.
    const sampleRate = 8000;
    const numSamples = 2400;
    const freq = 880;
    const decay = 15;
    const buf = new Uint8Array(44 + numSamples);
    const view = new DataView(buf.buffer);
    buf.set([82,73,70,70], 0);
    view.setUint32(4, 36 + numSamples, true);
    buf.set([87,65,86,69], 8);
    buf.set([102,109,116,32], 12);
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate, true);
    view.setUint16(32, 1, true);
    view.setUint16(34, 8, true);
    buf.set([100,97,116,97], 36);
    view.setUint32(40, numSamples, true);
    for (let i = 0; i < numSamples; i++) {
        const t = i / sampleRate;
        let s = Math.sin(2 * Math.PI * freq * t) * Math.exp(-t * decay) * 0.80;
        if (t >= 0.110) { const te = t - 0.110; s += Math.sin(2 * Math.PI * freq * te) * Math.exp(-te * decay) * 0.40; }
        if (t >= 0.210) { const te = t - 0.210; s += Math.sin(2 * Math.PI * freq * te) * Math.exp(-te * decay) * 0.20; }
        buf[44 + i] = Math.round((Math.max(-1, Math.min(1, s)) + 1) * 127.5);
    }
    let binary = '';
    for (let i = 0; i < buf.length; i++) { binary += String.fromCharCode(buf[i]); }
    window._pfodPingAudio = new Audio('data:audio/wav;base64,' + btoa(binary));
})();

/**
 * Play the cached ping sound.
 * Resets playback position before playing so rapid calls each produce a full tone.
 * The .play() promise rejection (e.g. blocked before first user gesture) is silently ignored.
 */
function pfodPlayPingSound() {
    if (!window._pfodPingAudio) return;
    window._pfodPingAudio.currentTime = 0;
    window._pfodPingAudio.play().catch(function() {});
}

// Export globally for use by pfodMenuDisplay.js and any other consumers
window.applyPfodFormats = applyPfodFormats;
window.pfodSetFormattedText = pfodSetFormattedText;
window.renderPfodButton = renderPfodButton;
window.renderPfodLabel = renderPfodLabel;
window.renderPfodToggleButton = renderPfodToggleButton;
window.renderPfodToggleLabel = renderPfodToggleLabel;
window.renderPfodNavButtons = renderPfodNavButtons;
window.renderPfodNumericSlider = renderPfodNumericSlider;
window.renderPfodNumericSliderLabel = renderPfodNumericSliderLabel;
window.pfodPlayPingSound = pfodPlayPingSound;
/*
   pfodMenuDisplay.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// pfod Menu Display Manager — manages the "menu-mode" display: scrollable list of buttons,
// labels, navigation rows, and an optional drawing canvas with a prompt at the bottom.
//
// Exports:    window.pfodMenuDisplay singleton (PfodMenuDisplay instance)
// Depends on: pfodMenuParser.js (pfodParseMenu, parsePfodFormatCodes),
//             pfodButtonRenderer.js (applyPfodFormats, renderPfodButton, renderPfodLabel,
//                                    renderPfodToggleButton, renderPfodToggleLabel,
//                                    renderPfodNavButtons),
//             redraw.js (getActualFontSize via pfodButtonRenderer)
// Called by:  responseHandlers.js (show, hide, update, isVisible, getMenuCanvas),
//             toolbarAndMenu.js (hide when navigating back from menu-mode)

class PfodMenuDisplay {
    constructor() {
        // DOM element references (created lazily on first use)
        this._menuContainer = null;
        this._scrollArea = null;
        this._promptEl = null;

        // The drawn-by-hand scrollbar, for browsers whose own one is an
        // overlay that fades out.  Stay null on browsers that draw a real
        // one — see _updateScrollIndicator.
        this._scrollTrack = null;
        this._scrollThumb = null;

        // Per drawing-item canvases: drawingName → {canvas, ctx, wrapper}
        this._menuCanvases = {};

        // Current menu state
        this._currentMenu = null;
        this._onItemClick = null;

        // True while any pointer is held down inside the menu scroll area.
        // Covers HTML buttons, sliders, toggles, and dwg canvases — all of which are
        // children of _scrollArea so their pointer events bubble up here.
        // Read by addToRequestQueue to block menuRefresh while user is interacting.
        this.menuMouseDown = false;
    }

    /**
     * Lazily find or create the menu container DOM elements.
     * Prefers elements already present in the HTML (added by pfodWeb.html via pfodCommon.html).
     * Falls back to dynamic creation and insertion into #canvas-wrapper if not found.
     * Subsequent calls are no-ops once the references are established.
     */
    _ensureContainer() {
        if (this._menuContainer) {
            // Throw if the container has been detached from the DOM - this happens if something
            // cleared canvas-wrapper.innerHTML, which destroys #menu-container.
            if (!document.contains(this._menuContainer)) {
                throw new Error('[pfodMenuDisplay] #menu-container was detached from the DOM (canvas-wrapper.innerHTML was cleared). Do not use innerHTML="" on canvas-wrapper.');
            }
            return;
        }

        // Find the existing DOM elements already present in the HTML
        const existing = document.getElementById('menu-container');
        if (!existing) {
            throw new Error('[pfodMenuDisplay] #menu-container not found in DOM');
        }
        this._menuContainer = existing;
        this._scrollArea = document.getElementById('menu-scroll-area');
        if (!this._scrollArea) {
            throw new Error('[pfodMenuDisplay] #menu-scroll-area not found in DOM');
        }

        // Track pointer-down state across all menu item types (HTML and canvas).
        // pointercancel covers cases where the OS cancels the pointer (e.g. scroll gesture).
        this._scrollArea.addEventListener('pointerdown', () => { this.menuMouseDown = true; });
        this._scrollArea.addEventListener('pointerup',   () => { this.menuMouseDown = false; });
        this._scrollArea.addEventListener('pointercancel', () => { this.menuMouseDown = false; });

        // The always-visible scrollbar, for browsers whose own one is an
        // overlay that fades out — see _updateScrollIndicator.  Built here,
        // with the rest of the persistent menu DOM, rather than per menu:
        // #menu-container and #menu-scroll-area both outlive any one menu.
        if (PfodMenuDisplay._usesOverlayScrollbars()) {
            this._scrollTrack = document.createElement('div');
            this._scrollTrack.id = 'menu-scroll-track';
            this._scrollThumb = document.createElement('div');
            this._scrollThumb.id = 'menu-scroll-thumb';
            this._menuContainer.appendChild(this._scrollTrack);
            this._menuContainer.appendChild(this._scrollThumb);
            // passive: the listener only reads geometry, and telling the
            // browser so keeps it off the scrolling critical path.
            this._scrollArea.addEventListener('scroll',
                () => this._updateScrollIndicator(), { passive: true });
        }

        this._promptEl = document.getElementById('menu-prompt');
        if (!this._promptEl) {
            throw new Error('[pfodMenuDisplay] #menu-prompt not found in DOM');
        }
    }

    /**
     * Show the pfod menu.
     * Switches body to 'menu-mode', renders all items in the scroll area,
     * displays the prompt at the bottom, and optionally moves the drawing
     * canvas into the drawing placeholder at the drawing item's scroll position.
     *
     * @param {object} menuData - Structured menu from pfodParseMenu()
     * @param {function} onItemClick - Callback(cmd) invoked when a menu item is clicked
     */
    show(menuData, onItemClick) {
        this._ensureContainer();

        // Re-render of the SAME menu (called from update() with this._currentMenu after
        // a {;} merge): preserve the user's scroll position.  innerHTML='' below resets
        // scrollTop, so capture it first.  Navigation to a NEW menu passes a different
        // menuData reference and resets to top, which is the expected behaviour.
        const isSameMenu = this._currentMenu === menuData && this._scrollArea;
        const savedScrollTop = isSameMenu ? this._scrollArea.scrollTop : 0;

        this._onItemClick = onItemClick;
        this._currentMenu = menuData;
        this._menuCanvases = {};

        // Clear previous content
        this._scrollArea.innerHTML = '';
        this._promptEl.innerHTML = '';
        this._promptEl.removeAttribute('style');
        this._scrollArea.removeAttribute('style');

        // Apply menu background colour to the scroll area and prompt.
        // When the header specifies no background colour, default to black (pfod default).
        const header = menuData.header;
        const menuBgColor = header.bgColor || '#000000';
        this._scrollArea.style.backgroundColor = menuBgColor;
        this._promptEl.style.backgroundColor = menuBgColor;

        // Render each item, grouping consecutive nav buttons into rows
        const items = menuData.items;
        let i = 0;
        while (i < items.length) {
            const item = items[i];

            if (item.type === 'nav') {
                // Collect all consecutive nav items into one row (up to 5)
                const navGroup = [];
                while (i < items.length && items[i].type === 'nav' && navGroup.length < 5) {
                    navGroup.push(items[i]);
                    i++;
                }
                const navEl = renderPfodNavButtons(navGroup, (cmd) => this._handleClick(cmd), menuBgColor);
                this._scrollArea.appendChild(navEl);

            } else if (item.type === 'dwg' || item.type === 'dwg-label') {
                // Drawing item: honour the same non-sticky flags as other menu items.
                // Hidden ('-') skips render entirely; disabled ('!') drops the click handler;
                // flash ('+') pulses the wrapper at 1Hz via the shared .pfod-flash class.
                if (item.formats && item.formats.hidden) {
                    i++;
                    continue;
                }
                // Each dwg/dwg-label item gets its own canvas so all drawings are visible
                // simultaneously (scrollable) and #drawing-canvas is never moved.
                const dwgWrapper = document.createElement('div');
                dwgWrapper.className = 'pfod-menu-dwg-wrapper';
                dwgWrapper.dataset.dwgCmd = item.cmd;
                dwgWrapper.dataset.loadCmd = item.loadCmd;
                dwgWrapper.style.backgroundColor = (item.formats && item.formats.bgColor) || menuBgColor || '#000000';

                // The MARGIN around the drawing is not a control.
                //
                // It used to carry a click listener that sent the item's cmd
                // whenever the press landed on the wrapper rather than the
                // canvas — and that margin is exactly where a finger ends up
                // when reaching past a full-width drawing for the scroll
                // strip, so scrolling regularly pressed the menu item by
                // accident.  The drawing itself is the control: a press on
                // it sends the item's cmd (pfodWebMouse.handleMouseDown,
                // when the dwg defines no touchZones) or works its
                // touchZones.  Nothing outside the canvas does anything.
                if (item.formats && item.formats.flash) {
                    dwgWrapper.classList.add('pfod-flash');
                }

                const menuCanvas = document.createElement('canvas');
                // Start hidden — the loading placeholder below occupies the
                // visible slot until the device response arrives with the
                // drawing's actual dimensions.  handleMenuResize unhides this
                // canvas (and removes the placeholder) once drawingsData[name].data
                // is populated.  This avoids the wide-aspect "Loading Drawing..."
                // rectangle flash that used to appear before the canvas could
                // be sized correctly.
                menuCanvas.style.display = 'none';
                menuCanvas.style.width = '100%';
                menuCanvas.style.height = 'auto';
                // An item that takes no user input takes no pointer events
                // either, and nothing happens when it is pressed: a
                // dwg-label is a picture, not a control, and a DISABLED dwg
                // item is one the device has switched off.  Making the
                // canvas transparent to the pointer is the whole of it —
                // the touch/mouse handlers are wired to the canvas, so with
                // this set they are never reached, whatever the drawing
                // contains.  Without it a disabled item still sent its
                // touchZones' cmds.
                if (item.type === 'dwg-label' || (item.formats && item.formats.disabled)) {
                    menuCanvas.style.pointerEvents = 'none';
                } else {
                    // The cursor belongs on the thing that is actually
                    // pressable, which is the drawing — it was on the
                    // wrapper, whose margin no longer does anything.
                    menuCanvas.style.cursor = 'pointer';
                }
                dwgWrapper.appendChild(menuCanvas);

                // Dummy "Loading drawing ..." placeholder shown until the dwg
                // dimensions arrive (important for slow BLE connections so the
                // user has some feedback that loading is in progress).  It is
                // completely discarded once data exists and the real canvas
                // is unhidden — see handleMenuResize.
                const loadingPlaceholder = document.createElement('div');
                loadingPlaceholder.className = 'pfod-menu-dwg-loading';
                loadingPlaceholder.textContent = 'Loading drawing …';
                dwgWrapper.appendChild(loadingPlaceholder);

                this._scrollArea.appendChild(dwgWrapper);

                const menuCtx = menuCanvas.getContext('2d');
                this._menuCanvases[item.loadCmd] = {
                    canvas: menuCanvas,
                    ctx: menuCtx,
                    wrapper: dwgWrapper,
                    loadingPlaceholder: loadingPlaceholder
                };
                i++;

            } else if (item.type === 'label') {
                if (!(item.formats && item.formats.hidden)) {
                    const el = renderPfodLabel(item, menuBgColor);
                    this._scrollArea.appendChild(el);
                }
                i++;

            } else if (item.type === 'toggle-button') {
                if (!(item.formats && item.formats.hidden)) {
                    const el = renderPfodToggleButton(item, (cmd) => this._handleClick(cmd), menuBgColor);
                    this._scrollArea.appendChild(el);
                }
                i++;

            } else if (item.type === 'toggle-label') {
                if (!(item.formats && item.formats.hidden)) {
                    const el = renderPfodToggleLabel(item, menuBgColor);
                    this._scrollArea.appendChild(el);
                }
                i++;

            } else if (item.type === 'numeric-slider-button') {
                if (!(item.formats && item.formats.hidden)) {
                    const el = renderPfodNumericSlider(item, (cmd) => this._handleClick(cmd), menuBgColor);
                    this._scrollArea.appendChild(el);
                }
                i++;

            } else if (item.type === 'numeric-slider-label') {
                if (!(item.formats && item.formats.hidden)) {
                    const el = renderPfodNumericSliderLabel(item, menuBgColor);
                    this._scrollArea.appendChild(el);
                }
                i++;

            } else {
                // Default: button
                if (!(item.formats && item.formats.hidden)) {
                    const el = renderPfodButton(item, (cmd) => this._handleClick(cmd), menuBgColor);
                    this._scrollArea.appendChild(el);
                }
                i++;
            }
        }

        // Render prompt text at the bottom.
        // Apply <bw> contrast default for prompt text when not explicitly specified.
        if (header.title) {
            const promptContrastHex = xtermColorToHex(getBlackWhite(menuBgColor));
            pfodSetFormattedText(this._promptEl, header.title, promptContrastHex, undefined, true); // prompt bar: links allowed
            applyPfodFormats(this._promptEl, header.promptFormat);
            if (!header.promptFormat.textColor) {
                this._promptEl.style.color = promptContrastHex;
            }
        }
        // Apply the `+` (flash) non-sticky flag from the prompt format.
        // applyPfodFormats only handles sticky formats; flash is applied
        // here as a class so the CSS animation (#menu-prompt.pfod-flash
        // — see pfodCommon.css) can run on the prompt's content.
        // toggle() rather than add() so a cleared flag reliably removes
        // the animation when the menu re-renders without flash.
        this._promptEl.classList.toggle('pfod-flash',
            !!(header.promptFormat && header.promptFormat.flash));

        // Play a ping sound if any item in this menu has the @ (sound)
        // flag — or if the prompt format itself does (pfod allows the
        // flag on either, matching pfodApp behaviour).
        const promptHasSound = !!(header.promptFormat && header.promptFormat.sound);
        const anyItemSound   = menuData.items.some(item => item.formats && item.formats.sound);
        if (promptHasSound || anyItemSound) {
            pfodPlayPingSound();
        }

        // Mark "empty side" menus so the CSS can hide whichever side
        // (items area or prompt area) has no content and let the other
        // side fill the container.  Without these, a help-style screen
        // (prompt only) reserves the items' flex share and an items-
        // only menu reserves the prompt's padding strip — visually
        // wasting space at the edges.
        const menuContainerEl = document.getElementById('menu-container');
        if (menuContainerEl) {
            menuContainerEl.classList.toggle('no-items', menuData.items.length === 0);
            menuContainerEl.classList.toggle('no-prompt', !header.title);
        }

        // Switch the body class to activate menu-mode CSS
        document.body.className = 'menu-mode';

        // Restore scroll position for same-menu re-renders.  Defer to the next animation
        // frame so the caller's handleMenuResize() has run and sized the per-item canvases —
        // otherwise scrollTop would clamp to a tiny value while content is still 0-height.
        if (isSameMenu && savedScrollTop > 0) {
            const scrollArea = this._scrollArea;
            requestAnimationFrame(() => {
                if (scrollArea) scrollArea.scrollTop = savedScrollTop;
            });
        }
    }

    /**
     * Handle resize events while in menu-mode.
     * For each per-item canvas in _menuCanvases, resizes it to fill its wrapper width
     * while maintaining the drawing's aspect ratio, then redraws.
     * Also syncs the per-item canvas registry into redraw so performRedrawInMode renders
     * to the correct canvas element.
     *
     * @param {Redraw} redraw - The Redraw instance from DrawingViewer
     */
    /**
     * True when this browser draws OVERLAY scrollbars — ones painted over
     * the content that take no layout space (every mobile browser, and
     * macOS by default).
     *
     * It matters because a menu drawing canvas swallows touchstart and
     * touchmove (pfodWebMouse preventDefaults them so a touchZone drag is
     * not read as a page scroll).  With a classic scrollbar the strip it
     * occupies is never covered by a canvas, so there is always somewhere
     * to start a scroll; with an overlay scrollbar there is not, and a menu
     * whose first drawing fills the screen cannot be scrolled at all.
     * #menu-scroll-area.overlay-scrollbars pads a strip in by hand for that
     * case.
     *
     * Measured once, off a throwaway element, rather than sniffing the user
     * agent: Chrome on Android honours the ::-webkit-scrollbar styling and
     * ends up with a classic scrollbar, Firefox on Android does not.
     * @returns {boolean}
     */
    static _usesOverlayScrollbars() {
        if (PfodMenuDisplay._overlayScrollbars === undefined) {
            const probe = document.createElement('div');
            probe.style.cssText =
                'position:absolute;top:-9999px;width:100px;height:100px;overflow-y:scroll;';
            document.body.appendChild(probe);
            // Zero difference => the scrollbar is drawn over the content.
            PfodMenuDisplay._overlayScrollbars = (probe.offsetWidth - probe.clientWidth) === 0;
            probe.remove();
            console.log('[MENU_SCROLL] overlay scrollbars: ' +
                PfodMenuDisplay._overlayScrollbars);
        }
        return PfodMenuDisplay._overlayScrollbars;
    }

    /** Width of the strip .needs-scroll-gutter reserves, in CSS px.
     *  MUST match #menu-scroll-area.overlay-scrollbars.needs-scroll-gutter's
     *  padding-right — the hysteresis below works out how much taller the
     *  drawings get when the strip is released, and a wrong number here
     *  makes that arithmetic wrong. */
    static get SCROLL_GUTTER_PX() { return 40; }

    /**
     * Reserve the scroll strip when, and only when, the menu has content
     * off screen — and never flap between the two states.
     *
     * The naive test oscillates: the strip narrows the wrappers, every
     * drawing is sized from wrapper width, so reserving it makes the
     * content SHORTER, which can put it back under the viewport height,
     * which un-reserves it, which makes the content taller again.  A menu
     * whose content sits near the viewport height would toggle on every
     * resize.
     *
     * So the two directions use different thresholds:
     *
     *   off -> on   content overflows now
     *   on  -> off  content fits now AND still fits once the strip is
     *               given back — `heightGivenBack` is exactly how much
     *               taller the drawings become at the wider width, summed
     *               over the width-constrained ones (a height-constrained
     *               drawing does not change height with width, so it
     *               contributes nothing).
     *
     * Turning it off therefore cannot make it overflow, and turning it on
     * only happens when it already does. Neither edge can re-trigger the
     * other.
     *
     * @param {number} heightGivenBack — px the content would grow by if the
     *        strip were removed, from _sizeMenuDrawings
     * @returns {boolean} true when the class changed, so the caller knows
     *          the wrappers are a different width and the drawings need
     *          sizing again
     */
    _applyScrollGutter(heightGivenBack) {
        const area = this._scrollArea;
        if (!area) return false;
        const on = area.classList.contains('needs-scroll-gutter');
        const overflows = area.scrollHeight > area.clientHeight;
        const want = on
            ? !(area.scrollHeight + heightGivenBack <= area.clientHeight)
            : overflows;
        if (want === on) return false;
        area.classList.toggle('needs-scroll-gutter', want);
        console.log('[MENU_SCROLL] gutter ' + (want ? 'on' : 'off') +
            ' (scrollHeight=' + area.scrollHeight + ' clientHeight=' + area.clientHeight +
            ' givenBack=' + Math.round(heightGivenBack) + ')');
        return true;
    }

    /**
     * Put the scroll position and proportion on screen, permanently.
     *
     * The strip reserved by .needs-scroll-gutter gave the user somewhere to
     * start a scroll, but on a phone it read as nothing more than a black
     * margin: an overlay scrollbar is drawn by the browser only WHILE
     * scrolling, so until you happened to drag in the right place there was
     * no sign the menu continued below.  This draws the bar instead, and
     * leaves it there.
     *
     * Sized and placed against the scroll area's own box, from
     * #menu-container (the scroll area's offsetParent) so it does not
     * scroll away with the content it is describing.  Thumb length is the
     * fraction of the menu on screen, floored at 28px so a very long menu
     * still leaves something visible; its travel is the fraction scrolled.
     *
     * Only ever called on browsers that drew no usable bar of their own —
     * the elements are not even created otherwise.
     */
    _updateScrollIndicator() {
        const area = this._scrollArea;
        if (!area || !this._scrollTrack) return;
        const overflow = area.scrollHeight - area.clientHeight;
        const show = overflow > 0;
        this._scrollTrack.style.display = show ? 'block' : 'none';
        this._scrollThumb.style.display = show ? 'block' : 'none';
        if (!show) return;

        const trackTop = area.offsetTop;
        const trackHeight = area.clientHeight;
        const thumbHeight = Math.max(28,
            Math.round(trackHeight * (area.clientHeight / area.scrollHeight)));
        const travelled = area.scrollTop / overflow;   // 0 .. 1

        this._scrollTrack.style.top = trackTop + 'px';
        this._scrollTrack.style.height = trackHeight + 'px';
        this._scrollThumb.style.top =
            (trackTop + Math.round((trackHeight - thumbHeight) * travelled)) + 'px';
        this._scrollThumb.style.height = thumbHeight + 'px';
    }

    handleMenuResize(redraw) {
        if (!redraw) return;
        // Which KIND of scrollbar this browser has is a property of the
        // browser, so it is settled once and for all; whether the strip is
        // currently reserved is a property of the content, and is decided
        // below once the drawings have been sized.
        if (this._scrollArea && PfodMenuDisplay._usesOverlayScrollbars()) {
            this._scrollArea.classList.add('overlay-scrollbars');
        }
        const givenBack = this._sizeMenuDrawings(redraw);
        // One re-run at most: the hysteresis above guarantees the decision
        // cannot flip back, so this settles rather than looping.
        if (this._applyScrollGutter(givenBack)) {
            this._sizeMenuDrawings(redraw);
        }
        // Last, once the heights are final — the bar describes them.
        this._updateScrollIndicator();
    }

    /**
     * Size and repaint every menu drawing against the wrappers' current
     * width.  Split out of handleMenuResize so it can be run again after
     * the scroll strip is reserved or released, which changes that width.
     *
     * @param {object} redraw
     * @returns {number} how much taller the content would be if the scroll
     *          strip were released — see _applyScrollGutter
     */
    _sizeMenuDrawings(redraw) {
        let heightGivenBack = 0;
        // Maximum displayed height a drawing may occupy: the scroll area's visible height.
        // With CSS width:100%; height:auto, displayed height = wrapperWidth / aspectRatio.
        // When that exceeds viewportHeight we switch to CSS height:viewportHeight; width:auto
        // so the drawing fits completely in the viewport when scrolled into view.
        const viewportHeight = this._scrollArea ? this._scrollArea.clientHeight : 0;
        console.log(`[MENU_RESIZE] viewportHeight=${viewportHeight} scrollArea=${this._scrollArea ? 'ok' : 'null'}`);

        // Re-register all per-item canvases with redraw (handles update() canvas recreation)
        redraw.clearMenuCanvases();
        for (const [drawingName, entry] of Object.entries(this._menuCanvases)) {
            redraw.setMenuCanvas(drawingName, entry.canvas, entry.ctx);
            const drawingDataEntry = redraw.redrawDrawingManager.drawingsData[drawingName];
            const wrapperWidth = entry.wrapper.clientWidth;
            if (wrapperWidth <= 0) continue;
            const availableWidth = Math.max(1, Math.floor(wrapperWidth - 26));

            if (!drawingDataEntry || !drawingDataEntry.data) {
                // No drawing data yet — the wrapper is currently showing its
                // "Loading drawing …" placeholder (created in show()).  Just
                // leave it there: nothing to paint, no canvas to size, and
                // the placeholder gives the user feedback on slow BLE links.
                console.log(`[MENU_RESIZE] ${drawingName}: no data — placeholder still showing`);
                continue;
            }
            // Data exists — drop the loading placeholder and unhide the real
            // canvas.  Removing the placeholder from the DOM (rather than
            // hiding it) keeps the wrapper clean and means future no-data
            // resizes can't accidentally re-show it.
            if (entry.loadingPlaceholder && entry.loadingPlaceholder.parentNode) {
                entry.loadingPlaceholder.parentNode.removeChild(entry.loadingPlaceholder);
                entry.loadingPlaceholder = null;
            }
            if (entry.canvas.style.display === 'none') {
                entry.canvas.style.display = 'block';
            }
            const logicalWidth = Math.min(Math.max(drawingDataEntry.data.x, 1), 255);
            const logicalHeight = Math.min(Math.max(drawingDataEntry.data.y, 1), 255);
            const aspectRatio = logicalWidth / logicalHeight;

            // With CSS width:100%, height:auto the canvas displays at wrapperWidth × wrapperWidth/aspectRatio.
            // If that height exceeds viewportHeight, switch to CSS height:(viewportHeight-20), width:auto.
            // The 20px margin keeps the wrapper border visible above and below the drawing.
            // The wrapper uses display:flex; justify-content:center so the narrower canvas is centred,
            // and the wrapper's bgColor (set per-item in show()) fills the side gaps.
            // displayed width = constrainedHeight × aspectRatio which is guaranteed ≤ wrapperWidth
            // (the two overflow conditions are mutually exclusive).
            const displayedHeightWidthFirst = wrapperWidth / aspectRatio;
            const heightConstrained = viewportHeight > 0 && displayedHeightWidthFirst > viewportHeight;
            const constrainedCssHeight = viewportHeight - 40;

            let canvasWidth, canvasHeight;
            if (heightConstrained) {
                // Set explicit CSS pixel dimensions so the canvas is exactly the right size.
                // The wrapper uses display:flex; justify-content:center so the narrower canvas
                // is centred; the wrapper's bgColor (set in show()) fills the side gaps.
                const cssDwgWidth = Math.floor(constrainedCssHeight * aspectRatio);
                entry.canvas.style.height = constrainedCssHeight + 'px';
                entry.canvas.style.width = cssDwgWidth + 'px';
                canvasHeight = Math.max(1, Math.floor(constrainedCssHeight - 26));
                canvasWidth = Math.max(1, Math.floor(canvasHeight * aspectRatio));
            } else {
                // Restore class-defined CSS (width:100%; height:auto) by clearing inline overrides.
                entry.canvas.style.width = '';
                entry.canvas.style.height = '';
                canvasWidth = availableWidth;
                canvasHeight = Math.max(1, Math.floor(canvasWidth / aspectRatio));
                // Only a WIDTH-constrained drawing grows when the scroll
                // strip is released — its height follows its width.  A
                // height-constrained one is already pinned to the viewport
                // and would not change at all, so it adds nothing here.
                heightGivenBack += PfodMenuDisplay.SCROLL_GUTTER_PX / aspectRatio;
            }
            console.log(`[MENU_RESIZE] ${drawingName}: logical=${logicalWidth}x${logicalHeight} wrapperW=${wrapperWidth} displayedH=${Math.floor(displayedHeightWidthFirst)} cssH=${heightConstrained ? constrainedCssHeight : 'auto'} canvas=${canvasWidth}x${canvasHeight} wrapperBg=${entry.wrapper.style.backgroundColor} constrained=${heightConstrained}`);

            if (entry.canvas.width !== canvasWidth || entry.canvas.height !== canvasHeight) {
                entry.canvas.width = canvasWidth;
                entry.canvas.height = canvasHeight;
            }
            entry.canvas.scaleX = canvasWidth / logicalWidth;
            entry.canvas.scaleY = canvasHeight / logicalHeight;
            redraw.performRedrawInMode('menu-mode', drawingName);
        }
        return heightGivenBack;
    }

    /**
     * Return the canvas registry entry for a menu drawing item, or null.
     * @param {string} drawingName - The loadCmd of the drawing item
     * @returns {{canvas: HTMLCanvasElement, ctx: CanvasRenderingContext2D, wrapper: HTMLElement}|null}
     */
    getMenuCanvas(drawingName) {
        return this._menuCanvases[drawingName] || null;
    }

    /**
     * Hide the menu display and switch to message-mode.
     * Moves the drawing canvas back to #canvas-wrapper and clears the menu content.
     */
    hide() {
        // Per-item canvases are destroyed by clearing the scroll area HTML below.
        // Clear the registry so stale references are not held.
        this._menuCanvases = {};

        // Clear menu content
        if (this._scrollArea) {
            this._scrollArea.innerHTML = '';
        }
        if (this._promptEl) {
            this._promptEl.innerHTML = '';
        }
        this._currentMenu = null;
        this._onItemClick = null;

        // Return to message-mode
        if (document.body.className === 'menu-mode') {
            document.body.className = 'message-mode';
        }
    }

    /**
     * Return true if the menu is currently being shown.
     * @returns {boolean}
     */
    isVisible() {
        return document.body.className === 'menu-mode';
    }

    /**
     * Return true if drawingName is one of the drawing items embedded in the current menu.
     * @param {string} drawingName
     * @returns {boolean}
     */
    isMenuDrawing(drawingName) {
        return drawingName in this._menuCanvases;
    }

    /**
     * Apply a pfod partial menu update ({; ...}) to the currently displayed menu.
     * Merges the update into the stored menu state then re-renders in full.
     *
     * Merge rules per the pfod spec:
     *   Items NOT in the update — left completely unchanged (sticky AND non-sticky).
     *   Items IN the update:
     *     Non-sticky flags (disabled, hidden, flash, sound): replaced by exactly what
     *       the update contains — absence of a flag clears it.
     *     Sticky formats (bgColor, textColor, bold, italic, underline, fontSize):
     *       only applied when non-default in the update; otherwise the existing value persists.
     *     Text / intFields / textFields: only replaced when the update provides non-empty values.
     *
     * @param {object} menuData - Parsed update from pfodParseMenu() where header.isUpdate === true
     */
    update(menuData) {
        this._ensureContainer();
        if (!this._currentMenu) {
            // No existing menu — {;} updates apply only to existing items by cmd
            // match.  With nothing to update, every update item is silently
            // ignored.  Per protocol: do NOT treat the update as a fresh menu.
            console.log('[MENU_DISPLAY] {;} update arrived with no current menu — silently ignored (updates apply only to existing items)');
            return;
        }

        // Build a lookup of updated items by cmd
        const updateMap = {};
        for (const item of menuData.items) {
            if (item.cmd) {
                updateMap[item.cmd] = item;
            }
        }

        // Merge updates into each current menu item
        for (const item of this._currentMenu.items) {
            const updatedItem = updateMap[item.cmd];
            if (!updatedItem) continue; // Not mentioned — leave unchanged

            // Non-sticky flags: replace entirely with what the update says
            // (absence of a flag in the update = flag is cleared)
            item.formats.disabled = updatedItem.formats.disabled;
            item.formats.hidden   = updatedItem.formats.hidden;
            item.formats.flash    = updatedItem.formats.flash;
            item.formats.sound    = updatedItem.formats.sound;

            // Sticky formats: only apply if non-default in the update
            if (updatedItem.formats.bgColor   !== null) item.formats.bgColor   = updatedItem.formats.bgColor;
            if (updatedItem.formats.textColor !== null) item.formats.textColor = updatedItem.formats.textColor;
            if (updatedItem.formats.bold)               item.formats.bold      = true;
            if (updatedItem.formats.italic)             item.formats.italic    = true;
            if (updatedItem.formats.underline)          item.formats.underline = true;
            if (updatedItem.formats.fontSize !== 0)     item.formats.fontSize  = updatedItem.formats.fontSize;
            // inlineFmtPrefix (the <b>/<+N>/etc. tags a label/button carries before its
            // ~text) is sticky too, same as bgColor/textColor above -- a {;} update that
            // resends the text but omits these tags means "text changed, formatting
            // didn't", not "clear the formatting". Matches pfodApp.
            if (updatedItem.formats.inlineFmtPrefix !== '') item.formats.inlineFmtPrefix = updatedItem.formats.inlineFmtPrefix;

            // Text/intFields/toggleData/numericSliderData merges don't apply to dwg items
            // (they have no text content — only loadCmd and a canvas).
            if (item.type === 'dwg' || item.type === 'dwg-label') continue;

            // Text: only replace when the update provides non-empty values
            if (updatedItem.text !== '')            item.text       = updatedItem.text;
            if (updatedItem.textFields.length > 0)  item.textFields = updatedItem.textFields;
            // Toggle items: refresh leading/trailing/options from the
            // update's parsed toggleData (the parser builds it whenever
            // textFields.length >= 3).  Without this the renderer keeps
            // reading the original toggleData.leading/trailing/options
            // — so format changes the designer emits INSIDE the leading
            // text (e.g. `<-2>Output is `) never show up in the
            // rendered toggle.  Real devices that send partial updates
            // without all 3 text fields leave updatedItem.toggleData
            // null, so the existing toggleData stays untouched.
            if (item.toggleData && updatedItem.toggleData) {
                item.toggleData.leading  = updatedItem.toggleData.leading;
                item.toggleData.trailing = updatedItem.toggleData.trailing;
                item.toggleData.options  = updatedItem.toggleData.options;
                item.toggleData.format   = updatedItem.toggleData.format;
                // idx is synced from intFields[0] below (the
                // pre-existing path).
            }
            // Numeric-slider items: same refresh pattern — without
            // this the renderer keeps reading the original
            // numericSliderData.leading / .trailing / .maxValue /
            // .minValue / .maxScaleStr / .minScaleStr so any edit
            // the designer applies to a PWM/Slider's text or range
            // never propagates to the preview.  Real devices sending
            // partial `{;|<cmd>`<newVal>}` updates leave
            // updatedItem.numericSliderData null (intFields=1,
            // textFields=0 — fails the parser's `>=2 ints` toggle/
            // slider detection), so the existing data stays
            // untouched and only currentValue syncs via the
            // intFields path below.
            if (item.numericSliderData && updatedItem.numericSliderData) {
                const oldNsd = item.numericSliderData;
                const newNsd = updatedItem.numericSliderData;
                oldNsd.leading      = newNsd.leading;
                oldNsd.trailing     = newNsd.trailing;
                oldNsd.maxValue     = newNsd.maxValue;
                oldNsd.minValue     = newNsd.minValue;
                oldNsd.maxScaleStr  = newNsd.maxScaleStr;
                oldNsd.minScaleStr  = newNsd.minScaleStr;
                oldNsd.format       = newNsd.format;
                // currentValue is synced from intFields[0] below.
            }
            if (updatedItem.intFields.length > 0) {
                item.intFields = updatedItem.intFields;
                // Sync toggleData.idx from intFields[0] — update messages like {;|M`1}
                // contain only the cmd + new index, so updatedItem.toggleData is null.
                if (item.toggleData) {
                    const newIdx = parseInt(updatedItem.intFields[0], 10);
                    if (!isNaN(newIdx)) {
                        item.toggleData.idx = Math.max(0, Math.min(newIdx, item.toggleData.options.length - 1));
                    }
                }
                // Sync numericSliderData.currentValue from intFields[0]
                if (item.numericSliderData) {
                    const newValue = parseInt(updatedItem.intFields[0], 10);
                    if (!isNaN(newValue)) {
                        const nsd = item.numericSliderData;
                        nsd.currentValue = Math.max(nsd.minValue, Math.min(newValue, nsd.maxValue));
                    }
                }
            }
        }

        // Header fields: only apply if non-default in the update
        if (menuData.header.bgColor !== null)      this._currentMenu.header.bgColor      = menuData.header.bgColor;
        if (menuData.header.title !== '')           this._currentMenu.header.title        = menuData.header.title;
        if (menuData.header.reRequestMs !== null)   this._currentMenu.header.reRequestMs  = menuData.header.reRequestMs;

        // Prompt-format fields: same sticky-merge semantics as item formats.
        //   Non-sticky flags (flash, sound): replaced entirely — absence clears them.
        //   Sticky formats (textColor, bold, italic, underline, fontSize): only applied
        //   when non-default in the update; otherwise the existing value persists.
        // This ensures a real device's {;} that only updates items (no format codes in
        // the header) does not wipe any bold/italic/size the user has already set.
        // To CLEAR a sticky field the device (or designer) must send a full {,} menu;
        // a {;} that omits e.g. <b> leaves existing bold in place.
        const upFmt = menuData.header.promptFormat;
        const cur   = this._currentMenu.header.promptFormat;
        if (upFmt && cur) {
            // Non-sticky: replace entirely (absence = cleared)
            cur.flash = upFmt.flash;
            cur.sound = upFmt.sound;
            // Sticky: only apply when non-default in the update
            if (upFmt.textColor !== null)  cur.textColor = upFmt.textColor;
            if (upFmt.bold)                cur.bold      = true;
            if (upFmt.italic)              cur.italic    = true;
            if (upFmt.underline)           cur.underline = true;
            if (upFmt.fontSize !== 0)      cur.fontSize  = upFmt.fontSize;
        }

        // Re-render the merged menu state in full (show() creates fresh per-item canvases)
        this.show(this._currentMenu, this._onItemClick);
    }

    /**
     * Forward a menu item click to the registered callback.
     * @param {string} cmd - The pfod command to send
     */
    _handleClick(cmd) {
        if (this._onItemClick) {
            this._onItemClick(cmd);
        }
    }
}

// Singleton instance accessible by pfodWeb.js and other modules
window.pfodMenuDisplay = new PfodMenuDisplay();
/*
   pfodInputDisplay.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Manages the full-screen text input display (input-mode) for pfod Section 10 string input.
// Assigned to window.pfodInputDisplay as a singleton after class definition.
//
// pfod format: {'<cmd>[`<maxLen>][~<prompt>][|<initialText>]}
// Submission sends: {<cmd>~<newText>} as a 'touch' request.
//
// State read:    document.body.className
// State written: document.body.className (input-mode <-> message-mode)
// DOM elements:  #input-container, #input-textarea, #input-prompt,
//                #input-popup, #input-popup-text, #input-submit-btn, #input-exit-btn
// Depends on:    pfodSetFormattedText from pfodButtonRenderer.js (must load first),
//                parsePfodFormatCodes from pfodMenuParser.js (must load first),
//                xtermColorToHex, getBlackWhite from redraw.js (must load first)
// Called by:     responseHandlers:handleNonDwgResponse (show),
//                responseHandlers:handleNonDwgResponse / handleDwgResponse / toolbarAndMenu (hide)

// Default background colour for text-input screens that supply no
// `<bg ...>` tag in their prompt — same black the CSS default for
// #input-container would have shown.  Declared at top-of-file so
// show() can initialise `bgColor` with it up-front, and the contrast
// calculation never needs an inline `||` fallback.
const PFOD_INPUT_DEFAULT_BG = '#000000';

class PfodInputDisplay {
  constructor() {
    this._encoder = new TextEncoder();
    this._decoder = new TextDecoder('utf-8', { fatal: false });
    this._cmd = '';
    this._maxLen = 255;
    this._onSubmit = null;
    this._popupTimer = null;
    // Bound handlers stored so they can be removed on hide()
    this._boundHandleInput = this._handleInput.bind(this);
    this._boundHandleSubmit = this._handleSubmit.bind(this);
    this._boundHandleKeydown = this._handleKeydown.bind(this);
  }

  // Pure static parser — no DOM access.
  // cmdArray[0]: "{'<cmd>[`<maxLen>][~<prompt>]"
  // cmdArray[1]: "|<initialText>" (optional, from pfodToJson splitting on '|')
  static parse(cmdArray) {
    const part0 = cmdArray[0]; // e.g. "{'x`11~Edit the message"
    let pos = 2; // skip {'
    // Read cmd chars until backtick, tilde, or end
    let cmd = '';
    while (pos < part0.length && part0[pos] !== '`' && part0[pos] !== '~') {
      cmd += part0[pos++];
    }
    // Default maxLen: 255 minus overhead of {cmd~} = 255 - cmd.length - 3
    let maxLen = 255 - cmd.length - 3;
    if (pos < part0.length && part0[pos] === '`') {
      pos++; // skip backtick
      let lenStr = '';
      while (pos < part0.length && part0[pos] !== '~') {
        lenStr += part0[pos++];
      }
      const parsed = parseInt(lenStr, 10);
      if (!isNaN(parsed)) {
        maxLen = parsed;
      }
    }
    let prompt = '';
    if (pos < part0.length && part0[pos] === '~') {
      pos++; // skip tilde
      prompt = part0.substring(pos);
    }
    let initialText = '';
    if (cmdArray[1] && cmdArray[1].startsWith('|')) {
      initialText = cmdArray[1].substring(1);
    }
    return { cmd, maxLen, prompt, initialText };
  }

  // Show the input screen.
  // inputData: result of PfodInputDisplay.parse()
  // onSubmit(cmd, text): called when user taps checkmark — sends text then navigates back
  show(inputData, onSubmit) {
    const textarea = document.getElementById('input-textarea');
    const promptEl = document.getElementById('input-prompt');
    const popup = document.getElementById('input-popup');
    const popupText = document.getElementById('input-popup-text');
    const submitBtn = document.getElementById('input-submit-btn');

    this._cmd = inputData.cmd;
    this._maxLen = inputData.maxLen;
    this._onSubmit = onSubmit;

    textarea.value = inputData.initialText || '';

    // Strip all <bg colorCode> tags from the prompt wherever they appear.
    // The last valid <bg> found sets the screen background; all are removed from the text.
    // Default background: PFOD_INPUT_DEFAULT_BG (top of file).  Default
    // text colour: <bw> against that background.
    let bgColor = PFOD_INPUT_DEFAULT_BG;
    const promptText = (inputData.prompt || '').replace(/<bg ([^>]+)>/g, function(match) {
      const color = parsePfodFormatCodes(match).bgColor;
      if (color) bgColor = color;
      return '';
    });
    // Apply bgColor to the container AND to the prompt.  The textarea
    // is deliberately left alone — it always renders with the CSS
    // default (`background: black; color: white`) regardless of the
    // device's `<bg ...>`, so the input area stays high-contrast and
    // legible across all themes.
    const container = document.getElementById('input-container');
    if (container) container.style.backgroundColor = bgColor;
    promptEl.style.backgroundColor = bgColor;
    const contrastHex = xtermColorToHex(getBlackWhite(bgColor));
    pfodSetFormattedText(promptEl, promptText, contrastHex, undefined, true); // prompt bar: links allowed
    promptEl.style.color = contrastHex;

    // Show transient byte-limit popup if maxLen was explicitly provided (not default)
    // We detect an explicit maxLen by checking if the original cmd array element contained a backtick.
    // The parse() result doesn't carry this flag, so we show popup whenever maxLen < default.
    const defaultMaxLen = 255 - inputData.cmd.length - 3;
    if (inputData.maxLen < defaultMaxLen) {
      popupText.textContent = 'Length of text limited to ' + inputData.maxLen;
      popup.style.display = 'flex';
      if (this._popupTimer) {
        clearTimeout(this._popupTimer);
      }
      this._popupTimer = setTimeout(() => {
        popup.style.display = 'none';
        this._popupTimer = null;
      }, 4000);
    } else {
      popup.style.display = 'none';
    }

    textarea.addEventListener('input', this._boundHandleInput);
    submitBtn.addEventListener('click', this._boundHandleSubmit);
    document.addEventListener('keydown', this._boundHandleKeydown);

    document.body.className = 'input-mode';
    textarea.focus();
  }

  // Clear input-mode and reset state.
  // Only switches body class if currently in input-mode.
  hide() {
    if (document.body.className === 'input-mode') {
      document.body.className = 'message-mode';
    }
    if (this._popupTimer) {
      clearTimeout(this._popupTimer);
      this._popupTimer = null;
    }
    const textarea = document.getElementById('input-textarea');
    const submitBtn = document.getElementById('input-submit-btn');
    const popup = document.getElementById('input-popup');
    if (textarea) {
      textarea.removeEventListener('input', this._boundHandleInput);
      textarea.value = '';
    }
    if (submitBtn) {
      submitBtn.removeEventListener('click', this._boundHandleSubmit);
    }
    if (popup) {
      popup.style.display = 'none';
    }
    document.removeEventListener('keydown', this._boundHandleKeydown);
    this._cmd = '';
    this._onSubmit = null;
  }

  isVisible() {
    return document.body.className === 'input-mode';
  }

  // Convert \uXXXX escape sequences and enforce byte limit.
  _handleInput() {
    const textarea = document.getElementById('input-textarea');
    let val = textarea.value;
    const selStart = textarea.selectionStart;

    // Auto-convert \uXXXX sequences to actual Unicode chars
    let cursorShift = 0;
    val = val.replace(/\\u([0-9a-fA-F]{4})/g, (match, hex, offset) => {
      const ch = String.fromCodePoint(parseInt(hex, 16));
      // Each 6-char escape replaced by 1 char = net -5 shift if before cursor
      if (offset < selStart - cursorShift) {
        cursorShift += 5; // match.length(6) - ch.length(1)
      }
      return ch;
    });

    // Enforce byte limit
    const encoded = this._encoder.encode(val);
    if (encoded.length > this._maxLen) {
      val = this._decoder.decode(encoded.slice(0, this._maxLen));
    }

    if (val !== textarea.value) {
      textarea.value = val;
      const newCursor = Math.max(0, selStart - cursorShift);
      textarea.setSelectionRange(newCursor, newCursor);
    }
  }

  // Called when user taps the checkmark button.
  // Does NOT call hide() — the device response handler does that.
  // Per spec, the USER is responsible for escaping restricted pfod characters.
  // If pfodWeb were to auto-escape, it would do so as follows (& must be first):
  //   text = text
  //     .replace(/&/g,  '&amp;')
  //     .replace(/`/g,  '&#96;')
  //     .replace(/\{/g, '&#123;')
  //     .replace(/\|/g, '&#124;')
  //     .replace(/\}/g, '&#125;')
  //     .replace(/~/g,  '&#126;')
  //     .replace(/\\/g, '&#92;')
  //     .replace(/</g,  '&lt;');
  _handleSubmit() {
    if (this._onSubmit) {
      const textarea = document.getElementById('input-textarea');
      this._onSubmit(this._cmd, textarea ? textarea.value : '');
    }
  }

  _handleKeydown(e) {
    // No key shortcuts — user uses the toolbar back button or submit button.
  }
}

window.pfodInputDisplay = new PfodInputDisplay();
/*
   pfodNumericInputDisplay.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Manages the full-screen numeric input display (numeric-input-mode) for pfod Section 11.
// Assigned to window.pfodNumericInputDisplay as a singleton after class definition.
//
// pfod format: {#<cmd>[~<prompt>]`<current>[`<max>[`<min>]][~units[~scale[~offset]]}
// Submission sends: {<cmd>`<integerValue>} as a 'touch' request.
// Display value = (integerValue * scale) + offset, shown with units appended.
//
// State read:    document.body.className
// State written: document.body.className (numeric-input-mode <-> message-mode)
// DOM elements:  #numeric-input-container, #numeric-input-value-display,
//                #numeric-input-value-text, #numeric-input-field,
//                #numeric-input-slider, #numeric-input-prompt,
//                #numeric-input-popup, #numeric-input-popup-text,
//                #numeric-input-submit-btn, #numeric-input-exit-btn
// Depends on:    pfodSetFormattedText from pfodButtonRenderer.js (must load first),
//                parsePfodFormatCodes from pfodMenuParser.js (must load first),
//                xtermColorToHex, getBlackWhite from redraw.js (must load first)
// Called by:     responseHandlers:handleNonDwgResponse (show),
//                responseHandlers:handleNonDwgResponse / handleDwgResponse / toolbarAndMenu (hide)

class PfodNumericInputDisplay {
  constructor() {
    this._cmd = '';
    this._min = 0;
    this._max = 254;
    this._scale = 1;
    this._offset = 0;
    this._units = '';
    this._currentInt = 0;
    this._onSubmit = null;
    this._popupTimer = null;
    // Bound handlers stored so they can be removed on hide()
    this._boundSliderInput = this._handleSliderInput.bind(this);
    this._boundValueTap = this._handleValueTap.bind(this);
    this._boundFieldChange = this._handleFieldChange.bind(this);
    this._boundFieldBlur = this._handleFieldBlur.bind(this);
    this._boundSubmit = this._handleSubmit.bind(this);
  }

  // Pure static parser — no DOM access.
  // cmdArray[0]: "{#<cmd>[~<prompt>]`<current>[`<max>[`<min>]][~units[~scale[~offset]]"
  // Backtick splits numbers; each numeric field may carry a ~units~scale~offset tail
  // if it is the last backtick-separated segment before the units section.
  static parse(cmdArray) {
    const raw = cmdArray[0]; // e.g. "{#n~Set Volts`908`1000`5~ Volts~0.011074~-0.055"
    const content = raw.slice(2); // strip "{#"

    const backtickParts = content.split('`');

    // First segment: "<cmd>[~<prompt>]"
    const firstPart = backtickParts[0];
    const tildeIdx = firstPart.indexOf('~');
    let cmd, prompt;
    if (tildeIdx >= 0) {
      cmd = firstPart.slice(0, tildeIdx);
      prompt = firstPart.slice(tildeIdx + 1);
    } else {
      cmd = firstPart;
      prompt = '';
    }

    let current = 0, max = 254, min = 0;
    let units = '', scale = 1, offset = 0;
    let unitsTail = '';

    // Each backtick segment is a numeric field; the final one may have ~units~scale~offset appended.
    function parseNumField(str) {
      const ti = str.indexOf('~');
      if (ti >= 0) {
        return { value: parseInt(str.slice(0, ti), 10) || 0, tail: str.slice(ti + 1) };
      }
      return { value: parseInt(str, 10) || 0, tail: '' };
    }

    if (backtickParts.length > 1) {
      const f = parseNumField(backtickParts[1]);
      current = f.value; if (f.tail) unitsTail = f.tail;
    }
    if (backtickParts.length > 2) {
      const f = parseNumField(backtickParts[2]);
      max = f.value; if (f.tail) unitsTail = f.tail;
    }
    if (backtickParts.length > 3) {
      const f = parseNumField(backtickParts[3]);
      min = f.value; if (f.tail) unitsTail = f.tail;
    }

    // Parse the units tail: "units~scale~offset"
    if (unitsTail) {
      const tailParts = unitsTail.split('~');
      units = tailParts[0] || '';
      if (tailParts.length > 1) { const s = parseFloat(tailParts[1]); if (!isNaN(s)) scale = s; }
      if (tailParts.length > 2) { const o = parseFloat(tailParts[2]); if (!isNaN(o)) offset = o; }
    }

    // Swap max/min if necessary so max >= min (mirrors pfodApp behaviour)
    if (min > max) { const tmp = min; min = max; max = tmp; }
    // Clamp current to [min, max]
    current = Math.max(min, Math.min(max, current));

    return { cmd, prompt, current, max, min, units, scale, offset };
  }

  // Show the numeric input screen.
  // inputData: result of PfodNumericInputDisplay.parse()
  // onSubmit(cmd, intValue): called when user taps checkmark
  show(inputData, onSubmit) {
    this._cmd = inputData.cmd;
    this._min = inputData.min;
    this._max = inputData.max;
    this._scale = inputData.scale;
    this._offset = inputData.offset;
    this._units = substituteUnsupportedUnitsGlyphs(inputData.units || '');
    this._currentInt = inputData.current;
    this._onSubmit = onSubmit;
    // dp: just enough so one raw count produces a visible change (scale = display change per count)
    this._decimals = calcDisplayDecimalPlaces(1, this._scale);

    const slider = document.getElementById('numeric-input-slider');
    const promptEl = document.getElementById('numeric-input-prompt');
    const popup = document.getElementById('numeric-input-popup');
    const popupText = document.getElementById('numeric-input-popup-text');
    const submitBtn = document.getElementById('numeric-input-submit-btn');
    const valueDisplay = document.getElementById('numeric-input-value-display');

    slider.min = this._min;
    slider.max = this._max;
    slider.value = this._currentInt;

    this._updateValueText(this._currentInt);

    // Strip all <bg colorCode> tags from the prompt wherever they appear.
    // The last valid <bg> found sets the screen background; all are removed from the text.
    // Default background: black. Default text colour: <bw> against that background.
    let bgColor = '';
    const promptText = (inputData.prompt || '').replace(/<bg ([^>]+)>/g, function(match) {
      const color = parsePfodFormatCodes(match).bgColor;
      if (color) bgColor = color;
      return '';
    });
    const container = document.getElementById('numeric-input-container');
    if (container) container.style.backgroundColor = bgColor;
    const contrastHex = xtermColorToHex(getBlackWhite(bgColor || '#000000'));
    pfodSetFormattedText(promptEl, promptText, contrastHex, undefined, true); // prompt bar: links allowed
    promptEl.style.color = contrastHex;

    // Show transient popup with the valid display-value range
    const minDisplay = (this._min * this._scale + this._offset).toFixed(this._decimals);
    const maxDisplay = (this._max * this._scale + this._offset).toFixed(this._decimals);
    popupText.textContent = 'Number between ' + minDisplay + ' and ' + maxDisplay;
    popup.style.display = 'flex';
    if (this._popupTimer) clearTimeout(this._popupTimer);
    this._popupTimer = setTimeout(() => {
      popup.style.display = 'none';
      this._popupTimer = null;
    }, 4000);

    slider.addEventListener('input', this._boundSliderInput);
    valueDisplay.addEventListener('click', this._boundValueTap);
    submitBtn.addEventListener('click', this._boundSubmit);

    document.body.className = 'numeric-input-mode';
  }

  // Clear numeric-input-mode and reset state.
  // Only switches body class if currently in numeric-input-mode.
  hide() {
    if (document.body.className === 'numeric-input-mode') {
      document.body.className = 'message-mode';
    }
    if (this._popupTimer) {
      clearTimeout(this._popupTimer);
      this._popupTimer = null;
    }

    const slider = document.getElementById('numeric-input-slider');
    const valueDisplay = document.getElementById('numeric-input-value-display');
    const submitBtn = document.getElementById('numeric-input-submit-btn');
    const field = document.getElementById('numeric-input-field');
    const valueText = document.getElementById('numeric-input-value-text');
    const popup = document.getElementById('numeric-input-popup');

    if (slider) slider.removeEventListener('input', this._boundSliderInput);
    if (valueDisplay) valueDisplay.removeEventListener('click', this._boundValueTap);
    if (submitBtn) submitBtn.removeEventListener('click', this._boundSubmit);
    if (field) {
      field.removeEventListener('change', this._boundFieldChange);
      field.removeEventListener('blur', this._boundFieldBlur);
      field.style.display = 'none';
    }
    if (valueText) valueText.style.display = '';
    if (popup) popup.style.display = 'none';

    this._cmd = '';
    this._onSubmit = null;
  }

  isVisible() {
    return document.body.className === 'numeric-input-mode';
  }

  // Format display value: (intVal * scale) + offset, to the calculated decimal places.
  _formatDisplay(intVal) {
    const d = intVal * this._scale + this._offset;
    return d.toFixed(this._decimals);
  }

  // Update the visible value text span with current integer value.
  _updateValueText(intVal) {
    const valueText = document.getElementById('numeric-input-value-text');
    if (valueText) valueText.textContent = this._formatDisplay(intVal) + this._units;
  }

  // Slider moved — update integer value and displayed text.
  _handleSliderInput() {
    const slider = document.getElementById('numeric-input-slider');
    this._currentInt = parseInt(slider.value, 10);
    this._updateValueText(this._currentInt);
  }

  // User tapped the value display — switch to editable numeric input field.
  _handleValueTap() {
    const valueText = document.getElementById('numeric-input-value-text');
    const field = document.getElementById('numeric-input-field');
    // Already editing iff we set display='block' below.  Don't test `!== 'none'` —
    // on first show the inline style is '' (CSS provides display:none), so that
    // test would falsely flag "already editing" and the field would never open.
    if (!field || field.style.display === 'block') return;
    valueText.style.display = 'none';
    field.value = this._formatDisplay(this._currentInt);
    field.style.display = 'block';
    field.addEventListener('change', this._boundFieldChange);
    field.addEventListener('blur', this._boundFieldBlur);
    field.focus();
    field.select();
  }

  // Commit the edited field value back to integer, clamp, update slider and text.
  _commitFieldValue() {
    const field = document.getElementById('numeric-input-field');
    const valueText = document.getElementById('numeric-input-value-text');
    const displayVal = parseFloat(field.value);
    if (!isNaN(displayVal)) {
      let intVal = Math.round((displayVal - this._offset) / this._scale);
      intVal = Math.max(this._min, Math.min(this._max, intVal));
      this._currentInt = intVal;
      const slider = document.getElementById('numeric-input-slider');
      if (slider) slider.value = intVal;
    }
    this._updateValueText(this._currentInt);
    field.removeEventListener('change', this._boundFieldChange);
    field.removeEventListener('blur', this._boundFieldBlur);
    field.style.display = 'none';
    if (valueText) valueText.style.display = '';
  }

  _handleFieldChange() {
    this._commitFieldValue();
  }

  _handleFieldBlur() {
    this._commitFieldValue();
  }

  // Called when user taps the checkmark button.
  // Does NOT call hide() — the response handler does that when device reply arrives.
  _handleSubmit() {
    if (this._onSubmit) {
      this._onSubmit(this._cmd, this._currentInt);
    }
  }
}

window.pfodNumericInputDisplay = new PfodNumericInputDisplay();
/*
   pfodSelectionDisplay.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Manages single-selection (Section 12: {?...}) and multi-selection (Section 13: {*...}) screens.
// Assigned to window.pfodSelectionDisplay as a singleton after class definition.
//
// Single:  {?<cmd>[`<init>][~<prompt>]|<label0>[|<labelN>]*}
//   Clicking an item immediately sends {<cmd>`N} and navigates back.
// Multi:   {*<cmd>[`<init>]*[~<prompt>]|<label0>[|<labelN>]*}
//   Tick button sends {<cmd>|N1[`N2...]} (or {<cmd>|} for none) and navigates back.
//
// State read:    document.body.className
// State written: document.body.className (selection-mode <-> message-mode)
// DOM elements:  #selection-container, #selection-list, #selection-prompt,
//                #selection-action-bar, #selection-submit-btn
// Depends on:    pfodSetFormattedText from pfodButtonRenderer.js (must load first),
//                parsePfodFormatCodes from pfodMenuParser.js (must load first)
// Called by:     responseHandlers:handleNonDwgResponse (show),
//                responseHandlers / toolbarAndMenu (hide)

class PfodSelectionDisplay {
  constructor() {
    this._cmd = '';
    this._isMulti = false;
    this._labels = [];
    this._selected = new Set();
    this._indicators = [];
    this._onSubmit = null;
    this._contrastHex = '';   // <bw> default text colour against screen background
    this._boundSubmit = this._handleSubmit.bind(this);
  }

  // Parse single-selection response: {?<cmd>[`<init>][~<prompt>]|<label>...}
  // cmdArray from pfodToJson split on '|': [{?cmd...}, |label0, |label1, ..., }]
  static parseSingle(cmdArray) {
    return PfodSelectionDisplay._parse(cmdArray, false);
  }

  // Parse multi-selection response: {*<cmd>[`<init>...][~<prompt>]|<label>...}
  static parseMulti(cmdArray) {
    return PfodSelectionDisplay._parse(cmdArray, true);
  }

  static _parse(cmdArray, isMulti) {
    const prefix = isMulti ? '{*' : '{?';
    const raw = cmdArray[0].slice(prefix.length); // strip "{?" or "{*"

    // Read cmd until ` or ~ or end
    let pos = 0;
    let cmd = '';
    while (pos < raw.length && raw[pos] !== '`' && raw[pos] !== '~') {
      cmd += raw[pos++];
    }

    // Read initial selection indices (one or more `N segments)
    const initialSelected = [];
    while (pos < raw.length && raw[pos] === '`') {
      pos++; // skip `
      let numStr = '';
      while (pos < raw.length && raw[pos] !== '`' && raw[pos] !== '~') {
        numStr += raw[pos++];
      }
      const n = parseInt(numStr, 10);
      if (!isNaN(n)) initialSelected.push(n);
    }

    // Read optional prompt after ~
    let prompt = '';
    if (pos < raw.length && raw[pos] === '~') {
      prompt = raw.slice(pos + 1);
    }

    // Labels from cmdArray[1..] — each element starts with '|'
    const labels = [];
    for (let i = 1; i < cmdArray.length; i++) {
      if (cmdArray[i].startsWith('|')) labels.push(cmdArray[i].slice(1));
    }

    return { cmd, prompt, initialSelected, labels, isMulti };
  }

  // Show the selection screen.
  // inputData: result of parseSingle() or parseMulti()
  // onSubmit(cmd, isMulti, sortedSelectedIndices): called to send response and navigate back
  show(inputData, onSubmit) {
    this._cmd = inputData.cmd;
    this._isMulti = inputData.isMulti;
    this._labels = inputData.labels;
    this._onSubmit = onSubmit;

    // Validate initial selection indices against label count
    this._selected = new Set(
      inputData.initialSelected.filter(n => n >= 0 && n < inputData.labels.length)
    );

    // Strip all <bg colorCode> tags from the prompt wherever they appear.
    // The last valid <bg> found sets the screen background; all are removed from the text.
    // Default background: black. Default text colour: <bw> against that background.
    let bgColor = '';
    const promptText = (inputData.prompt || '').replace(/<bg ([^>]+)>/g, function(match) {
      const color = parsePfodFormatCodes(match).bgColor;
      if (color) bgColor = color;
      return '';
    });
    // Cache screen bg for _buildList — per-option rows that don't
    // declare their own bg fall back to this for the auto-contrast
    // text colour calc.
    this._screenBg    = bgColor || '#000000';
    this._contrastHex = xtermColorToHex(getBlackWhite(this._screenBg));

    this._buildList();

    const container = document.getElementById('selection-container');
    if (container) container.style.backgroundColor = bgColor;

    const promptEl = document.getElementById('selection-prompt');
    if (promptEl) {
      pfodSetFormattedText(promptEl, promptText, this._contrastHex, undefined, true); // prompt bar: links allowed
      promptEl.style.color = this._contrastHex;
    }

    const submitBtn = document.getElementById('selection-submit-btn');
    if (submitBtn) {
      if (this._isMulti) {
        submitBtn.style.display = 'flex';
        submitBtn.addEventListener('click', this._boundSubmit);
      } else {
        submitBtn.style.display = 'none';
      }
    }

    document.body.className = 'selection-mode';
  }

  // Clear selection-mode and reset state.
  hide() {
    if (document.body.className === 'selection-mode') {
      document.body.className = 'message-mode';
    }
    const list = document.getElementById('selection-list');
    if (list) list.innerHTML = '';
    const submitBtn = document.getElementById('selection-submit-btn');
    if (submitBtn) submitBtn.removeEventListener('click', this._boundSubmit);

    this._cmd = '';
    this._onSubmit = null;
    this._selected = new Set();
    this._labels = [];
    this._indicators = [];
    this._contrastHex = '';
  }

  isVisible() {
    return document.body.className === 'selection-mode';
  }

  // Build the scrollable list of labelled items with checkbox/radio indicators.
  _buildList() {
    const list = document.getElementById('selection-list');
    if (!list) return;
    list.innerHTML = '';
    this._indicators = [];

    this._labels.forEach((label, idx) => {
      const item = document.createElement('div');
      item.className = 'selection-item';

      // Parse the option's leading format prefix the same way a
      // menu-item button would — `<bg X>` for per-row background,
      // `<colorCode>` for sticky text colour, `<+N>` / `<-N>` for
      // font-size, `<b>` / `<i>` / `<u>` for sticky styles.  The
      // tags before the first non-format character apply to the
      // ENTIRE row; tags inside the remainder go through pfod-
      // SetFormattedText's inline-tag parser as before.  Mirrors
      // renderPfodButton's approach in pfodButtonRenderer.js so
      // single-selection rows render visually as button-style
      // items rather than plain text.
      const fmt  = parsePfodFormatCodes(label);
      const text = fmt.remaining;

      // applyPfodFormats sets bgColor / textColor (when non-null) /
      // bold / italic / underline / non-zero fontSize on the row.
      // Children inherit text-related styles, so the label span
      // below renders with the same colour / weight / size.
      applyPfodFormats(item, fmt);

      // Auto-contrast text colour against whatever bg the row
      // ended up with — explicit textColor wins, otherwise <bw>
      // against the row's bg (per-row when declared, else the
      // screen bg).
      const rowBg       = fmt.bgColor || this._screenBg;
      const rowContrast = xtermColorToHex(getBlackWhite(rowBg));
      if (!fmt.textColor) item.style.color = rowContrast;

      const labelEl = document.createElement('span');
      labelEl.className = 'selection-label';
      // Inline tags inside the remainder still go through the
      // text-renderer.  contrastHex resolves inline <bw> tags
      // against the row's bg (not the screen bg).
      pfodSetFormattedText(labelEl, text, rowContrast);

      const indicator = document.createElement('span');
      indicator.className = this._isMulti ? 'selection-checkbox' : 'selection-radio';
      if (this._selected.has(idx)) indicator.classList.add('selected');
      this._indicators.push(indicator);

      item.appendChild(labelEl);
      item.appendChild(indicator);
      item.addEventListener('click', () => this._handleItemClick(idx));
      list.appendChild(item);

      // Separator between items (not after last)
      if (idx < this._labels.length - 1) {
        const sep = document.createElement('div');
        sep.className = 'selection-separator';
        list.appendChild(sep);
      }
    });
  }

  _handleItemClick(idx) {
    if (this._isMulti) {
      if (this._selected.has(idx)) {
        this._selected.delete(idx);
        this._indicators[idx].classList.remove('selected');
      } else {
        this._selected.add(idx);
        this._indicators[idx].classList.add('selected');
      }
    } else {
      // Single selection: clicking submits immediately
      this._selected = new Set([idx]);
      this._handleSubmit();
    }
  }

  // Called when tick button clicked (multi) or item clicked (single).
  // Does NOT call hide() — responseHandlers does that when the device reply arrives.
  _handleSubmit() {
    if (this._onSubmit) {
      const sorted = Array.from(this._selected).sort((a, b) => a - b);
      this._onSubmit(this._cmd, this._isMulti, sorted);
    }
  }
}

window.pfodSelectionDisplay = new PfodSelectionDisplay();
