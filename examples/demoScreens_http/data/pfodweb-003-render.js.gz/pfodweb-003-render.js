/*
   caching.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Response Caching Module — stores versioned pfod responses in localStorage.
//
// Exports:    cacheResponse(data, request, connectionManager) global function
// Depends on: connectionManager (passed as parameter, reads .protocol and .config)
// Called by:  requestQueue.js processRequestQueue (after each successful response)

// Get unique identifier for the current connection endpoint.
//
// Delegates to connectionManager.getConnectionId() so every cache layer
// (cacheResponse here, the per-drawing / per-menuDwg caches in
// DrawingManager, the menuCache in PfodMenuCache, and the per-connection
// scheduler in navigationAndQueue) all key on the same string:
//   'http_<ip>'    e.g. 'http_10.1.1.100'
//   'serial_<port>' e.g. 'serial_COM3'
//   'ble_<name>'   e.g. 'ble_MyDevice'
//
// This is strictly more specific than the previous protocol-only form
// (which returned a bare 'Serial' for any serial port), so two devices
// on different serial ports no longer share cache entries.
function getConnectionIdentifier(connectionManager) {
  if (!connectionManager) {
    throw new Error('[CACHE] getConnectionIdentifier: connectionManager is required');
  }
  if (typeof connectionManager.getConnectionId !== 'function') {
    throw new Error('[CACHE] getConnectionIdentifier: connectionManager.getConnectionId() is not available');
  }
  return connectionManager.getConnectionId();
}

// Determine response type from msgType (cmd[0])
// Returns: 'menuStart', 'menuUpdate', 'dwgStart', 'dwgUpdate', or null
function getResponseType(msgType) {
  if (!msgType || typeof msgType !== 'string') {
    throw new Error(`[CACHE] getResponseType: msgType must be a non-empty string, got ${typeof msgType}`);
  }

  if (msgType.startsWith('{,')) {
    return 'menuStart';
  }
  if (msgType.startsWith('{;')) {
    return 'menuUpdate';
  }
  if (msgType === '{+') {
    return 'dwgUpdate';
  }
  if (msgType.startsWith('{+') && msgType.length > 2) {
    return 'dwgStart';
  }

  return null;
}

// Extract version prefix from request cmd, if present.
// pfod versioned cmd format: {version:commandKey...}
// Returns null when the request has no version prefix.
// Examples:
//   {V1:.}              → "V1"
//   {V361:llcA~...}     → "V361"
//   {.}                 → null
//   {c1}                → null
function getVersionFromRequest(request) {
  if (!request) return null;
  const cmd = request.cmd;
  if (!cmd || typeof cmd !== 'string' || cmd.length < 2) return null;
  // Skip the opening {
  const content = cmd.substring(1);
  const colonIndex = content.indexOf(':');
  if (colonIndex === -1) return null;
  const version = content.substring(0, colonIndex).trim();
  return version || null;
}

// Extract command key from request
// Format: {[version:]commandKey[separator...]}
// Separators: backtick, tilde, space, closing brace
// Examples:
//   {v1:.} → "."
//   {v1:c1`data} → "c1"
//   {v1:c1~data} → "c1"
//   {c1`data} → "c1"
//   {.} → "."
function getCommandKeyFromRequest(request) {
  if (!request) {
    throw new Error('[CACHE] getCommandKeyFromRequest: request is required');
  }

  const cmd = request.cmd;
  if (!cmd || typeof cmd !== 'string') {
    throw new Error(`[CACHE] getCommandKeyFromRequest: request.cmd must be a non-empty string, got ${typeof cmd}`);
  }

  // Skip the opening {
  let content = cmd.substring(1);

  // Check if there's a version prefix (indicated by :)
  const colonIndex = content.indexOf(':');
  if (colonIndex !== -1) {
    // Skip the version part
    content = content.substring(colonIndex + 1);
  }

  // Extract the command key up to the next separator or closing brace
  // Separators are: backtick, tilde, space, closing brace
  const match = content.match(/^([^`~\s}]+)/);
  if (match && match[1]) {
    return match[1];
  }

  console.log('[CACHE] Could not extract command key from request:', cmd);
  return null;
}

// Extract version from msgType string (cmd[0]).
// Returns null when no version is present.
//
// Menu headers ({,...} and {;...}) can mix title text containing tildes, an
// optional `<reRequestMs> field that may appear before OR after the version,
// and an empty version emitted as `~~`.  Tilde-counting heuristics get fooled
// by all three.  Delegate menu cases to parsePfodMenuHeader (the canonical
// header parser used by the menu display) which handles each correctly.
function extractVersionFromResponse(msgType) {
  if (!msgType || typeof msgType !== 'string') {
    return null;
  }

  // Menu headers — use the canonical parser
  if ((msgType.startsWith('{,') || msgType.startsWith('{;'))
      && typeof window.parsePfodMenuHeader === 'function') {
    const header = window.parsePfodMenuHeader(msgType);
    const v = (header.version || '').trim();
    if (v.length === 0) {
      console.log('[CACHE] No version found in menu header');
      return null;
    }
    console.log(`[CACHE] Extracted version: ${v}`);
    return v;
  }

  // Drawing headers ({+...}) — version is the last ~-separated field.
  // Format: {+<col>`<x>`<y>[~m][`<refreshMs>~<version>]
  // Find the LAST '~' and take everything after it as the version token.
  const lastTilde = msgType.lastIndexOf('~');
  if (lastTilde === -1) {
    console.log('[CACHE] No version found (no tildes)');
    return null;
  }
  const tail = msgType.substring(lastTilde + 1).trim();
  // The tail is the version only if it doesn't look like a flag/refreshMs.
  // 'm' on its own is the more-flag, not a version; reject.  Empty -> null.
  if (tail.length === 0 || tail === 'm') {
    console.log('[CACHE] No version found after last tilde');
    return null;
  }
  // Strip an accidental leading '`<digits>' that some emitters place before
  // the version's separating tilde (defensive — not expected in dwg headers).
  const v = tail.replace(/^`\d+/, '').trim();
  if (v.length === 0) {
    console.log('[CACHE] No version found after stripping reRequestMs');
    return null;
  }
  console.log(`[CACHE] Extracted version: ${v}`);
  return v;
}

// Generate cache key for storing response
// Format: pfodWeb_cache_{connection_identifier}_{commandKey}
function getCacheKey(connectionId, commandKey) {
  return `pfodWeb_cache_${connectionId}_${commandKey}`;
}

// Cache response to localStorage
// Only caches if version is present and response is a cacheable type
// Uses the command key from the request (what was sent)
// Extracts msgType from data.cmd[0]
function cacheResponse(data, request, connectionManager) {
  try {
    // Extract msgType from response data
    if (!data || !data.cmd || !Array.isArray(data.cmd) || data.cmd.length === 0) {
      console.log('[CACHE] Not caching - no cmd data in response');
      return;
    }

    const msgType = data.cmd[0];

    // Determine response type (to validate it's cacheable)
    const responseType = getResponseType(msgType);
    if (!responseType) {
      console.log('[CACHE] Not caching - response type not recognized');
      return;
    }

    // Extract version from response.
    //
    // For menuStart ({,...}) and dwgStart ({+x`y...}) the device always
    // includes a version (after the second ~).  For menuUpdate ({;...})
    // and dwgUpdate ({+|...}) the device omits the version because it
    // means "your request version matched — here's just an update".
    // We don't re-cache in that case (the full versioned response is
    // already cached); we just acknowledge that the existing cache
    // entry is still valid at the request's version.
    const version = extractVersionFromResponse(msgType);
    if (!version) {
      if (responseType === 'menuUpdate' || responseType === 'dwgUpdate') {
        const requestVersion = getVersionFromRequest(request);
        if (requestVersion) {
          console.log(`[CACHE] ${responseType} matched request version "${requestVersion}" — existing cache entry is still valid, no re-cache needed`);
          data.version = requestVersion;
          return;
        }
        console.log(`[CACHE] ${responseType} has no version and request had no version prefix — not caching`);
        return;
      }
      // Unversioned menuStart / dwgStart: any prior cache entry is now stale.
      // Evict it so the next request re-fetches fresh, and so /MENU_CACHE eviction
      // remains consistent with this legacy cache layer.
      const commandKey = getCommandKeyFromRequest(request);
      if (commandKey) {
        const connectionId = getConnectionIdentifier(connectionManager);
        const cacheKey = getCacheKey(connectionId, commandKey);
        if (localStorage.getItem(cacheKey) !== null) {
          localStorage.removeItem(cacheKey);
          console.log(`[CACHE] ${responseType} has no version - evicted "${commandKey}" from cache. Key: ${cacheKey}`);
        } else {
          console.log(`[CACHE] Not caching ${responseType} - no version found in response`);
        }
      } else {
        console.log(`[CACHE] Not caching ${responseType} - no version found in response`);
      }
      return;
    }

    // Extract command key from request
    const commandKey = getCommandKeyFromRequest(request);
    if (!commandKey) {
      console.log('[CACHE] Not caching - could not extract command key from request');
      return;
    }

    // Add version to data object
    data.version = version;

    // Get connection identifier
    const connectionId = getConnectionIdentifier(connectionManager);

    // Generate cache key
    const cacheKey = getCacheKey(connectionId, commandKey);

    // Store to localStorage
    localStorage.setItem(cacheKey, JSON.stringify(data));
    console.log(`[CACHE] Cached ${responseType} (cmd key: ${commandKey}) for connection "${connectionId}" with version "${version}". Key: ${cacheKey}`);
  } catch (e) {
    console.error('[CACHE] Error caching response:', e);
    throw e;
  }
}
/*
   messageViewer.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Exports:    window.MessageCollector class, window.RawMessageViewer class,
//             window.ChartConfigViewer class
// Depends on: window.csvCollector (ChartConfigViewer reads CSV field counts and applies configs),
//             window.chartDisplay (ChartConfigViewer calls displayChartWithPlotNo indirectly)
// Called by:  keepAliveAndHttp.js initializeMessageViewer (creates all three instances as
//             window.messageCollector, window.rawMessageViewer, window.chartConfigViewer);
//             toolbarAndMenu.js showToolbarMenu (opens rawMessageViewer / chartConfigViewer)

// How long a partial (not yet newline terminated) run of OUTSIDE text is held
// before it is shown anyway.  Serial/BLE hand the stream over in arbitrary
// sized chunks, so the characters of one printed line typically arrive over
// several reads a few ms apart; this delay lets them be joined back together.
const RAW_TEXT_FLUSH_MS = 100;

/**
 * MessageCollector - Centralized collector for raw messages from all connections
 * Stores messages with metadata (timestamp, direction, connection type, size)
 */
class MessageCollector {
  constructor(maxMessages = 500) {
    this.messages = [];
    this.maxMessages = maxMessages;
    this.subscribers = []; // Callback functions to notify of new messages
    this.isPaused = false;
    // Buffer for OUTSIDE (non-pfod) received text - see addRawText()
    this.pendingRawText = '';     // characters received but not shown yet
    this.pendingRawProtocol = null; // protocol the pending characters came from
    this.pendingRawTimer = null;  // setTimeout id for the partial-line flush
    // console.log('[MESSAGE_COLLECTOR Created with max messages:', maxMessages);
  }

  /**
   * Add received text that arrived OUTSIDE any pfod {..} command - streaming
   * CSV data, and on a Serial connection any debug print statements.
   *
   * The characters are buffered rather than shown per read, so a line that
   * arrives split over several reads is shown as ONE entry.  The buffer is
   * turned into an entry when either
   *   - a '\n' is seen: everything up to and including the LAST '\n' is shown
   *     immediately, so complete lines are never held back and the entry keeps
   *     its terminating newline even when the next character is the '{' of a
   *     command (which is shown as its own entry), or
   *   - RAW_TEXT_FLUSH_MS elapses with no further characters: the partial line
   *     is shown so nothing is ever held back indefinitely.
   * Any other addMessage() (sent cmd, complete {..} cmd, timeout) flushes the
   * buffer first, so entries always stay in stream order.
   *
   * Only the Raw Message viewer is buffered - the CSV and raw data collectors
   * are fed every character immediately by the caller.
   *
   * @param {string} message - the OUTSIDE characters just received
   * @param {string} protocol - 'http', 'serial', 'tcp' or 'ble'
   */
  addRawText(message, protocol) {
    if (this.isPaused || !message) {
      return;
    }

    this.pendingRawText += message;
    this.pendingRawProtocol = protocol;

    // Show all complete lines now, keeping their newlines.
    const lastNewline = this.pendingRawText.lastIndexOf('\n');
    if (lastNewline !== -1) {
      const completeLines = this.pendingRawText.substring(0, lastNewline + 1);
      this.pendingRawText = this.pendingRawText.substring(lastNewline + 1);
      this.addEntry('received', completeLines, protocol, null);
    }

    // Whatever is left is a partial line - wait a little for the rest of it.
    this.clearRawTextTimer();
    if (this.pendingRawText.length > 0) {
      this.pendingRawTimer = setTimeout(() => {
        this.pendingRawTimer = null;
        this.flushRawText();
      }, RAW_TEXT_FLUSH_MS);
    }
  }

  /**
   * Show any buffered OUTSIDE text now, as a single entry.
   * Called by the flush timer and by addMessage() (so a sent command, a
   * complete {..} command or a timeout never jumps ahead of text that was
   * received before it).  Does nothing if the buffer is empty.
   */
  flushRawText() {
    this.clearRawTextTimer();
    if (this.pendingRawText.length === 0) {
      return;
    }
    const text = this.pendingRawText;
    this.pendingRawText = '';
    this.addEntry('received', text, this.pendingRawProtocol, null);
  }

  /**
   * Cancel the pending partial-line flush timer, if one is running.
   */
  clearRawTextTimer() {
    if (this.pendingRawTimer !== null) {
      clearTimeout(this.pendingRawTimer);
      this.pendingRawTimer = null;
    }
  }

  /**
   * Add a message to the collector
   * @param {string} direction - 'sent' or 'received'
   * @param {string} message - The raw message text
   * @param {string} protocol - 'http', 'serial', or 'ble'
   * @param {string} cmd - Optional command that was sent (for reference)
   */
  addMessage(direction, message, protocol, cmd = null) {
    if (this.isPaused) {
      return;
    }
    // Buffered OUTSIDE text was received before this message - show it first.
    this.flushRawText();
    this.addEntry(direction, message, protocol, cmd);
  }

  /**
   * Create the entry, store it (trimming to maxMessages) and notify
   * subscribers.  Internal - callers go through addMessage() / addRawText().
   * @param {string} direction - 'sent', 'received', 'timeout' or 'excess >1024'
   * @param {string} message - The raw message text
   * @param {string} protocol - 'http', 'serial', 'tcp' or 'ble'
   * @param {string} cmd - Optional command that was sent (for reference)
   */
  addEntry(direction, message, protocol, cmd) {
    const entry = {
      timestamp: new Date().toISOString(),
      direction: direction,
      protocol: protocol,
      message: message,
      cmd: cmd,
      size: message ? message.length : 0
    };

    this.messages.push(entry);

    // Trim to max messages if needed
    if (this.messages.length > this.maxMessages) {
      this.messages.shift();
    }

    // Notify subscribers
    this.notifySubscribers(entry);

    const logPrefix = direction === 'sent' ? '>>> SENT' : '<<< RECEIVED';
    // console.log('[MESSAGE_COLLECTOR ${logPrefix} [${protocol}] ${message ? message.substring(0, 100) : '(empty)'}`);
  }

  /**
   * Subscribe to new messages
   * @param {function} callback - Function to call with new message entry
   */
  subscribe(callback) {
    this.subscribers.push(callback);
  }

  /**
   * Unsubscribe from messages
   * @param {function} callback - The callback to remove
   */
  unsubscribe(callback) {
    this.subscribers = this.subscribers.filter(cb => cb !== callback);
  }

  /**
   * Notify all subscribers of a new message
   */
  notifySubscribers(entry) {
    this.subscribers.forEach(callback => {
      callback(entry);
    });
  }

  /**
   * Get all messages
   */
  getMessages() {
    return [...this.messages];
  }

  /**
   * Get messages filtered by protocol
   */
  getMessagesByProtocol(protocol) {
    return this.messages.filter(msg => msg.protocol === protocol);
  }

  /**
   * Get messages filtered by direction
   */
  getMessagesByDirection(direction) {
    return this.messages.filter(msg => msg.direction === direction);
  }

  /**
   * Clear all messages
   */
  clear() {
    this.clearRawTextTimer();
    this.pendingRawText = '';
    this.messages = [];
    // console.log('[MESSAGE_COLLECTOR Messages cleared');
  }

  /**
   * Pause collecting messages
   */
  pause() {
    this.isPaused = true;
    // console.log('[MESSAGE_COLLECTOR Paused');
  }

  /**
   * Resume collecting messages
   */
  resume() {
    this.isPaused = false;
    // console.log('[MESSAGE_COLLECTOR Resumed');
  }

  /**
   * Export messages as JSON, with ms field (ms since first message timestamp)
   * and bytes field (raw uint8_t wire-byte count — pfod is a text protocol
   * with one wire byte per character, so this is the JS string length).
   */
  exportAsJSON() {
    const t0 = this.messages.length > 0 ? new Date(this.messages[0].timestamp).getTime() : 0;
    const withMs = this.messages.map(msg => {
      const ms = new Date(msg.timestamp).getTime() - t0;
      const bytes = msg.message ? msg.message.length : 0;
      return { timestamp: msg.timestamp, ms, direction: msg.direction, bytes, message: msg.message };
    });
    return JSON.stringify(withMs, null, 2);
  }

  /**
   * Export messages as CSV, with ms column (ms since first message timestamp)
   * and bytes column (raw uint8_t wire-byte count — pfod is a text protocol
   * with one wire byte per character, so this is the JS string length).
   */
  exportAsCSV() {
    if (this.messages.length === 0) {
      return 'timestamp,ms,direction,bytes,message\n';
    }

    const t0 = new Date(this.messages[0].timestamp).getTime();
    const header = 'timestamp,ms,direction,bytes,message\n';
    const rows = this.messages.map(msg => {
      const ms = new Date(msg.timestamp).getTime() - t0;
      const bytes = msg.message ? msg.message.length : 0;
      const message = msg.message.replace(/"/g, '""').replace(/\n/g, '\\n'); // Escape quotes; represent newlines as \n
      return `"${msg.timestamp}",${ms},"${msg.direction}",${bytes},"${message}"`;
    });

    return header + rows.join('\n');
  }
}

/**
 * RawMessageViewer - UI component to display collected messages
 */
class RawMessageViewer {
  constructor(messageCollector, containerId = 'side-panel') {
    this.collector = messageCollector;
    this.containerId = containerId;
    this.isVisible = false;
    this.filterDirection = 'all'; // 'all', 'sent', 'received', 'timeout'
    this.autoScroll = true;
    this.messageViews = []; // Store references to message view elements for scrolling

    // Message batching for performance with high-speed data
    this.pendingMessages = []; // Queue of messages to add
    this.updateScheduled = false; // Flag to track if an update is already scheduled
    this.maxBatchSize = 50; // Process up to 50 messages per animation frame
    this.animationFrameId = null;

    console.log('[RAW_MESSAGE_VIEWER] Created with container:', containerId);

    // Subscribe to new messages
    this.collector.subscribe((entry) => this.onNewMessage(entry));
  }

  /**
   * Initialize and create the viewer UI
   */
  initialize() {
    const container = document.getElementById(this.containerId);
    if (!container) {
      console.error('[RAW_MESSAGE_VIEWER] Container not found:', this.containerId);
      return;
    }

    this.createViewerHTML(container);
    this.attachEventListeners();
    this.updateMessageDisplay();
    console.log('[RAW_MESSAGE_VIEWER] Initialized');
  }

  /**
   * Create the HTML structure for the viewer
   */
  createViewerHTML(container) {
    container.innerHTML = `
      <div class="raw-message-viewer" id="raw-message-viewer-main">
        <div class="raw-message-header">
          <div class="raw-message-title">
            <span>Raw Message Viewer</span>
            <button class="raw-message-close-btn" id="raw-message-close-btn" title="Close viewer">&times;</button>
          </div>
          <div class="raw-message-toolbar">
            <div class="raw-message-filters">
              <select id="raw-msg-filter-direction" class="raw-message-filter">
                <option value="all">Direction: All</option>
                <option value="sent">Direction: Sent</option>
                <option value="received">Direction: Received</option>
                <option value="timeout">Direction: Timeout</option>
              </select>
            </div>
            <div class="raw-message-buttons">
              <label class="raw-message-checkbox">
                <input type="checkbox" id="raw-msg-autoscroll" checked>
                Auto-scroll
              </label>
              <button id="raw-msg-clear-btn" class="raw-message-btn">Clear</button>
              <button id="raw-msg-export-json-btn" class="raw-message-btn">Export JSON</button>
              <button id="raw-msg-export-csv-btn" class="raw-message-btn">Export CSV</button>
              <button id="raw-msg-export-csv-by-fields-btn" class="raw-message-btn" title="Export CSV data organized by field count">Export CSV by Fields</button>
            </div>
          </div>
        </div>
        <div class="raw-message-content">
          <div class="raw-message-list" id="raw-message-list">
            <div class="raw-message-empty">No messages yet</div>
          </div>
        </div>
      </div>
    `;

    this.attachStyles(container);
  }

  /**
   * Attach CSS styles to the container
   */
  attachStyles(container) {
    const style = document.createElement('style');
    style.textContent = `
      #${this.containerId} {
        all: initial;
        display: none;
        flex-direction: column;
        width: 100%;
        height: 100%;
        font-family: 'Courier New', monospace;
        min-width: 200px;
        background-color: #1e1e1e;
      }

      .raw-message-viewer {
        display: flex;
        flex-direction: column;
        height: 100%;
        width: 100%;
        background-color: #1e1e1e;
        color: #d4d4d4;
        border: 1px solid #333;
        box-sizing: border-box;
        z-index: 5000;
      }

      .raw-message-header {
        flex-shrink: 0;
        background-color: #252526;
        border-bottom: 1px solid #3e3e42;
        padding: 8px;
      }

      .raw-message-title {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 8px;
        font-weight: bold;
        font-size: 14px;
        color: #cccccc;
      }

      .raw-message-close-btn {
        background: none;
        border: none;
        color: #cccccc;
        font-size: 20px;
        cursor: pointer;
        padding: 0;
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .raw-message-close-btn:hover {
        color: #ffffff;
      }

      .raw-message-toolbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 8px;
      }

      .raw-message-filters {
        display: flex;
        gap: 8px;
      }

      .raw-message-filter,
      .raw-message-btn,
      .raw-message-checkbox input {
        background-color: #3c3c3c;
        color: #d4d4d4;
        border: 1px solid #555;
        padding: 4px 8px;
        border-radius: 3px;
        font-size: 12px;
        cursor: pointer;
        font-family: Arial, sans-serif;
      }

      .raw-message-filter:hover,
      .raw-message-btn:hover {
        background-color: #454545;
      }

      .raw-message-filter:focus,
      .raw-message-btn:focus {
        outline: 1px solid #007acc;
      }

      .raw-message-buttons {
        display: flex;
        gap: 8px;
      }

      .raw-message-checkbox {
        display: flex;
        align-items: center;
        gap: 4px;
        cursor: pointer;
        font-size: 12px;
        color: #d4d4d4;
      }

      .raw-message-checkbox input {
        cursor: pointer;
        padding: 0;
        width: 16px;
        height: 16px;
      }

      .raw-message-content {
        flex: 1;
        overflow: hidden;
        display: flex;
        flex-direction: column;
      }

      .raw-message-list {
        flex: 1;
        overflow-y: auto;
        overflow-x: auto;
        background-color: #1e1e1e;
        padding: 4px;
      }

      .raw-message-item {
        display: flex;
        padding: 4px;
        margin: 2px 0;
        border-radius: 2px;
        border-left: 3px solid;
        white-space: pre-wrap;
        word-wrap: break-word;
        font-size: 11px;
        line-height: 1.4;
      }

      .raw-message-item.sent {
        border-left-color: #4ec9b0;
        background-color: #1e3b2a;
      }

      .raw-message-item.received {
        border-left-color: #ce9178;
        background-color: #3b2a1e;
      }

      .raw-message-item.timeout {
        border-left-color: #f44747;
        background-color: #3b1e1e;
      }

      .raw-message-item-time {
        color: #858585;
        min-width: 100px;
        margin-right: 0px;
        flex-shrink: 0;
      }

      .raw-message-item-direction {
        color: #d7ba7d;
        min-width: 20px;
        margin-right: 2px;
        flex-shrink: 0;
        font-weight: bold;
      }

      .raw-message-item-text {
        flex: 1;
        color: #ce9178;
        word-break: break-all;
      }

      .raw-message-empty {
        color: #858585;
        padding: 20px;
        text-align: center;
        font-style: italic;
      }

      /* Scrollbar styling */
      .raw-message-list::-webkit-scrollbar {
        width: 12px;
        height: 12px;
      }

      .raw-message-list::-webkit-scrollbar-track {
        background-color: #1e1e1e;
      }

      .raw-message-list::-webkit-scrollbar-thumb {
        background-color: #464647;
        border-radius: 4px;
      }

      .raw-message-list::-webkit-scrollbar-thumb:hover {
        background-color: #5a5a5a;
      }
    `;
    document.head.appendChild(style);
  }

  /**
   * Attach event listeners to controls
   */
  attachEventListeners() {
    const closeBtn = document.getElementById('raw-message-close-btn');
    if (!closeBtn) throw new Error('[messageViewer] attachEventListeners: #raw-message-close-btn not found');
    closeBtn.addEventListener('click', () => this.hide());

    const filterDir = document.getElementById('raw-msg-filter-direction');
    if (!filterDir) throw new Error('[messageViewer] attachEventListeners: #raw-msg-filter-direction not found');
    filterDir.addEventListener('change', (e) => {
      this.filterDirection = e.target.value;
      this.updateMessageDisplay();
    });

    const autoscroll = document.getElementById('raw-msg-autoscroll');
    if (!autoscroll) throw new Error('[messageViewer] attachEventListeners: #raw-msg-autoscroll not found');
    autoscroll.addEventListener('change', (e) => {
      this.autoScroll = e.target.checked;
    });

    const clearBtn = document.getElementById('raw-msg-clear-btn');
    if (!clearBtn) throw new Error('[messageViewer] attachEventListeners: #raw-msg-clear-btn not found');
    clearBtn.addEventListener('click', () => {
      this.collector.clear();
      // Also clear CSV collector if available
      if (ConnectionManager.csvCollector) {
        ConnectionManager.csvCollector.clear();
      }
      this.updateMessageDisplay();
    });

    const exportJsonBtn = document.getElementById('raw-msg-export-json-btn');
    if (!exportJsonBtn) throw new Error('[messageViewer] attachEventListeners: #raw-msg-export-json-btn not found');
    exportJsonBtn.addEventListener('click', () => this.exportJSON());

    const exportCsvBtn = document.getElementById('raw-msg-export-csv-btn');
    if (!exportCsvBtn) throw new Error('[messageViewer] attachEventListeners: #raw-msg-export-csv-btn not found');
    exportCsvBtn.addEventListener('click', () => this.exportCSV());

    const exportCsvByFieldsBtn = document.getElementById('raw-msg-export-csv-by-fields-btn');
    if (!exportCsvByFieldsBtn) throw new Error('[messageViewer] attachEventListeners: #raw-msg-export-csv-by-fields-btn not found');
    exportCsvByFieldsBtn.addEventListener('click', () => this.exportCSVByFieldCount());
  }

  /**
   * Called when a new message is added to the collector
   * Messages are queued and processed in batches to prevent DOM thrashing
   */
  onNewMessage(entry) {
    if (!this.isVisible) {
      return; // Don't update if not visible
    }

    if (!this.shouldDisplayMessage(entry)) {
      return;
    }

    // Queue the message instead of adding it immediately
    this.pendingMessages.push(entry);

    // Schedule a batch update if one isn't already scheduled
    if (!this.updateScheduled) {
      this.updateScheduled = true;
      this.animationFrameId = requestAnimationFrame(() => {
        this.processPendingMessages();
      });
    }
  }

  /**
   * Process queued messages in batches using requestAnimationFrame
   * This prevents DOM thrashing when receiving high-speed data
   */
  processPendingMessages() {
    if (this.pendingMessages.length === 0) {
      this.updateScheduled = false;
      return;
    }

    const messageList = document.getElementById('raw-message-list');
    if (!messageList) {
      this.pendingMessages = [];
      this.updateScheduled = false;
      return;
    }

    // Process up to maxBatchSize messages
    const batch = this.pendingMessages.splice(0, this.maxBatchSize);

    // Remove empty message if it exists
    const emptyMsg = messageList.querySelector('.raw-message-empty');
    if (emptyMsg && this.messageViews.length === 0) {
      emptyMsg.remove();
    }

    // Use document fragment for better performance
    const fragment = document.createDocumentFragment();
    batch.forEach(entry => {
      const messageEl = this.createMessageElement(entry);
      fragment.appendChild(messageEl);
      this.messageViews.push(messageEl);
    });

    messageList.appendChild(fragment);

    // Limit number of visible elements to prevent memory issues
    const maxVisibleMessages = 1000;
    while (this.messageViews.length > maxVisibleMessages) {
      const removed = this.messageViews.shift();
      removed.remove();
    }

    // Scroll to bottom if autoScroll is enabled
    if (this.autoScroll) {
      messageList.scrollTop = messageList.scrollHeight;
    }

    // Schedule next batch if there are more messages
    if (this.pendingMessages.length > 0) {
      this.animationFrameId = requestAnimationFrame(() => {
        this.processPendingMessages();
      });
    } else {
      this.updateScheduled = false;
    }
  }

  /**
   * Check if message should be displayed based on current filters
   */
  shouldDisplayMessage(entry) {
    if (this.filterDirection !== 'all' && entry.direction !== this.filterDirection) {
      return false;
    }
    return true;
  }

  /**
   * Create a message element from an entry
   */
  createMessageElement(entry) {
    const messageEl = document.createElement('div');
    messageEl.className = `raw-message-item ${entry.direction}`;

    const timeEl = document.createElement('span');
    timeEl.className = 'raw-message-item-time';
    const time = new Date(entry.timestamp).toLocaleTimeString('en-US', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      fractionalSecondDigits: 3
    });
    timeEl.textContent = time;

    const directionEl = document.createElement('span');
    directionEl.className = 'raw-message-item-direction';
    directionEl.textContent = entry.direction === 'sent' ? '<<' : '>>';

    const textEl = document.createElement('span');
    textEl.className = 'raw-message-item-text';
    // The list is white-space:pre-wrap so newlines in the text are shown as
    // line breaks.  A newline at the very END of the text is trimmed by the
    // browser (a segment break at the end of a block is removed), so a
    // zero-width space is appended after it to force the empty last line to be
    // shown - the entry then visibly ends with its newline.  Display only:
    // entry.message and the JSON/CSV exports are untouched.
    const ZERO_WIDTH_SPACE = String.fromCharCode(0x200B);
    const endsWithNewline = entry.message && entry.message.charAt(entry.message.length - 1) === '\n';
    textEl.textContent = endsWithNewline ? (entry.message + ZERO_WIDTH_SPACE) : entry.message;

    messageEl.appendChild(timeEl);
    messageEl.appendChild(directionEl);
    messageEl.appendChild(textEl);

    return messageEl;
  }

  /**
   * Add a message to the display (used by updateMessageDisplay during filtering)
   */
  addMessageToDisplay(entry) {
    const messageList = document.getElementById('raw-message-list');
    if (!messageList) throw new Error('[messageViewer] addMessageToDisplay: #raw-message-list not found');

    // Remove empty message if it exists
    const emptyMsg = messageList.querySelector('.raw-message-empty');
    if (emptyMsg) {
      emptyMsg.remove();
    }

    const messageEl = this.createMessageElement(entry);
    messageList.appendChild(messageEl);
    this.messageViews.push(messageEl);

    // Limit number of visible elements to prevent memory issues
    const maxVisibleMessages = 1000;
    if (this.messageViews.length > maxVisibleMessages) {
      const removed = this.messageViews.shift();
      removed.remove();
    }
  }

  /**
   * Update the entire message display based on filters
   */
  updateMessageDisplay() {
    const messageList = document.getElementById('raw-message-list');
    if (!messageList) throw new Error('[messageViewer] updateMessageDisplay: #raw-message-list not found');

    messageList.innerHTML = '';
    this.messageViews = [];

    const messages = this.collector.getMessages();
    const filteredMessages = messages.filter(msg => this.shouldDisplayMessage(msg));

    if (filteredMessages.length === 0) {
      messageList.innerHTML = '<div class="raw-message-empty">No messages match the filters</div>';
      return;
    }

    filteredMessages.forEach(entry => this.addMessageToDisplay(entry));

    if (this.autoScroll) {
      messageList.scrollTop = messageList.scrollHeight;
    }
  }

  /**
   * Show the viewer.
   * Hides chart-config-viewer-main if present so only one view shows at a time.
   */
  show() {
    // Hide chart config inner content if it exists - only one view at a time
    const configMain = document.getElementById('chart-config-viewer-main');
    if (configMain) {
      configMain.style.display = 'none';
    }
    if (window.chartConfigViewer) {
      window.chartConfigViewer.isVisible = false;
    }

    // Show raw message viewer inner content (may have been hidden by ChartConfigViewer.show())
    const rawMain = document.getElementById('raw-message-viewer-main');
    if (rawMain) {
      rawMain.style.display = 'flex';
    }

    const container = document.getElementById(this.containerId);
    if (container) {
      container.style.display = 'flex';
      container.style.flexDirection = 'column';
      container.style.flex = 0.30; // 30% width
      this.isVisible = true;
      this.updateMessageDisplay();

      // Show the divider
      const divider = document.getElementById('resize-divider');
      if (divider) {
        divider.style.display = 'block';
      }

      // Set canvas pane to 70%
      const canvasPane = document.getElementById('canvas-pane');
      if (canvasPane) {
        canvasPane.style.flex = 0.70;
      }

      console.log('[RAW_MESSAGE_VIEWER] Shown - canvas 70%, viewer 30%');
      setTimeout(() => window.drawingViewer.handleResize(), 0);
    }
  }

  /**
   * Hide the viewer
   */
  hide() {
    const container = document.getElementById(this.containerId);
    if (container) {
      container.style.display = 'none';
      container.style.flex = 0; // Take no space
      this.isVisible = false;

      // Cancel any pending animation frame and clear pending messages
      if (this.animationFrameId) {
        cancelAnimationFrame(this.animationFrameId);
        this.animationFrameId = null;
      }
      this.pendingMessages = [];
      this.updateScheduled = false;

      // Hide the divider
      const divider = document.getElementById('resize-divider');
      if (divider) {
        divider.style.display = 'none';
      }

      // Set canvas pane to 100%
      const canvasPane = document.getElementById('canvas-pane');
      if (canvasPane) {
        canvasPane.style.flex = 1;
      }

      console.log('[RAW_MESSAGE_VIEWER] Hidden - canvas 100%');
      setTimeout(() => window.drawingViewer.handleResize(), 0);
    }
  }

  /**
   * Toggle viewer visibility
   */
  toggle() {
    if (this.isVisible) {
      this.hide();
    } else {
      this.show();
    }
  }

  /**
   * Export messages as JSON file
   */
  exportJSON() {
    const json = this.collector.exportAsJSON();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `pfod-messages-${new Date().toISOString().replace(/:/g, '-')}.json`;
    link.click();
    URL.revokeObjectURL(url);
    console.log('[RAW_MESSAGE_VIEWER] Exported as JSON');
  }

  /**
   * Export messages as CSV file
   */
  exportCSV() {
    const csv = this.collector.exportAsCSV();
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `pfod-messages-${new Date().toISOString().replace(/:/g, '-')}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    console.log('[RAW_MESSAGE_VIEWER] Exported as CSV');
  }

  /**
   * Export CSV data by field count (from CSVCollector)
   * Creates separate files for each field count format
   * Shows dialog to choose timestamp format
   */
  exportCSVByFieldCount() {
    const csvCollector = ConnectionManager.csvCollector;
    if (!csvCollector) {
      console.warn('[RAW_MESSAGE_VIEWER] CSV collector not available');
      return;
    }

    const fieldCounts = csvCollector.getFieldCounts();
    if (fieldCounts.length === 0) {
      console.warn('[RAW_MESSAGE_VIEWER] No CSV data collected');
      pfodAlert('No CSV data has been collected yet.\n\nCSV data appears after closing braces } or line breaks in the device communication.', () => {
        // onClose callback - alert will be dismissed when Close button is clicked
      });
      return;
    }

    // Always use default format (no timestamps)
    this.doExportCSVByFieldCount(csvCollector, fieldCounts, 'none');

    // Commented out: popup dialog to select export format
    // this.showExportFormatDialog((format) => {
    //   this.doExportCSVByFieldCount(csvCollector, fieldCounts, format);
    // });
  }

  /**
   * Show modal dialog to select CSV export format
   * @param {function} callback - Called with selected format: 'none', 'ms', 'z', 'local'
   */
  showExportFormatDialog(callback) {
    // Create modal overlay
    const overlay = document.createElement('div');
    overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      display: flex;
      align-items: flex-start;
      justify-content: center;
      padding-top: 150px;
      z-index: 10001;
    `;

    // Create modal box
    const modal = document.createElement('div');
    modal.style.cssText = `
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
      max-width: 500px;
      width: 90%;
      overflow: hidden;
    `;

    // Create title bar
    const titleBar = document.createElement('div');
    titleBar.style.cssText = `
      background-color: #4CAF50;
      color: white;
      padding: 15px 20px;
      font-size: 18px;
      font-weight: bold;
      font-family: Arial, sans-serif;
    `;
    titleBar.textContent = 'Export CSV Format';

    // Create content area
    const contentArea = document.createElement('div');
    contentArea.style.cssText = `
      padding: 20px;
      font-family: Arial, sans-serif;
      font-size: 14px;
      line-height: 1.6;
      color: #333;
    `;

    const title = document.createElement('div');
    title.style.cssText = `
      font-weight: bold;
      margin-bottom: 15px;
    `;
    title.textContent = 'Choose timestamp format for CSV export:';
    contentArea.appendChild(title);

    // Create radio button options
    const options = [
      { value: 'none', label: 'No Timestamps (default)', description: 'Just the CSV data' },
      { value: 'ms', label: 'With Milliseconds', description: 'ms,field1,field2... (epoch ms)' },
      { value: 'z', label: 'With UTC Z Timestamps', description: '2025-11-15T14:30:45.123Z,field1,field2...' },
      { value: 'local', label: 'With Local Time', description: '2025-11-15 14:30:45.123,field1,field2...' }
    ];

    let selectedValue = 'none';

    for (const option of options) {
      const label = document.createElement('label');
      label.style.cssText = `
        display: flex;
        align-items: flex-start;
        gap: 10px;
        margin-bottom: 12px;
        cursor: pointer;
      `;

      const radio = document.createElement('input');
      radio.type = 'radio';
      radio.name = 'csv-format';
      radio.value = option.value;
      radio.checked = option.value === 'none';
      radio.style.cssText = `
        margin-top: 3px;
        cursor: pointer;
      `;
      radio.addEventListener('change', (e) => {
        if (e.target.checked) selectedValue = option.value;
      });

      const textDiv = document.createElement('div');
      textDiv.style.cssText = `
        display: flex;
        flex-direction: column;
        gap: 3px;
      `;

      const labelText = document.createElement('div');
      labelText.style.cssText = `
        font-weight: 500;
      `;
      labelText.textContent = option.label;

      const descText = document.createElement('div');
      descText.style.cssText = `
        font-size: 12px;
        color: #666;
        font-family: monospace;
      `;
      descText.textContent = option.description;

      textDiv.appendChild(labelText);
      textDiv.appendChild(descText);
      label.appendChild(radio);
      label.appendChild(textDiv);
      contentArea.appendChild(label);
    }

    // Create button area
    const buttonArea = document.createElement('div');
    buttonArea.style.cssText = `
      padding: 0 20px 20px 20px;
      display: flex;
      gap: 10px;
      justify-content: center;
    `;

    const exportButton = document.createElement('button');
    exportButton.textContent = 'Export';
    exportButton.style.cssText = `
      background-color: #4CAF50;
      color: white;
      padding: 10px 30px;
      border: none;
      border-radius: 5px;
      font-size: 14px;
      font-weight: bold;
      cursor: pointer;
      font-family: Arial, sans-serif;
    `;
    exportButton.onclick = () => {
      document.body.removeChild(overlay);
      callback(selectedValue);
    };

    const cancelButton = document.createElement('button');
    cancelButton.textContent = 'Cancel';
    cancelButton.style.cssText = `
      background-color: #888;
      color: white;
      padding: 10px 30px;
      border: none;
      border-radius: 5px;
      font-size: 14px;
      font-weight: bold;
      cursor: pointer;
      font-family: Arial, sans-serif;
    `;
    cancelButton.onclick = () => {
      document.body.removeChild(overlay);
    };

    buttonArea.appendChild(exportButton);
    buttonArea.appendChild(cancelButton);

    // Assemble modal
    modal.appendChild(titleBar);
    modal.appendChild(contentArea);
    modal.appendChild(buttonArea);
    overlay.appendChild(modal);
    document.body.appendChild(overlay);

    // Focus export button
    setTimeout(() => exportButton.focus(), 100);
  }

  /**
   * Perform the actual CSV export with selected format
   * @param {CSVCollector} csvCollector - The CSV collector instance
   * @param {array} fieldCounts - Array of field counts to export
   * @param {string} format - Export format: 'none', 'ms', 'z', 'local'
   */
  doExportCSVByFieldCount(csvCollector, fieldCounts, format) {
    // Select export method based on format
    let exportMethod;
    let suffix = '';
    switch (format) {
      case 'ms':
        exportMethod = 'exportAsTextWithMs';
        suffix = '-with-ms';
        break;
      case 'z':
        exportMethod = 'exportAsTextWithZTimestamps';
        suffix = '-with-z-time';
        break;
      case 'local':
        exportMethod = 'exportAsTextWithLocalTimestamps';
        suffix = '-with-local-time';
        break;
      case 'none':
      default:
        exportMethod = 'exportAsText';
        suffix = '';
    }

    // Export each field count as separate file
    const timestamp = new Date().toISOString().replace(/:/g, '-');
    let exportedCount = 0;

    for (const fieldCount of fieldCounts) {
      const csvText = csvCollector[exportMethod](fieldCount);
      if (csvText.length > 0) {
        const blob = new Blob([csvText], { type: 'text/csv; charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `pfod-csv-${fieldCount}fields${suffix}-${timestamp}.csv`;
        link.click();
        URL.revokeObjectURL(url);
        exportedCount++;
        console.log(`[RAW_MESSAGE_VIEWER] Exported CSV file for ${fieldCount} fields with format=${format} (${csvCollector.getLineCount(fieldCount)} lines)`);
      }
    }

    console.log(`[RAW_MESSAGE_VIEWER] Exported ${exportedCount} CSV files with format=${format}`);
  }
}

/**
 * ChartConfigViewer - UI panel for chart field configuration.
 * Shares the side-panel container with RawMessageViewer.
 * Only one of the two views is visible at a time.
 *
 * Shows ALL CSV fields (from csvCollector) with editable title, plotNo, max, min,
 * and units. Apply rebuilds the chartInfo and re-displays the chart.
 */
class ChartConfigViewer {
  /**
   * @param {string} containerId - ID of the shared side-panel container
   */
  constructor(containerId = 'side-panel') {
    this.containerId = containerId;
    this.isVisible = false;
    console.log('[CHART_CONFIG_VIEWER] Created with container:', containerId);
  }

  /**
   * Initialize: create the shell structure (header + scrollable body) and append
   * to the shared container. Called after RawMessageViewer.initialize().
   */
  initialize() {
    const container = document.getElementById(this.containerId);
    if (!container) {
      console.error('[CHART_CONFIG_VIEWER] Container not found:', this.containerId);
      return;
    }

    const main = document.createElement('div');
    main.id = 'chart-config-viewer-main';
    main.style.cssText = `
      display: none;
      flex-direction: column;
      width: 100%;
      height: 100%;
      background-color: #ffffff;
      color: #333333;
      border: 1px solid #cccccc;
      box-sizing: border-box;
      font-family: Arial, sans-serif;
    `;

    // Title bar with close button
    const header = document.createElement('div');
    header.style.cssText = `
      flex-shrink: 0;
      background-color: #f0f0f0;
      border-bottom: 1px solid #cccccc;
      padding: 8px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-weight: bold;
      font-size: 14px;
      color: #333333;
    `;

    const titleSpan = document.createElement('span');
    titleSpan.textContent = 'Chart Configuration';

    const closeBtn = document.createElement('button');
    closeBtn.style.cssText = `
      background: none;
      border: none;
      color: #666666;
      font-size: 20px;
      cursor: pointer;
      padding: 0;
      width: 24px;
      height: 24px;
      display: flex;
      align-items: center;
      justify-content: center;
    `;
    closeBtn.textContent = '\u00d7';
    closeBtn.title = 'Close';
    closeBtn.addEventListener('click', () => this.hide());
    closeBtn.addEventListener('mouseover', () => { closeBtn.style.color = '#000000'; });
    closeBtn.addEventListener('mouseout', () => { closeBtn.style.color = '#666666'; });

    const datasetSelect = document.createElement('select');
    datasetSelect.id = 'ccv-dataset-select';
    datasetSelect.title = 'Select CSV dataset by field count';
    datasetSelect.style.cssText = `
      background: #ffffff;
      color: #333333;
      border: 1px solid #cccccc;
      border-radius: 3px;
      font-size: 11px;
      padding: 2px 4px;
      margin-right: 6px;
      cursor: pointer;
    `;
    datasetSelect.addEventListener('change', () => this._switchDataset(parseInt(datasetSelect.value)));

    header.appendChild(titleSpan);
    header.appendChild(datasetSelect);
    header.appendChild(closeBtn);
    main.appendChild(header);

    // Fixed action bar: Save / Load / Apply
    const actionBar = document.createElement('div');
    actionBar.style.cssText = `
      flex-shrink: 0;
      background-color: #f0f0f0;
      border-bottom: 1px solid #cccccc;
      padding: 6px 8px;
      display: flex;
      gap: 6px;
    `;
    const saveBtn = document.createElement('button');
    saveBtn.className = 'ccv-action-btn';
    saveBtn.id = 'ccv-save-btn';
    saveBtn.textContent = 'Save';
    saveBtn.title = 'Save config to browser storage';
    saveBtn.addEventListener('click', () => this._saveConfig());
    const loadBtn = document.createElement('button');
    loadBtn.className = 'ccv-action-btn';
    loadBtn.id = 'ccv-load-btn';
    loadBtn.textContent = 'Load';
    loadBtn.title = 'Load config from browser storage';
    loadBtn.addEventListener('click', () => this._loadConfig());
    actionBar.appendChild(saveBtn);
    actionBar.appendChild(loadBtn);
    main.appendChild(actionBar);

    // Scrollable body - populated by populate() each time show() is called
    const body = document.createElement('div');
    body.id = 'chart-config-body';
    body.style.cssText = `
      flex: 1;
      overflow-y: auto;
      background-color: #ffffff;
      padding: 8px;
      box-sizing: border-box;
    `;
    main.appendChild(body);

    // Inject shared CSS for form controls (once per page)
    if (!document.getElementById('ccv-styles')) {
      const style = document.createElement('style');
      style.id = 'ccv-styles';
      style.textContent = `
        .ccv-input {
          background-color: #ffffff;
          color: #333333;
          border: 1px solid #cccccc;
          border-radius: 3px;
          padding: 2px 4px;
          font-size: 12px;
          width: 100%;
          box-sizing: border-box;
        }
        .ccv-input:focus { outline: 1px solid #0e7acb; border-color: #0e7acb; }
        .ccv-label { font-size: 11px; color: #666666; margin-bottom: 2px; display: block; }
        .ccv-row2 { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; margin-bottom: 6px; }
        .ccv-row3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 4px; margin-bottom: 4px; }
        .ccv-field-block {
          background: #f8f8f8;
          border: 1px solid #dddddd;
          border-radius: 4px;
          padding: 6px;
          margin-bottom: 6px;
        }
        .ccv-field-hdr { font-size: 11px; margin-bottom: 5px; font-weight: bold; }
        .ccv-action-btn {
          flex: 1;
          background: #e8e8e8;
          color: #333333;
          border: 1px solid #bbbbbb;
          border-radius: 3px;
          padding: 5px 0;
          font-size: 12px;
          font-weight: bold;
          cursor: pointer;
        }
        .ccv-action-btn:hover { background: #d0d0d0; }
        .ccv-action-btn-primary { background: #0e7acb; color: #fff; border-color: #0e7acb; }
        .ccv-action-btn-primary:hover { background: #1a8de0; }
        .ccv-section-sep {
          border: none;
          border-top: 1px solid #cccccc;
          margin: 8px 0;
        }
      `;
      document.head.appendChild(style);
    }

    container.appendChild(main);
    console.log('[CHART_CONFIG_VIEWER] Initialized');
  }

  /**
   * Show the Chart Configuration view.
   * Hides raw-message-viewer-main, makes the panel visible, then populates the form.
   */
  show() {
    // Hide raw message viewer inner content - only one view at a time
    const rawMain = document.getElementById('raw-message-viewer-main');
    if (rawMain) {
      rawMain.style.display = 'none';
    }
    if (window.rawMessageViewer) {
      if (window.rawMessageViewer.animationFrameId) {
        cancelAnimationFrame(window.rawMessageViewer.animationFrameId);
        window.rawMessageViewer.animationFrameId = null;
      }
      window.rawMessageViewer.pendingMessages = [];
      window.rawMessageViewer.updateScheduled = false;
      window.rawMessageViewer.isVisible = false;
    }

    // Show chart config inner content
    const configMain = document.getElementById('chart-config-viewer-main');
    if (configMain) {
      configMain.style.display = 'flex';
    }

    // Show the shared container
    const container = document.getElementById(this.containerId);
    if (container) {
      container.style.display = 'flex';
      container.style.flexDirection = 'column';
      container.style.flex = 0.30;
    }

    // Show the divider
    const divider = document.getElementById('resize-divider');
    if (divider) {
      divider.style.display = 'block';
    }

    // Set canvas pane to 70%
    const canvasPane = document.getElementById('canvas-pane');
    if (canvasPane) {
      canvasPane.style.flex = 0.70;
    }

    // Populate form with current data
    this.populate();
    this.isVisible = true;
    console.log('[CHART_CONFIG_VIEWER] Shown');
    setTimeout(() => window.drawingViewer.handleResize(), 0);
  }

  /**
   * Hide the Chart Configuration view and collapse the side panel.
   */
  hide() {
    const configMain = document.getElementById('chart-config-viewer-main');
    if (configMain) {
      configMain.style.display = 'none';
    }

    const container = document.getElementById(this.containerId);
    if (container) {
      container.style.display = 'none';
      container.style.flex = 0;
    }

    const divider = document.getElementById('resize-divider');
    if (divider) {
      divider.style.display = 'none';
    }

    const canvasPane = document.getElementById('canvas-pane');
    if (canvasPane) {
      canvasPane.style.flex = 1;
    }

    this.isVisible = false;
    console.log('[CHART_CONFIG_VIEWER] Hidden');
    setTimeout(() => window.drawingViewer.handleResize(), 0);
  }

  /**
   * Toggle visibility of the Chart Configuration view.
   */
  toggle() {
    if (this.isVisible) {
      this.hide();
    } else {
      this.show();
    }
  }

  /**
   * Helper: create a labelled input wrapper and return the wrapper element.
   * The input element has the given id so _applyConfig() can find it by id.
   *
   * @param {string} id        - id attribute for the <input>
   * @param {string} labelText - visible label above the input
   * @param {string} type      - input type ('text' or 'number')
   * @param {string} value     - initial value (already a string)
   * @param {string} placeholder
   * @returns {HTMLElement} wrapper div
   */
  _makeInput(id, labelText, type, value, placeholder) {
    const wrap = document.createElement('div');
    const lbl = document.createElement('label');
    lbl.className = 'ccv-label';
    lbl.textContent = labelText;
    const inp = document.createElement('input');
    inp.className = 'ccv-input';
    inp.id = id;
    inp.type = type;
    inp.value = value;
    inp.placeholder = placeholder;
    wrap.appendChild(lbl);
    wrap.appendChild(inp);
    return wrap;
  }

  /**
   * Build a flat array (indexed by CSV column 0..csvFieldCount-1) of field specs,
   * merging what the last chartInfo knew about each field.
   * Fields not mentioned in chartInfo get default label/plotNo/max/min/unit.
   *
   * @param {object|null} chartInfo    - window.drawingViewer.currentChartInfo (may be null)
   * @param {number}      csvFieldCount - actual number of columns in CSV data
   * @returns {Array} - [{label, plotNo, max, min, unit, index}, ...]
   */
  _buildAllFieldSpecs(chartInfo, csvFieldCount) {
    // Start with defaults for every CSV column
    const result = [];
    for (let i = 0; i < csvFieldCount; i++) {
      result.push({ label: `field${i + 1}`, plotNo: null, max: null, min: null, unit: null, index: i, included: false });
    }

    // No chart loaded yet — return the default per-column specs so the config
    // viewer can still render (user opens Chart Config from a non-chart state
    // or before displayChartWithPlotNo has set drawingViewer.currentChartInfo).
    if (!chartInfo) return result;

    // Overlay X-axis field from chartInfo (plotNo = 0).
    // xAxisFieldIndex >= 0 means a CSV column is the X-axis (regardless of useCountFlag).
    const xIdx = chartInfo.xAxisFieldIndex;
    if (xIdx >= 0 && xIdx < csvFieldCount) {
      result[xIdx].label = chartInfo.xAxisFieldLabel || result[xIdx].label;
      result[xIdx].plotNo = 0;
      result[xIdx].included = true;
    }

    // Overlay Y-axis fields from subplots; never overwrite the X-axis slot.
    // Track auto-assignment counter for unassigned fields (subplot.plotNo === -1):
    // these fields had no explicit plotNo in the chart command, so assign them
    // sequential Y-field numbers (1, 2, 3...) matching the DEFAULT MODE auto-assignment.
    let autoYPlotNo = 0;
    for (const subplot of (chartInfo.subplots || [])) {
      for (const spec of (subplot.fieldSpecs || [])) {
        if (spec.index >= 0 && spec.index < csvFieldCount && spec.index !== xIdx) {
          autoYPlotNo++;
          result[spec.index] = {
            label: spec.label || `field${spec.index + 1}`,
            plotNo: spec.plotNo !== null && spec.plotNo !== undefined ? spec.plotNo : (subplot.plotNo === -1 ? autoYPlotNo : subplot.plotNo),
            max: spec.max !== null && spec.max !== undefined ? spec.max : null,
            min: spec.min !== null && spec.min !== undefined ? spec.min : null,
            unit: spec.unit || null,
            index: spec.index,
            included: true
          };
        }
      }
    }

    return result;
  }

  /**
   * Apply a raw plot command string directly (e.g. from a URL ?chart= param).
   * Parses the command and re-displays the chart without reading the form.
   * @param {string} cmdStr - e.g. "{=Chart`500|field1`1}"
   */
  applyChartCommand(cmdStr) {
    const cmdArray = this._parsePlotCommand(cmdStr);
    const newChartInfo = window.chartDisplay
      ? window.chartDisplay.parseChartLabelsWithPlotNo(cmdArray)
      : null;
    if (newChartInfo && window.drawingViewer) {
      window.currentChartInfo = newChartInfo;
      window.drawingViewer.displayChartWithPlotNo();
    }
  }

  /**
   * Build a plot command from the form, parse it, and re-display the chart.
   * Going through the plot command path ensures the same field count and
   * column mapping as if the command had been received from the device.
   * Called by the Apply button.
   */
  /**
   * Schedule _applyConfig() after a delay (ms). Resets the timer on every call
   * so rapid input only triggers one apply. Cancelled automatically when
   * _applyConfig() is called directly (blur, Enter, dropdown change).
   */
  _scheduleApply(delay = 5000) {
    clearTimeout(this._applyTimer);
    this._applyTimer = setTimeout(() => {
      this._applyTimer = null;
      this._applyConfig();
    }, delay);
  }

  _applyConfig() {
    clearTimeout(this._applyTimer);
    this._applyTimer = null;
    const { cmd } = this._buildPlotCommand();
    const cmdArray = this._parsePlotCommand(cmd);
    const newChartInfo = window.chartDisplay
      ? window.chartDisplay.parseChartLabelsWithPlotNo(cmdArray)
      : null;
    if (newChartInfo && window.drawingViewer) {
      // Stamp per-field autoScale from the form checkboxes onto the parsed
      // fieldSpecs. autoScale=false means the field opts in to hard constraints
      // when Apply is pressed; autoScale=true (default / unchecked) keeps the
      // axis soft regardless. This state is not saved in the plot command.
      for (const subplot of (newChartInfo.subplots || [])) {
        for (const fieldSpec of (subplot.fieldSpecs || [])) {
          const el = document.getElementById(`ccv-f-autoscale-${fieldSpec.index}`);
          fieldSpec.autoScale = el ? el.checked : true;
        }
      }

      // If frozen and maxPoints changed, keep the current center row constant:
      // center = frozenStartRow + oldMaxPoints/2  =>  newStartRow = center - newMaxPoints/2
      // Must read window.currentChartInfo (the OLD value) before overwriting it below.
      if (window.chartDisplay && window.chartDisplay.frozenStartRow !== null) {
        const oldMaxPoints = window.currentChartInfo.maxPoints;
        const newMaxPoints = newChartInfo.maxPoints;
        if (oldMaxPoints !== newMaxPoints) {
          const before = window.chartDisplay.frozenStartRow;
          const center = window.chartDisplay.frozenStartRow + Math.floor(oldMaxPoints / 2);
          window.chartDisplay.frozenStartRow = Math.max(0, Math.round(center - newMaxPoints / 2));
          console.error('[FREEZE_DBG] _applyConfig recenter: oldMaxPoints=', oldMaxPoints,
            'newMaxPoints=', newMaxPoints, 'frozenStartRow', before, '->', window.chartDisplay.frozenStartRow);
        }
      }
      window.currentChartInfo = newChartInfo;
      window.drawingViewer.displayChartWithPlotNo();
      // Update the URL ?chart= param so the user can bookmark this config
      const urlParams = new URLSearchParams(window.location.search);
      urlParams.set('chart', cmd);
      history.replaceState(null, '', '?' + urlParams.toString());
    }
  }

  /**
   * Read all form inputs and build a pfod plot command string.
   * Excluded fields use empty labels to preserve CSV column positions.
   * Format: {=title`maxPoints~timeFormat|field1spec|field2spec...}
   *
   * @returns {{cmd: string, filename: string}} - plot command string and suggested filename
   */
  _buildPlotCommand() {
    const chartInfo = window.currentChartInfo;
    // Use the field count of the currently displayed chart — matches the form rows shown.
    const formFieldCount = chartInfo ? chartInfo.fieldCount : 0;

    const titleEl   = document.getElementById('ccv-title');
    const maxPtsEl  = document.getElementById('ccv-maxpoints');
    const timeFmtEl = document.getElementById('ccv-timeformat');

    const title      = titleEl   ? titleEl.value.trim()   : 'Chart';
    const maxPtsRaw  = maxPtsEl  ? maxPtsEl.value.trim() : '';
    const maxPtsVal  = parseInt(maxPtsRaw);
    const totalCsvLines = (window.csvCollector && chartInfo && window.csvCollector.getFieldCounts().includes(chartInfo.fieldCount))
      ? window.csvCollector.getLineCount(chartInfo.fieldCount) : 500;
    const maxPoints  = (maxPtsRaw === '' || isNaN(maxPtsVal)) ? totalCsvLines : maxPtsVal;
    const timeFormat = timeFmtEl ? timeFmtEl.value.trim() : '';

    // Build first element: =title`maxPoints[~timeFormat][~C][~S]
    // Preserve ~C (clear) / ~S (sort) plot-option flags from the current chartInfo
    // since the form has no checkbox for them yet — without this, every Apply
    // strips the flags and the chart loses its sort/clear behaviour.
    let firstElem = `=${title}\`${maxPoints}`;
    if (timeFormat.length > 0) firstElem += `~${timeFormat}`;
    if (chartInfo && chartInfo.clearData) firstElem += '~C';
    if (chartInfo && chartInfo.sortData)  firstElem += '~S';

    // Build one pipe element per form field row
    const fieldParts = [];
    for (let i = 0; i < formFieldCount; i++) {
      const inclEl    = document.getElementById(`ccv-f-incl-${i}`);
      const titleFEl  = document.getElementById(`ccv-f-title-${i}`);
      const plotNoEl  = document.getElementById(`ccv-f-plotno-${i}`);
      const maxEl     = document.getElementById(`ccv-f-max-${i}`);
      const minEl     = document.getElementById(`ccv-f-min-${i}`);
      const unitEl    = document.getElementById(`ccv-f-unit-${i}`);

      const included  = inclEl ? inclEl.checked : true;
      if (!included) {
        fieldParts.push('');
        continue;
      }

      const label     = titleFEl  ? titleFEl.value.trim()   : `field${i + 1}`;
      const plotNoStr = plotNoEl  ? plotNoEl.value.trim()   : '';
      const plotNo    = plotNoStr === '' ? null : parseInt(plotNoStr);
      let maxStr    = maxEl     ? maxEl.value.trim()      : '';
      let minStr    = minEl     ? minEl.value.trim()      : '';
      const unit      = unitEl    ? unitEl.value.trim()     : '';

      // If both max and min are numbers and max < min, swap them and update the form
      const maxNum = parseFloat(maxStr);
      const minNum = parseFloat(minStr);
      if (maxStr !== '' && minStr !== '' && !isNaN(maxNum) && !isNaN(minNum) && maxNum < minNum) {
        if (maxEl) maxEl.value = minStr;
        if (minEl) minEl.value = maxStr;
        const tmp = maxStr; maxStr = minStr; minStr = tmp;
      }

      let spec = label;
      if (plotNo !== null && !isNaN(plotNo)) spec += '`' + plotNo;

      const hasMax  = maxStr !== '';
      const hasMin  = minStr !== '';
      const hasUnit = unit   !== '';
      if (hasMax || hasMin || hasUnit) {
        spec += '~' + maxStr;
        if (hasMin || hasUnit) {
          spec += '~' + minStr;
          if (hasUnit) spec += '~' + unit;
        }
      }
      fieldParts.push(spec);
    }

    const cmd      = '{' + firstElem + '|' + fieldParts.join('|') + '}';
    const filename = title.replace(/[^a-zA-Z0-9]/g, '_') + '.' + formFieldCount + 'fields';
    return { cmd, filename };
  }

  /**
   * Save the current chart configuration as a pfod plot command file.
   * The filename is the chart title with non-alphanumeric characters replaced by _.
   */
  _saveConfig() {
    // Apply first so any max/min swap is done and the chart matches what is saved
    this._applyConfig();
    const { cmd, filename } = this._buildPlotCommand();
    const blob = new Blob([cmd], { type: 'text/plain' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  /**
   * Parse a pfod plot command string into the cmdArray format expected by
   * window.chartDisplay.parseChartLabelsWithPlotNo().
   * Strips outer { } then splits on |, re-prefixing | on each field element.
   *
   * @param {string} cmdStr - e.g. "{=TestChart`50~ss.SSS|time`0|temp`1~100~0~C}"
   * @returns {Array} cmdArray - e.g. ["=TestChart`50~ss.SSS", "|time`0", "|temp`1~100~0~C"]
   */
  _parsePlotCommand(cmdStr) {
    let content = cmdStr.trim();
    if (content.startsWith('{')) content = content.substring(1);
    if (content.endsWith('}'))  content = content.slice(0, -1);

    const parts    = content.split('|');
    const cmdArray = [parts[0]];
    for (let i = 1; i < parts.length; i++) {
      cmdArray.push('|' + parts[i]);
    }
    return cmdArray;
  }

  /**
   * Open a file picker for .pfod files, read the selected file,
   * parse the pfod plot command, and re-populate the form.
   */

  /**
   * Switch to a different CSV dataset by field count.
   * If the current chartInfo already matches, just re-populate the form.
   * Otherwise generate a default plot command for that field count, display it, and populate.
   *
   * @param {number} fieldCount - The field count of the target dataset
   */
  _switchDataset(fieldCount) {
    const currentInfo = window.currentChartInfo;
    if (currentInfo && currentInfo.fieldCount === fieldCount) {
      this.populate();
      return;
    }
    // Build a default plot command: field1 = X-axis (plotNo 0), remaining = subplot 1
    let cmd = '{=Chart`500|field1`0';
    for (let i = 2; i <= fieldCount; i++) {
      cmd += '|field' + i + '`1';
    }
    cmd += '}';
    const cmdArray = this._parsePlotCommand(cmd);
    const newChartInfo = window.chartDisplay
      ? window.chartDisplay.parseChartLabelsWithPlotNo(cmdArray)
      : null;
    if (newChartInfo) {
      window.currentChartInfo = newChartInfo;
      window.drawingViewer.displayChartWithPlotNo();
    }
    this.populate();
  }

  _loadConfig() {
    const chartInfo     = window.currentChartInfo;
    const fieldCount    = chartInfo ? chartInfo.fieldCount : 0;
    const acceptExt     = fieldCount > 0 ? ('.' + fieldCount + 'fields') : '.fields';

    const input  = document.createElement('input');
    input.type   = 'file';
    input.accept = acceptExt;
    input.addEventListener('change', () => {
      const file = input.files[0];
      if (!file) throw new Error('[messageViewer] file input change: no file selected');
      const reader = new FileReader();
      reader.onload = (e) => {
        const cmdStr   = e.target.result.trim();
        const cmdArray = this._parsePlotCommand(cmdStr);
        const loadedChartInfo = window.chartDisplay
          ? window.chartDisplay.parseChartLabelsWithPlotNo(cmdArray)
          : null;
        if (loadedChartInfo) {
          window.currentChartInfo = loadedChartInfo;
          this.populate();
          // Apply via _applyConfig so max/min swap is performed and URL is updated
          this._applyConfig();
        } else {
          console.warn('[CHART_CONFIG_VIEWER] Failed to parse loaded plot command');
          alert('Failed to load chart configuration: the file is not a valid pfod chart config.');
        }
      };
      reader.readAsText(file);
    });
    input.click();
  }

  /**
   * Populate the body with editable form fields.
   * Field count is taken from csvCollector (actual data), not from the last plot command.
   * Chart-level settings (title, maxPoints, timeFormat) are taken from
   * window.currentChartInfo — the single holder for the currently displayed chart.
   */
  populate() {
    const body = document.getElementById('chart-config-body');
    if (!body) {
      console.error('[CHART_CONFIG_VIEWER] Body element not found');
      return;
    }

    // Snapshot autoScale checkbox states before rebuilding DOM so Apply / live
    // chart refresh don't reset them. Map: field index → boolean.
    const savedAutoScale = {};
    body.querySelectorAll('input[id^="ccv-f-autoscale-"]').forEach(el => {
      const idx = el.id.replace('ccv-f-autoscale-', '');
      savedAutoScale[idx] = el.checked;
    });

    // Save focused element so blur-triggered rebuilds don't lose cursor position.
    const activeId = document.activeElement ? document.activeElement.id : null;
    const selStart = document.activeElement ? document.activeElement.selectionStart : null;
    const selEnd   = document.activeElement ? document.activeElement.selectionEnd   : null;

    // Determine field count from actual CSV data
    const fieldCounts = window.csvCollector ? window.csvCollector.getFieldCounts() : [];
    const csvFieldCount = fieldCounts.length > 0
      ? Math.max(...fieldCounts.map(f => parseInt(f)))
      : 0;

    const setActionBtns = (enabled) => {
      ['ccv-save-btn', 'ccv-load-btn'].forEach(id => {
        const btn = document.getElementById(id);
        if (btn) { btn.disabled = !enabled; btn.style.opacity = enabled ? '' : '0.4'; }
      });
    };
    if (csvFieldCount === 0) {
      setActionBtns(false);
      body.innerHTML = '<div style="padding:12px;color:#666666;font-size:13px;">No CSV data available.<br>Connect to a device and receive data first.<br>Close and reopen Chart Configuration when data is available.</div>';
      return;
    }
    setActionBtns(true);

    // Update dataset dropdown with all available field counts
    const datasetSelect = document.getElementById('ccv-dataset-select');
    if (datasetSelect) {
      const allFieldCounts = window.csvCollector ? window.csvCollector.getFieldCounts() : [];
      datasetSelect.innerHTML = '';
      for (const fc of allFieldCounts) {
        const opt = document.createElement('option');
        opt.value = String(fc);
        opt.textContent = fc + ' fields';
        datasetSelect.appendChild(opt);
      }
    }

    const chartInfo = window.currentChartInfo;
    console.log('[CHART_CONFIG_VIEWER] populate: title=', chartInfo ? chartInfo.title : 'null');
    const displayFieldCount = chartInfo ? chartInfo.fieldCount : 0;
    const totalLines = (window.csvCollector && displayFieldCount > 0 && window.csvCollector.getFieldCounts().includes(displayFieldCount))
      ? window.csvCollector.getLineCount(displayFieldCount) : 0;

    // Set dropdown to the current dataset's field count
    if (datasetSelect && displayFieldCount > 0) datasetSelect.value = String(displayFieldCount);

    // Build per-field color map matching the chart plot line colors.
    // Colors are assigned per-subplot: subplot series 0 = index 0, series 1 = index 1, etc.
    // Must stay in sync with the colors array in chartDisplay.js (black removed).
    const PLOT_LINE_COLORS = [
      '#0000FF',  // Blue
      '#FF0000',  // Red
      '#008000',  // Green
      '#FF8000',  // Orange
      '#800080',  // Purple
      '#008080',  // Teal
      '#FF69B4',  // Hot Pink (chart uses #FFC0CB, darkened for white bg)
      '#A52A2A',  // Brown
      '#FF7F50',  // Coral
      '#B8860B',  // Dark Goldenrod (chart uses #FFFF00, darkened for white bg)
    ];
    const fieldColors = {};
    if (chartInfo) {
      if (chartInfo.xAxisFieldIndex >= 0) {
        fieldColors[chartInfo.xAxisFieldIndex] = '#000000';
      }
      for (const subplot of (chartInfo.subplots || [])) {
        for (const spec of (subplot.fieldSpecs || [])) {
          fieldColors[spec.index] = PLOT_LINE_COLORS[spec.index % PLOT_LINE_COLORS.length];
        }
      }
    }
    const allFieldSpecs = this._buildAllFieldSpecs(chartInfo, displayFieldCount);

    // Clear previous content
    body.innerHTML = '';

    // --- Chart-level settings ---
    const section = document.createElement('div');

    const row1 = document.createElement('div');
    row1.className = 'ccv-row2';
    row1.appendChild(this._makeInput('ccv-title', 'Screen Title', 'text',
      chartInfo ? (chartInfo.title || '') : '', 'Chart title'));
    // Display Points field with side-by-side ▲/▼ buttons, each the full height of the input
    const maxPtsWrap = document.createElement('div');
    maxPtsWrap.className = 'ccv-field-wrap';
    const maxPtsLbl = document.createElement('label');
    maxPtsLbl.className = 'ccv-label';
    maxPtsLbl.textContent = 'Display Points of ' + totalLines;
    maxPtsLbl.id = 'ccv-maxpoints-label';
    const maxPtsInner = document.createElement('div');
    maxPtsInner.style.cssText = 'display:flex;align-items:stretch;';
    const maxPtsInp = document.createElement('input');
    maxPtsInp.className = 'ccv-input';
    maxPtsInp.id = 'ccv-maxpoints';
    maxPtsInp.type = 'number';
    maxPtsInp.value = String(chartInfo ? (chartInfo.maxPoints || 500) : 500);
    maxPtsInp.placeholder = String(totalLines);
    maxPtsInp.style.flex = '1';
    const makeArrow = (symbol, factor) => {
      const btn = document.createElement('button');
      btn.textContent = symbol;
      btn.style.cssText = 'padding:0 7px;cursor:pointer;border:1px solid #aaa;border-left:none;background:#f0f0f0;font-size:12px;line-height:1;';
      btn.type = 'button';
      btn.addEventListener('click', () => {
        const inp = document.getElementById('ccv-maxpoints');
        if (!inp) throw new Error('[messageViewer] makeArrow: #ccv-maxpoints not found');
        const cur = parseInt(inp.value);
        const next = Math.max(1, isNaN(cur) ? 500 : Math.round(cur * factor));
        inp.value = String(next);
        this._applyConfig();
      });
      return btn;
    };
    maxPtsInner.appendChild(maxPtsInp);
    maxPtsInner.appendChild(makeArrow('▲', 2));
    maxPtsInner.appendChild(makeArrow('▼', 0.5));
    maxPtsWrap.appendChild(maxPtsLbl);
    maxPtsWrap.appendChild(maxPtsInner);
    row1.appendChild(maxPtsWrap);

    section.appendChild(row1);

    // X-axis format dropdown
    const timeFmtWrap = document.createElement('div');
    timeFmtWrap.className = 'ccv-field-wrap';
    timeFmtWrap.style.marginBottom = '6px';
    const timeFmtLbl = document.createElement('label');
    timeFmtLbl.className = 'ccv-label';
    timeFmtLbl.textContent = 'X-axis Format';
    const timeFmtSel = document.createElement('select');
    timeFmtSel.className = 'ccv-input';
    timeFmtSel.id = 'ccv-timeformat';
    timeFmtSel.style.cursor = 'pointer';
    const timeFmtOptions = [
      { value: '',             label: '' },
      { value: 'ss.S',         label: 'secs (ss.S)' },
      { value: 'mm:ss',        label: 'mins:sec (mm:ss)' },
      { value: 'HH:mm:ss',     label: 'hr:mins:sec (HH:mm:ss)' },
      { value: 'unix-dt',      label: 'Year Month Day Hr:Mins:sec' },
      { value: 'unix-ddd-hm',  label: 'weekday hr:mins' },
      { value: 'unix-ddd-hms', label: 'weekday hr:mins:sec' }
    ];
    const currentTimeFmt = chartInfo ? (chartInfo.timeFormat || '') : '';

    // If the current format isn't one of the presets (e.g. a SimpleDateFormat
    // pattern like "E MMM/dd HH:mm UTC" sent by the device), preserve it as a
    // custom option so it round-trips through Apply unchanged.
    const isPreset = timeFmtOptions.some(o => o.value === currentTimeFmt);
    if (!isPreset && currentTimeFmt !== '') {
      const customOpt = document.createElement('option');
      customOpt.value = currentTimeFmt;
      customOpt.textContent = currentTimeFmt + '  (current)';
      timeFmtSel.appendChild(customOpt);
    }
    for (const opt of timeFmtOptions) {
      const el = document.createElement('option');
      el.value = opt.value;
      el.textContent = opt.label;
      timeFmtSel.appendChild(el);
    }
    timeFmtSel.value = currentTimeFmt;
    timeFmtWrap.appendChild(timeFmtLbl);
    timeFmtWrap.appendChild(timeFmtSel);
    section.appendChild(timeFmtWrap);

    const sep = document.createElement('hr');
    sep.className = 'ccv-section-sep';
    section.appendChild(sep);

    // Hint line

    body.appendChild(section);

    // --- One block per CSV field ---
    for (let i = 0; i < allFieldSpecs.length; i++) {
      const spec = allFieldSpecs[i];
      const block = document.createElement('div');
      block.className = 'ccv-field-block';

      const hdr = document.createElement('div');
      hdr.className = 'ccv-field-hdr';
      const fieldColor = fieldColors[i] || '#333333';
      const isXAxis = chartInfo && chartInfo.xAxisFieldIndex === i;
      // White pill background for checkbox + label
      const chkWrap = document.createElement('span');
      chkWrap.style.cssText = 'display:inline-flex;align-items:center;background:#ffffff;border-radius:4px;padding:2px 6px;border:1px solid #ccc;';
      const chk = document.createElement('input');
      chk.type = 'checkbox';
      chk.id = `ccv-f-incl-${i}`;
      chk.checked = spec.included;
      chk.style.cssText = `margin-right:6px;cursor:pointer;vertical-align:middle;accent-color:${fieldColor};`;
      const chkLbl = document.createElement('label');
      chkLbl.htmlFor = `ccv-f-incl-${i}`;
      chkLbl.textContent = `CSV column ${i + 1}` + (isXAxis ? ' (X-Axis)' : '');
      chkLbl.style.cursor = 'pointer';
      chkLbl.style.color = fieldColor;
      chkLbl.style.fontWeight = 'bold';
      chkWrap.appendChild(chk);
      chkWrap.appendChild(chkLbl);
      hdr.appendChild(chkWrap);

      // autoScale checkbox: ticked (default) = axis expands beyond max/min;
      // unticked = axis fixed at max/min values. Not saved/loaded.
      const autoScaleWrap = document.createElement('span');
      autoScaleWrap.style.cssText = 'display:inline-flex;align-items:center;background:#ffffff;border-radius:4px;padding:2px 6px;border:1px solid #ccc;margin-left:8px;';
      const autoScaleChk = document.createElement('input');
      autoScaleChk.type = 'checkbox';
      autoScaleChk.id = `ccv-f-autoscale-${i}`;
      autoScaleChk.checked = true;
      autoScaleChk.disabled = isXAxis;
      autoScaleChk.style.cssText = `margin-right:6px;cursor:${isXAxis ? 'default' : 'pointer'};vertical-align:middle;${isXAxis ? 'opacity:0.4;' : ''}`;
      const autoScaleLbl = document.createElement('label');
      autoScaleLbl.htmlFor = `ccv-f-autoscale-${i}`;
      autoScaleLbl.textContent = 'autoScale';
      autoScaleLbl.style.cursor = isXAxis ? 'default' : 'pointer';
      autoScaleLbl.style.opacity = isXAxis ? '0.4' : '';
      autoScaleWrap.appendChild(autoScaleChk);
      autoScaleWrap.appendChild(autoScaleLbl);
      autoScaleChk.addEventListener('change', () => {
        syncPlotSiblings(i, 'autoscale');
        this._applyConfig();
      });
      hdr.appendChild(autoScaleWrap);

      block.appendChild(hdr);

      // Row: Title + Plot No
      const row1f = document.createElement('div');
      row1f.className = 'ccv-row2';
      row1f.appendChild(this._makeInput(`ccv-f-title-${i}`, 'Title', 'text',
        spec.label, `field${i + 1}`));
      // Plot No dropdown: X-Axis (0) then 1..displayFieldCount
      // For single-field charts, count is always the X-axis — only offer plotNo 1, no X-Axis option.
      const plotNoWrap = document.createElement('div');
      plotNoWrap.className = 'ccv-field-wrap';
      const plotNoLbl = document.createElement('label');
      plotNoLbl.className = 'ccv-label';
      plotNoLbl.textContent = 'Plot No';
      const plotNoSel = document.createElement('select');
      plotNoSel.className = 'ccv-input';
      plotNoSel.id = `ccv-f-plotno-${i}`;
      plotNoSel.style.cursor = 'pointer';
      if (displayFieldCount > 1) {
        // X-Axis option
        const optX = document.createElement('option');
        optX.value = '0';
        optX.textContent = '0 X-Axis';
        plotNoSel.appendChild(optX);
      }
      for (let pn = 1; pn <= displayFieldCount; pn++) {
        const opt = document.createElement('option');
        opt.value = String(pn);
        opt.textContent = String(pn);
        plotNoSel.appendChild(opt);
      }
      // Single-field: always plotNo=1; multi-field: use auto-assigned spec value.
      // _buildAllFieldSpecs guarantees non-null plotNo for included fields (auto-assigned
      // from subplot position when no explicit plotNo was in the chart command).
      const currentPlotNo = displayFieldCount === 1 ? 1 : Math.max(0, spec.plotNo ?? 1);
      plotNoSel.value = String(currentPlotNo);
      // Disable Plot No when only one field — Count is used as X-axis automatically
      if (displayFieldCount === 1) {
        plotNoSel.disabled = true;
        plotNoSel.style.opacity = '0.4';
        plotNoSel.style.cursor = 'default';
      }
      plotNoWrap.appendChild(plotNoLbl);
      plotNoWrap.appendChild(plotNoSel);
      row1f.appendChild(plotNoWrap);
      block.appendChild(row1f);

      // Row: Max + Min + Units
      const row2f = document.createElement('div');
      row2f.className = 'ccv-row3';
      const maxWrap  = this._makeInput(`ccv-f-max-${i}`, 'Max', 'number',
        spec.max !== null ? String(spec.max) : '', 'auto');
      const minWrap  = this._makeInput(`ccv-f-min-${i}`, 'Min', 'number',
        spec.min !== null ? String(spec.min) : '', 'auto');
      const unitWrap = this._makeInput(`ccv-f-unit-${i}`, 'Units', 'text',
        spec.unit || '', 'units');
      if (isXAxis) {
        [maxWrap, minWrap, unitWrap].forEach(w => {
          const inp = w.querySelector('input');
          if (inp) { inp.disabled = true; inp.style.opacity = '0.4'; inp.style.cursor = 'default'; }
        });
      }
      row2f.appendChild(maxWrap);
      row2f.appendChild(minWrap);
      row2f.appendChild(unitWrap);
      block.appendChild(row2f);

      // Toggle input fields disabled state when checkbox changes
      const setRowsEnabled = (enabled) => {
        [row1f, row2f].forEach(row => {
          row.querySelectorAll('input, select').forEach(inp => {
            inp.disabled = !enabled;
            inp.style.opacity = enabled ? '' : '0.4';
          });
        });
      };
      chk.addEventListener('change', () => setRowsEnabled(chk.checked));
      if (!spec.included) setRowsEnabled(false);

      body.appendChild(block);
    }

    // Restore autoScale checkbox states saved before DOM rebuild
    Object.keys(savedAutoScale).forEach(idx => {
      const el = document.getElementById(`ccv-f-autoscale-${idx}`);
      if (el) el.checked = savedAutoScale[idx];
    });

    // Wire live-apply listeners to all rebuilt inputs.
    // Validation helper: red border on max/min fields when value is non-numeric.
    const markValidity = (inp) => {
      const empty = inp.value.trim() === '';
      const valid = empty || !isNaN(parseFloat(inp.value));
      inp.style.borderColor = valid ? '' : 'red';
    };

    // Fields sharing a Plot No share one Y-axis (chartDisplay.js combines
    // their max/min into max(max's)/min(min's) when drawing it), so per-field
    // divergence in the form is confusing. Propagate autoScale/max/min/unit
    // from the edited field to every other field currently on the same plot.
    // Called before _applyConfig() so the same apply pass picks up the
    // synced sibling values.
    const syncPlotSiblings = (sourceIndex, kind) => {
      const plotNoSel = document.getElementById(`ccv-f-plotno-${sourceIndex}`);
      const src = document.getElementById(`ccv-f-${kind}-${sourceIndex}`);
      if (!plotNoSel || !src) return;
      for (let j = 0; j < displayFieldCount; j++) {
        if (j === sourceIndex) continue;
        const siblingPlotNoSel = document.getElementById(`ccv-f-plotno-${j}`);
        if (!siblingPlotNoSel || siblingPlotNoSel.value !== plotNoSel.value) continue;
        const dst = document.getElementById(`ccv-f-${kind}-${j}`);
        if (!dst) continue;
        if (kind === 'autoscale') dst.checked = src.checked;
        else dst.value = src.value;
      }
    };

    // One-time cleanup pass: the fields were just populated as-is from the
    // chart command / loaded config, which can disagree within a Plot No
    // group (e.g. a {=...} message or saved file specifying different
    // max/min/unit per field on the same plot). Reconcile each group once
    // here, then syncPlotSiblings (above) keeps them in lockstep from here
    // on as the user edits.
    const plotGroups = {};
    for (let i = 0; i < displayFieldCount; i++) {
      const plotNoSel = document.getElementById(`ccv-f-plotno-${i}`);
      if (!plotNoSel || plotNoSel.value === '0') continue; // X-axis is never shared
      (plotGroups[plotNoSel.value] = plotGroups[plotNoSel.value] || []).push(i);
    }
    for (const indices of Object.values(plotGroups)) {
      if (indices.length < 2) continue;
      const first = indices[0];

      // autoScale: matches chartDisplay.js's subplotAllAutoScale — ANY field
      // set to hard (unticked) already makes the whole shared axis hard.
      const anyHard = indices.some(idx => {
        const el = document.getElementById(`ccv-f-autoscale-${idx}`);
        return el && !el.checked;
      });
      const firstAuto = document.getElementById(`ccv-f-autoscale-${first}`);
      if (firstAuto) firstAuto.checked = !anyHard;
      syncPlotSiblings(first, 'autoscale');

      // max/min: combine the same way chartDisplay.js does when drawing the axis.
      let combinedMax = null, combinedMin = null;
      for (const idx of indices) {
        const maxEl = document.getElementById(`ccv-f-max-${idx}`);
        const minEl = document.getElementById(`ccv-f-min-${idx}`);
        if (maxEl && maxEl.value.trim() !== '' && !isNaN(parseFloat(maxEl.value))) {
          const v = parseFloat(maxEl.value);
          combinedMax = combinedMax === null ? v : Math.max(combinedMax, v);
        }
        if (minEl && minEl.value.trim() !== '' && !isNaN(parseFloat(minEl.value))) {
          const v = parseFloat(minEl.value);
          combinedMin = combinedMin === null ? v : Math.min(combinedMin, v);
        }
      }
      const firstMax = document.getElementById(`ccv-f-max-${first}`);
      const firstMin = document.getElementById(`ccv-f-min-${first}`);
      if (firstMax && combinedMax !== null) firstMax.value = String(combinedMax);
      if (firstMin && combinedMin !== null) firstMin.value = String(combinedMin);
      syncPlotSiblings(first, 'max');
      syncPlotSiblings(first, 'min');

      // unit: first non-empty value found in the group.
      const firstUnit = document.getElementById(`ccv-f-unit-${first}`);
      if (firstUnit && firstUnit.value.trim() === '') {
        const otherUnit = indices
          .map(idx => document.getElementById(`ccv-f-unit-${idx}`))
          .find(el => el && el.value.trim() !== '');
        if (otherUnit) firstUnit.value = otherUnit.value;
      }
      syncPlotSiblings(first, 'unit');
    }

    body.querySelectorAll('input[type="text"], input[type="number"]').forEach(inp => {
      const isMaxMin = inp.id.startsWith('ccv-f-max-') || inp.id.startsWith('ccv-f-min-');
      if (isMaxMin) inp.addEventListener('input', () => markValidity(inp));
      inp.addEventListener('blur', (e) => {
        if (isMaxMin) markValidity(inp);
        const m = inp.id.match(/^ccv-f-(max|min|unit)-(\d+)$/);
        if (m) syncPlotSiblings(parseInt(m[2], 10), m[1]);
        // If focus is moving to an autoScale checkbox (user clicked it while
        // this field was active), skip the apply here. The checkbox's own
        // change listener calls _applyConfig() after the click completes,
        // with the correct toggled state already set on the element.
        // Applying here would rebuild the DOM mid-click, replacing the
        // checkbox and swallowing the change event.
        const rt = e.relatedTarget;
        if (rt && rt.id && rt.id.startsWith('ccv-f-autoscale-')) return;
        this._applyConfig();
      });
      inp.addEventListener('keydown', e => { if (e.key === 'Enter') inp.blur(); });
      inp.addEventListener('input', () => this._scheduleApply(5000));
    });

    body.querySelectorAll('select').forEach(sel => {
      sel.addEventListener('change', () => this._applyConfig());
    });

    body.querySelectorAll('input[type="checkbox"]').forEach(chk => {
      if (!chk.id.startsWith('ccv-f-autoscale-')) {
        chk.addEventListener('change', () => this._applyConfig());
      }
    });

    // Restore focus and cursor position after DOM rebuild (e.g. triggered by blur-apply)
    if (activeId && activeId.startsWith('ccv-')) {
      const el = document.getElementById(activeId);
      if (el) {
        el.focus();
        if (selStart !== null && el.setSelectionRange) el.setSelectionRange(selStart, selEnd);
      }
    }
  }
}

// Make classes available globally
window.MessageCollector = MessageCollector;
window.RawMessageViewer = RawMessageViewer;
window.ChartConfigViewer = ChartConfigViewer;
/*   
   DrawingManager.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// DrawingManager — centralized per-drawing data store: items, touchZones, touchActions,
// metadata, and the ordered drawings array for inserted-drawing support.
//
// Exports:    window.DrawingManager class
// Depends on: nothing (standalone, no external dependencies)
// Called by:  redraw.js (has its own this.redrawDrawingManager instance — the
//                        single live drawing-state instance for the viewer),
//             drawingMerger.js (reads all drawing collections),
//             drawingDataProcessor.js (populates collections)



class DrawingManager {
    constructor() {
        // Per-drawing RAW collections — these are the merger's INPUTS, where
        // drawingDataProcessor lands incoming items.  Last-received-wins
        // semantics for unindexed are enforced by addUnindexedLastWins below;
        // keyed maps (indexed by idx, touchZones/touchActions/touchActionInputs
        // by cmd) accumulate per-key-assign naturally.
        this.touchZonesByCmd        = {}; // {drawingName: {cmd: item}}
        this.touchActionsByCmd      = {}; // {drawingName: {cmd: actionArray}}
        this.touchActionInputsByCmd = {}; // {drawingName: {cmd: {prompt, textIdx}}}
        this.unindexedItems         = {}; // {drawingName: [items]}
        this.indexedItems           = {}; // {drawingName: {idx: item}}

        // Per-menuDwg MERGED items, produced by DrawingMerger.mergeAllDrawings()
        // and consumed by redraw.performRedrawInMode() in menu-mode.  Each
        // entry is the result of merging the drawing tree rooted at the named
        // menuDwg — every `insertDwg` reference recursively expanded into the
        // target drawing's items, transforms composed.  This is what redraw
        // displays for each menu canvas; the raw per-drawing collections
        // above are the merger's INPUTS only.
        //
        // For a menu item rooted at c1 that contains insertDwgs c2 and c3,
        // there will be one entry (key "c1") in each of the five maps below
        // holding the fully-expanded merge of c1+c2+c3.
        //
        // Format for each: {menuDwgName: <collection>}
        this.allTouchZonesByCmd        = {}; // {menuDwg: {cmd: item}}
        this.allTouchActionsByCmd      = {}; // {menuDwg: {cmd: actions[]}}
        this.allTouchActionInputsByCmd = {}; // {menuDwg: {cmd: input}}
        this.allUnindexedItems         = {}; // {menuDwg: [items]}
        this.allIndexedItemsByNumber   = {}; // {menuDwg: {idx: item}}
        
        // Track all drawings including main and inserted ones
        this.drawings = []; // Array of drawing names in order, with main drawing first
        this.drawingsData = {}; // Format: {drawingName: {xOffset, yOffset, transform, data, parentDrawing}}
        
        // Flag to track if all drawings have been received
        this.allDrawingsReceived = false; // this is not actually used!!
        
        // Only store the last transform for drawing updates
        this.savedTransforms = {}; // Format: {drawingName: {x, y, scale}}
        
        // Track response status for each drawing
        this.drawingResponseStatus = {}; // Format: {drawingName: boolean} - true if response received, false if pending

        // Global display transform for merged canvas; set by setGlobalTransform() before use
        this.globalTransform = { x: 0, y: 0, scale: 1.0 };

        // No auto-load on construction.  The cache uses connectionId-keyed
        // entries (pfodWeb_dwg_<conn>_<dwg> and pfodWeb_menuDwg_<conn>_<menuDwg>)
        // so callers explicitly hydrate per-drawing/per-menuDwg state via
        // loadDrawingDataFromStorage / loadMenuDwgMergedFromStorage with the
        // active connectionId.
    }
    
    // Initialize the manager with a drawing name
    initialize(drawingName) {
        // Add the main drawing as the first entry in the drawings array
        if (!this.drawings.includes(drawingName)) {
            this.drawings.unshift(drawingName);
        }
        
        if (!this.touchZonesByCmd[drawingName]) {
            this.touchZonesByCmd[drawingName] = {};
        }
        if (!this.touchActionsByCmd[drawingName]) {
            this.touchActionsByCmd[drawingName] = {};
        }
        if (!this.touchActionInputsByCmd[drawingName]) {
            this.touchActionInputsByCmd[drawingName] = {};
        }
        // Initialize collections for the drawing if they don't exist
        if (!this.unindexedItems[drawingName]) {
            this.unindexedItems[drawingName] = [];
        }
        if (!this.indexedItems[drawingName]) {
            this.indexedItems[drawingName] = {};
        }
        
        // Initialize saved transform to identity so getTransform() never needs a fallback
        if (!this.savedTransforms[drawingName]) {
            this.savedTransforms[drawingName] = { x: 0, y: 0, scale: 1.0 };
        }

        console.log(`DrawingManager initialized with drawing: ${drawingName}`);
        return this;
    }
    
    // Get the saved transform for a drawing
    // This is only used for restoring the last saved transform for updates
    getSavedTransform(drawingName) {
        if (!this.savedTransforms[drawingName]) {
            throw new Error(`[DRAWING_MANAGER] getSavedTransform: no saved transform for drawing "${drawingName}"`);
        }
        return this.savedTransforms[drawingName];
    }
    
    // Save the current transform for a drawing
    // This is used only to store the final transform for the next update
    saveTransform(drawingName, transform) {
        this.savedTransforms[drawingName] = { ...transform };
        return this;
    }
    
    // Get the drawing data for a specific drawing
    getDrawingData(drawingName) {
        return this.drawingsData[drawingName]?.data;
    }
    
    // Set drawing data for a drawing
    setDrawingData(drawingName, data) {
        // Ensure drawingsData entry exists
        if (!this.drawingsData[drawingName]) {
            this.drawingsData[drawingName] = {
                xOffset: 0,
                yOffset: 0,
                transform: { x: 0, y: 0, scale: 1.0 },
                data: null,
                parentDrawing: null
            };
            
            // If this is a new drawing, add it to the drawings array
            if (!this.drawings.includes(drawingName)) {
                this.drawings.push(drawingName);
            }
        }
        
        // Update the data
        this.drawingsData[drawingName].data = data;
        this.drawingsData[drawingName].name = drawingName;
        this.drawingResponseStatus[drawingName] = true;
        
        // Ensure there are item collections for this drawing
        this.ensureItemCollections(drawingName);
        
        console.log(`DrawingManager: Set data for drawing ${drawingName}`);
        return this;
    }
    
    // Update drawing data (partial update)
    updateDrawingData(drawingName, updates) {
        if (!this.drawingsData[drawingName]) {
            this.drawingsData[drawingName] = {
                xOffset: 0,
                yOffset: 0,
                transform: { x: 0, y: 0, scale: 1.0 },
                data: {},
                parentDrawing: null
            };
            
            // If this is a new drawing, add it to the drawings array
            if (!this.drawings.includes(drawingName)) {
                this.drawings.push(drawingName);
            }
        }
        
        const currentData = this.drawingsData[drawingName].data;
        this.drawingsData[drawingName].data = { ...currentData, ...updates };
        this.drawingResponseStatus[drawingName] = true;
        
        console.log(`DrawingManager: Updated data for drawing ${drawingName}`);
        return this;
    }
    
    // Add an item to a drawing
    addItem(drawingName, item) {
        // Ensure the item collections exist
        this.ensureItemCollections(drawingName);

        // Apply current transform to the item
        if (!item.transform) {
            item.transform = {...this.getTransform(drawingName)};
        }

        // Handle indexed vs. unindexed items
        if (item.idx && item.idx !== 'null') {
            const idx = item.idx;
            // Per-idx assign already gives "last received wins" — overwrites
            // any prior item with the same idx, leaves untouched indices alone.
            this.indexedItems[drawingName][idx] = item;
            return this;
        }

        // Non-indexed items go through the dedup helper so re-receiving the
        // same item (same loadcmd for insertDwg, or same attribute fingerprint
        // for everything else) doesn't accumulate duplicates.
        DrawingManager.addUnindexedLastWins(this.unindexedItems[drawingName], item);
        return this;
    }

    // Identity key used to dedupe unindexed items.  insertDwg items collide
    // on their loadcmd (cmd) regardless of transform/offset; all other types
    // collide on a stable JSON of their attributes (excluding transient
    // render fields like clipRegion / parentDrawingName which are added
    // later by the merger and would otherwise prevent a stable match).
    static unindexedKey(item) {
        if (item && item.type === 'insertDwg') {
            return 'insertDwg:' + (item.cmd || item.drawingName || '');
        }
        const stripped = {};
        for (const k in item) {
            if (k === 'clipRegion' || k === 'parentDrawingName') continue;
            stripped[k] = item[k];
        }
        return 'attrs:' + JSON.stringify(stripped);
    }

    // "Last received wins" insert into an unindexed list:
    //   * insertDwg with matching loadcmd → REPLACE the old one IN PLACE
    //     (preserves draw order so re-receiving an insertDwg with a new
    //     transform doesn't reshuffle surrounding shapes).
    //   * Any other type with matching attribute fingerprint → REMOVE the
    //     old entries and APPEND the new one at end (so the latest copy
    //     draws last and overlays earlier matches).
    //   * No matching entry → APPEND at end.
    //
    // Static so DrawingMerger can use the same canonical implementation
    // when populating allUnindexedItems[menuDwg].
    static addUnindexedLastWins(list, item) {
        const isInsertDwg = item && item.type === 'insertDwg';
        const key = DrawingManager.unindexedKey(item);

        if (isInsertDwg) {
            for (let i = 0; i < list.length; i++) {
                if (DrawingManager.unindexedKey(list[i]) === key) {
                    list[i] = item;          // in-place replace, position preserved
                    return;
                }
            }
            list.push(item);                  // first time → append
            return;
        }

        // Non-insertDwg: drop existing matches, append the newcomer at end.
        for (let i = list.length - 1; i >= 0; i--) {
            if (DrawingManager.unindexedKey(list[i]) === key) {
                list.splice(i, 1);
            }
        }
        list.push(item);
    }
    
    // Process a touchZone item
    addTouchZone(drawingName, touchZone) {
        // Ensure the item has a drawing name
        touchZone.drawingName = drawingName;
        const cmd = touchZone.cmd;
        if (!cmd || cmd.trim().length === 0) {
            throw new Error(`[DRAWING_MANAGER] addTouchZone: empty or missing cmd in drawing "${drawingName}": ${JSON.stringify(touchZone)}`);
        }
 
        // Check if there's already an existing item (could be index item) with this cmd
        const existingItem = this.touchZonesByCmd[drawingName] && this.touchZonesByCmd[drawingName][cmd];
        
        if (existingItem) {
            // Preserve transform and visibility state from existing item (likely an index item)
            touchZone.transform = existingItem.transform;
            touchZone.visible = existingItem.visible !== undefined ? existingItem.visible : touchZone.visible;
            console.log(`[DRAWING_MANAGER] Preserving state from existing item for cmd="${cmd}": visible=${touchZone.visible}, transform=(${touchZone.transform.x},${touchZone.transform.y},${touchZone.transform.scale})`);
        } else {
            // Apply current transform if not already set
            if (!touchZone.transform) {
                touchZone.transform = {...this.getTransform(drawingName)};
            }
        }
        
        // Add to the touchZones map - cmd is unique reference
        this.touchZonesByCmd[drawingName][touchZone.cmd] = touchZone;
        
        return this;
    }

    // Process a touchAction item
    addTouchAction(drawingName, touchAction) {
        const cmd = touchAction.cmd;
        if (!cmd || cmd.trim().length === 0) {
            throw new Error(`[DRAWING_MANAGER] addTouchAction: empty or missing cmd in drawing "${drawingName}": ${JSON.stringify(touchAction)}`);
        }
        console.log(`[DRAWING_MANAGER] Adding touchAction: cmd=${cmd}, drawingName=${drawingName}`);

        // Check if there's a touchZone with the same cmd in this drawing
        if (!this.touchZonesByCmd[drawingName] || !this.touchZonesByCmd[drawingName][cmd]) {
            throw new Error(`[DRAWING_MANAGER] addTouchAction: cmd="${cmd}" has no corresponding touchZone in drawing "${drawingName}". TouchActions must be positioned AFTER their touchZone.`);
        }
        
        // Ensure the collections exist
        this.ensureItemCollections(drawingName);
        
        // Initialize actions array if it doesn't exist for this cmd
        if (!this.touchActionsByCmd[drawingName][cmd]) {
            this.touchActionsByCmd[drawingName][cmd] = [];
        }
        
        // Append the action items to existing actions array instead of replacing
        if (touchAction.action && Array.isArray(touchAction.action)) {
            this.touchActionsByCmd[drawingName][cmd].push(...touchAction.action);
        }
        
        console.log(`[DRAWING_MANAGER] TouchAction added successfully: cmd=${cmd}, actions=${touchAction.action.length}, drawingName=${drawingName}`);
        return true;
    }

    // Get touchActions for a specific cmd
    getTouchAction(drawingName, cmd) {
        if (!this.touchActionsByCmd[drawingName]) {
            throw new Error(`[DRAWING_MANAGER] getTouchAction: drawing "${drawingName}" not initialized`);
        }
        if (!this.touchActionsByCmd[drawingName][cmd]) {
            throw new Error(`[DRAWING_MANAGER] getTouchAction: no touchActions for cmd "${cmd}" in drawing "${drawingName}"`);
        }
        return this.touchActionsByCmd[drawingName][cmd];
    }

    // Add touchActionInput for a specific cmd
    addTouchActionInput(drawingName, touchActionInput) {
        const cmd = touchActionInput.cmd;
        if (!cmd || cmd.trim().length === 0) {
            throw new Error(`[DRAWING_MANAGER] addTouchActionInput: empty or missing cmd in drawing "${drawingName}": ${JSON.stringify(touchActionInput)}`);
        }
        console.log(`[DRAWING_MANAGER] Adding touchActionInput: cmd=${cmd}, drawingName=${drawingName}`);

        // Check if there's a touchZone with the same cmd in this drawing
        if (!this.touchZonesByCmd[drawingName] || !this.touchZonesByCmd[drawingName][cmd]) {
            throw new Error(`[DRAWING_MANAGER] addTouchActionInput: cmd="${cmd}" has no corresponding touchZone in drawing "${drawingName}". TouchActionInputs must be positioned AFTER their touchZone.`);
        }
        
        // Ensure the collections exist
        this.ensureItemCollections(drawingName);
        
        // Store the touchActionInput - overwrites any existing touchActionInput with same cmd
        this.touchActionInputsByCmd[drawingName][cmd] = {
            prompt: touchActionInput.prompt,
            textIdx: touchActionInput.textIdx,
            fontSize: touchActionInput.fontSize !== undefined ? touchActionInput.fontSize : 0,
            color: touchActionInput.color !== undefined ? touchActionInput.color : 0,
            backgroundColor: touchActionInput.backgroundColor !== undefined ? touchActionInput.backgroundColor : 0
        };
        
        // Force touchZone filter to TOUCH when touchActionInput is present, but only if not TOUCH_DISABLED
        const touchZone = this.touchZonesByCmd[drawingName][cmd];
        if (touchZone && touchZone.filter !== TouchZoneFilters.TOUCH && touchZone.filter !== TouchZoneFilters.TOUCH_DISABLED) {
            console.log(`[DRAWING_MANAGER] Forcing touchZone filter from ${touchZone.filter} to TOUCH for cmd=${cmd} due to touchActionInput`);
            touchZone.filter = TouchZoneFilters.TOUCH;
        }
        
        console.log(`[DRAWING_MANAGER] TouchActionInput added successfully: cmd=${cmd}, prompt="${touchActionInput.prompt}", textIdx=${touchActionInput.textIdx}, drawingName=${drawingName}`);
        return true;
    }

    // Get touchActionInput for a specific cmd
    getTouchActionInput(drawingName, cmd) {
        if (!this.touchActionInputsByCmd[drawingName]) {
            throw new Error(`[DRAWING_MANAGER] getTouchActionInput: drawing "${drawingName}" not initialized`);
        }
        if (!this.touchActionInputsByCmd[drawingName][cmd]) {
            throw new Error(`[DRAWING_MANAGER] getTouchActionInput: no touchActionInput for cmd "${cmd}" in drawing "${drawingName}"`);
        }
        return this.touchActionInputsByCmd[drawingName][cmd];
    }
    
    // Get touchZones dict for a drawing
    getTouchZonesByCmd(drawingName) {
        if (!this.touchZonesByCmd[drawingName]) {
            throw new Error(`[DRAWING_MANAGER] getTouchZonesByCmd: drawing "${drawingName}" not initialized`);
        }
        return this.touchZonesByCmd[drawingName];
    }
    
    // Clear items for a drawing
    clearItems(drawingName) {
        this.unindexedItems[drawingName] = [];
        this.indexedItems[drawingName] = {};
        this.touchZonesByCmd[drawingName] = {};
        this.touchActionsByCmd[drawingName] = {};
        this.touchActionInputsByCmd[drawingName] = {};
        return this;
    }
    
    // Get all unindexed items for a drawing
    getUnindexedItems(drawingName) {
        if (!this.unindexedItems[drawingName]) {
            throw new Error(`[DRAWING_MANAGER] getUnindexedItems: drawing "${drawingName}" not initialized`);
        }
        return this.unindexedItems[drawingName];
    }

    // Get all indexed items for a drawing
    getIndexedItems(drawingName) {
        if (!this.indexedItems[drawingName]) {
            throw new Error(`[DRAWING_MANAGER] getIndexedItems: drawing "${drawingName}" not initialized`);
        }
        return this.indexedItems[drawingName];
    }
    
    // Add an inserted drawing
    addInsertedDrawing(drawingName, xOffset, yOffset, transform, parentDrawing) {
        // Add to tracking array if not already present
        if (!this.drawings.includes(drawingName)) {
            this.drawings.push(drawingName);
        }
        
        // Initialize data structure for the inserted drawing
        if (!transform) {
            throw new Error(`[DRAWING_MANAGER] addInsertedDrawing: transform is required for drawing "${drawingName}"`);
        }
        this.drawingsData[drawingName] = {
            xOffset: xOffset,
            yOffset: yOffset,
            transform: transform,
            data: null,
            parentDrawing: parentDrawing
        };
        
        // Initialize saved transform
        this.savedTransforms[drawingName] = { x: 0, y: 0, scale: 1.0 };
        
        // Set response status to false (pending) when request is queued
        this.drawingResponseStatus[drawingName] = false;
        
        // Ensure the item collections exist for this drawing
        this.ensureItemCollections(drawingName);
        
        return this;
    }
 /**   
    // Set data for an inserted drawing
    setInsertedDrawingData(drawingName, data) {
        if (this.drawingsData[drawingName]) {
            this.drawingsData[drawingName].data = data;
            
            // Set response status to true when response is received
            this.drawingResponseStatus[drawingName] = true;
            console.log(`[DRAWING_MANAGER] Set response status to TRUE for "${drawingName}"`);
        } else {
            console.warn(`[DRAWING_MANAGER] Cannot set data for "${drawingName}" - not found in drawingsData`);
        }
        return this;
    }
 **/   
    // Remove an inserted drawing
    removeInsertedDrawing(drawingName) {
         console.log(`[DRAWING_MANAGER] Remove inserted drawing: "${drawingName}" `);
        // (No "cannot remove main drawing" guard — there is no privileged
        // drawing.  Callers should not call this with a drawingName they
        // still need; if they do, the drawing is gone and any access errors
        // will surface naturally.)

        // Remove from drawings array
        const index = this.drawings.indexOf(drawingName);
        if (index !== -1) {
            this.drawings.splice(index, 1);
        }
        
        // Remove the drawing data
        delete this.drawingsData[drawingName];
        
        // Remove the drawing's item collections
        delete this.unindexedItems[drawingName];
        delete this.indexedItems[drawingName];
        
        // Remove saved transform
        delete this.savedTransforms[drawingName];
        
        // Remove response status
        delete this.drawingResponseStatus[drawingName];
        
        return this;
    }
    
    // Remove touchZone and associated touchActions by cmd, and also erase insertDwg items
    eraseByCmd(drawingName, cmd, dwgName = null) {
        console.log(`[DRAWING_MANAGER] Erasing touchZone and associated actions for cmd="${cmd}" in drawing="${drawingName}"`);
        if (!dwgName) {
        // Remove touchZone
        if (this.touchZonesByCmd[drawingName] && this.touchZonesByCmd[drawingName][cmd]) {
            delete this.touchZonesByCmd[drawingName][cmd];
            console.log(`[DRAWING_MANAGER] Removed touchZone for cmd="${cmd}"`);
        }
        
        // Remove associated touchActions
        if (this.touchActionsByCmd[drawingName] && this.touchActionsByCmd[drawingName][cmd]) {
            delete this.touchActionsByCmd[drawingName][cmd];
            console.log(`[DRAWING_MANAGER] Removed touchActions for cmd="${cmd}"`);
        }
        
        // Remove associated touchActionInputs
        if (this.touchActionInputsByCmd[drawingName] && this.touchActionInputsByCmd[drawingName][cmd]) {
            delete this.touchActionInputsByCmd[drawingName][cmd];
            console.log(`[DRAWING_MANAGER] Removed touchActionInput for cmd="${cmd}"`);
        }
        } else {
          // Also erase any insertDwg items with drawingName matching the cmd
          this.eraseInsertDwgByCmd(drawingName, cmd);
        }
        
        return this;
    }
    
    // Remove insertDwg items and recursively cleanup associated data
    eraseInsertDwgByCmd(parentDrawingName, targetDrawingName) {
        console.log(`[DRAWING_MANAGER] Erasing insertDwg for drawing="${targetDrawingName}" from parent="${parentDrawingName}"`);
        
        // Remove insertDwg items from unindexed items where drawingName matches cmd
        if (this.unindexedItems[parentDrawingName]) {
            const originalLength = this.unindexedItems[parentDrawingName].length;
            this.unindexedItems[parentDrawingName] = this.unindexedItems[parentDrawingName].filter(item => {
                if (item.type === 'insertDwg' && item.drawingName === targetDrawingName) {
                    console.log(`[DRAWING_MANAGER] Removing insertDwg item for "${targetDrawingName}" from unindexed items`);
                    return false; // Remove this item
                }
                return true; // Keep this item
            });
            const newLength = this.unindexedItems[parentDrawingName].length;
            if (originalLength !== newLength) {
                console.log(`[DRAWING_MANAGER] Removed ${originalLength - newLength} insertDwg items from unindexed items`);
            }
        }
        
        // Recursively remove all drawings that were inserted by the target drawing
        if (this.unindexedItems[targetDrawingName]) {
            const insertDwgItems = this.unindexedItems[targetDrawingName].filter(item => 
                item.type === 'insertDwg'
            );
            
            insertDwgItems.forEach(item => {
                console.log(`[DRAWING_MANAGER] Recursively removing nested insertDwg: "${item.drawingName}"`);
                this.eraseInsertDwgByCmd(targetDrawingName, item.drawingName);
            });
        }
        
        // Remove the inserted drawing from our tracking and cleanup all associated data
        if (this.drawings.includes(targetDrawingName)) {
            this.removeInsertedDrawing(targetDrawingName);
            console.log(`[DRAWING_MANAGER] Removed inserted drawing "${targetDrawingName}" from drawings array and cleaned up data`);
        }
        
        // Clear localStorage for the erased drawing
        try {
            localStorage.removeItem(`${targetDrawingName}_version`);
            localStorage.removeItem(`${targetDrawingName}_data`);
            console.log(`[DRAWING_MANAGER] Cleared localStorage for "${targetDrawingName}"`);
        } catch (error) {
            console.error(`[DRAWING_MANAGER] Error clearing localStorage for "${targetDrawingName}":`, error);
            throw error;
        }
        
        return this;
    }
    
    // Hide touchZone and insertDwg items by cmd
    hideByCmd(drawingName, cmd, dwgName = null) {
        console.log(`[DRAWING_MANAGER] Hiding items with cmd="${cmd}" in drawing="${drawingName}"`);
        if (!dwgName) {
        // Hide touchZone
        if (this.touchZonesByCmd[drawingName] && this.touchZonesByCmd[drawingName][cmd]) {
            this.touchZonesByCmd[drawingName][cmd].visible = false;
            console.log(`[DRAWING_MANAGER] Hidden touchZone for cmd="${cmd}"`);
        }
        } else {
        // Hide insertDwg items with cmd matching the hide command
        if (this.unindexedItems[drawingName]) {
            console.log(`[DRAWING_MANAGER] Checking ${this.unindexedItems[drawingName].length} unindexed items for insertDwg to hide with cmd="${cmd}"`);
            this.unindexedItems[drawingName].forEach((item, index) => {
                if (item.type === 'insertDwg') {
                    console.log(`[DRAWING_MANAGER] Found insertDwg item ${index}: cmd="${item.cmd}", target cmd="${cmd}", match=${item.cmd === cmd}`);
                    if (item.cmd === cmd) {
                        item.visible = false;
                        console.log(`[DRAWING_MANAGER] Hidden insertDwg item with cmd="${cmd}"`);
                    }
                }
            });
        }
        }
        
        return this;
    }
    
    // Unhide touchZone and insertDwg items by cmd
    unhideByCmd(drawingName, cmd, dwgName = null) {
        console.log(`[DRAWING_MANAGER] Unhiding items with cmd="${cmd}" in drawing="${drawingName}"`);
        if (!dwgName) {
        // Unhide touchZone
        if (this.touchZonesByCmd[drawingName] && this.touchZonesByCmd[drawingName][cmd]) {
            this.touchZonesByCmd[drawingName][cmd].visible = true;
            console.log(`[DRAWING_MANAGER] Unhidden touchZone for cmd="${cmd}"`);
        }
        } else {
        // Unhide insertDwg items with cmd matching the unhide command
        if (this.unindexedItems[drawingName]) {
            this.unindexedItems[drawingName].forEach(item => {
                if (item.type === 'insertDwg' && item.cmd === cmd) {
                    item.visible = true;
                    console.log(`[DRAWING_MANAGER] Unhidden insertDwg item with cmd="${cmd}"`);
                }
            });
        }
        }
        return this;
    }
    
    // Get all child drawings for a parent drawing
    getChildDrawings(parentDrawingName) {
        const childDrawings = [];
        
        for (const childName in this.drawingsData) {
            if (this.drawingsData[childName].parentDrawing === parentDrawingName) {
                childDrawings.push(childName);
            }
        }
        
        return childDrawings;
    }
    
    // Save the current transform for a drawing
    saveTransform(drawingName, transform) {
        this.savedTransforms[drawingName] = { ...transform };
        return this;
    }
    
    // Get the saved transform for a drawing
    getTransform(drawingName) {
        if (!this.savedTransforms[drawingName]) {
            throw new Error(`[DRAWING_MANAGER] getTransform: no saved transform for drawing "${drawingName}"`);
        }
        return this.savedTransforms[drawingName];
    }
    
    // Wipe every collection and lifecycle scalar in place, returning this
    // manager to its constructor-state.  Used by drawingDataProcessor's
    // touch-replacement path to restart fresh while keeping the same
    // DrawingManager instance (the caller — redraw.redrawDrawingManager —
    // can't be reassigned externally).
    reset() {
        this.touchZonesByCmd        = {};
        this.touchActionsByCmd      = {};
        this.touchActionInputsByCmd = {};
        this.unindexedItems         = {};
        this.indexedItems           = {};

        this.allTouchZonesByCmd        = {};
        this.allTouchActionsByCmd      = {};
        this.allTouchActionInputsByCmd = {};
        this.allUnindexedItems         = {};
        this.allIndexedItemsByNumber   = {};

        this.drawings              = [];
        this.drawingsData          = {};
        this.savedTransforms       = {};
        this.drawingResponseStatus = {};
        this.allDrawingsReceived   = false;
        this.globalTransform       = { x: 0, y: 0, scale: 1.0 };
        return this;
    }

    // Get all data needed for the mergeAndRedraw module
    getMergeAndRedrawState() {
        return {
            unindexedItems: this.unindexedItems,
            indexedItems: this.indexedItems,
            touchZonesByCmd: this.touchZonesByCmd,
            touchActionsByCmd: this.touchActionsByCmd,
            touchActionInputsByCmd: this.touchActionInputsByCmd,
            // Per-menuDwg merged collections — re-derivable from the per-drawing
            // raw collections via DrawingMerger.mergeAllDrawings(), so persisting
            // them is purely an optimisation.
            allTouchZonesByCmd:        this.allTouchZonesByCmd,
            allTouchActionsByCmd:      this.allTouchActionsByCmd,
            allTouchActionInputsByCmd: this.allTouchActionInputsByCmd,
            allUnindexedItems:         this.allUnindexedItems,
            allIndexedItemsByNumber:   this.allIndexedItemsByNumber,
            drawings: this.drawings,
            drawingsData: this.drawingsData,
            allDrawingsReceived: this.allDrawingsReceived, // this is not actually used!!
            drawingResponseStatus: this.drawingResponseStatus
        };
    }
    
    // Return initial transform state based on command type
    // This doesn't store any state, just returns the appropriate initial transform
    getInitialTransform(drawingName, command) {
        const name = drawingName;
        
        if (command === 'start') {
            // For 'start' commands, always use initial state
            console.log(`[TRANSFORM] Using initial transform (0,0,1.0) for drawing start: ${name}`);
            return { x: 0, y: 0, scale: 1.0 };
        } else if (command === 'update' && this.savedTransforms[name]) {
            // For 'update' commands, use the saved transform if available
            const savedTransform = {...this.savedTransforms[name]};
            console.log(`[TRANSFORM] Using saved transform for update: x=${savedTransform.x}, y=${savedTransform.y}, scale=${savedTransform.scale}`);
            return savedTransform;
        } else {
            // Default fallback
            console.log(`[TRANSFORM] No saved transform found, using default (0,0,1.0)`);
            return { x: 0, y: 0, scale: 1.0 };
        }
    }
    
    // Load drawing data from localStorage (if available)
    loadFromLocalStorage(drawingName) {
        try {
            const savedVersion = localStorage.getItem(`${drawingName}_version`);
            const savedData = localStorage.getItem(`${drawingName}_data`);
            
            if (savedData) {
                const drawingData = JSON.parse(savedData);
                
                // Ensure the drawing is in the drawings array
                if (!this.drawings.includes(drawingName)) {
                        this.drawings.push(drawingName);
                }
                
                // Create or update drawingsData entry
                if (!this.drawingsData[drawingName]) {
                    this.drawingsData[drawingName] = {
                        xOffset: 0,
                        yOffset: 0,
                        transform: { x: 0, y: 0, scale: 1.0 },
                        data: null,
                        parentDrawing: null
                    };
                }
                
                // Update the data
                this.drawingsData[drawingName].data = drawingData;
                this.drawingResponseStatus[drawingName] = true;
                
                console.log(`DrawingManager: Loaded drawing ${drawingName} from localStorage (version: ${savedVersion})`);
                return drawingData;
            }
        } catch (error) {
            console.error(`Error loading drawing ${drawingName} from localStorage:`, error);
            throw error;
        }
    }

    // ---- Per-drawing cache (pfodWeb_dwg_<conn>_<drawingName>) ----
    //
    // Stores ONE drawing's data + version + per-drawing raw collections,
    // independently of which menu(s) reference it.  The cache key is
    // per-(connection, drawing) so the same drawing reused across multiple
    // menu items has a single cache entry, and connections to different
    // devices keep separate state.
    //
    // The five raw collections are saved/loaded TOGETHER with .data, so a
    // non-null drawingsData[name].data always implies the raw collections
    // are populated (and vice versa).  Callers can rely on the ?.data
    // signal to mean "fully loaded".
    saveDrawingDataToStorage(drawingName, connectionId) {
        if (!drawingName || !connectionId) return this;
        const data = this.drawingsData[drawingName]?.data;
        if (!data) {
            console.warn(`[DRAWING_MANAGER] saveDrawingDataToStorage: no data for "${drawingName}", skipping`);
            return this;
        }
        const key = `pfodWeb_dwg_${connectionId}_${drawingName}`;
        // Don't cache unversioned drawings — without a version the next
        // session has no way to verify staleness, so persisting would mask
        // a fresh fetch.  Also evict any prior cached entry so the next
        // start request goes out unversioned and the device replies with
        // current state.
        if (!data.version) {
            try {
                localStorage.removeItem(key);
                console.log(`[DRAWING_MANAGER] saveDrawingDataToStorage: "${drawingName}" is unversioned — not cached, evicted any prior entry at ${key}`);
            } catch (error) {
                console.error(`[DRAWING_MANAGER] saveDrawingDataToStorage error evicting unversioned "${drawingName}":`, error);
            }
            return this;
        }
        try {
            const entry = {
                data: data,
                version: data.version,
                touchZonesByCmd:        this.touchZonesByCmd[drawingName]        || {},
                touchActionsByCmd:      this.touchActionsByCmd[drawingName]      || {},
                touchActionInputsByCmd: this.touchActionInputsByCmd[drawingName] || {},
                unindexedItems:         this.unindexedItems[drawingName]         || [],
                indexedItems:           this.indexedItems[drawingName]           || {}
            };
            localStorage.setItem(key, JSON.stringify(entry));
            console.log(`[DRAWING_MANAGER] Saved per-drawing cache "${drawingName}" version="${entry.version}" key=${key}`);
        } catch (error) {
            console.error(`[DRAWING_MANAGER] saveDrawingDataToStorage error for "${drawingName}":`, error);
            throw error;
        }
        return this;
    }

    // Load a single drawing from per-drawing cache.  Returns the cached
    // entry on hit (with .version), null on miss.  On hit, populates the
    // 5 per-drawing raw collections and drawingsData[name].data atomically,
    // ensures the drawing is registered in this.drawings, and seeds
    // savedTransforms / drawingResponseStatus.
    loadDrawingDataFromStorage(drawingName, connectionId) {
        if (!drawingName || !connectionId) return null;
        try {
            const key = `pfodWeb_dwg_${connectionId}_${drawingName}`;
            const stored = localStorage.getItem(key);
            if (!stored) return null;
            const entry = JSON.parse(stored);
            // Restore raw atomically with .data so the (data set <=> raw populated) invariant holds.
            this.touchZonesByCmd[drawingName]        = entry.touchZonesByCmd        || {};
            this.touchActionsByCmd[drawingName]      = entry.touchActionsByCmd      || {};
            this.touchActionInputsByCmd[drawingName] = entry.touchActionInputsByCmd || {};
            this.unindexedItems[drawingName]         = entry.unindexedItems         || [];
            this.indexedItems[drawingName]           = entry.indexedItems           || {};
            // Restore drawingsData; preserve xOffset/yOffset/transform/parentDrawing
            // if a prior addInsertedDrawing has already populated them.
            if (!this.drawingsData[drawingName]) {
                this.drawingsData[drawingName] = {
                    xOffset: 0, yOffset: 0,
                    transform: { x: 0, y: 0, scale: 1.0 },
                    data: entry.data,
                    parentDrawing: null
                };
            } else {
                this.drawingsData[drawingName].data = entry.data;
            }
            this.drawingResponseStatus[drawingName] = true;
            if (!this.savedTransforms[drawingName]) {
                this.savedTransforms[drawingName] = { x: 0, y: 0, scale: 1.0 };
            }
            if (!this.drawings.includes(drawingName)) {
                this.drawings.push(drawingName);
            }
            console.log(`[DRAWING_MANAGER] Loaded per-drawing cache "${drawingName}" version="${entry.version}" key=${key}`);
            return entry;
        } catch (error) {
            console.error(`[DRAWING_MANAGER] loadDrawingDataFromStorage error for "${drawingName}":`, error);
            return null;
        }
    }

    // ---- Per-menuDwg merged cache (pfodWeb_menuDwg_<conn>_<menuDwgName>) ----
    //
    // Stores the merged tree (allXXX[menuDwg]) for a menuDwg — the rendered
    // result of the merger walking the menuDwg's insertDwg tree.  Separate
    // from the per-drawing cache: the same component drawing may appear in
    // multiple menuDwg trees and each menuDwg owns its own merged result
    // (with composed transforms etc.).
    //
    // Versioning rule mirrors saveDrawingDataToStorage: only persist when the
    // top-level menuDwg has a version.  Without one, the next session has no
    // way to verify staleness, so caching would mask a fresh fetch.  Evict any
    // prior entry so a stale merge from an earlier (versioned) firmware does
    // not leak into the new run.
    saveMenuDwgMergedToStorage(menuDwgName, connectionId) {
        if (!menuDwgName || !connectionId) return this;
        const key = `pfodWeb_menuDwg_${connectionId}_${menuDwgName}`;
        const version = this.drawingsData[menuDwgName]?.data?.version;
        if (!version) {
            try {
                localStorage.removeItem(key);
                console.log(`[DRAWING_MANAGER] saveMenuDwgMergedToStorage: "${menuDwgName}" is unversioned — not cached, evicted any prior entry at ${key}`);
            } catch (error) {
                console.error(`[DRAWING_MANAGER] saveMenuDwgMergedToStorage error evicting unversioned "${menuDwgName}":`, error);
            }
            return this;
        }
        try {
            const entry = {
                allTouchZonesByCmd:        this.allTouchZonesByCmd[menuDwgName]        || {},
                allTouchActionsByCmd:      this.allTouchActionsByCmd[menuDwgName]      || {},
                allTouchActionInputsByCmd: this.allTouchActionInputsByCmd[menuDwgName] || {},
                allUnindexedItems:         this.allUnindexedItems[menuDwgName]         || [],
                allIndexedItemsByNumber:   this.allIndexedItemsByNumber[menuDwgName]   || {}
            };
            localStorage.setItem(key, JSON.stringify(entry));
            console.log(`[DRAWING_MANAGER] Saved menuDwg merged cache "${menuDwgName}" version="${version}" key=${key}`);
        } catch (error) {
            console.error(`[DRAWING_MANAGER] saveMenuDwgMergedToStorage error for "${menuDwgName}":`, error);
            throw error;
        }
        return this;
    }

    loadMenuDwgMergedFromStorage(menuDwgName, connectionId) {
        if (!menuDwgName || !connectionId) return null;
        try {
            const key = `pfodWeb_menuDwg_${connectionId}_${menuDwgName}`;
            const stored = localStorage.getItem(key);
            if (!stored) return null;
            const entry = JSON.parse(stored);
            this.allTouchZonesByCmd[menuDwgName]        = entry.allTouchZonesByCmd        || {};
            this.allTouchActionsByCmd[menuDwgName]      = entry.allTouchActionsByCmd      || {};
            this.allTouchActionInputsByCmd[menuDwgName] = entry.allTouchActionInputsByCmd || {};
            this.allUnindexedItems[menuDwgName]         = entry.allUnindexedItems         || [];
            this.allIndexedItemsByNumber[menuDwgName]   = entry.allIndexedItemsByNumber   || {};
            console.log(`[DRAWING_MANAGER] Loaded menuDwg merged cache "${menuDwgName}" key=${key}`);
            return entry;
        } catch (error) {
            console.error(`[DRAWING_MANAGER] loadMenuDwgMergedFromStorage error for "${menuDwgName}":`, error);
            return null;
        }
    }


    // Helper method to ensure item collections exist for a drawing
    ensureItemCollections(drawingName) {
        if (!this.unindexedItems[drawingName]) {
            this.unindexedItems[drawingName] = [];
        }
        if (!this.indexedItems[drawingName]) {
            this.indexedItems[drawingName] = {};
        }
        if (!this.touchZonesByCmd[drawingName]) {
            this.touchZonesByCmd[drawingName] = {};
        }
        if (!this.touchActionsByCmd[drawingName]) {
            this.touchActionsByCmd[drawingName] = {};
        }
        if (!this.touchActionInputsByCmd[drawingName]) {
            this.touchActionInputsByCmd[drawingName] = {};
        }
    }
    
    // (Removed: getMainDrawingName / getCurrentDrawingName / getCurrentDrawingData.
    // A menu has zero or more drawing items, no privileged "main" drawing.
    // Callers must pass an explicit drawingName.)

    // Create a structured response for sharing state with other modules
    getState() {
        return {
            drawings: this.drawings,
            drawingsData: this.drawingsData,
            unindexedItems: this.unindexedItems,
            indexedItems: this.indexedItems,
            allDrawingsReceived: this.allDrawingsReceived,
            savedTransforms: this.savedTransforms,
            drawingResponseStatus: this.drawingResponseStatus
        };
    }
    
    // Get the response status for a drawing
    getDrawingResponseStatus(drawingName) {
        // Add debug logging to help troubleshoot
        console.log(`[DRAWING_MANAGER] Checking response status for "${drawingName}": ${this.drawingResponseStatus[drawingName]}`);
        
        // If it's undefined, treat as false - if it's truthy, treat as true
        return !!this.drawingResponseStatus[drawingName];
    }
    
    // Get the version stored for a drawing.  Returns the in-memory version
    // when loaded; falls back to peeking at the per-drawing cache (without
    // populating any other state).  Callers wanting full restore should use
    // loadDrawingDataFromStorage which returns the same version plus the
    // raw collections and data.
    getStoredVersion(drawingName, connectionId) {
        if (!drawingName) return null;
        const memVersion = this.drawingsData[drawingName]?.data?.version;
        if (memVersion) return memVersion;
        if (!connectionId) return null;
        try {
            const key = `pfodWeb_dwg_${connectionId}_${drawingName}`;
            const stored = localStorage.getItem(key);
            if (!stored) return null;
            return JSON.parse(stored).version || null;
        } catch (error) {
            console.error(`[DRAWING_MANAGER] getStoredVersion error for "${drawingName}":`, error);
            return null;
        }
    }
}

// Make DrawingManager available globally for class definition access
// IMPORTANT: Only pfodWeb should create instances of DrawingManager
// Other modules should use the instance provided by pfodWeb
window.DrawingManager = DrawingManager;/*   
   displayTextUtils.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Utility functions for display text formatting
// Extracted from add-item.js and redraw.js to be reusable across server and client code
//
// Exports:    window.printFloatDecimals, window.addFormattedValueToText,
//             window.generateItemDisplayText, window.getActualFontSizeForDialog,
//             window.convertColorToHex, window.substituteUnsupportedUnitsGlyphs
// Depends on: getColorValue() from redraw.js (optional fallback if absent)
// Called by:  redraw.js (generateItemDisplayText for label/value rendering),
//             pfodWebMouse.js (getActualFontSizeForDialog for touchActionInput dialogs)

// JavaScript implementation of printFloatDecimals based on C++ version
// prints just number rounded to decPlaces, -ve decPlaces round to left of decimal point
function printFloatDecimals(f, decPlaces) {
    if (f === undefined || f === null) {
        return '';
    }
    
    let isNegative = false;
    if (f < 0) {
        f = -f;
        isNegative = true;
    }
    
    let result = '';
    
    if (decPlaces <= 0) {
        let iValue = Math.floor(f);
        if ((f - iValue) !== 0) {
            // round
            iValue = Math.floor(f + 0.5);
        }
        
        if (decPlaces === 0) {
            result = iValue.toString();
        } else {
            // decPlaces < 0
            // limit divider to be < number so always get something
            let divider = 1;
            for (let i = 0; i < (-decPlaces) && (divider < iValue); i++) {
                divider = divider * 10;
            }
            if (divider > iValue) {
                divider = Math.floor(divider / 10);
            }
            let idValue = Math.floor(iValue / divider) * divider;
            if ((idValue - iValue) !== 0) {
                // need to round
                iValue = iValue + Math.floor(divider / 2);
                iValue = Math.floor(iValue / divider);
                idValue = iValue * divider;
            }
            result = idValue.toString();
        }
    } else {
        // decPlaces > 0
        result = f.toFixed(decPlaces);
    }
    
    return isNegative ? '-' + result : result;
}

// Roboto (used for both canvas text and HTML) has no glyphs for U+2103 (℃)
// or U+2109 (℉); Android's pfodApp renders these via their Unicode NFKD
// compatibility decomposition (℃ -> °C, ℉ -> °F) using the surrounding
// font's ordinary Latin glyphs. Substitute the same way here so pfodWeb
// matches pfodApp instead of falling back to a different system font.
function substituteUnsupportedUnitsGlyphs(units) {
    return units.replace(/℃/g, '°C').replace(/℉/g, '°F');
}

// Utility function to add formatted value to text (used by labels)
// Returns the text with formatted value and units appended if value exists
function addFormattedValueToText(text, item) {
    // Device-supplied text may itself contain ℃/℉ (e.g. a static scale label
    // with no attached value), not just the units field, so substitute here too.
    text = substituteUnsupportedUnitsGlyphs(text);
    if (item.value !== undefined && item.value !== null && item.value !== '') {
        const decimals = (item.decimals !== undefined && item.decimals !== null) ? parseInt(item.decimals) : 2;
        const units = substituteUnsupportedUnitsGlyphs(item.units || '');
        const formattedValue = printFloatDecimals(parseFloat(item.value), decimals);
        return text + formattedValue + units;
    }
    return text;
}

function generateItemDisplayText(item) {
    if (item.type === 'label') {
        // Label text generation: text + formatted value + units (if value exists)
        const text = item.text || '';
        return addFormattedValueToText(text, item);
    } else if (item.type === 'value') {
        // Value text generation: text + scaled/formatted intValue + units
        const textPrefix = substituteUnsupportedUnitsGlyphs(item.text || '');
        const intValue = parseFloat(item.intValue || 0);
        const max = parseFloat(item.max || 1);
        const min = parseFloat(item.min || 0);
        const displayMax = parseFloat(item.displayMax || 1.0);
        const displayMin = parseFloat(item.displayMin || 0.0);
        const decimals = (item.decimals !== undefined && item.decimals !== null) ? parseInt(item.decimals) : 2;
        const units = substituteUnsupportedUnitsGlyphs(item.units || '');

        // Scale the value (same logic as pfodWebMouse)
        let maxMin = max - min;
        if (maxMin === 0) maxMin = 1;  // Prevent division by zero
        const scaledValue = (intValue - min) * (displayMax - displayMin) / maxMin + displayMin;
        
        // Format and combine
        const formattedValue = printFloatDecimals(scaledValue, decimals);
        const displayText = textPrefix + formattedValue + units;
        
        return displayText;
    } else {
        // For other item types, just return the basic text
        return substituteUnsupportedUnitsGlyphs(item.text || item.textFormat || '');
    }
}

// Font size calculation for touchActionInput dialogs
// fontSize 0 = 14px for dialog boxes, with baseFontSize = 14
function getActualFontSizeForDialog(relativeFontSize) {
    // Matches Android pfodApp V2_ImageTextUpdate.getRelativeSize():
    //   each +6 step doubles size *linearly*, not exponentially.
    const baseFontSize = 14;
    const FONT_SIZES_PLUS = [1.0, 1.1225, 1.2599, 1.4142, 1.5874, 1.7818];

    const intFontSize = Math.round(relativeFontSize);
    const absSize = Math.abs(intFontSize);
    const multiple2 = Math.floor(absSize / 6);
    let relativeSize = FONT_SIZES_PLUS[absSize % 6];
    if (multiple2 > 0) {
        relativeSize *= 2 * multiple2;
    }
    if (intFontSize < 0) {
        relativeSize = 1.0 / relativeSize;
    }
    return baseFontSize * relativeSize;
}

// Color conversion function for touchActionInput dialogs
// Converts color index to hex color value
function convertColorToHex(colorIndex) {
    // Check if colorUtils is available and has the conversion function
    if (typeof getColorValue === 'function') {
        return getColorValue(colorIndex);
    }
    
    // Fallback color mapping for basic colors
    const colorMap = {
        0: '#000000',   // Black
        1: '#800000',   // Maroon
        2: '#008000',   // Green
        3: '#808000',   // Olive
        4: '#000080',   // Navy
        5: '#800080',   // Purple
        6: '#008080',   // Teal
        7: '#C0C0C0',   // Silver
        8: '#808080',   // Gray
        9: '#FF0000',   // Red
        10: '#00FF00',  // Lime
        11: '#FFFF00',  // Yellow
        12: '#0000FF',  // Blue
        13: '#FF00FF',  // Fuchsia
        14: '#00FFFF',  // Aqua
        15: '#FFFFFF'   // White
    };
    
    return colorMap[colorIndex] || '#000000';
}

// Calculate the number of decimal places needed so that one raw count
// produces a visible change in the displayed (scaled) value.
// rawRange and displayRange are both max-min (not just max).
// If the fractional part of -log10(oneCount) is < 0.3 use floor, else ceil.
// Minimum returned value is 1.
function calcDisplayDecimalPlaces(rawRange, displayRange) {
    const absRaw     = Math.abs(rawRange);
    const absDisplay = Math.abs(displayRange);
    if (absRaw === 0 || absDisplay === 0) return 1;
    const oneCount = absDisplay / absRaw;
    const log  = -Math.log10(oneCount);
    const frac = log - Math.floor(log);   // fractional part, always in [0, 1)
    const dec  = (frac < 0.3) ? Math.floor(log) : Math.ceil(log);
    return Math.max(1, dec);
}

// Export for browser (client-side) - no longer needed server-side
if (typeof window !== 'undefined') {
    window.printFloatDecimals = printFloatDecimals;
    window.addFormattedValueToText = addFormattedValueToText;
    window.generateItemDisplayText = generateItemDisplayText;
    window.getActualFontSizeForDialog = getActualFontSizeForDialog;
    window.convertColorToHex = convertColorToHex;
    window.calcDisplayDecimalPlaces = calcDisplayDecimalPlaces;
    window.substituteUnsupportedUnitsGlyphs = substituteUnsupportedUnitsGlyphs;
}/*   
   redraw.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Redraw module — canvas drawing operations, coordinate transforms, and drawing rendering.
// Owns its own DrawingManager (redrawDrawingManager) holding the live display state.
//
// Exports:    window.Redraw class, window.getActualFontSize(relativeFontSize) function,
//             window.pfodColorTagToHex(tag) function, window.PFOD_COLOR_NAME_TO_INDEX map,
//             window.getColorValue(index) function
// Depends on: DrawingManager (creates this.redrawDrawingManager internally),
//             displayTextUtils.js (generateItemDisplayText for label/value rendering)
// Called by:  pfodWeb.js constructor (new window.Redraw(canvas, ctx, dims) → this.redraw),
//             resizeAndDimensions.js (resizeCanvas, performRedraw),
//             requestQueue.js / drawingProcessing.js (performRedraw after each
//                                  response batch, via DrawingMerger.mergeAllDrawings),
//             pfodMenuParser.js / pfodButtonRenderer.js (getActualFontSize, pfodColorTagToHex)

// Convert relative fontSize to actual pixel size
// fontSize 0 → baseFontSize (≈2.832 in dwg-col-units); +1 → ×1.1225; -1 → ÷1.1225.
// +6 doubles size, -6 halves size.  relativeFontSize must be an integer.
function getActualFontSize(relativeFontSize) {
    // Matches Android pfodApp V2_ImageTextUpdate / V2_ImageValueUpdate exactly:
    //   each +6 step doubles size *linearly* (×2, ×4, ×6, ×8, ...) — not exponentially —
    //   and the sub-step lookup covers the fractional 0..5 portion within each doubling band.
    //
    // The base value `char20TextSize × DEFAULT_TEXT_COLS_WIDTH / 1024` (= 58 × 50 / 1024 ≈
    // 2.832) is Android's per-dwg-col font height, derived as paintTextSize ÷ pixels-per-col
    // from V2_ImageTextUpdate.java:178,186,215.  Algebraically the device's screen width
    // (x_cols) and the dwg's column count (imageCols) cancel out, so the value is constant
    // and produces text identical in size to Android relative to the dwg outline — no
    // matter the dwg dimensions or the canvas pixel size.
    const baseFontSize = 58 * 50 / 1024;
    const FONT_SIZES_PLUS = [1.0, 1.1225, 1.2599, 1.4142, 1.5874, 1.7818];

    const intFontSize = Math.round(relativeFontSize);
    const absSize = Math.abs(intFontSize);
    const multiple2 = Math.floor(absSize / 6);
    let relativeSize = FONT_SIZES_PLUS[absSize % 6];
    if (multiple2 > 0) {
        relativeSize *= 2 * multiple2;
    }
    if (intFontSize < 0) {
        relativeSize = 1.0 / relativeSize;
    }
    return baseFontSize * relativeSize;
}

// Import formatting utilities
// Note: printFloatDecimals and addFormattedValueToText are now in displayTextUtils.js

// Get appropriate black or white color based on background contrast
function getBlackWhite(color) {
    // Convert color to RGB values
    function getRGB(color) {
        // Handle hex colors - '#RRGGBB' (CSS form) or bare 'RRGGBB' (pfod wire form)
        if (typeof color === 'string' && (color.startsWith('#') || /^[0-9A-Fa-f]{6}$/.test(color))) {
            const hex = color.startsWith('#') ? color.slice(1) : color;
            const r = parseInt(hex.substr(0, 2), 16);
            const g = parseInt(hex.substr(2, 2), 16);
            const b = parseInt(hex.substr(4, 2), 16);
            return [r, g, b];
        }

        // Handle color numbers - convert to hex first, then to RGB using xtermColorToHex
        const hexColor = xtermColorToHex(color);
        const hex = hexColor.slice(1);
        const r = parseInt(hex.substr(0, 2), 16);
        const g = parseInt(hex.substr(2, 2), 16);
        const b = parseInt(hex.substr(4, 2), 16);
        return [r, g, b];
    }
    
    const [r, g, b] = getRGB(color);
    
    // Use the same algorithm as Java code: y = (299 * R + 587 * G + 114 * B) / 1000
    const y = (299 * r + 587 * g + 114 * b) / 1000;
    
    // If y >= 128, background is light, use black text. Otherwise use white text.
    return y >= 128 ? 0 : 15; // BLACK (0) : WHITE (15)
}

// Convert xterm 256 color index to RGB hex color
function xtermColorToHex(colorIndex) {
    if (typeof colorIndex !== 'number' || colorIndex > 255 || colorIndex < 0) {
        throw new Error(`[xtermColorToHex] invalid colorIndex: ${colorIndex} (must be number 0-255)`);
    }
    colorIndex = Math.floor(colorIndex);
    
    let r, g, b;
    
    if (colorIndex < 16) {
        // Standard colors (0-15)
        const standardColors = [
            [0, 0, 0],       // 0: Black
            [128, 0, 0],     // 1: Maroon
            [0, 128, 0],     // 2: Green
            [128, 128, 0],   // 3: Olive
            [0, 0, 128],     // 4: Navy
            [128, 0, 128],   // 5: Purple
            [0, 128, 128],   // 6: Teal
            [192, 192, 192], // 7: Silver
            [128, 128, 128], // 8: Grey
            [255, 0, 0],     // 9: Red
            [0, 255, 0],     // 10: Lime
            [255, 255, 0],   // 11: Yellow
            [0, 0, 255],     // 12: Blue
            [255, 0, 255],   // 13: Fuchsia
            [0, 255, 255],   // 14: Aqua
            [255, 255, 255]  // 15: White
        ];
        [r, g, b] = standardColors[colorIndex];
        
    } else if (colorIndex >= 16 && colorIndex <= 231) {
        // 216 color cube (16-231)
        const cubeIndex = colorIndex - 16;
        const cubeValues = [0, 95, 135, 175, 215, 255];
        
        const rIndex = Math.floor(cubeIndex / 36);
        const gIndex = Math.floor((cubeIndex % 36) / 6);
        const bIndex = cubeIndex % 6;
        
        r = cubeValues[rIndex];
        g = cubeValues[gIndex];
        b = cubeValues[bIndex];
        
    } else {
        // Grayscale ramp (232-255)
        const grayIndex = colorIndex - 232;
        const grayValue = 8 + grayIndex * 10;
        r = g = b = grayValue;
    }
    
    const toHex = (value) => {
        const hex = value.toString(16).toUpperCase();
        return hex.length === 1 ? '0' + hex : hex;
    };
    
    return '#' + toHex(r) + toHex(g) + toHex(b);
}

// pfod short colour names and their xterm palette indices (0-15).
// Used by pfodColorTagToHex() to resolve named colours from menu/drawing format codes.
const PFOD_COLOR_NAME_TO_INDEX = {
  'bk': 0, 'm': 1,  'g':  2,  'o':  3,
  'n':  4, 'p': 5,  't':  6,  's':  7,
  'gy': 8, 'r': 9,  'l':  10, 'y':  11,
  'bl': 12,'f': 13, 'a':  14, 'w':  15
};

/**
 * Resolve a pfod colour tag string to a CSS hex colour.
 * Handles:
 *   - Named colours: bk m g o n p t s gy r l y bl f a w
 *   - 6-char hex strings: RRGGBB
 *   - 256-palette numbers: 0-255 (via xtermColorToHex)
 * Returns null for unrecognised input.
 *
 * @param {string} s - colour string from inside a pfod <tag>, e.g. "bl", "FF0000", "12"
 * @returns {string|null} CSS hex colour or null
 */
function pfodColorTagToHex(s) {
  if (!s) return null;
  s = s.trim();
  if (Object.prototype.hasOwnProperty.call(PFOD_COLOR_NAME_TO_INDEX, s)) {
    return xtermColorToHex(PFOD_COLOR_NAME_TO_INDEX[s]);
  }
  if (/^[0-9A-Fa-f]{6}$/.test(s)) return '#' + s.toUpperCase();
  const n = parseInt(s, 10);
  if (!isNaN(n) && n >= 0 && n <= 255) return xtermColorToHex(n);
  return null;
}

// Convert color value to hex - supports integers (0-255) and RRGGBB hex strings
function convertColorToHex(color, backgroundColorNumber = null) {
    // Handle Black/White mode (color -1)
    if (color === -1 && backgroundColorNumber !== null) {
        const blackWhiteColor = getBlackWhite(backgroundColorNumber);
        return xtermColorToHex(blackWhiteColor);
    }

    // 6-char RRGGBB hex string (bare, no '#' — matches pfod <RRGGBB> tag format)
    if (typeof color === 'string' && /^[0-9A-Fa-f]{6}$/.test(color)) {
        return '#' + color.toUpperCase();
    }

    // Support both integer colors and string numbers
    if (typeof color === 'number') {
        if (color < 0 || color > 255) {
            throw new Error(`[convertColorToHex] color index out of range: ${color}`);
        }
        return xtermColorToHex(color);
    }
    if (typeof color === 'string' && !isNaN(color)) {
        const n = parseInt(color, 10);
        if (isNaN(n) || n < 0 || n > 255) {
            throw new Error(`[convertColorToHex] color string out of range: "${color}"`);
        }
        return xtermColorToHex(n);
    }
    throw new Error(`[convertColorToHex] unrecognised color value: ${color}`);
}

// Build a canvas font string from style flags and a pixel size.
function _buildCanvasFontStyle(bold, italic, sizePx) {
    let s = '';
    if (italic) s += 'italic ';
    if (bold)   s += 'bold ';
    return s + sizePx + 'px Roboto, Arial, sans-serif';
}

/**
 * Decode pfod escape sequences in a text segment.  Shared by every pfod-text
 * renderer (dwg canvas labels/values here in redraw.js, DOM-based buttons/
 * labels/prompts in pfodButtonRenderer.js's pfodSetFormattedText).  Defined
 * here because redraw.js loads before pfodButtonRenderer.js in the bundle.
 * &amp; is decoded last so &amp;lt; produces &lt; (literal) not < (tag opener).
 *
 * @param {string} str
 * @returns {string}
 */
function decodeEscapes(str) {
    if (!str || str.indexOf('&') === -1) return str;
    return str
        .replace(/&#96;/g,  '`')
        .replace(/&#123;/g, '{')
        .replace(/&#124;/g, '|')
        .replace(/&#125;/g, '}')
        .replace(/&#126;/g, '~')
        .replace(/&lt;/g,   '<')
        .replace(/&#92;/g,  '\\')
        .replace(/&amp;/g,  '&');
}

/**
 * Markdown link in pfod text: `[text](url)`.
 *
 * Group 1 is the link text — anything between the brackets that contains no
 * bracket, so inline format tags inside it are fine and nested [ ] is not.
 * Group 2 is the url, and it MUST begin `http://`, `https://` or a single `/`
 * (a page on the device's own web root — see pfodLinkHref in
 * pfodButtonRenderer.js).  That one constraint is what keeps ordinary prose
 * safe ("Battery [12] (%)" has [..](..) but "%" is not a url) and is the
 * security boundary (javascript: never matches).  `//host/x` is excluded by
 * the (?!\/) so a link is either a full url or a device path, never a
 * scheme-relative third thing.  The url runs to the closing `)` and so
 * cannot contain spaces or parentheses.
 *
 * Only pfodSetFormattedText renders these as links, and only when its caller
 * allows it (menu labels and the prompt bars).  Everywhere else — buttons,
 * drawing text — the text is shown exactly as the device sent it, brackets
 * and all.  Defined here because redraw.js loads before
 * pfodButtonRenderer.js in the bundle.
 */
const PFOD_MD_LINK_RE = /\[([^\[\]]+)\]\(((?:https?:\/\/|\/(?!\/))[^\s()]+)\)/g;

/**
 * Parse pfod inline format tags from text and return a flat array of styled segments.
 * Segment shape: {text, bold, italic, underline, deltaSize, color}
 * Tags: <b> <i> <u> <+N> <-N> colour-name/hex/index tags; </tag> closes matching open tag.
 * Unrecognised tags are left as literal text.  Open tags auto-terminate at end of string.
 * Text within each segment has pfod escape sequences (&#96; &#123; &#124; &#125;
 * &#126; &lt; &#92; &amp;) decoded — dwg labels/text-displays are automatically
 * escaped by the pfodDevice, so this must be reversed before drawing on the canvas.
 *
 * @param {string} rawText
 * @param {{bold?:boolean, italic?:boolean, underline?:boolean}} [baseStyle]
 * @returns {{text:string, bold:boolean, italic:boolean, underline:boolean, deltaSize:number, color:string|null}[]}
 */
function parsePfodInlineSegments(rawText, baseStyle) {
    const base  = baseStyle || {};
    const stack = [];

    function currentStyle() {
        let bold = !!base.bold, italic = !!base.italic, underline = !!base.underline;
        let deltaSize = 0, color = null;
        for (const e of stack) {
            if (e.bold)                    bold      = true;
            if (e.italic)                  italic    = true;
            if (e.underline)               underline = true;
            if (e.deltaSize !== undefined) deltaSize += e.deltaSize;
            if (e.color      !== undefined) color    = e.color;
        }
        return { bold, italic, underline, deltaSize, color };
    }

    function parseTag(inner) {
        if (inner === 'b')  return { bold: true };
        if (inner === 'i')  return { italic: true };
        if (inner === 'u')  return { underline: true };
        if (/^\+\d+$/.test(inner)) return { deltaSize:  parseInt(inner.substring(1), 10) };
        if (/^-\d+$/.test(inner))  return { deltaSize: -parseInt(inner.substring(1), 10) };
        if (inner.startsWith('bg ')) return null;
        const hex = pfodColorTagToHex(inner);
        if (hex) return { color: hex };
        return null;
    }

    const segs = [];
    let i = 0, segStart = 0;

    while (i < rawText.length) {
        if (rawText[i] !== '<') { i++; continue; }
        const close = rawText.indexOf('>', i + 1);
        if (close === -1) { i++; continue; }
        const inner = rawText.substring(i + 1, close);

        if (inner.startsWith('/')) {
            const name = inner.substring(1).trim();
            let found = -1;
            for (let j = stack.length - 1; j >= 0; j--) {
                if (stack[j].tag === name) { found = j; break; }
            }
            if (found !== -1) {
                const txt = decodeEscapes(rawText.substring(segStart, i));
                if (txt) segs.push(Object.assign({ text: txt }, currentStyle()));
                segStart = close + 1;
                stack.splice(found);
            }
        } else {
            const parsed = parseTag(inner);
            if (parsed !== null) {
                const txt = decodeEscapes(rawText.substring(segStart, i));
                if (txt) segs.push(Object.assign({ text: txt }, currentStyle()));
                segStart = close + 1;
                parsed.tag = inner;
                stack.push(parsed);
            }
        }
        i = close + 1;
    }

    const tail = decodeEscapes(rawText.substring(segStart));
    if (tail) segs.push(Object.assign({ text: tail }, currentStyle()));
    return segs;
}

// Split a flat array of segments (which may contain '\n' in their text) into
// an array of lines, each line being an array of segments with no '\n'.
function _splitSegmentsToLines(segments) {
    const lines = [[]];
    for (const seg of segments) {
        const parts = seg.text.split('\n');
        for (let p = 0; p < parts.length; p++) {
            if (p > 0) lines.push([]);
            if (parts[p]) lines[lines.length - 1].push(Object.assign({}, seg, { text: parts[p] }));
        }
    }
    return lines;
}

class Redraw {
    constructor(initialDimensions = null) {
        // canvas and ctx are set transiently by _withMenuCanvas during per-item rendering

        // Local drawing manager for redraw operations
        this.redrawDrawingManager = new window.DrawingManager();

        // Original data holder - stores pristine copy for restoration
        this.originalDataManager = new window.DrawingManager();

        // Drawing state
        this.currentBackgroundColor = 0; // Store current drawing background color for Black/White mode

        // Canvas caching for optimization
        this.cachedCanvasWidth = 0;
        this.cachedCanvasHeight = 0;
        this.hasCompletedFirstDraw = false;

        // Per-item canvases for menu-mode: drawingName → {canvas, ctx}
        this._menuCanvases = {};

        // Track last dimensions for resize optimization
        // Initialize from loaded dimensions if provided
        if (initialDimensions) {
            this.lastWindowWidth = initialDimensions.windowWidth;
            this.lastWindowHeight = initialDimensions.windowHeight;
            console.log(`[REDRAW] Initialized with dimensions: window=${this.lastWindowWidth}x${this.lastWindowHeight}`);
        } else {
            this.lastWindowWidth = null;
            this.lastWindowHeight = null;
        }
    }

    // Redraw uses its own local data - no external configuration needed

    // Get global display transform for merged canvas
    getGlobalTransform() {
        if (!this.redrawDrawingManager.globalTransform) {
            throw new Error('[REDRAW] getGlobalTransform: globalTransform not set on redrawDrawingManager');
        }
        return this.redrawDrawingManager.globalTransform;
    }

    // Set global display transform for merged canvas
    setGlobalTransform(transform) {
        this.redrawDrawingManager.globalTransform = { ...transform };
    }

    // (Removed: getCurrentDrawingName — no privileged "current" drawing.
    // Callers needing a per-canvas drawing name should reference the
    // menu item's loadCmd directly via pfodMenuDisplay.)

    // Create backup of current merged-collections data for touchAction
    // restoration.  Each backup is keyed to a single menuDwg (set by the
    // proxy override in pfodWebMouse.setupMenuCanvasListeners) and snapshots
    // ONLY that menuDwg's allXXX[name] entries — the per-drawing raw
    // collections aren't modified by touchActions, so they don't need
    // capturing.
    //
    // Restore happens on response receipt (not on touch-up); the backup
    // persists across the network round-trip until the response handler
    // restores allXXX[drawingName] to the snapshot then re-merges.
    //
    // This base implementation returns empty placeholders for the five
    // allXXX maps; the proxy override fills them with the touched
    // drawing's data.
    makeBackup() {
        if (!this.redrawDrawingManager) {
            console.info(`[TOUCH_ACTION] this.redrawDrawingManager is undefined - cannot create backup!`);
            return null;
        }
        // No drawingName field — the menuDwg loadCmd is recovered from the
        // request cmd in the response handler (via _resolveLoadCmdFromRequest)
        // and from this._menuDrawingName / drawingName-parameter inside
        // pfodWebMouse handlers.
        return {
            allTouchZonesByCmd:        {},
            allTouchActionsByCmd:      {},
            allTouchActionInputsByCmd: {},
            allUnindexedItems:         {},
            allIndexedItemsByNumber:   {}
        };
    }


    // Public interface for touch action redraws with pseudo response merging
    redrawForTouchAction(pseudoResponse) {
        console.log(`[REDRAW] TouchAction redraw - processing pseudo response and merging`);
        console.log(`[REDRAW] TouchAction merging pseudo response with ${pseudoResponse.items.length} items`);

        // Process the pseudo response directly on current redrawDrawingManager
        if (window.drawingViewer && window.drawingViewer.drawingDataProcessor) {
            window.drawingViewer.drawingDataProcessor.processDrawingData(pseudoResponse, this.redrawDrawingManager, null, 'touchAction');
        }

        // Use DrawingMerger to merge all drawings including the pseudo updates
        const drawingMerger = new window.DrawingMerger(this.redrawDrawingManager);
        drawingMerger.mergeAllDrawings();

        // Trigger redraw with updated data
        this.performRedraw();
    }

    // Public interface for normal redraws
//    redrawForNormal() {
//        console.log(`[REDRAW] Normal redraw - restoring original data`);

//        // Restore original data before redrawing
//        this.restoreFromOriginalData();
//    }

    // Direct redraw with working copy — used by touchActions to avoid extra
    // processing.  drawingName names the menuItemDwg whose per-item canvas
    // should receive the render; it is the loadCmd of the menu's drawing item.
    redrawWithWorkingCopy(workingCopy, drawingName) {
        if (!drawingName) {
            throw new Error('[REDRAW] redrawWithWorkingCopy: drawingName is required (the menu item loadCmd to render into)');
        }
        console.log(`[REDRAW] Direct redraw with working copy - avoiding extra processing`);
        console.log(`[REDRAW] Working copy data: unindexed=${workingCopy.allUnindexedItems.length}, indexed=${Object.keys(workingCopy.allIndexedItemsByNumber).length}, touchZones=${Object.keys(workingCopy.allTouchZonesByCmd).length}`);

        const drawingData = this.redrawDrawingManager.drawingsData[drawingName];
        if (!drawingData) throw new Error(`[REDRAW] redrawWithWorkingCopy: no drawing data for "${drawingName}"`);
        const backgroundColor = drawingData.data.color;
        console.log(`[REDRAW] Using background color: ${backgroundColor} for drawing: ${drawingName}`);

        // Route to the correct per-item canvas
        console.log(`[REDRAW] Calling redrawCanvasImpl with working copy data`);
        this._withMenuCanvas(drawingName, () => {
            this.redrawCanvasImpl(workingCopy.allUnindexedItems, workingCopy.allIndexedItemsByNumber, workingCopy.allTouchZonesByCmd, backgroundColor);
        });
        console.log(`[REDRAW] redrawCanvasImpl completed`);
    }

    /**
     * Redraw in a specific body-class mode (e.g. 'menu-mode').
     *
     * Operates on the fully-merged menuDwg keyed by `drawingName`:
     * the per-menuDwg merged collections produced by
     * DrawingMerger.mergeAllDrawings() and stored on the live
     * DrawingManager as
     *     dm.allUnindexedItems[drawingName]
     *     dm.allIndexedItemsByNumber[drawingName]
     *     dm.allTouchZonesByCmd[drawingName]
     * Each menu canvas owns one menuDwg root; every `insertDwg` child
     * (e.g. c1 -> c2, c3) has been recursively expanded into that root's
     * merged tree with composed transforms, so the renderer never sees
     * a raw `insertDwg` item.
     * @param {string} mode - Expected body class
     * @param {string} drawingName - menuItemDwg loadCmd whose per-item canvas
     *                               should receive the render. REQUIRED — a
     *                               menu has zero or more drawing items, no
     *                               privileged "main" drawing to fall back to.
     */
    performRedrawInMode(mode, drawingName) {
        if (!drawingName) {
            throw new Error(`[REDRAW] performRedrawInMode: drawingName is required (the menu item loadCmd to render). mode="${mode}"`);
        }
        if (document.body.className !== mode) {
            console.log(`[REDRAW] performRedrawInMode(${mode}) skipped - current mode: ${document.body.className}`);
            return;
        }
        const name = drawingName;
        const drawingData = this.redrawDrawingManager.drawingsData[name];
        // drawingData exists (registered by addInsertedDrawing) but .data is
        // still null until the device's drawing response actually arrives.
        // Show nothing while waiting — pfodMenuDisplay.handleMenuResize hides
        // the canvas entirely in this state.  Painting a default-sized blue
        // "Loading Drawing..." rectangle here used to cause a visible flash
        // before the actual dwg dimensions were known.
        if (!drawingData || !drawingData.data) {
            console.log(`[REDRAW] performRedrawInMode: no drawing data for "${name}" — skipping paint (canvas hidden)`);
            return;
        }
        const backgroundColor = drawingData.data.color;
        const logicalWidth = Math.min(Math.max(drawingData.data.x, 1), 255);
        const logicalHeight = Math.min(Math.max(drawingData.data.y, 1), 255);

        // Read the merged item set produced by DrawingMerger.mergeAllDrawings()
        // — this drawing's tree fully expanded (every `insertDwg` recursively
        // replaced by the target drawing's items with composed transforms),
        // so the renderer never sees a raw `insertDwg` and drawInsertDwg's
        // "Should not be drawing" warning never fires.
        // The raw per-drawing fallback is only used pre-merge, before the
        // merger has run.
        const dm = this.redrawDrawingManager;
        const hasMerged = dm.allUnindexedItems && dm.allUnindexedItems[name] !== undefined;
        const unindexed  = hasMerged ? dm.allUnindexedItems[name]       : (dm.unindexedItems[name]   || []);
        const indexed    = hasMerged ? dm.allIndexedItemsByNumber[name] : (dm.indexedItems[name]     || {});
        const touchZones = hasMerged ? dm.allTouchZonesByCmd[name]      : (dm.touchZonesByCmd[name]  || {});
        this._withMenuCanvas(name, () => {
            // Ensure scaleX/scaleY are set on the per-item canvas before rendering.
            // handleMenuResize sets them on resize events, but performRedraw
            // may fire before the first resize — set them here too.
            if (this.canvas.width > 0 && this.canvas.height > 0) {
                this.canvas.scaleX = this.canvas.width / logicalWidth;
                this.canvas.scaleY = this.canvas.height / logicalHeight;
            }
            this.redrawCanvasImpl(unindexed, indexed, touchZones, backgroundColor);
        });
    }

    performRedraw() {
        // In menu-mode, redraw every menu drawing into its own per-item canvas
        if (document.body.className === 'menu-mode') {
            for (const dwgName of this.redrawDrawingManager.drawings) {
                this.performRedrawInMode('menu-mode', dwgName);
            }
            return;
        }
        // No main canvas in other modes — nothing to redraw
    }

    // (Removed: canvas-mode `redrawCanvas(...)` method — canvas-mode no longer
    // exists.  Menu-mode rendering goes through performRedrawInMode(), which
    // reads the per-menuDwg merged collections populated by
    // DrawingMerger.mergeAllDrawings() on drawingManager.allXXX[name].)

    // Get current state for debugging
    getState() {
        return {
            hasCompletedFirstDraw: this.hasCompletedFirstDraw,
            registeredDrawings: [...this.redrawDrawingManager.drawings]
        };
    }

    /**
     * Register a per-item menu canvas so performRedrawInMode renders to it.
     * @param {string} drawingName
     * @param {HTMLCanvasElement} canvas
     * @param {CanvasRenderingContext2D} ctx
     */
    setMenuCanvas(drawingName, canvas, ctx) {
        this._menuCanvases[drawingName] = { canvas, ctx };
    }

    /** Remove all per-item menu canvas registrations. */
    clearMenuCanvases() {
        this._menuCanvases = {};
    }

    /**
     * Temporarily swap this.canvas/this.ctx to the per-item canvas for drawingName,
     * call fn(), then restore. Falls through to fn() unchanged if no entry exists.
     * @param {string} drawingName
     * @param {function} fn
     */
    _withMenuCanvas(drawingName, fn) {
        const entry = this._menuCanvases[drawingName];
        if (entry) {
            const savedCanvas = this.canvas;
            const savedCtx = this.ctx;
            this.canvas = entry.canvas;
            this.ctx = entry.ctx;
            fn();
            this.canvas = savedCanvas;
            this.ctx = savedCtx;
        }
        // If no per-item canvas registered for this drawing, skip rendering
    }

    // Main canvas redraw implementation
    redrawCanvasImpl(allUnindexedItems, allIndexedItemsByNumber, allTouchZonesByCmd, backgroundColor = 0) {
        console.log(`[REDRAW] Starting redraw for canvas, size=${this.canvas.width}x${this.canvas.height} at ${new Date().toISOString()}`);
        console.log(`[REDRAW_DEBUG] Redraw inputs - unindexed: ${allUnindexedItems.length}, indexed keys: [${Object.keys(allIndexedItemsByNumber).join(', ')}], touchZones: [${Object.keys(allTouchZonesByCmd).join(', ')}]`);
        
        // Check if canvas size has changed or this is the first draw
        const sizeChanged = !this.hasCompletedFirstDraw || this.cachedCanvasWidth !== this.canvas.width || this.cachedCanvasHeight !== this.canvas.height;
        
        console.log(`[REDRAW] Proceeding with redraw, using passed drawing data and merged items`);
        
        // Clear canvas - use cached dimensions after first draw if size hasn't changed
        const rawBackgroundColor = backgroundColor;
        this.currentBackgroundColor = rawBackgroundColor; // Store for Black/White color mode
        const backgroundColorHex = convertColorToHex(rawBackgroundColor);
        console.log(`[REDRAW] Setting canvas background color to: ${backgroundColorHex} (from raw: ${rawBackgroundColor})`);
        this.ctx.fillStyle = backgroundColorHex;
        this.ctx.strokeStyle = backgroundColorHex;
        this.ctx.lineWidth = 2; 
        if (this.hasCompletedFirstDraw && !sizeChanged) {
            // Use cached dimensions if they exist and size hasn't changed
            //this.drawRoundedRectangle(0, 0, this.cachedCanvasWidth, this.cachedCanvasHeight, 10, true);
            console.log(`[REDRAW] Using cached dimensions: ${this.cachedCanvasWidth}x${this.cachedCanvasHeight}`);
        } else {
            // Use current canvas dimensions and update cache
            this.cachedCanvasWidth = this.canvas.width;
            this.cachedCanvasHeight = this.canvas.height;
            this.hasCompletedFirstDraw = true;
            //this.drawRoundedRectangle(0, 0, this.cachedCanvasWidth, this.cachedCanvasHeight, 10, true);
            console.log(`[REDRAW] Canvas size changed or first draw - updated cached dimensions to ${this.cachedCanvasWidth}x${this.cachedCanvasHeight}`);
        }
        this.ctx.fillRect(0, 0, this.cachedCanvasWidth, this.cachedCanvasHeight);
//        this.ctx.strokeStyle = "#FFFFFF";
//        this.drawRoundedRectangle(0, 0, this.cachedCanvasWidth, this.cachedCanvasHeight, 20, false);
//        this.ctx.strokeStyle = "#000000";
//        this.drawRoundedRectangle(2, 2, this.cachedCanvasWidth-4, this.cachedCanvasHeight-4, 20, false);
        
        this.ctx.strokeStyle = backgroundColor;

        console.log(`[REDRAW] Drawing ${allUnindexedItems.length} merged unindexed items`);
        
        // Debug: log each unindexed item
        for (let i = 0; i < allUnindexedItems.length; i++) {
            const item = allUnindexedItems[i];
            console.log(`[REDRAW] DEBUG: Unindexed item ${i}: type=${item.type}, drawingName=${item.drawingName || 'none'}, transform=(${item.transform.x},${item.transform.y}), scale=${item.transform.scale}`);
        }
        
        // Handle case where no items to draw
        if (allUnindexedItems.length === 0) {
            console.log(`[REDRAW] No unindexed items to draw.`);
        }
        
        // Draw all merged unindexed items in order
        allUnindexedItems.forEach((item, index) => {
            const drawingSource = item.parentDrawingName || 'unknown';
            console.log(`[REDRAW] Drawing unindexed item ${index} of type ${item.type} from ${drawingSource} with color ${item.color}`);
            if (item.transform) {
                console.log(`[REDRAW] Item transform: x=${item.transform.x}, y=${item.transform.y}, scale=${item.transform.scale}`);
            } else {
                console.log(`[REDRAW] Item has no transform!`);
            }
            this.drawItem(item);
        });

        // Draw all indexed items in order of their indices
        const sortedIndices = Object.keys(allIndexedItemsByNumber)
            .map(idx => parseInt(idx))
            .filter(idx => !isNaN(idx))
            .sort((a, b) => a - b);

        console.log(`[REDRAW] Drawing items with ${sortedIndices.length} different indices`);
        sortedIndices.forEach(idx => {
            const itemWithIndex = allIndexedItemsByNumber[idx];
            const drawingSource = itemWithIndex.parentDrawingName || 'unknown';
            console.log(`[REDRAW] Drawing indexed item ${idx} of type ${itemWithIndex.type} from ${drawingSource}`);
            console.log(`[REDRAW_INDEXED_DEBUG] Item ${idx} full data:`, JSON.stringify(itemWithIndex, null, 2));
            if (itemWithIndex.transform) {
                console.log(`[REDRAW] Indexed item transform: x=${itemWithIndex.transform.x}, y=${itemWithIndex.transform.y}, scale=${itemWithIndex.transform.scale}`);
            } else {
                console.log(`[REDRAW] Indexed item has no transform!`);
            }
            this.drawItem(itemWithIndex);
        });

        Object.keys(allTouchZonesByCmd).forEach(cmd => {
            const touchZone = allTouchZonesByCmd[cmd];
            const drawingSource = touchZone.parentDrawingName || 'unknown';
            console.log(`[REDRAW] Drawing touchZone item ${cmd} from ${drawingSource}`);
            if (touchZone.transform) {
                console.log(`[REDRAW] TouchZone transform: x=${touchZone.transform.x}, y=${touchZone.transform.y}, scale=${touchZone.transform.scale}`);
            } else {
                console.log(`[REDRAW] TouchZone item has no transform!`);
            }
            this.drawItem(touchZone);
        });

        
        console.log(`[REDRAW] Canvas redraw completed at ${new Date().toISOString()}`);
        console.log(`[REDRAW] Final item counts: ${allUnindexedItems.length} unindexed, ${sortedIndices.length} different indices`);
    }


    // Draw a single item implementation
    drawItem(itemToDraw) {
        if (!itemToDraw || !itemToDraw.type) {
            console.error('Invalid item with missing or undefined type:', itemToDraw);
            return;
        }
        const item = {...itemToDraw};
        // protect transform
        const itemTransform = {...itemToDraw.transform};
        item.transform = itemTransform;
        const itemClipRegion = {...itemToDraw.clipRegion};
        item.clipRegion = itemClipRegion;

        try {
            console.log(`[DRAWING] Drawing item of type: ${item.type}`, JSON.stringify(item));
            
            // Check if item is visible
            if (item.visible === false) {
                console.log(`Skipping draw for invisible item of type: ${item.type}, idx: ${item.idx || 'none'}, cmd: ${item.cmd || 'none'}`);
                return;
            }
            
            // Skip items that should have been processed in pfodWeb.js
            if (item.type === 'hide' || item.type === 'unhide' || item.type == 'push' || item.type == 'pop' || item.type == 'erase') {
                console.warn(`WARNING: ${item.type} item should be processed in pfodWeb.js and not passed to drawing layer!`);
                return;
            }
            
            // Save canvas state (including clipping)
            this.ctx.save();
            
            // Apply clipping if clipRegion is provided and has valid properties
            if (item.clipRegion && typeof item.clipRegion.x === 'number' && typeof item.clipRegion.width === 'number') {
                // Use pre-calculated clip region
                console.log(`Using pre-calculated clip region: (${item.clipRegion.x}, ${item.clipRegion.y}, ${item.clipRegion.width}, ${item.clipRegion.height})`);
                
                // Convert logical coordinates to canvas pixel coordinates
                const scaledX = item.clipRegion.x * this.canvas.scaleX;
                const scaledY = item.clipRegion.y * this.canvas.scaleY;
                const scaledWidth = item.clipRegion.width * this.canvas.scaleX;
                const scaledHeight = item.clipRegion.height * this.canvas.scaleY;
                
                // Apply clipping rectangle
                this.ctx.beginPath();
                this.ctx.rect(Math.round(scaledX), Math.round(scaledY), Math.round(scaledWidth), Math.round(scaledHeight));
                this.ctx.clip();
                
                // Optionally draw the clip region for debugging
               // this.ctx.strokeStyle = 'rgba(0,255,0,0.3)'; // Use green for clip regions
               // this.ctx.strokeRect(Math.round(scaledX), Math.round(scaledY), Math.round(scaledWidth), Math.round(scaledHeight));
                
                console.log(`Applied pre-calculated clip region: (${scaledX}, ${scaledY}, ${scaledWidth}, ${scaledHeight})`);
            }
            
            // Set default color for drawing
            if (item.color === undefined) {
              item.color = -1;
            }
            const hexColor = convertColorToHex(item.color, this.currentBackgroundColor);
            this.ctx.fillStyle = hexColor;
            this.ctx.strokeStyle = hexColor;
            // Dispatch to specific drawing functions based on type
            switch (item.type.toLowerCase()) {
                case 'line':
                    this.drawLine(item);
                    break;
                case 'rectangle':
                    console.log('Drawing rectangle item with:', 
                        `xOffset: ${item.xOffset} yOffset: ${item.yOffset}`,
                        `xSize: ${item.xSize} ySize: ${item.ySize}`,
                        `centered: ${item.centered}`,
                        `style: ${item.style}`,
                        `corners: ${item.corners}`
                    );
                    this.drawRectangle(item);
                    break;
                case 'label':
                    console.log('Drawing label item with:',
                        `text: "${item.text}"`,
                        `xOffset: ${item.xOffset} yOffset: ${item.yOffset}`,
                        `xSize: ${item.xSize} ySize: ${item.ySize}`,
                        `fontSize: ${item.fontSize}`,
                        `align: ${item.align}`,
                        `bold: ${item.bold} italic: ${item.italic} underline: ${item.underline}`
                    );
                    this.drawLabel(item);
                    break;
                case 'value':
                    console.log('Drawing value item with:',
                        `text: "${item.text}"`,
                        `intValue: ${item.intValue}`,
                        `min: ${item.min} max: ${item.max}`,
                        `displayMin: ${item.displayMin} displayMax: ${item.displayMax}`,
                        `decimals: ${item.decimals} units: "${item.units}"`,
                        `xOffset: ${item.xOffset} yOffset: ${item.yOffset}`,
                        `fontSize: ${item.fontSize} align: ${item.align}`
                    );
                    this.drawValue(item);
                    break;
                case 'circle':
                    console.log('Drawing circle item with:',
                        `xOffset: ${item.xOffset} yOffset: ${item.yOffset}`,
                        `radius: ${item.radius}`,
                        `filled: ${item.filled}`
                    );
                    this.drawCircle(item);
                    break;
                case 'arc':
                    console.log('Drawing arc item with:',
                        `xOffset: ${item.xOffset} yOffset: ${item.yOffset}`,
                        `radius: ${item.radius}`,
                        `start: ${item.start}° angle: ${item.angle}°`,
                        `filled: ${item.filled}`
                    );
                    this.drawArc(item);
                    break;
                case 'touchzone':
                    console.log('Drawing touchZone item with:',
                        `cmd: ${item.cmd}`,
                        `xOffset: ${item.xOffset} yOffset: ${item.yOffset}`,
                        `xSize: ${item.xSize} ySize: ${item.ySize}`,
                        `centered: ${item.centered}`,
                        `filter: ${item.filter}`,
                        `idx: ${item.idx}`
                    );
                    this.drawTouchZone(item);
                    break;
                case 'insertdwg':
                    // Draw the inserted drawing directly as a rectangle with background color
                    console.log(`Drawing insertdwg item: ${item.drawingName}`);
                    this.drawInsertDwg(item);
                    break;
                case 'index':
                    // Index type is a placeholder that doesn't draw anything
                    console.log(`Skipping draw for index item with idx=${item.idx} - this is a placeholder that maintains transform/clipping data only`);
                    break;
                default:
                    console.error(`ERROR: Unknown item type: ${item.type} - not supported by drawing layer!`);
            }
        } catch (error) {
            console.error(`Error drawing item of type ${item.type}:`, error);
        }
        
        // Restore canvas state (also removes clipping)
        this.ctx.restore();
    }

    //========== drawInsertDwg ==========
    // Draw an insertDwg item as a background rectangle
    drawInsertDwg(item) {
        console.error('drawInsertDwg called. Should not be drawing insertDwg:', JSON.stringify(item,null,2));
/**        
        if (!item || !item.drawingName) {
            console.error('Invalid insertDwg item or missing drawingName:', item);
            return;
        }
            
        // Get the transform for positioning
        const transform = item.transform || { x: 0, y: 0, scale: 1.0 };
        
        // Get drawing dimensions and color from DrawingManager
        let drawingWidth = 50;  // Default width
        let drawingHeight = 50; // Default height
        let backgroundColor = 7; // Default light gray (silver) for missing drawings
        
        const drawingData = this.redrawDrawingManager.drawingsData[item.drawingName];
        if (drawingData && drawingData.data) {
            // Use actual drawing data
            drawingWidth = drawingData.data.x || drawingWidth;
            drawingHeight = drawingData.data.y || drawingHeight;
            backgroundColor = drawingData.data.color || backgroundColor;
            
            console.log(`[DRAWING] insertDwg Using actual drawing data: ${drawingWidth}x${drawingHeight}, color: ${backgroundColor}`);
        } else {
            console.log(`[DRAWING] insertDwg '${item.drawingName}' not loaded - skipping drawing`);
            return; // Skip drawing insertDwg if not loaded
        }
**/
        /**
        // Use the drawing bounds if available
        if (item.drawingBounds) {
            drawingWidth = item.drawingBounds.width;
            drawingHeight = item.drawingBounds.height;
            
            // CRITICAL FIX: Apply the transform scale to the drawing bounds
            if (transform && transform.scale) {
                console.log(`Applying scale ${transform.scale} to drawing bounds`);
                drawingWidth *= transform.scale;
                drawingHeight *= transform.scale;
            }
            
            console.log(`[DRAWING] Using drawing bounds from item: ${drawingWidth}x${drawingHeight}`);
        }
        **/
        /**
        console.log(`[DRAWING] Using transform for insertDwg '${item.drawingName}': (${transform.x}, ${transform.y}, ${transform.scale})`);
        
        // Create a rectangle to represent the inserted drawing's background
        const rectItem = {
            xSize: drawingWidth,
            ySize: drawingHeight,
            xOffset: 0,
            yOffset: 0,
            color: backgroundColor,
            filled: 'true',
            centered: 'false',
            transform: transform,
            drawingBounds: item.drawingBounds,
        };
        
        // Store original colors
        const originalFill = this.ctx.fillStyle;
        const originalStroke = this.ctx.strokeStyle;
        
        // Set color for the inserted drawing background
        const hexBackgroundColor = convertColorToHex(backgroundColor);
        this.ctx.fillStyle = hexBackgroundColor;
        this.ctx.strokeStyle = hexBackgroundColor;
        
        // Draw the rectangle
        console.log(`[DRAWING] Drawing insertDwg background rectangle: ${drawingWidth}x${drawingHeight} at (${transform.x}, ${transform.y}), scale: ${transform.scale}`);
            
        this.drawRectangle(rectItem);
        
        // Restore original colors
        this.ctx.fillStyle = originalFill;
        this.ctx.strokeStyle = originalStroke;
        **/
    }

    // Draw a label
    drawLabel(item) {
        console.log('[DRAWING_LABEL] Drawing label - Raw item:', JSON.stringify(item));

        if (item.visible === false) {
            console.log('[DRAWING_LABEL] label not visible, skipping drawing');
            return;
        }

        const transform    = item.transform || { x: 0, y: 0, scale: 1.0 };
        const xOffset      = parseFloat(item.xOffset || 0);
        const yOffset      = parseFloat(item.yOffset || 0);
        const rawText      = addFormattedValueToText(item.text || '', item);
        const relFontSize  = parseInt(item.fontSize || 0);
        const align        = item.align || 'left';

        const actualX      = (xOffset * transform.scale) + transform.x;
        const actualY      = (yOffset * transform.scale) + transform.y;
        const canvasX      = actualX * this.canvas.scaleX;
        const canvasY      = actualY * this.canvas.scaleY;
        const canvasBaseFS = getActualFontSize(relFontSize) * transform.scale * this.canvas.scaleX;

        // Base item colour — used for segments that carry no inline colour tag.
        const isHexColor   = typeof item.color === 'string' && /^[0-9A-Fa-f]{6}$/.test(item.color);
        const itemColorIdx = (!isHexColor && item.color !== undefined) ? parseInt(item.color) : -1;
        const baseColor    = isHexColor
            ? '#' + item.color.toUpperCase()
            : (itemColorIdx >= 0 && itemColorIdx <= 255) ? xtermColorToHex(itemColorIdx) : this.ctx.fillStyle;

        console.log(`[DRAWING_LABEL] Drawing label at canvas coordinates (${canvasX}, ${canvasY}), fontSize: ${canvasBaseFS}`);

        const baseStyle = {
            bold:      item.bold      === 'true' || item.bold      === true,
            italic:    item.italic    === 'true' || item.italic    === true,
            underline: item.underline === 'true' || item.underline === true,
        };
        const lines = _splitSegmentsToLines(parsePfodInlineSegments(rawText, baseStyle));

        this.ctx.textBaseline = 'middle';

        // Per-line height = max segment font size; drives spacing and vertical centering.
        const lineHeights = lines.map(lineSegs =>
            lineSegs.length === 0
                ? canvasBaseFS
                : Math.max(...lineSegs.map(seg =>
                    getActualFontSize(relFontSize + (seg.deltaSize || 0)) * transform.scale * this.canvas.scaleX
                  ))
        );
        const totalHeight = lineHeights.reduce((s, h) => s + h, 0);
        let lineY = canvasY - totalHeight / 2 + lineHeights[0] / 2;

        lines.forEach((lineSegs, li) => {
            // Measure each segment width (also sets ctx.font for later drawing).
            const measured = lineSegs.map(seg => {
                const segFS = getActualFontSize(relFontSize + (seg.deltaSize || 0))
                              * transform.scale * this.canvas.scaleX;
                const font  = _buildCanvasFontStyle(seg.bold, seg.italic, segFS);
                this.ctx.font = font;
                return { seg, font, segFS, w: this.ctx.measureText(seg.text).width };
            });

            const totalW = measured.reduce((s, m) => s + m.w, 0);
            let curX = align === 'center' ? canvasX - totalW / 2
                     : align === 'right'  ? canvasX - totalW
                     :                      canvasX;

            for (const { seg, font, segFS, w } of measured) {
                this.ctx.font      = font;
                this.ctx.fillStyle = seg.color || baseColor;
                this.ctx.fillText(seg.text, curX, lineY);
                if (seg.underline) {
                    const ulY = lineY + segFS / 2;
                    this.ctx.beginPath();
                    this.ctx.moveTo(curX, ulY);
                    this.ctx.lineTo(curX + w, ulY);
                    this.ctx.stroke();
                }
                curX += w;
            }
            if (li < lines.length - 1) {
                lineY += (lineHeights[li] + lineHeights[li + 1]) / 2;
            }
        });

        console.log(`[DRAWING_LABEL] Label drawn: "${rawText}" at (${canvasX}, ${canvasY})`);
    }

    // Draw a value
    drawValue(item) {
        console.log('[DRAWING_VALUE] Drawing value - Raw item:', JSON.stringify(item));

        // Check if value should be visible
        if (item.visible === false) {
            console.log('[DRAWING_VALUE] value not visible, skipping drawing');
            return;
        }

        const transform = item.transform || { x: 0, y: 0, scale: 1.0 };
        const xOffset = parseFloat(item.xOffset || 0);
        const yOffset = parseFloat(item.yOffset || 0);
        const textPrefix   = substituteUnsupportedUnitsGlyphs(item.text || '');
        const relFontSize  = parseInt(item.fontSize || 0);
        const align        = item.align || 'left';
        const intValue     = parseFloat(item.intValue   || 0);
        const max          = parseFloat(item.max        || 1);
        const min          = parseFloat(item.min        || 0);
        const displayMax   = parseFloat(item.displayMax || 1.0);
        const displayMin   = parseFloat(item.displayMin || 0.0);
        const decimals     = (item.decimals !== undefined && item.decimals !== null) ? parseInt(item.decimals) : 2;
        const units        = substituteUnsupportedUnitsGlyphs(item.units || '');

        let maxMin = max - min;
        if (maxMin === 0) maxMin = 1;
        const scaledValue  = (intValue - min) * (displayMax - displayMin) / maxMin + displayMin;
        const fmtValue     = printFloatDecimals(scaledValue, decimals);
        const displayText  = textPrefix + fmtValue + units;

        console.log(`[DRAWING_VALUE] Calculated scaled value: ${intValue} -> ${scaledValue} (${fmtValue}) -> "${displayText}"`);

        const actualX      = (xOffset * transform.scale) + transform.x;
        const actualY      = (yOffset * transform.scale) + transform.y;
        const canvasX      = actualX * this.canvas.scaleX;
        const canvasY      = actualY * this.canvas.scaleY;
        const canvasBaseFS = getActualFontSize(relFontSize) * transform.scale * this.canvas.scaleX;

        const isHexColor   = typeof item.color === 'string' && /^[0-9A-Fa-f]{6}$/.test(item.color);
        const itemColorIdx = (!isHexColor && item.color !== undefined) ? parseInt(item.color) : -1;
        const baseColor    = isHexColor
            ? '#' + item.color.toUpperCase()
            : (itemColorIdx >= 0 && itemColorIdx <= 255) ? xtermColorToHex(itemColorIdx) : this.ctx.fillStyle;

        console.log(`[DRAWING_VALUE] Drawing value at canvas coordinates (${canvasX}, ${canvasY}), fontSize: ${canvasBaseFS}`);

        const baseStyle = {
            bold:      item.bold      === 'true' || item.bold      === true,
            italic:    item.italic    === 'true' || item.italic    === true,
            underline: item.underline === 'true' || item.underline === true,
        };
        const lines = _splitSegmentsToLines(parsePfodInlineSegments(displayText, baseStyle));

        this.ctx.textBaseline = 'middle';

        // Per-line height = max segment font size; drives spacing and vertical centering.
        const lineHeights = lines.map(lineSegs =>
            lineSegs.length === 0
                ? canvasBaseFS
                : Math.max(...lineSegs.map(seg =>
                    getActualFontSize(relFontSize + (seg.deltaSize || 0)) * transform.scale * this.canvas.scaleX
                  ))
        );
        const totalHeight = lineHeights.reduce((s, h) => s + h, 0);
        let lineY = canvasY - totalHeight / 2 + lineHeights[0] / 2;

        lines.forEach((lineSegs, li) => {
            const measured = lineSegs.map(seg => {
                const segFS = getActualFontSize(relFontSize + (seg.deltaSize || 0))
                              * transform.scale * this.canvas.scaleX;
                const font  = _buildCanvasFontStyle(seg.bold, seg.italic, segFS);
                this.ctx.font = font;
                return { seg, font, segFS, w: this.ctx.measureText(seg.text).width };
            });

            const totalW = measured.reduce((s, m) => s + m.w, 0);
            let curX = align === 'center' ? canvasX - totalW / 2
                     : align === 'right'  ? canvasX - totalW
                     :                      canvasX;

            for (const { seg, font, segFS, w } of measured) {
                this.ctx.font      = font;
                this.ctx.fillStyle = seg.color || baseColor;
                this.ctx.fillText(seg.text, curX, lineY);
                if (seg.underline) {
                    const ulY = lineY + segFS / 2;
                    this.ctx.beginPath();
                    this.ctx.moveTo(curX, ulY);
                    this.ctx.lineTo(curX + w, ulY);
                    this.ctx.stroke();
                }
                curX += w;
            }
            if (li < lines.length - 1) {
                lineY += (lineHeights[li] + lineHeights[li + 1]) / 2;
            }
        });

        console.log(`[DRAWING_VALUE] Value drawn: "${displayText}" at (${canvasX}, ${canvasY})`);
    }

    // Draw a line
    drawLine(item) {
        console.log('[DRAWING_LINE] Drawing line - Raw item:', JSON.stringify(item));

        // Check if touchZone should be visible
        if (item.visible === false) {
            console.log('[DRAWING_LINE] line not visible, skipping drawing');
            return;
        }
        // default for test-modules.html use only
        const transform = item.transform ? {...item.transform} : { x: 0, y: 0, scale: 1.0 };
        const x = parseFloat(item.xSize || 0);         // Vector X component
        const y = parseFloat(item.ySize || 0);         // Vector Y component
        const xOffset = parseFloat(item.xOffset || 0); // Starting X position
        const yOffset = parseFloat(item.yOffset || 0); // Starting Y position
        
        console.log(`[DRAWING_LINE] drawLine: original coords - offset(${xOffset},${yOffset}), vector(${x},${y})`);
        console.log(`[DRAWING_LINE] drawLine: using transform - x=${transform.x}, y=${transform.y}, scale=${transform.scale}`);
        
        // Use offsets and dimensions as-is since scaling is handled in merge step
        const transformedXOffset = xOffset*transform.scale;
        const transformedYOffset = yOffset*transform.scale;
        const transformedX = x*transform.scale;
        const transformedY = y*transform.scale;
        
        console.log(`[DRAWING_LINE] drawLine: after transform scale - offset(${transformedXOffset},${transformedYOffset}), vector(${transformedX},${transformedY})`);
                                  
        // Apply the translation component of the transform
        const translatedStartX = transform.x + transformedXOffset;
        const translatedStartY = transform.y + transformedYOffset;
        const translatedEndX = translatedStartX + transformedX;
        const translatedEndY = translatedStartY + transformedY;
        
        console.log(`drawLine: after transform translation - start(${translatedStartX},${translatedStartY}), end(${translatedEndX},${translatedEndY})`);
        
        // Apply canvas scaling to get actual pixel coordinates
        const scaledStartX = translatedStartX * this.canvas.scaleX;
        const scaledStartY = translatedStartY * this.canvas.scaleY;
        const scaledEndX = translatedEndX * this.canvas.scaleX;
        const scaledEndY = translatedEndY * this.canvas.scaleY;
        console.log(`[DRAWING_LINE] drawLine: after canvas scaling - start(${scaledStartX},${scaledStartY}), end(${scaledEndX},${scaledEndY})`);
         
        // Draw the line
        this.ctx.beginPath();
      //  this.ctx.lineWidth = 2;
        
        this.ctx.moveTo(Math.round(scaledStartX), Math.round(scaledStartY));
        this.ctx.lineTo(Math.round(scaledEndX), Math.round(scaledEndY));
        
        this.ctx.stroke();
        
        console.log(`[DRAWING_LINE] Drawing line from (${translatedStartX},${translatedStartY}) to (${translatedEndX},${translatedEndY})`);
    }
    
    // draw rounded rectangel
    drawRoundedRectangle(roundedX, roundedY, roundedWidth, roundedHeight, radius, filled = false) {
      // uses preset 
      //this.ctx.fillStyle = color;
      //this.ctx.strokeStyle = color;

                 // Create rounded rectangle path
                this.ctx.beginPath();
                
                // Top edge and top-right corner
                this.ctx.moveTo(roundedX + radius, roundedY);
                this.ctx.lineTo(roundedX + roundedWidth - radius, roundedY);
                this.ctx.arc(roundedX + roundedWidth - radius, roundedY + radius, radius, Math.PI * 1.5, 0, false);
                
                // Right edge and bottom-right corner
                this.ctx.lineTo(roundedX + roundedWidth, roundedY + roundedHeight - radius);
                this.ctx.arc(roundedX + roundedWidth - radius, roundedY + roundedHeight - radius, radius, 0, Math.PI * 0.5, false);
                
                // Bottom edge and bottom-left corner
                this.ctx.lineTo(roundedX + radius, roundedY + roundedHeight);
                this.ctx.arc(roundedX + radius, roundedY + roundedHeight - radius, radius, Math.PI * 0.5, Math.PI, false);
                
                // Left edge and top-left corner
                this.ctx.lineTo(roundedX, roundedY + radius);
                this.ctx.arc(roundedX + radius, roundedY + radius, radius, Math.PI, Math.PI * 1.5, false);
                
                this.ctx.closePath();
                
                if (filled) {
                    console.log(`[DRAWING_ROUNDED_RECTANGLE] Filling rounded rectangle at (${roundedX},${roundedY}) with size ${roundedWidth}x${roundedHeight}`);
                    this.ctx.fill();
                } else {
                    console.log(`[DRAWING_ROUNDED_RECTANGLE] Stroking rounded rectangle at (${roundedX},${roundedY}) with size ${roundedWidth}x${roundedHeight}`);
                    this.ctx.stroke();
                }
     }
     
    // Draw a rectangle
    drawRectangle(item) {
        console.log('[DRAWING_RECTANGLE] Drawing rectangle - Raw item:', JSON.stringify(item));
        
        try {
            
            // Get the transform from the item (or use default if not present)
            // default for test-modules.html use only
            const transform = item.transform ? {...item.transform} : { x: 0, y: 0, scale: 1.0 };
            console.log(`[DRAWING_RECTANGLE] drawRectangle: using transform - x=${transform.x}, y=${transform.y}, scale=${transform.scale}`);
            // Check if rectanglee should be visible
            if (item.visible === false) {
                console.log('[DRAWING_RECTANGLE] rectangle not visible, skipping drawing');
                return;
            }
            
            // Default offsets to 0 if not specified
            const xOffset = parseFloat(item.xOffset || 0);
            const yOffset = parseFloat(item.yOffset || 0);
            
            // Default sizes to 1 if not specified
            let xSize = parseFloat(item.xSize);
            let ySize = parseFloat(item.ySize);
            
            // Get the centered flag
            const centered = item.centered === 'true' || item.centered === true;
            
            console.log(`[DRAWING_RECTANGLE] Rectangle original properties: xOffset=${xOffset}, yOffset=${yOffset}, xSize=${xSize}, ySize=${ySize}, centered=${centered}`);
            
            const transformedXOffset = xOffset*transform.scale;
            const transformedYOffset = yOffset*transform.scale;
            const transformedXSize = xSize*transform.scale;
            const transformedYSize = ySize*transform.scale;
            
            console.log(`[DRAWING_RECTANGLE] Rectangle dimensions  xOffset=${transformedXOffset}, yOffset=${transformedYOffset}, xSize=${transformedXSize}, ySize=${transformedYSize}`);
            
            // Calculate the starting point (top-left) and dimensions based on rectangle properties
            let startX, startY, width, height;
            
            // If centered is true, negative values result in the same drawing as positive values
            if (centered) {
                // For centered rectangles, the center point is at the transformed offset
                startX = transformedXOffset - Math.abs(transformedXSize) / 2;
                startY = transformedYOffset - Math.abs(transformedYSize) / 2;
                width = Math.abs(transformedXSize);
                height = Math.abs(transformedYSize);
                console.log(`[DRAWING_RECTANGLE] Centered rectangle: Position set to (${startX},${startY}), size set to ${width}x${height}`);
            } else {
                // For non-centered rectangles, handle negative sizes
                if (transformedXSize >= 0) {
                    startX = transformedXOffset;
                    width = transformedXSize;
                } else {
                    // Negative width - draw rectangle left from offset
                    startX = transformedXOffset + transformedXSize; // Move start point left
                    width = Math.abs(transformedXSize);
                    console.log(`[DRAWING_RECTANGLE] Negative width: Position adjusted to x=${startX}, width=${width}`);
                }
                
                if (transformedYSize >= 0) {
                    startY = transformedYOffset;
                    height = transformedYSize;
                } else {
                    // Negative height - draw rectangle up from offset
                    startY = transformedYOffset + transformedYSize; // Move start point up
                    height = Math.abs(transformedYSize);
                    console.log(`[DRAWING_RECTANGLE] Negative height: Position adjusted to y=${startY}, height=${height}`);
                }
            }
            
            // Apply the translation component of the transform
            const translatedX = transform.x + startX;
            const translatedY = transform.y + startY;
            
            console.log(`[DRAWING_RECTANGLE] Rectangle after transform translation: x=${translatedX}, y=${translatedY}, width=${width}, height=${height}`);
            
            // Use the actual rectangle coordinates for drawing
            let visibleRect = {
                x: translatedX,
                y: translatedY,
                width: width,
                height: height
            };
            
            console.log(`[DRAWING_RECTANGLE] Rectangle drawing coordinates: (${visibleRect.x}, ${visibleRect.y}, ${visibleRect.width}, ${visibleRect.height})`);
            
            // Apply canvas scaling to the visible rectangle to get actual pixel coordinates
            const scaledX = visibleRect.x * this.canvas.scaleX;
            const scaledY = visibleRect.y * this.canvas.scaleY;
            const scaledWidth = visibleRect.width * this.canvas.scaleX;
            const scaledHeight = visibleRect.height * this.canvas.scaleY;
            
            console.log(`[DRAWING_RECTANGLE] Rectangle after canvas scaling: x=${scaledX}, y=${scaledY}, width=${scaledWidth}, height=${scaledHeight}`);
            
            // Round to whole pixels for sharp edges
            const roundedX = Math.round(scaledX);
            const roundedY = Math.round(scaledY);
            
            // Ensure width and height are at least 1 pixel
            const minPixelSize = 2; // Minimum size to ensure visibility
            const roundedWidth = Math.max(Math.round(scaledWidth), minPixelSize);
            const roundedHeight = Math.max(Math.round(scaledHeight), minPixelSize);
            
            console.log(`[DRAWING_RECTANGLE] Rectangle after rounding: x=${roundedX}, y=${roundedY}, width=${roundedWidth}, height=${roundedHeight}`);
            
            // Determine drawing style
            const filled = item.filled === 'true' || item.filled === true;
            console.log(`Rectangle filled: ${filled}`);
            
            // Handle rounded corners if specified
            const rounded = item.rounded === 'true' || item.rounded === true;
            console.log(`[DRAWING_RECTANGLE] Rectangle rounded: ${rounded}`);
            
            // Draw the rectangle
            if (rounded) {
                // Draw rounded rectangle
                const radius = Math.min(roundedWidth, roundedHeight) * 0.2;
                console.log(`[DRAWING_RECTANGLE] Using corner radius: ${radius}px`);
                this.drawRoundedRectangle(roundedX, roundedY, roundedWidth, roundedHeight,radius, filled);
                
            } else {
                // Draw regular rectangle
                if (filled) {
                    console.log(`[DRAWING_RECTANGLE] Filling rectangle at (${roundedX},${roundedY}) with size ${roundedWidth}x${roundedHeight}`);
                    this.ctx.fillRect(roundedX, roundedY, roundedWidth, roundedHeight);
                } else {
                    console.log(`[DRAWING_RECTANGLE] Stroking rectangle at (${roundedX},${roundedY}) with size ${roundedWidth}x${roundedHeight}`);
                    this.ctx.strokeRect(roundedX, roundedY, roundedWidth, roundedHeight);
                }
            }
            
            console.log('[DRAWING_RECTANGLE] Rectangle drawing completed');
        } catch (error) {
            console.error('[DRAWING_RECTANGLE] Error in drawRectangle:', error);
        }
    }

    // Draw a touch zone (for debugging/visualization)
    drawTouchZone(item) {
      if (typeof DEBUG === 'undefined') {
        // assume debugging
      } else {
        if ((DEBUG === false) || (DEBUG === 'false')) {
          return;
        } // continue if not false
      }
      console.log('[DRAWING_TOUCHZONE] Drawing touchZone - Raw item:', JSON.stringify(item));
        
      const rect = this.canvas.getBoundingClientRect();
      let minTouch_mm = 9;
      let minPercent = 2/100;
      let colPixelsHalf9mm = (96 * minTouch_mm) / (2 * 25.4); // half 9mm to add to both sides
      let rowPixelsHalf9mm = (96 * minTouch_mm) / (2 * 25.4);
      if ((rect.width * minPercent) > colPixelsHalf9mm) {
        colPixelsHalf9mm = rect.width * minPercent;
      }
      if ((rect.height * minPercent) > rowPixelsHalf9mm) {
        rowPixelsHalf9mm = rect.height * minPercent;
      }
      console.log(`[REDRAW_TOUCHZONE]: enlarge by ${colPixelsHalf9mm} x ${rowPixelsHalf9mm}`);
      console.log(`[REDRAW_TOUCHZONE] touchZone: canvas ${rect.width} x ${rect.height}`);
        
        try {
            
            // Get the transform from the item (or use default if not present)
            // default for test-modules.html use only
            const transform = item.transform ? {...item.transform} : { x: 0, y: 0, scale: 1.0 };
            console.log(`[DRAWING_TOUCHZONE] drawTouchZone: using transform - x=${transform.x}, y=${transform.y}, scale=${transform.scale}`);
            // Check if touchZone should be visible
            if (item.visible === false) {
                console.log('[DRAWING_TOUCHZONE] TouchZone not visible, skipping drawing');
                return;
            }
            
            // Default offsets to 0 if not specified
            const xOffset = parseFloat(item.xOffset || 0);
            const yOffset = parseFloat(item.yOffset || 0);
            
            // Default sizes to 1 if not specified
            let xSize = parseFloat(item.xSize || 1);
            let ySize = parseFloat(item.ySize || 1);
            
            // Get the centered flag
            const centered = item.centered === 'true' || item.centered === true;
            
            console.log(`[DRAWING_TOUCHZONE] TouchZone original properties: xOffset=${xOffset}, yOffset=${yOffset}, xSize=${xSize}, ySize=${ySize}, centered=${centered}`);
                       
            const transformedXOffset = xOffset*transform.scale;
            const transformedYOffset = yOffset*transform.scale;
            const transformedXSize = xSize*transform.scale;
            const transformedYSize = ySize*transform.scale;
            
            console.log(`[DRAWING_TOUCHZONE] TouchZone after transform scale: xOffset=${transformedXOffset}, yOffset=${transformedYOffset}, xSize=${transformedXSize}, ySize=${transformedYSize}`);
            
            // Calculate the starting point (top-left) and dimensions based on touchZone properties
            let startX, startY, width, height;
            
            // If centered is true, negative values result in the same drawing as positive values
            if (centered) {
                // For centered touchZones, the center point is at the transformed offset
                startX = transformedXOffset - Math.abs(transformedXSize) / 2;
                startY = transformedYOffset - Math.abs(transformedYSize) / 2;
                width = Math.abs(transformedXSize);
                height = Math.abs(transformedYSize);
                console.log(`[DRAWING_TOUCHZONE] Centered touchZone: Position set to (${startX},${startY}), size set to ${width}x${height}`);
            } else {
                // For non-centered touchZones, handle negative sizes
                if (transformedXSize >= 0) {
                    startX = transformedXOffset;
                    width = transformedXSize;
                } else {
                    // Negative width - draw touchZone left from offset
                    startX = transformedXOffset + transformedXSize; // Move start point left
                    width = Math.abs(transformedXSize);
                    console.log(`[DRAWING_TOUCHZONE] Negative width: Position adjusted to x=${startX}, width=${width}`);
                }
                
                if (transformedYSize >= 0) {
                    startY = transformedYOffset;
                    height = transformedYSize;
                } else {
                    // Negative height - draw touchZone up from offset
                    startY = transformedYOffset + transformedYSize; // Move start point up
                    height = Math.abs(transformedYSize);
                    console.log(`[DRAWING_TOUCHZONE] Negative height: Position adjusted to y=${startY}, height=${height}`);
                }
            }
            
            // Apply the translation component of the transform
            const translatedX = transform.x + startX;
            const translatedY = transform.y + startY;
            
            console.log(`[DRAWING_TOUCHZONE] TouchZone after transform translation: x=${translatedX}, y=${translatedY}, width=${width}, height=${height}`);
            
            // Apply canvas scaling to get actual pixel coordinates
            let scaledX = translatedX * this.canvas.scaleX;
            let scaledY = translatedY * this.canvas.scaleY;
            let scaledWidth = width * this.canvas.scaleX;
            let scaledHeight = height * this.canvas.scaleY;
            // add extra  colPixelsHalf9mm,  rowPixelsHalf9mm
            let extra_scaledX = scaledX -colPixelsHalf9mm;
            let extra_scaledY = scaledY - rowPixelsHalf9mm;
            let extra_scaledWidth = scaledWidth + 2 * colPixelsHalf9mm;
            let extra_scaledHeight = scaledHeight + 2 * rowPixelsHalf9mm;
            console.log(`[DRAWING_TOUCHZONE] TouchZone after canvas scaling: x=${scaledX}, y=${scaledY}, width=${scaledWidth}, height=${scaledHeight}`);
            
            // Round to whole pixels for sharp edges
            const roundedX = Math.round(scaledX);
            const roundedY = Math.round(scaledY);
            const minPixelSize = 2; // Minimum size to ensure visibility
            const roundedWidth = Math.max(Math.round(scaledWidth), minPixelSize);
            const roundedHeight = Math.max(Math.round(scaledHeight), minPixelSize);
            
            // Round to whole pixels for sharp edges
            const extra_roundedX = Math.round(extra_scaledX);
            const extra_roundedY = Math.round(extra_scaledY);
            const extra_roundedWidth = Math.max(Math.round(extra_scaledWidth), minPixelSize);
            const extra_roundedHeight = Math.max(Math.round(extra_scaledHeight), minPixelSize);
            
            console.log(`[DRAWING_TOUCHZONE] TouchZone after rounding: x=${roundedX}, y=${roundedY}, width=${roundedWidth}, height=${roundedHeight}`);
            
            // Store original styles
            const originalStroke = this.ctx.strokeStyle;
            const originalFill = this.ctx.fillStyle;
            const originalFont = this.ctx.font;
            const originalTextAlign = this.ctx.textAlign;
            const originalTextBaseline = this.ctx.textBaseline;
            const originalLineWidth = this.ctx.lineWidth;
            const originalLineDash = this.ctx.setLineDash;
            
            // Set touchZone-specific style
            this.ctx.strokeStyle = 'rgba(0, 128, 255, 0.7)';
          //  this.ctx.lineWidth = 2;
            
            // Draw touchZone as dashed rectangle
            this.ctx.beginPath();
            this.ctx.setLineDash([5, 3]); // 5px dash, 3px gap
            this.ctx.strokeRect(roundedX, roundedY, roundedWidth, roundedHeight);
            this.ctx.beginPath();
            const doubleLinePixels = -2; // draw line inside
            this.ctx.strokeRect(roundedX-doubleLinePixels, roundedY-doubleLinePixels, roundedWidth+2*doubleLinePixels, roundedHeight+2*doubleLinePixels);
          //  this.ctx.strokeRect(extra_roundedX, extra_roundedY, extra_roundedWidth, extra_roundedHeight);
            
            this.ctx.setLineDash([]); // Reset to solid line
//            this.ctx.beginPath();
//            this.ctx.strokeRect(roundedX, roundedY, roundedWidth, roundedHeight);
            
//            console.log(`[DRAWING_TOUCHZONE] TouchZone item `, JSON.stringify(item,null,2));
//            console.log(`[DRAWING_TOUCHZONE] TouchZone item.cmdName ${item.cmdName}`);
//            console.log(`[DRAWING_TOUCHZONE] TouchZone item.cmd ${item.cmd}`);

            // Draw command text if present
                this.ctx.fillStyle = 'rgba(0, 128, 255, 0.7)';
                this.ctx.font = '16px Roboto, Arial, sans-serif';
                this.ctx.textAlign = 'center';
                this.ctx.textBaseline = 'top'; //'middle';
            if (item.cmdName !== undefined) {
                this.ctx.fillText(item.cmdName, roundedX + roundedWidth / 2, roundedY + 5);
            } else {
                this.ctx.fillText(item.cmd, roundedX + roundedWidth / 2, roundedY + 5);
            }  
                // Draw filter text if present
                if (item.filter !== undefined) {
                    const filterText = `f:${item.filter}`;
                    this.ctx.font = '16px Roboto, Arial, sans-serif';
                    this.ctx.textAlign = 'left';
                    this.ctx.textBaseline = 'top';
                    this.ctx.fillText(filterText, roundedX + 5, roundedY + 5);
                }
                
                // Draw idx text if present
                let idxText;
                if ((item.idx !== undefined) && (item.idx > 0)) {
                    if (item.idxName !== undefined) {
                      idxText = `i:${item.idxName}`;
                    } else {
                     idxText = `i:${item.idx}`;
                    }                  
                    this.ctx.font = '10px Roboto, Arial, sans-serif';
                    this.ctx.textAlign = 'right';
                    this.ctx.textBaseline = 'top';
                    this.ctx.fillText(idxText, roundedX + roundedWidth - 5, roundedY + 5);
                }
           
            
            // Restore original styles
            this.ctx.strokeStyle = originalStroke;
            this.ctx.fillStyle = originalFill;
            this.ctx.font = originalFont;
            this.ctx.textAlign = originalTextAlign;
            this.ctx.textBaseline = originalTextBaseline;
            this.ctx.lineWidth = originalLineWidth;
            this.ctx.setLineDash = originalLineDash;


            
            console.log('[DRAWING_TOUCHZONE] TouchZone drawing completed');
        } catch (error) {
            console.error('[DRAWING_TOUCHZONE] Error in drawTouchZone:', error);
        }
    }

    // Draw a circle
    drawCircle(item) {
        console.log('[DRAWING_CIRCLE] Drawing circle - Raw item:', JSON.stringify(item));

        // Check if circle should be visible
        if (item.visible === false) {
            console.log('[DRAWING_CIRCLE] Circle not visible, skipping drawing');
            return;
        }

        try {
            const transform = item.transform || { x: 0, y: 0, scale: 1.0 };
            const xOffset = parseFloat(item.xOffset || 0);
            const yOffset = parseFloat(item.yOffset || 0);
            // Use ?? not || — radius:0 is legitimate (invisible zero-radius circle).
            // Clamp negative radius to 0 to match Android V2_ImageCircleUpdate.getRadius().
            let radius = parseFloat(item.radius ?? 1);
            if (radius < 0) radius = 0;
            const filled = item.filled === 'true' || item.filled === true;

            console.log(`[DRAWING_CIRCLE] Circle properties: xOffset=${xOffset}, yOffset=${yOffset}, radius=${radius}, filled=${filled}`);

            // Apply transform to position and radius
            const transformedX = (xOffset * transform.scale) + transform.x;
            const transformedY = (yOffset * transform.scale) + transform.y;
            const transformedRadius = radius * transform.scale;

            console.log(`[DRAWING_CIRCLE] Circle after transform: center=(${transformedX}, ${transformedY}), radius=${transformedRadius}`);

            // Apply canvas scaling
            const canvasX = transformedX * this.canvas.scaleX;
            const canvasY = transformedY * this.canvas.scaleY;
            const canvasRadius = transformedRadius * this.canvas.scaleX;

            console.log(`[DRAWING_CIRCLE] Circle after canvas scaling: center=(${canvasX}, ${canvasY}), radius=${canvasRadius}`);

            // Draw the circle.  Android uses FILL_AND_STROKE for filled, STROKE for unfilled.
            this.ctx.beginPath();
            this.ctx.arc(canvasX, canvasY, canvasRadius, 0, 2 * Math.PI);

            if (filled) {
                console.log(`[DRAWING_CIRCLE] Filling+stroking circle at (${canvasX}, ${canvasY}) with radius ${canvasRadius}`);
                this.ctx.fill();
                this.ctx.stroke();
            } else {
                console.log(`[DRAWING_CIRCLE] Stroking circle at (${canvasX}, ${canvasY}) with radius ${canvasRadius}`);
                this.ctx.stroke();
            }

            console.log('[DRAWING_CIRCLE] Circle drawing completed');
        } catch (error) {
            console.error('[DRAWING_CIRCLE] Error in drawCircle:', error);
        }
    }

    // Draw an arc
    drawArc(item) {
        console.log('[DRAWING_ARC] Drawing arc - Raw item:', JSON.stringify(item));

        // Check if arc should be visible
        if (item.visible === false) {
            console.log('[DRAWING_ARC] Arc not visible, skipping drawing');
            return;
        }

        try {
            const transform = item.transform || { x: 0, y: 0, scale: 1.0 };
            const xOffset = parseFloat(item.xOffset || 0);
            const yOffset = parseFloat(item.yOffset || 0);
            // Use ?? not || — radius:0 is legitimate (invisible zero-radius arc).
            // Clamp negative radius to 0 to match Android V2_ImageCircleUpdate.getRadius().
            let radius = parseFloat(item.radius ?? 1);
            if (radius < 0) radius = 0;
            const filled = item.filled === 'true' || item.filled === true;
            const startDegrees = -parseFloat(item.start || 0); // angles go anti-clockwise
            // Use ?? not || — angle:0 is a legitimate value (zero-sweep arc / tick
            // mark) and must NOT be replaced with the default 90°.  The earlier
            // `|| 90` rewrote 0 to 90 and produced visible black pie wedges
            // wherever the device sent a zero-angle marker.
            const angleDegrees = parseFloat(item.angle ?? 90);

            console.log(`[DRAWING_ARC] Arc properties: xOffset=${xOffset}, yOffset=${yOffset}, radius=${radius}, filled=${filled}, start=${startDegrees}°, angle=${angleDegrees}°`);

            // Convert degrees to radians
            // Note: Canvas uses radians where 0 is 3 o'clock, positive is clockwise
            // The specification says +ve is anti-clockwise, -ve is clockwise
            // So we need to negate the angles to match the specification
            const startRadians = (startDegrees * Math.PI) / 180;
            const endRadians = startRadians - ((angleDegrees * Math.PI) / 180);
            const anticlockwise = angleDegrees < 0; // +ve angle = anti-clockwise in specification

            console.log(`[DRAWING_ARC] Arc angles: start=${startRadians}rad, end=${endRadians}rad, anticlockwise=${anticlockwise}`);

            // Apply transform to position and radius
            const transformedX = (xOffset * transform.scale) + transform.x;
            const transformedY = (yOffset * transform.scale) + transform.y;
            const transformedRadius = radius * transform.scale;

            console.log(`[DRAWING_ARC] Arc after transform: center=(${transformedX}, ${transformedY}), radius=${transformedRadius}`);

            // Apply canvas scaling
            const canvasX = transformedX * this.canvas.scaleX;
            const canvasY = transformedY * this.canvas.scaleY;
            const canvasRadius = transformedRadius * this.canvas.scaleX;

            console.log(`[DRAWING_ARC] Arc after canvas scaling: center=(${canvasX}, ${canvasY}), radius=${canvasRadius}`);

            // Draw the arc
            this.ctx.beginPath();
                // For filled arcs, draw from center to create a pie slice
            this.ctx.moveTo(canvasX, canvasY);
            this.ctx.arc(canvasX, canvasY, canvasRadius, startRadians, endRadians, !anticlockwise);
            this.ctx.closePath();
            // Stroke width for a FILLED arc, kept as its own setting
            // because it is what the gauge's ring seam turns on.
            //
            // The path is a pie, so a filled arc's stroke traces its own
            // two straight edges as well as its rim, and that stroke is
            // what a filled mask arc uses to cover the strokes beneath
            // it. Widening it to 3 made the mask cover them outright. At
            // 2 it matches the global width set once per redraw
            // (redrawCanvasImpl), so a filled arc strokes exactly like
            // every other item and a drawing that needs a mark to stay
            // visible paints it ABOVE whatever would cover it (index it
            // after the mask) rather than relying on width.
            const originalArcLineWidth = this.ctx.lineWidth;
            if (filled) {
                this.ctx.lineWidth = 2;
                console.log(`[DRAWING_ARC] Filling arc pie slice at (${canvasX}, ${canvasY}) with radius ${canvasRadius}`);
                this.ctx.fill();
            }
            // Every arc is stroked, filled or not.
            //
            // An earlier attempt skipped the stroke on filled arcs
            // (`if (!filled || angleDegrees === 0)`) to stop a filled arc
            // painting radial lines along its own straight edges. That
            // removed the hairline but took the covering power with it,
            // and a zero-sweep tick — whose stroke IS the mark, running
            // from the centre out — then had nothing to bury its inner
            // half. Drawings solve that with paint order instead.
            this.ctx.stroke();
            this.ctx.lineWidth = originalArcLineWidth;
            console.log('[DRAWING_ARC] Arc drawing completed');
        } catch (error) {
            console.error('[DRAWING_ARC] Error in drawArc:', error);
        }
    }
}

// Export as global for browser compatibility
window.Redraw = Redraw;
window.pfodColorTagToHex = pfodColorTagToHex;
window.xtermColorToHex = xtermColorToHex;
window.parsePfodInlineSegments = parsePfodInlineSegments;/*
   drawingMerger.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// DrawingMerger — recursively expands `insertDwg` references into their target
// drawing's items, with composed transforms, into PER-MENUDWG MERGED sets on
// the DrawingManager.  There is no single "main drawing" global view; every
// menu drawing item has its own canvas and its own merged set rooted at that
// drawing.  The merged collections are spread across five DrawingManager
// fields keyed by menuDwg name:
//
//     drawingManager.allTouchZonesByCmd[menuDwg]        = {cmd: item}
//     drawingManager.allTouchActionsByCmd[menuDwg]      = {cmd: actions[]}
//     drawingManager.allTouchActionInputsByCmd[menuDwg] = {cmd: input}
//     drawingManager.allUnindexedItems[menuDwg]         = [items]
//     drawingManager.allIndexedItemsByNumber[menuDwg]   = {idx: item}
//
// These are derived views — rebuilt from scratch each merge from the
// per-drawing RAW collections (drawingManager.unindexedItems[name] etc.).
// The "last received wins, never remove" semantics live at the per-drawing
// raw layer in DrawingManager.addItem; this merger just walks that data.
//
// Exports:    window.DrawingMerger class
// Depends on: DrawingManager instance (passed to constructor),
//             DrawingManager.addUnindexedLastWins static helper
// Called by:  requestQueue.js processRequestQueue (after each dwg response)
//             drawingProcessing.js processPendingResponses (after pending batch drains)
class DrawingMerger {
    constructor(drawingManager) {
        this.drawingManager = drawingManager;
    }

    // Build per-menuDwg merged sets for every drawing currently registered
    // on the drawing manager.  Drawings whose data hasn't arrived yet are
    // skipped (they'll be picked up on a later merge once their data is in).
    mergeAllDrawings() {
        // Always start with fresh containers — the allXXX maps are derived
        // views, so any stale entry would just survive longer than its
        // source; better to wipe and rebuild from current state.
        this.drawingManager.allTouchZonesByCmd        = {};
        this.drawingManager.allTouchActionsByCmd      = {};
        this.drawingManager.allTouchActionInputsByCmd = {};
        this.drawingManager.allUnindexedItems         = {};
        this.drawingManager.allIndexedItemsByNumber   = {};

        for (const drawingName of (this.drawingManager.drawings || [])) {
            this.mergeForDrawing(drawingName);
        }
    }

    // Build the merged set rooted at one drawing.  Initialises empty entries
    // for that drawing in each of the five allXXX maps, then walks the tree
    // via mergeDrawingItems with those entries as the output targets.
    mergeForDrawing(drawingName) {
        const drawingData = this.drawingManager.drawingsData[drawingName];
        if (!drawingData || !drawingData.data) {
            // Data hasn't arrived yet — leave allXXX[name] absent; the renderer
            // will show the placeholder until a later merge runs.
            return;
        }

        const dm = this.drawingManager;
        dm.allTouchZonesByCmd[drawingName]        = {};
        dm.allTouchActionsByCmd[drawingName]      = {};
        dm.allTouchActionInputsByCmd[drawingName] = {};
        dm.allUnindexedItems[drawingName]         = [];
        dm.allIndexedItemsByNumber[drawingName]   = {};

        const rootDwg = {
            type: 'insertDwg',
            xOffset: 0,
            yOffset: 0,
            color: drawingData.color,
            parentDrawingName: drawingName,
            drawingName: drawingName,
            transform: { x: 0, y: 0, scale: 1.0 }
        };

        const processedDrawings = new Set();
        this.mergeDrawingItems(rootDwg,
            dm.allUnindexedItems[drawingName],
            dm.allIndexedItemsByNumber[drawingName],
            dm.allTouchZonesByCmd[drawingName],
            dm.allTouchActionsByCmd[drawingName],
            dm.allTouchActionInputsByCmd[drawingName],
            processedDrawings, /*parentClipRegion*/ null, drawingData.data.x);

        console.info(`[DRAWING_MERGER] Merged "${drawingName}": ${dm.allUnindexedItems[drawingName].length} unindexed, ${Object.keys(dm.allIndexedItemsByNumber[drawingName]).length} indices, ${Object.keys(dm.allTouchZonesByCmd[drawingName]).length} touchZones, ${Object.keys(dm.allTouchActionsByCmd[drawingName]).length} touchActions, ${Object.keys(dm.allTouchActionInputsByCmd[drawingName]).length} touchActionInputs`);
    }

    getDrawingResponseStatus(drawingName) {
        // An insertDwg can reference a child that is not yet registered — its
        // {cX} fetch is still queued/in-flight, or it was de-registered by a
        // version change while the parent still lists the insertDwg item.
        // That is the normal progressive-load case: return false so
        // mergeDrawingItems skips this insertDwg and picks it up on the later
        // re-merge once the child arrives.  No log here — the caller already
        // logs the skip — and it must NOT throw (throwing aborted the entire
        // parent-drawing render: "error loading dwg").
        if (!(drawingName in this.drawingManager.drawingResponseStatus)) {
            return false;
        }
        return this.drawingManager.drawingResponseStatus[drawingName];
    }

    // Calculate clipping region for a drawing
    calculateItemClipRegion(transform, drawingWidth, drawingHeight, parentClipRegion) {
        return parentClipRegion; // do not limit insertDwgs
    }

    /**
    transform calculations
    each items has a base offset and a scale and a clip region
    when the item is drawn, first the item's offset x scale is added to the base to the the position
    then the size is scaled by scale and the item drawn
    insertDwg's offset are different they do not change the position of the the background rectangle
    rather they move the insertDwg's items up and to left by offset * scale (for +ve offsets)
    clip regions are only updated when insertDwg processed

    the insertDwg arg contains the current transformation offset and scale
    the insertDwg xOffset,yOffset move the dwg items up and left by offset * scale (for +ve offsets)
    scale insertDwg by ratio of cols i.e. a 20xh inserted in a 40xhh will be scaled down by 2 i.e. x 20/40
    **/
    // Recursively merge a drawing tree rooted at `insertDwg` into the supplied
    // per-drawing output collections.  Output args are objects/arrays owned
    // by mergeForDrawing — this function never touches the global all*
    // (those have been removed).
    mergeDrawingItems(insertDwg,
                      outUnindexed, outIndexed, outTouchZones,
                      outTouchActions, outTouchActionInputs,
                      processedDrawings, parentClipRegion, parentDrawingWidth) {
        let drawingName = insertDwg.drawingName;
        console.info(`[MERGE_DWG] Merging Drawing "${drawingName}".`);
        console.info(`[MERGE_DWG] Beginning merge process for drawing "${drawingName}" ${JSON.stringify(insertDwg)}`);

        const drawingData = this.drawingManager.drawingsData[drawingName];
        if (!drawingData || !drawingData.data) {
            console.info(`[DRAWING_MERGER] Drawing "${drawingName}" data not available.`);
            return;
        }

        let clipRegion = parentClipRegion;
        if (parentClipRegion) {
            console.info(`[DRAWING_MERGER] Using parent clip region: (${parentClipRegion.x}, ${parentClipRegion.y}, width:${parentClipRegion.width}, height:${parentClipRegion.height})`);
        } else {
            console.info(`[DRAWING_MERGER] No parent clip region provided, using drawing bounds for clipping`);
            clipRegion = {
                x: 0, y: 0,
                width: drawingData.data.x, height: drawingData.data.y
            };
        }
        parentClipRegion = clipRegion;

        const drawingWidth  = drawingData.data.x || 50;
        const drawingHeight = drawingData.data.y || 50;
        const backgroundColor = drawingData.data.color || 'white';

        console.info(`[DRAWING_MERGER] Drawing "${drawingName}" has dimensions ${drawingWidth}x${drawingHeight}, color: ${backgroundColor}`);

        const parentTransform = insertDwg.transform || { x: 0, y: 0, scale: 1.0 };
        console.info(`[SCALE_MERGE_DWG]  parentTransform transform: ${JSON.stringify(parentTransform)}`);

        const drawingUnindexedItems = this.drawingManager.unindexedItems[drawingName]   || [];
        const drawingIndexedItems   = this.drawingManager.indexedItems[drawingName]     || {};
        const touchZoneItems        = this.drawingManager.touchZonesByCmd[drawingName]  || {};
        const touchActionItems      = this.drawingManager.touchActionsByCmd[drawingName]|| {};
        const touchActionInputItems = this.drawingManager.touchActionInputsByCmd[drawingName] || {};

        console.info(`[DRAWING_MERGER] Processing ${drawingUnindexedItems.length} unindexed items, ${Object.keys(drawingIndexedItems).length} indexed items, ${Object.keys(touchZoneItems).length} touchZones from "${drawingName}"`);

        if (drawingUnindexedItems.length === 0 && Object.keys(drawingIndexedItems).length === 0) {
            console.info(`[DRAWING_MERGER] Drawing "${drawingName}" has no items, but will still be drawn as a rectangle with background color.`);
            if (Object.keys(touchZoneItems).length !== 0) {
                console.info(`[DRAWING_MERGER] Drawing "${drawingName}" has touchZones which will be drawn in debug mode.`);
            }
        }

        let dwgTransform = {...insertDwg.transform};
        console.info(`[SCALE_MERGE_DWG]  insertDwg transform: ${JSON.stringify(dwgTransform)}`);
        console.info(`[DRAWING_MERGER] For drawing: Raw dimensions: ${drawingWidth}x${drawingHeight}`);

        const dwgClipRegion = this.calculateItemClipRegion(dwgTransform, drawingWidth, drawingHeight, parentClipRegion);
        console.info(`[DRAWING_MERGER] Calculated nested drawing clip region: (${dwgClipRegion.x}, ${dwgClipRegion.y}, width:${dwgClipRegion.width}, height:${dwgClipRegion.height})`);

        // Apply insertDwg offset move (in scaled space)
        const dwg_xOffset = parseFloat(insertDwg.xOffset || 0);
        const dwg_yOffset = parseFloat(insertDwg.yOffset || 0);
        dwgTransform.x += (-dwg_xOffset) * dwgTransform.scale;
        dwgTransform.y += (-dwg_yOffset) * dwgTransform.scale;
        console.info(`[DRAWING_MERGER] Using item transform for nested drawing items: (${dwgTransform.x}, ${dwgTransform.y}, ${dwgTransform.scale})`);

        // ----- Process touchZones -----
        // Per-cmd assign into the per-drawing merged outTouchZones map.
        // Last-received-wins per cmd; map keys not touched by this walk
        // remain from earlier insertDwgs in the same merge call.
        for (const cmd in touchZoneItems) {
            const touchZone = touchZoneItems[cmd];
            const processedItem = {...touchZone};
            processedItem.clipRegion = dwgClipRegion;
            const itemTransform = {...processedItem.transform};
            itemTransform.x = itemTransform.x * dwgTransform.scale + dwgTransform.x;
            itemTransform.y = itemTransform.y * dwgTransform.scale + dwgTransform.y;
            itemTransform.scale = itemTransform.scale * dwgTransform.scale;
            processedItem.transform = itemTransform;

            console.info(`[DRAWING_MERGER] Found touchzone item for drawing "${drawingName}" at offsets (${touchZone.xOffset || 0}, ${touchZone.yOffset || 0})`);
            const touchZoneCmd = touchZone.cmd || '';
            if (touchZoneCmd.trim().length === 0) {
                console.info(`[DRAWING_MERGER] Error empty touchzone cmd in drawing "${drawingName}" ${JSON.stringify(processedItem)}`);
                continue;
            }
            if (outTouchZones[touchZoneCmd]) {
                const currentItem = outTouchZones[touchZoneCmd];
                if (currentItem.parentDrawingName !== processedItem.parentDrawingName) {
                    console.info(`[DRAWING_MERGER] Error: Updating existing touchZone with cmd ${touchZoneCmd} in "${processedItem.parentDrawingName}" with item from different drawing, "${currentItem.parentDrawingName}"`);
                }
                processedItem.transform  = {...currentItem.transform};
                processedItem.clipRegion = {...currentItem.clipRegion};
                console.info(`[DRAWING_MERGERG_UPDATE] Update existing touchZone with cmd ${touchZoneCmd} to ${JSON.stringify(processedItem)}`);
            }
            console.info(`[DRAWING_MERGER] Added touchZone to outTouchZones  ${JSON.stringify(processedItem)}`);
            outTouchZones[touchZoneCmd] = processedItem;
        }

        // ----- Process touchActions / touchActionInputs -----
        // These now flow into the PER-DRAWING merged set (not a global),
        // keyed by cmd.  Per-cmd assign — last received wins per cmd.
        for (const cmd in touchActionItems) {
            const touchActions = touchActionItems[cmd];
            if (touchActions && touchActions.length > 0) {
                outTouchActions[cmd] = [...touchActions];
                console.info(`[DRAWING_MERGER] Added ${touchActions.length} touchActions for cmd="${cmd}" to merged set`);
            }
        }
        for (const cmd in touchActionInputItems) {
            const touchActionInput = touchActionInputItems[cmd];
            if (touchActionInput) {
                outTouchActionInputs[cmd] = {...touchActionInput};
                console.info(`[DRAWING_MERGER] Added touchActionInput for cmd="${cmd}" to merged set`);
            }
        }

        // ----- Process unindexed items -----
        for (let i = 0; i < drawingUnindexedItems.length; i++) {
            const item = drawingUnindexedItems[i];
            item.clipRegion = dwgClipRegion;

            console.info(`[MERGE_DWG] Processing unindexed item ${i} of type '${item.type}' in drawing "${drawingName}"`);

            if (item.type && item.type === 'insertDwg') {
                if (item.visible === false) {
                    console.info(`[MERGE_DWG] Skipping hidden insertDwg for drawing "${item.drawingName}"`);
                    continue;
                }
                const nestedDrawingName = item.drawingName;
                console.info(`[MERGE_DWG] Found nested insertDwg item for drawing "${nestedDrawingName}" at offsets (${item.xOffset || 0}, ${item.yOffset || 0})`);

                const hasResponse = this.getDrawingResponseStatus(nestedDrawingName);
                if (!hasResponse) {
                    console.info(`[MERGE_DWG] No response received for drawing "${nestedDrawingName}" - skipping this insertDwg`);
                    continue;
                }

                if (nestedDrawingName && !processedDrawings.has(nestedDrawingName)) {
                    processedDrawings.add(nestedDrawingName);

                    // Compose the nested insertDwg's transform with the current parent transform.
                    const composedItem = {...item};
                    const composedTransform = {...item.transform};
                    composedTransform.x     = composedTransform.x     * dwgTransform.scale + dwgTransform.x;
                    composedTransform.y     = composedTransform.y     * dwgTransform.scale + dwgTransform.y;
                    composedTransform.scale = composedTransform.scale * dwgTransform.scale;
                    composedItem.transform  = composedTransform;

                    console.info(`[MERGE_DWG_NESTED] Composed transform for nested drawing "${nestedDrawingName}": parent=${JSON.stringify(dwgTransform)}, local=${JSON.stringify(item.transform)}, composed=${JSON.stringify(composedTransform)}`);

                    this.mergeDrawingItems(composedItem,
                        outUnindexed, outIndexed, outTouchZones,
                        outTouchActions, outTouchActionInputs,
                        processedDrawings, dwgClipRegion, drawingWidth);
                } else if (nestedDrawingName) {
                    // Drawing already encountered in this merge walk — either
                    // a circular inclusion (e.g. c3 → c4 → c3) or a duplicate
                    // reference of the same drawing within one tree.  Per the
                    // data model "every merged-tree key is unique", neither
                    // is valid pfod.  Short-circuit (already done by this
                    // branch) and surface as an error so the device-side
                    // misconfiguration is visible.
                    console.info(`[MERGE_DWG] Circular / duplicate insertDwg: drawing "${nestedDrawingName}" already in the merge chain (currently merging into "${drawingName}"). Skipping to prevent infinite recursion. Chain so far: [${[...processedDrawings].join(', ')}]`);
                }
            } else {
                // Regular drawing item (line, rectangle, label, …)
                const processedItem = {...item};
                processedItem.clipRegion = dwgClipRegion;
                const itemTransform = {...(processedItem.transform || { x: 0, y: 0, scale: 1 })};
                itemTransform.x     = itemTransform.x     * dwgTransform.scale + dwgTransform.x;
                itemTransform.y     = itemTransform.y     * dwgTransform.scale + dwgTransform.y;
                itemTransform.scale = itemTransform.scale * dwgTransform.scale;
                processedItem.transform = itemTransform;
                console.info(`[MERGE_DWG] Added unindexed Item  ${JSON.stringify(processedItem)}`);
                // Use last-received-wins helper so re-receiving the same item
                // (same attribute fingerprint) doesn't pile up duplicates.
                DrawingManager.addUnindexedLastWins(outUnindexed, processedItem);
            }
        }

        // ----- Process indexed items -----
        for (const idx in drawingIndexedItems) {
            const item = drawingIndexedItems[idx];

            console.info(`[MERGE_DWG] Processing indexed item idx=${idx}, type='${item.type}' in drawing "${drawingName}"`);
            const processedItem = {...item};
            processedItem.clipRegion = dwgClipRegion;
            const itemTransform = {...processedItem.transform};
            itemTransform.x     = itemTransform.x     * dwgTransform.scale + dwgTransform.x;
            itemTransform.y     = itemTransform.y     * dwgTransform.scale + dwgTransform.y;
            itemTransform.scale = itemTransform.scale * dwgTransform.scale;
            processedItem.transform = itemTransform;

            const numericIdx = parseInt(idx);
            if (outIndexed[numericIdx]) {
                // An idx is unique across a whole merged tree, so two drawings
                // claiming the same idx means the invariant is already broken
                // upstream.  Keep the entry that claimed the idx first — its
                // transform was captured when the idx was first seen and must
                // not change — and report the collision rather than silently
                // reconciling the two items.
                const currentItem = outIndexed[numericIdx];
                console.error(`[MERGE_DWG] idx=${numericIdx} claimed by both "${currentItem.parentDrawingName}" and "${drawingName}" - merged-tree indices must be unique. Keeping the "${currentItem.parentDrawingName}" item, discarding ${JSON.stringify(processedItem)}`);
                continue;
            }
            console.info(`[MERGE_DWG] Added indexed Item  ${JSON.stringify(processedItem)}`);
            outIndexed[numericIdx] = processedItem;
        }

        console.info(`[MERGE_DWG] Completed merging items from "${drawingName}" at ${new Date().toISOString()}`);
        console.info(`[MERGE_DWG] Current status: ${outUnindexed.length} unindexed items, ${Object.keys(outIndexed).length} different indices, ${Object.keys(outTouchZones).length} touchZones `);
    }
}

// Export as global for browser compatibility
window.DrawingMerger = DrawingMerger;
/*
 * pfodMenuCache.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Exports:    window.pfodStripMenuCmdVersion(cmd) function, window.PfodMenuCache class
// Depends on: localStorage (browser built-in)
// Called by:  navigationAndQueue.js (versionedMenuCmd uses getMenuVersion),
//             responseHandlers.js (processMenuResponse uses storeMenu, getMenuCmdArray),
//             connectionSetup.js (initializeApp creates instance via new PfodMenuCache)

// pfod Menu Cache — persists menu responses in localStorage keyed by connection + bare menu cmd.
// Each menu cmd that has returned a {, response is stored with its version string and raw
// cmd array. On reconnect the cached version is used to send versioned requests, and cached
// menus are shown immediately when the device confirms the version is still valid.

/**
 * Strip version prefix from a pfod menu cmd string.
 * e.g. '{V2:A}' → '{A}',  '{V1:.}' → '{.}',  '{.}' → '{.}' (unchanged)
 *
 * @param {string} cmd - Full braced cmd, possibly versioned
 * @returns {string} Unversioned braced cmd
 */
function pfodStripMenuCmdVersion(cmd) {
    const colonIdx = cmd.indexOf(':');
    if (colonIdx > 1) {
        // Has version prefix — reconstruct as '{bareCmd}'
        return '{' + cmd.slice(colonIdx + 1);
    }
    return cmd;
}

/**
 * Manages localStorage caching of pfod menu responses for a specific connection.
 *
 * Storage schema (one entry per connection):
 *   Key:   'pfodMenuCache_<connectionId>'
 *   Value: JSON { menuCmds, menus }
 *     menuCmds - string[] of bare cmd keys known to produce menus, e.g. ['.', 'A']
 *     menus    - object mapping bareCmd → { version, cmd }
 *                  version: version string from the {, header (e.g. 'V1'), or ''
 *                  cmd:     pfodToJson cmd array snapshot for re-parsing on reconnect
 */
class PfodMenuCache {
    /**
     * @param {string} connectionId - Stable identifier for this connection endpoint
     */
    constructor(connectionId) {
        this.connectionId = connectionId;
        this.storageKey = 'pfodMenuCache_' + connectionId;
        this._cache = null; // loaded lazily on first access
    }

    /**
     * Lazily load the cache from localStorage.
     * If missing or corrupt, initialises an empty cache structure.
     */
    _load() {
        if (this._cache !== null) return;
        try {
            const saved = localStorage.getItem(this.storageKey);
            this._cache = saved ? JSON.parse(saved) : { menuCmds: [], menus: {} };
        } catch (e) {
            console.warn('[MENU_CACHE] Failed to load cache for "' + this.connectionId + '":', e);
            this._cache = { menuCmds: [], menus: {} };
        }
    }

    /**
     * Persist the current in-memory cache to localStorage.
     */
    _save() {
        try {
            localStorage.setItem(this.storageKey, JSON.stringify(this._cache));
        } catch (e) {
            console.warn('[MENU_CACHE] Failed to save cache for "' + this.connectionId + '":', e);
        }
    }

    /**
     * Return the list of bare cmd strings that are known to produce menus on this connection.
     * e.g. ['.', 'A', 'B']
     *
     * @returns {string[]}
     */
    getMenuCmds() {
        this._load();
        return this._cache.menuCmds.slice();
    }

    /**
     * Return the cached version string for a bare menu cmd, or null if not cached.
     *
     * @param {string} bareCmd - e.g. '.', 'A'
     * @returns {string|null}
     */
    getMenuVersion(bareCmd) {
        this._load();
        const entry = this._cache.menus[bareCmd];
        return (entry && entry.version) ? entry.version : null;
    }

    /**
     * Return a copy of the cached pfodToJson cmd array for a bare menu cmd, or null.
     * The returned array can be passed directly to pfodParseMenu().
     *
     * @param {string} bareCmd - e.g. '.', 'A'
     * @returns {string[]|null}
     */
    getMenuCmdArray(bareCmd) {
        this._load();
        const entry = this._cache.menus[bareCmd];
        return entry ? entry.cmd.slice() : null;
    }

    /**
     * Store a full {, menu response for a bare cmd.
     *
     * Versioning is per-menu — the device decides independently for each menu
     * whether to include a version, and an unversioned response for one cmd
     * says nothing about the other cmds.  So a version change here only
     * invalidates THIS menu's prior entry (overwrite), and unversioned
     * responses must not be persisted (callers should use removeMenu instead).
     *
     * @param {string} bareCmd   - bare cmd key, e.g. '.', 'A'
     * @param {string[]} cmdArray - snapshot of the pfodToJson cmd array for this response
     * @param {string} version   - version string from the {, header (must be truthy;
     *                              callers should call removeMenu for unversioned responses)
     */
    storeMenu(bareCmd, cmdArray, version) {
        this._load();
        if (!version) {
            // Unversioned — refuse to store and evict any prior entry so
            // next cycle re-requests this menu unversioned.  Callers should
            // call removeMenu(bareCmd) directly; this guard is defensive.
            this.removeMenu(bareCmd);
            return;
        }
        if (!this._cache.menuCmds.includes(bareCmd)) {
            this._cache.menuCmds.push(bareCmd);
        }
        this._cache.menus[bareCmd] = { version: version, cmd: cmdArray };
        this._save();
        console.log('[MENU_CACHE] Stored menu for cmd "' + bareCmd + '" version="' + version + '"');
    }

    /**
     * Evict a single menu's cached entry (for an unversioned {,} response, or
     * any other case where the prior cached state is known to be stale).
     * Other cached menus on this connection are untouched.
     *
     * @param {string} bareCmd - e.g. '.', 'A'
     */
    removeMenu(bareCmd) {
        this._load();
        // Read the drawings this menu reaches BEFORE the entry goes — after
        // the delete there is nothing left to walk. It is the OLD cached
        // menu's drawings that are stale, not whatever the replacement
        // response happens to reference.
        const reached = this._drawingsReachedByMenu(bareCmd);
        const had = this._cache.menus[bareCmd] !== undefined;
        delete this._cache.menus[bareCmd];
        this._cache.menuCmds = this._cache.menuCmds.filter(c => c !== bareCmd);
        if (had) {
            this._save();
            console.log('[MENU_CACHE] Removed cached menu for cmd "' + bareCmd + '"');
        }
        // A menu is only stale together with its drawings. Dropping the menu
        // alone left every drawing it showed — and every insertDwg under
        // those, at any depth — cached at its old version, so the menu was
        // re-fetched fresh and then filled with stale content.
        this._removeDrawingCaches(reached, 'menu "' + bareCmd + '"');
    }

    /**
     * Every drawing a cached menu reaches: the drawings its own Drawing items
     * name, then each of those drawings' insertDwg children, to any depth.
     *
     * Both halves come out of localStorage, so this works on a cold start
     * with no in-memory DrawingManager: the menu's parsed items carry
     * `loadCmd` (pfodMenuParser sets it for dwg / dwg-label items), and each
     * per-drawing cache entry carries `unindexedItems`, which is where an
     * insertDwg item lands (it is never indexed).
     *
     * @param {string} bareCmd
     * @returns {string[]} drawing names, each once
     */
    _drawingsReachedByMenu(bareCmd) {
        const parsed = this.getParsedMenu(bareCmd);
        const roots = [];
        if (parsed && Array.isArray(parsed.items)) {
            parsed.items.forEach((item) => {
                if (item && item.loadCmd) roots.push(item.loadCmd);
            });
        }
        const seen = new Set();
        const queue = roots.slice();
        while (queue.length > 0) {
            const name = queue.shift();
            // The `seen` guard is not just an optimisation: two drawings can
            // insert each other, and nothing rejects that on load, so an
            // unguarded walk would not terminate.
            if (!name || seen.has(name)) continue;
            seen.add(name);
            const entry = this._readDrawingCache(name);
            const items = (entry && entry.unindexedItems) || [];
            items.forEach((it) => {
                if (it && it.type === 'insertDwg' && it.drawingName) queue.push(it.drawingName);
            });
        }
        return Array.from(seen);
    }

    /**
     * The parsed per-drawing cache entry for `drawingName`, or null.
     * Never throws: a corrupt or absent entry simply ends that branch of the
     * walk, which is the right answer — there is nothing there to clear.
     *
     * @param {string} drawingName
     * @returns {object|null}
     */
    _readDrawingCache(drawingName) {
        try {
            const raw = localStorage.getItem('pfodWeb_dwg_' + this.connectionId + '_' + drawingName);
            return raw ? JSON.parse(raw) : null;
        } catch (e) {
            console.warn('[MENU_CACHE] Could not read cached drawing "' + drawingName + '":', e);
            return null;
        }
    }

    /**
     * Drop both cache entries for each named drawing — the per-drawing raw
     * cache and the per-menuDwg merged cache. DrawingManager writes both
     * (saveDrawingDataToStorage / saveMenuDwgMergedToStorage), so clearing
     * one and leaving the other puts back exactly the stale content that was
     * being cleared.
     *
     * @param {string[]} names
     * @param {string} why — for the log line
     */
    _removeDrawingCaches(names, why) {
        if (!names || names.length === 0) return;
        names.forEach((name) => {
            try {
                localStorage.removeItem('pfodWeb_dwg_' + this.connectionId + '_' + name);
                localStorage.removeItem('pfodWeb_menuDwg_' + this.connectionId + '_' + name);
            } catch (e) {
                console.warn('[MENU_CACHE] Could not clear cached drawing "' + name + '":', e);
            }
        });
        console.log('[MENU_CACHE] Cleared ' + names.length + ' drawing(s) reached by ' + why +
                    ': ' + names.join(', '));
    }

    /**
     * Update the stored parsed menu object for a bare cmd after an in-place {;} update.
     * Keeps the cache in sync with the latest device state so back-navigation shows
     * current values rather than the original {, snapshot.
     * Does nothing if no entry exists for this bareCmd (unversioned menus are not cached).
     *
     * @param {string} bareCmd  - bare cmd key, e.g. '.', 'A'
     * @param {object} menuData - merged parsed menu object (will be deep-copied)
     */
    updateParsedMenu(bareCmd, menuData) {
        this._load();
        const entry = this._cache.menus[bareCmd];
        if (entry) {
            entry.parsed = JSON.parse(JSON.stringify(menuData));
            this._save();
        }
    }

    /**
     * Return the stored parsed menu object for a bare cmd, or null if not available.
     * Prefer this over getMenuCmdArray when available — it reflects the latest {;} state.
     *
     * @param {string} bareCmd - e.g. '.', 'A'
     * @returns {object|null}
     */
    getParsedMenu(bareCmd) {
        this._load();
        const entry = this._cache.menus[bareCmd];
        return (entry && entry.parsed) ? entry.parsed : null;
    }

    /**
     * Clear all cached menus for this connection (e.g. when user presses Clear Cache).
     */
    clearMenus() {
        this._cache = { menuCmds: [], menus: {} };
        this._save();
        // Every drawing cached for this connection, not just the ones the
        // menus still reach. This is the clear-EVERYTHING path, and a walk
        // from the menus would leave behind any drawing they no longer
        // mention — a design edited since it was last cached, or a drawing
        // whose menu entry has already been evicted — which is precisely the
        // stale content someone pressing Clear Cache is trying to be rid of.
        const dwgPrefix  = 'pfodWeb_dwg_' + this.connectionId + '_';
        const mergePrefix = 'pfodWeb_menuDwg_' + this.connectionId + '_';
        const toRemove = [];
        try {
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                if (key && (key.startsWith(dwgPrefix) || key.startsWith(mergePrefix))) {
                    toRemove.push(key);
                }
            }
            // Collected first, removed after: removing inside the loop
            // reindexes localStorage under the cursor and skips entries.
            toRemove.forEach((key) => localStorage.removeItem(key));
        } catch (e) {
            console.warn('[MENU_CACHE] Could not clear cached drawings:', e);
        }
        console.log('[MENU_CACHE] Cleared all menus and ' + toRemove.length +
                    ' cached drawing entry(s) for "' + this.connectionId + '"');
    }
}

// Export globally
window.pfodStripMenuCmdVersion = pfodStripMenuCmdVersion;
window.PfodMenuCache = PfodMenuCache;
