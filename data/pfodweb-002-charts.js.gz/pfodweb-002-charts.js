/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * A base object for a table element.
 * @param {jsfc.BaseElement} [instance]  the object where the element's 
 *         attributes will be stored (defaults to 'this').
 * @constructor 
 * @classdesc A base table element. 
 * @returns {jsfc.BaseElement} The new instance.
 */
jsfc.BaseElement = function(instance) {
    if (!(this instanceof jsfc.BaseElement)) {
        throw new Error("Use 'new' for construction.");
    }
    if (!instance) {
        instance = this;
    }
    jsfc.BaseElement.init(instance);
};

/**
 * Initialises the attributes requires by this base class, in the supplied
 * instance object.
 * 
 * @param {jsfc.BaseElement} instance  the instance.
 * @returns {undefined}
 */
jsfc.BaseElement.init = function(instance) {
    instance._insets = new jsfc.Insets(2, 2, 2, 2);
    instance._refPt = jsfc.RefPt2D.CENTER;
    instance._backgroundPainter = null;    
};

/**
 * Returns the insets.
 * 
 * @returns {jsfc.Insets} The insets.
 */
jsfc.BaseElement.prototype.getInsets = function() {
    return this._insets;
};

/**
 * Sets the insets.
 * 
 * @param {!jsfc.Insets} insets  the new insets.
 * @returns {undefined}
 */
jsfc.BaseElement.prototype.setInsets = function(insets) {
    this._insets = insets;
};

/**
 * Gets/sets the reference point for the element.
 * @param {number} [value]
 * @returns {number|jsfc.BaseElement}
 */
jsfc.BaseElement.prototype.refPt = function(value) {
    if (!arguments.length) {
        return this._refPt;
    }
    this._refPt = value;
    return this;
};

/**
 * Gets/sets the background painter.
 * 
 * @param {Object} [painter] the new painter (optional, if not specified the
 *     function returns the current painter).
 * @returns {Object|jsfc.BaseElement}
 */
jsfc.BaseElement.prototype.backgroundPainter = function(painter) {
    if (!arguments.length) {
        return this._backgroundPainter;
    }
    this._backgroundPainter = painter;
    return this;    
};

/**
 * Receives a visitor.
 * 
 * @param {!Function} visitor  the visitor function.
 * @returns {undefined}
 */
jsfc.BaseElement.prototype.receive = function(visitor) {
    // in the default case, call the visitor function just passing this element
    visitor(this);
};/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * @classdesc A table element is a rectangular element that is either a 
 *     container for other table elements, or has some visual representation.
 *     These elements can be composed into table-like structures in a general
 *     way (here they are used primarily to construct chart legends).
 *     
 * @interface
 */
jsfc.TableElement = function() {
};

/**
 * Returns the preferred dimensions for this element.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context.
 * @param {!jsfc.Rectangle} bounds  the drawing bounds.
 * 
 * @returns {jsfc.Dimension} The preferred dimensions for the text.
 */
jsfc.TableElement.prototype.preferredSize = function(ctx, bounds) {
};
    
/**
 * Calculates the layout for the element subject to the specified bounds.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context.
 * @param {!jsfc.Rectangle} bounds  the available space for the layout.
 * @returns {Array} An array containing a jsfc.Rectangle that is the location
 *     of the text element.
 */
jsfc.TableElement.prototype.layoutElements = function(ctx, bounds) {
};

/**
 * Draws the text element within the specified bounds by creating the 
 * required SVG text element and setting the attributes.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context.
 * @param {!jsfc.Rectangle} bounds  the bounds.
 * @returns {undefined}
 */
jsfc.TableElement.prototype.draw = function(ctx, bounds) {
};

/**
 * Receives a table element visitor.
 * 
 * @param {!Function} visitor  the visitor (a function that receives a table 
 *         element as its only argument).
 * @returns {undefined}
 */
jsfc.TableElement.prototype.receive = function(visitor) {
};/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * @classdesc A table element that displays a text string on a single line.
 * @implements jsfc.TableElement
 * 
 * @param {!string} textStr  the element text.
 * @returns {jsfc.TextElement}
 * @constructor
 */
jsfc.TextElement = function(textStr) {
    if (!(this instanceof jsfc.TextElement)) {
        throw new Error("Use 'new' for construction.");
    };
    jsfc.BaseElement.init(this); // inherit attributes from BaseElement
    this._text = textStr;
    this._font = new jsfc.Font("Palatino, serif", 16);
    this._color = new jsfc.Color(0, 0, 0);
    this._halign = jsfc.HAlign.LEFT;
    // the following field overrides the default from BaseElement
    this._backgroundPainter = new jsfc.StandardRectanglePainter(
            new jsfc.Color(255,255,255,0.3), new jsfc.Color(0,0,0,0));
};

// inherit from BaseElement (see also the init() call in the constructor)
jsfc.TextElement.prototype = new jsfc.BaseElement();
    
/**
 * Returns the text displayed by this element.
 * 
 * @returns {!string} The text.
 */
jsfc.TextElement.prototype.getText = function() {
    return this._text;
};

/**
 * Sets the text to be displayed by this element.
 * 
 * @param {!string} text  the text.
 * @returns {jsfc.TextElement}
 */
jsfc.TextElement.prototype.setText = function(text) {
    this._text = text;
    return this;
};

jsfc.TextElement.prototype.getFont = function() {
    return this._font;
};

jsfc.TextElement.prototype.setFont = function(font) {
    this._font = font;
    return this;
};

jsfc.TextElement.prototype.getColor = function() {
    return this._color;
};

jsfc.TextElement.prototype.setColor = function(color) {
    this._color = color;
    return this;
};

/**
 * Gets/sets the text to be displayed by this element.
 * 
 * @param {string} str  the string.
 * 
 * @returns {string|jsfc.TextElement}
 */
jsfc.TextElement.prototype.text = function(str) {
    throw new Error("Use get/setText()");
};

/**
 * Gets/sets the color for the text.
 * 
 * @param {string} str  the color string.
 * @returns {jsfc.Color|jsfc.TextElement}
 */
jsfc.TextElement.prototype.color = function(str) {
    throw new Error("Use get/setColor()");
};

/**
 * Gets/sets the font.
 * 
 * @param {jsfc.Font} font  the new font.
 * 
 * @returns {jsfc.Font|jsfc.TextElement}
 */
jsfc.TextElement.prototype.font = function(font) {
    throw new Error("Use get/setFont().");
};
    
/**
 * Gets/sets the horizontal alignment.
 * 
 * @param {number} align  the new alignment.
 * @returns {number|jsfc.TextElement}
 */
jsfc.TextElement.prototype.halign = function(align) {
    if (!arguments.length) {
        return this._halign;
    }
    this._halign = align;
    return this;
};

/**
 * Returns the preferred dimensions for this element.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context.
 * @param {!jsfc.Rectangle} bounds  the drawing bounds.
 * 
 * @returns {jsfc.Dimension} The preferred dimensions for the text.
 */
jsfc.TextElement.prototype.preferredSize = function(ctx, bounds) {
    var insets = this.getInsets();
    ctx.setFont(this._font);
    var dim = ctx.textDim(this._text);
    return new jsfc.Dimension(insets.left() + dim.width() + insets.right(), 
            insets.top() + dim.height() + insets.bottom());
};
    
/**
 * Calculates the layout for the element subject to the specified bounds.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context.
 * @param {!jsfc.Rectangle} bounds  the available space for the layout.
 * @returns {Array} An array containing a jsfc.Rectangle that is the location
 *     of the text element.
 */
jsfc.TextElement.prototype.layoutElements = function(ctx, bounds) {
    var insets = this.getInsets();
    ctx.setFont(this._font);
    var dim = ctx.textDim(this._text);
    var w = dim.width() + insets.left() + insets.right();
    var x = bounds.x();
    switch(this._halign) {
        case jsfc.HAlign.LEFT : 
            x = bounds.x();
            break;
        case jsfc.HAlign.CENTER :
            x = bounds.centerX() - w / 2;
            break;
        case jsfc.HAlign.RIGHT :
            x = bounds.maxX() - w;
            break;
    }
    var y = bounds.y();
    var h = Math.min(dim.height() + insets.top() + insets.bottom(), 
        bounds.height());
    return [new jsfc.Rectangle(x, y, w, h)];
};

/**
 * Draws the text element within the specified bounds by creating the 
 * required SVG text element and setting the attributes.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context.
 * @param {jsfc.Rectangle} bounds
 * @returns {undefined}
 */
jsfc.TextElement.prototype.draw = function(ctx, bounds) {
    var backgroundPainter = this.backgroundPainter();
    if (backgroundPainter) {
        backgroundPainter.paint(ctx, bounds);
    }
    var insets = this.getInsets();
    var pos = this.layoutElements(ctx, bounds)[0];

    ctx.setFillColor(this._color);
    ctx.setFont(this._font);
    var upper = pos.y() + insets.top();
    var lower = pos.maxY() - insets.bottom();
    var span = lower - upper; 
    var base = lower - 0.18 * span;
    ctx.drawString(this._text, pos.x() + insets.left(), base);
};/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * Creates a new painter.
 * @class A painter that fills a rectangle with a color.
 * @constructor
 * @implements {jsfc.RectanglePainter}
 * @param {jsfc.Color} fillColor  the fill color (null permitted).
 * @param {jsfc.Color} [strokeColor]  the stroke color (null permitted).
 * @returns {undefined}
 */
jsfc.StandardRectanglePainter = function(fillColor, strokeColor) {
    if (!(this instanceof jsfc.StandardRectanglePainter)) {
        throw new Error("Use 'new' for construction.");
    }
    this._fillColor = fillColor;
    this._strokeColor = strokeColor;
};

/**
 * Paints the background within the specified bounds.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context (null not permitted).
 * @param {!jsfc.Rectangle} bounds  the bounds (null not permitted).
 * @returns {undefined}
 */
jsfc.StandardRectanglePainter.prototype.paint = function(ctx, bounds) {
    if (this._fillColor) {
        ctx.setFillColor(this._fillColor);
        ctx.fillRect(bounds.x(), bounds.y(), bounds.width(), bounds.height());
    }
    if (this._strokeColor) {
        ctx.setLineColor(this._strokeColor);
    }
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * Creates a new instance.
 * 
 * @class A container element that lays out its children in a horizontal 
 * flow layout running from left to right (wrapping to a new line when 
 * necessary).
 * 
 * @constructor 
 * @implements {jsfc.TableElement}
 * @returns {jsfc.FlowElement}
 */
jsfc.FlowElement = function() {
    if (!(this instanceof jsfc.FlowElement)) {
        throw Error("Use 'new' for constructor.");
    }
    jsfc.BaseElement.init(this); // inherit attributes from BaseElement
    this._elements = [];
    this._halign = jsfc.HAlign.LEFT;
    this._hgap = 2;
};

jsfc.FlowElement.prototype = new jsfc.BaseElement();
    
/**
 * Gets/sets the horizontal alignment of the elements.
 * 
 * @param {number} align  the new alignment.
 * 
 * @returns {number|jsfc.FlowElement}
 */
jsfc.FlowElement.prototype.halign = function(align) {
    if (!arguments.length) {
        return this._halign;
    }
    this._halign = align;
    return this;
};

/**
 * Gets or sets the gap between items in the flowlayout (when no argument
 * is supplied, the function returns the current value). 
 * 
 * @param {number} [value]  the new value.
 * @returns {number|jsfc.FlowElement}
 */
jsfc.FlowElement.prototype.hgap = function(value) {
    if (!arguments.length) {
        return this._hgap;
    }
    this._hgap = value;
    return this;
};

/**
 * Adds an element to the flow layout.
 * 
 * @param {Object} element  the element.
 * @returns {undefined}
 */
jsfc.FlowElement.prototype.add = function(element) {
    this._elements.push(element);
    return this;
};
    
jsfc.FlowElement.prototype.receive = function(visitor) {
    this._elements.forEach(function(child) { child.receive(visitor); });    
};
    
/**
 * Returns the preferred dimensions for this element.
 * 
 * @param {jsfc.Context2D} ctx  the graphics context.
 * @param {jsfc.Rectangle} bounds  the drawing bounds.
 * 
 * @returns {jsfc.Dimension} The preferred dimensions for the text.
 */
jsfc.FlowElement.prototype.preferredSize = function(ctx, bounds) {
    // split the children into rows and measure the rows
    var insets = this.getInsets();
    var w = insets.left() + insets.right();
    var h = insets.top() + insets.bottom();
    var maxRowWidth = 0.0;
    var elementCount = this._elements.length;
    var i = 0;
    while (i < elementCount) {
        // get one row of elements...
        var elementsInRow = this._rowOfElements(i, ctx, bounds);
        var rowHeight = this._calcRowHeight(elementsInRow);
        var rowWidth = this._calcRowWidth(elementsInRow, this._hgap);
        maxRowWidth = Math.max(rowWidth, maxRowWidth);
        h += rowHeight;
        i = i + elementsInRow.length;
    }
    w += maxRowWidth;
    return new jsfc.Dimension(insets.left() + w + insets.right(), 
            insets.top() + h + insets.bottom());
};
    
/**
 * Returns a row of elements starting with the specified element and
 * respecting the width of the supplied bounds.
 * 
 * @param {number} first  the index of the first element to include.
 * @param {jsfc.Context2D} ctx  the graphics context.
 * @param {jsfc.Rectangle} bounds  the bounds.
 * 
 * @returns {Array}
 */
jsfc.FlowElement.prototype._rowOfElements = function(first, ctx, bounds) {
    var result = [];
    var index = first;
    var full = false;
    var insets = this.getInsets();
    var w = insets.left() + insets.right();
    while (index < this._elements.length && !full) {
        var element = this._elements[index];
        var dim = element.preferredSize(ctx, bounds);
        if (w + dim.width() < bounds.width() || index === first) {
            result.push({ "element": element, "dim": dim });
            w += dim.width() + this._hgap;
            index++;
        } else {
            full = true;
        }
    }
    return result;
};
    
jsfc.FlowElement.prototype._calcRowHeight = function(elements) {
    var height = 0.0;
    for (var i = 0; i < elements.length; i++) {
        height = Math.max(height, elements[i].dim.height());
    }    
    return height;
};
    
jsfc.FlowElement.prototype._calcRowWidth = function(elements) {
    var width = 0.0;
    var count = elements.length;
    for (var i = 0; i < elements.length; i++) {
        width += elements[i].dim.width();
    }
    if (count > 1) {
        width += (count - 1) * this._hgap;
    }
    return width;
};
    
jsfc.FlowElement.prototype.layoutElements = function(context, bounds) {
    var result = []; // a list of jsfc.Rectangle objects
    var i = 0;
    var insets = this.getInsets();
    var x = bounds.x() + insets.left();
    var y = bounds.y() + insets.top();
    while (i < this._elements.length) {
        var elementsInRow = this._rowOfElements(i, context, bounds);
        var h = this._calcRowHeight(elementsInRow);
        var w = this._calcRowWidth(elementsInRow);  
        if (this._halign === jsfc.HAlign.CENTER) {
            x = bounds.centerX() - (w / 2);
        } else if (this._halign === jsfc.HAlign.RIGHT) {
            x = bounds.maxX() - insets.right() - w;
        }
        for (var j = 0; j < elementsInRow.length; j++) {
            //Dimension2D dim = elementInfo.getDimension();
            var position = new jsfc.Rectangle(x, y, 
                elementsInRow[j].dim.width(), h);
            result.push(position);
            x += position.width() + this._hgap;
        }
        i = i + elementsInRow.length;
        x = bounds.x() + insets.left();
        y += h;        
    }
    return result;
};
    
jsfc.FlowElement.prototype.draw = function(context, bounds) {
    var dim = this.preferredSize(context, bounds);
    var fitter = new jsfc.Fit2D(new jsfc.Anchor2D(this.refPt()), 
        jsfc.Scale2D.NONE);
    var dest = fitter.fit(dim, bounds);
    var layoutInfo = this.layoutElements(context, dest);
    for (var i = 0; i < this._elements.length; i++) {
        var rect = layoutInfo[i];
        var element = this._elements[i];
        element.draw(context, rect);
    }
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * @class A table element that contains a rectangle (centered within the 
 * element).
 * @constructor
 * @param {number} width  the rectangle width.
 * @param {number} height  the rectangle height.
 * @returns {jsfc.RectangleElement}
 */
jsfc.RectangleElement = function(width, height) {
    if (!(this instanceof jsfc.RectangleElement)) {
        throw new Error("Use 'new' for construction.");
    }
    jsfc.BaseElement.init(this); // inherit attributes from BaseElement
    this._width = width;
    this._height = height;
    this._fillColor = new jsfc.Color(255, 255, 255);

    // the following field overrides the default from BaseElement
    this._backgroundPainter = new jsfc.StandardRectanglePainter(
            new jsfc.Color(255,255,255,0.3), new jsfc.Color(0,0,0,0));
};

jsfc.RectangleElement.prototype = new jsfc.BaseElement();

/**
 * Gets/sets the rectangle width.
 * 
 * @param {number} [value]  the new width.
 * @returns {number|jsfc.RectangleElement} 
 */
jsfc.RectangleElement.prototype.width = function(value) {
    if (!arguments.length) {
        return this._width;
    }
    this._width = value;
    return this;
};

/**
 * Gets/sets the rectangle height.
 * 
 * @param {number} [value]  the new height.
 * @returns {jsfc.RectangleElement|number}
 */
jsfc.RectangleElement.prototype.height = function(value) {
    if (!arguments.length) {
        return this._height;
    }
    this._height = value;
    return this;
};

jsfc.RectangleElement.prototype.getFillColor = function() {
    return this._fillColor;
};

jsfc.RectangleElement.prototype.setFillColor = function(color) {
    if (typeof color === "string") {
        throw new Error("needs to be a color");
    }
    this._fillColor = color;
    return this;
};

/**
 * Returns the preferred dimensions for this element, which is the 
 * size of the rectangle plus the insets.
 * 
 * @param {jsfc.Context2D} ctx  the graphics context.
 * @param {jsfc.Rectangle} bounds  the drawing bounds.
 * 
 * @returns {jsfc.Dimension} The preferred dimensions for the text.
 */
jsfc.RectangleElement.prototype.preferredSize = function(ctx, bounds) {
    var insets = this.getInsets();
    var w = insets.left() + this._width + insets.right();
    var h = insets.top() + this._height + insets.bottom();
    var bw = bounds.width();
    var bh = bounds.height();
    return new jsfc.Dimension(Math.min(w, bw), Math.min(h, bh));
};
    
/**
 * Performs a layout of the element.
 * 
 * @param {jsfc.Context2D} ctx  the SVG context.
 * @param {jsfc.Rectangle} bounds  the bounds.
 * @returns {Array}
 */
jsfc.RectangleElement.prototype.layoutElements = function(ctx, bounds) {
    var insets = this.getInsets();
    var w = Math.min(insets.left() + this._width + insets.right(), 
            bounds.width());
    var h = Math.min(insets.top() + this._height + insets.bottom(), 
            bounds.height());
    var pos = new jsfc.Rectangle(bounds.centerX() - w / 2, 
            bounds.centerY() - h / 2, w, h);
    return [pos];
};

/**
 * Draws the element.
 * 
 * @param {jsfc.Context2D} ctx  the graphics context.
 * @param {jsfc.Rectangle} bounds  the bounds.
 * @returns {undefined}
 */
jsfc.RectangleElement.prototype.draw = function(ctx, bounds) {
    var backgroundPainter = this.backgroundPainter();
    if (backgroundPainter) {
        backgroundPainter.paint(ctx, bounds);
    }
    // create a new rectangle element
    var insets = this.getInsets();
    var ww = Math.max(bounds.width() - insets.left() - insets.right(), 0);
    var hh = Math.max(bounds.height() - insets.top() - insets.bottom(), 0);
    var w = Math.min(this._width, ww);
    var h = Math.min(this._height, hh);
    ctx.setFillColor(this._fillColor);
    ctx.fillRect(bounds.centerX() - w / 2, bounds.centerY() - h / 2, w, h);
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * @class A table element that is a grid of sub-elements.
 * 
 * @constructor
 * @implements {jsfc.TableElement}
 */
jsfc.GridElement = function() {
    if (!(this instanceof jsfc.GridElement)) {
        throw new Error("Use 'new' for construction.");
    }    
    jsfc.BaseElement.init(this); // inherit attributes from BaseElement
    this._elements = new jsfc.KeyedValues2DDataset();
};
 
// inherit from BaseElement (see also the init() call in the constructor)
jsfc.GridElement.prototype = new jsfc.BaseElement();
    
/**
 * Adds an element to the grid (or, if the keys are already defined, 
 * replaces an existing element).
 * 
 * @param {jsfc.TableElement} element  the table element to add.
 * @param {!string} rowKey  the row key.
 * @param {!string} columnKey  the column key.
 * @returns {jsfc.GridElement} This object (for chaining method calls).
 */
jsfc.GridElement.prototype.add = function(element, rowKey, columnKey) {
    this._elements.add(rowKey, columnKey, element);
    return this;
};

// private method
jsfc.GridElement.prototype._findCellDims = function(context, bounds) {
    var widths = jsfc.Utils.makeArrayOf(0, this._elements.columnCount());
    var heights = jsfc.Utils.makeArrayOf(0, this._elements.rowCount());
    for (var r = 0; r < this._elements.rowCount(); r++) {
        for (var c = 0; c < this._elements.columnCount(); c++) {
            var element = this._elements.valueByIndex(r, c);
            if (!element) {
                continue;
            }
            var dim = element.preferredSize(context, bounds);
            widths[c] = Math.max(widths[c], dim.width());
            heights[r] = Math.max(heights[r], dim.height());
        }
    }
    return { "widths": widths, "heights": heights };
};
    
/**
 * Returns the preferred dimensions for this element.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context.
 * @param {jsfc.Rectangle} bounds  the drawing bounds.
 * 
 * @returns {jsfc.Dimension} The preferred dimensions for the text.
 */
jsfc.GridElement.prototype.preferredSize = function(ctx, bounds) {
    var me = this;
    var insets = this.getInsets();
    var cellDims = this._findCellDims(ctx, bounds);
    var w = insets.left() + insets.right();
    for (var i = 0; i < cellDims.widths.length; i++) {
        w = w + cellDims.widths[i];
    }
    var h = insets.top() + insets.bottom();
    for (var i = 0; i < cellDims.heights.length; i++) {
        h = h + cellDims.heights[i];
    }
    return new jsfc.Dimension(w, h);
};
    
/**
 * Performs a layout of the grid, returning an array with the positions of
 * the elements in the grid.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context.
 * @param {jsfc.Rectangle} bounds  the area available for drawing the grid.
 * 
 * @returns {Array}
 */
jsfc.GridElement.prototype.layoutElements = function(ctx, bounds) {
    var insets = this.getInsets();        
    var cellDims = this._findCellDims(ctx, bounds);
    var positions = [];
    var y = bounds.y() + insets.top();
    for (var r = 0; r < this._elements.rowCount(); r++) {
        var x = bounds.x() + insets.left();
        for (var c = 0; c < this._elements.columnCount(); c++) {
            positions.push(new jsfc.Rectangle(x, y, cellDims.widths[c], 
                cellDims.heights[r]));
            x += cellDims.widths[c];
        }
        y = y + cellDims.heights[r];
    }
    return positions;
};
 
/**
 * Draws the element within the specified bounds.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context.
 * @param {jsfc.Rectangle} bounds
 * @returns {undefined}
 */
jsfc.GridElement.prototype.draw = function(ctx, bounds) {
    var positions = this.layoutElements(ctx, bounds);
    for (var r = 0; r < this._elements.rowCount(); r++) {
        for (var c = 0; c < this._elements.columnCount(); c++) {
            var element = this._elements.valueByIndex(r, c);
            if (!element) {
                continue;
            }
            var pos = positions[r * this._elements.columnCount() + c];
            element.draw(ctx, pos);
        }
    }
};

jsfc.GridElement.prototype.receive = function(visitor) {
    for (var r = 0; r < this._elements.rowCount(); r++) {
        for (var c = 0; c < this._elements.columnCount(); c++) {
            var element = this._elements.valueByIndex(r, c);
            if (element === null) {
                continue;
            }
            element.receive(visitor);
        }
    }
};

/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Creates and returns a new color source.
 * 
 * @param {jsfc.Color[]} colors An array of colors.
 * 
 * @returns {jsfc.ColorSource}
 * 
 * @constructor
 */
jsfc.ColorSource = function(colors) {
    if (!(this instanceof jsfc.ColorSource)) {
        throw new Error("Use 'new' for constructor.");
    }
    this._colors = colors;
};

/**
 * Returns a color.
 * 
 * @param {number} series  the series index.
 * @param {number} item  the item index.
 * 
 * @returns {jsfc.Color} A color.
 */
jsfc.ColorSource.prototype.getColor = function(series, item) {
    return this._colors[series % this._colors.length];
};

/**
 * Returns a color to represent the specified series in the legend.
 * @param {number} series  the series index.
 * @returns {jsfc.Color} A color to represent the series.
 */
jsfc.ColorSource.prototype.getLegendColor = function(series) {
    return this._colors[series % this._colors.length];
};/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Creates and returns a new stroke source.
 * 
 * @param {jsfc.Stroke[]} strokes An array of strokes.
 * 
 * @returns {jsfc.StrokeSource}
 * 
 * @constructor
 */
jsfc.StrokeSource = function(strokes) {
    if (!(this instanceof jsfc.StrokeSource)) {
        throw new Error("Use 'new' for constructor.");
    }
    this._strokes = strokes;
};

/**
 * Returns a stroke for the specified item.
 * 
 * @param {number} series  the series index.
 * @param {number} item  the item index.
 * 
 * @returns {jsfc.Stroke} A stroke.
 */
jsfc.StrokeSource.prototype.getStroke = function(series, item) {
    return this._strokes[series % this._strokes.length];
};/*
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Based on XYItemRendererState from AFreeChart (Android port of JFreeChart)
 */

"use strict";

/**
 * Creates a new renderer state object that maintains rendering context
 * across the rendering of a dataset. This object is passed to the renderer's
 * drawItem() method for each data point, providing a persistent context that
 * can be reused and modified across the rendering sequence.
 *
 * @classdesc State object for XY item rendering that maintains context
 * and provides reusable objects (like workingLine) to avoid excessive
 * memory allocations during rendering.
 *
 * @constructor
 * @param {Object} plotRenderingInfo  the plot rendering info (optional).
 * @returns {jsfc.XYItemRendererState}
 */
jsfc.XYItemRendererState = function(plotRenderingInfo) {
    if (!(this instanceof jsfc.XYItemRendererState)) {
        return new jsfc.XYItemRendererState(plotRenderingInfo);
    }

    this.plotRenderingInfo = plotRenderingInfo;

    /**
     * The first item index in the current series pass.
     * @type {number}
     */
    this.firstItemIndex = 0;

    /**
     * The last item index in the current series pass.
     * @type {number}
     */
    this.lastItemIndex = 0;

    /**
     * The local series index in the current series pass.
     * This is used to access the dataset with the correct local index,
     * while the global series index (passed to drawItem) is used for colors.
     * @type {number}
     */
    this.localSeriesIndex = 0;

    /**
     * A reusable line object to avoid creating new line objects for
     * every line segment during rendering. This is an important
     * optimization for rendering large datasets.
     * @type {Object}
     */
    this.workingLine = {
        x0: 0,
        y0: 0,
        x1: 0,
        y1: 0,
        setLine: function(x0, y0, x1, y1) {
            this.x0 = x0;
            this.y0 = y0;
            this.x1 = x1;
            this.y1 = y1;
        }
    };

    /**
     * Flag that controls whether the renderer processes all data items
     * or just the visible ones. Default is true (process visible only).
     * @type {boolean}
     */
    this.processVisibleItemsOnly = true;
};

/**
 * Returns the plot rendering info object.
 *
 * @returns {Object} The plot rendering info (or null).
 */
jsfc.XYItemRendererState.prototype.getPlotRenderingInfo = function() {
    return this.plotRenderingInfo;
};

/**
 * Returns the first item index for the current series pass.
 *
 * @returns {number} The first item index.
 */
jsfc.XYItemRendererState.prototype.getFirstItemIndex = function() {
    return this.firstItemIndex;
};

/**
 * Returns the last item index for the current series pass.
 *
 * @returns {number} The last item index.
 */
jsfc.XYItemRendererState.prototype.getLastItemIndex = function() {
    return this.lastItemIndex;
};

/**
 * Returns the working line object that can be reused for drawing.
 *
 * @returns {jsfc.Line} The working line.
 */
jsfc.XYItemRendererState.prototype.getWorkingLine = function() {
    return this.workingLine;
};

/**
 * Returns the flag that controls whether visible items only are processed.
 *
 * @returns {boolean} The flag.
 */
jsfc.XYItemRendererState.prototype.getProcessVisibleItemsOnly = function() {
    return this.processVisibleItemsOnly;
};

/**
 * Sets the flag that controls whether visible items only are processed.
 *
 * @param {boolean} flag  the flag.
 * @returns {undefined}
 */
jsfc.XYItemRendererState.prototype.setProcessVisibleItemsOnly = function(flag) {
    this.processVisibleItemsOnly = flag;
};

/**
 * This method is called by the plot when it starts rendering a pass
 * through a series. The default implementation records the first and
 * last item indices. Subclasses can override this method to implement
 * custom per-series initialization.
 *
 * @param {jsfc.XYDataset} dataset  the dataset.
 * @param {number} series  the series index.
 * @param {number} firstItem  the index of the first item in the series.
 * @param {number} lastItem  the index of the last item in the series.
 * @param {number} pass  the pass index.
 * @param {number} passCount  the total number of passes.
 * @returns {undefined}
 */
jsfc.XYItemRendererState.prototype.startSeriesPass = function(dataset, series,
        firstItem, lastItem, pass, passCount) {
    this.firstItemIndex = firstItem;
    this.lastItemIndex = lastItem;
    // Hook for subclasses to override for custom behavior
};

/**
 * This method is called by the plot when it ends rendering a pass
 * through a series. The default implementation does nothing, but
 * subclasses can override this method to implement custom per-series
 * cleanup or finalization.
 *
 * @param {jsfc.XYDataset} dataset  the dataset.
 * @param {number} series  the series index.
 * @param {number} firstItem  the index of the first item in the series.
 * @param {number} lastItem  the index of the last item in the series.
 * @param {number} pass  the pass index.
 * @param {number} passCount  the total number of passes.
 * @returns {undefined}
 */
jsfc.XYItemRendererState.prototype.endSeriesPass = function(dataset, series,
        firstItem, lastItem, pass, passCount) {
    // Hook for subclasses to override for custom behavior
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * A base object for XYRenderer implementations.
 * @constructor
 * @param {jsfc.BaseXYRenderer} [instance]  the instance.
 */
jsfc.BaseXYRenderer = function(instance) {
    if (!(this instanceof jsfc.BaseXYRenderer)) {
        throw new Error("Use 'new' for constructor.");
    }
    if (!instance) {
        instance = this;
    }
    jsfc.BaseXYRenderer.init(instance);
};

/**
 * Initialises an object to have the attributes provided by this base 
 * renderer.
 * 
 * @param {jsfc.BaseXYRenderer} instance  the instance.
 * @returns {undefined}
 */
jsfc.BaseXYRenderer.init = function(instance) {
    var lineColors = jsfc.Colors.colorsAsObjects(jsfc.Colors.fancyLight());
    var fillColors = jsfc.Colors.colorsAsObjects(jsfc.Colors.fancyLight());
    instance._lineColorSource = new jsfc.ColorSource(lineColors);
    instance._fillColorSource = new jsfc.ColorSource(fillColors);
    instance._strokeSource = new jsfc.StrokeSource([new jsfc.Stroke(2)]);
    instance._listeners = [];    
};

/**
 * Returns the color source that provides line colors.
 * 
 * @returns {jsfc.ColorSource}
 */
jsfc.BaseXYRenderer.prototype.getLineColorSource = function() {
    return this._lineColorSource;
};

/**
 * Sets the color source that determines the line color for each data item.
 * 
 * @param {jsfc.ColorSource} cs  the color source.
 * @param {boolean} [notify]
 * @returns {undefined}
 */
jsfc.BaseXYRenderer.prototype.setLineColorSource = function(cs, notify) {
    this._lineColorSource = cs;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns a color to be used to draw lines for the specified data item.  The
 * method will first check if there is a series property in the dataset with
 * the key 'color'.  If it is present, it will be used as the line color, if
 * not the lineColorSource will be used.
 * 
 * @param {jsfc.XYDataset} dataset  the dataset.
 * @param {number} series  the series index.
 * @param {number} item  the item index.
 * @returns {jsfc.Color}
 */
jsfc.BaseXYRenderer.prototype.lookupLineColor = function(dataset, series, 
        item) {
    var seriesKey = dataset.seriesKey(series);
    var colorStr = dataset.getSeriesProperty(seriesKey, "color");
    if (colorStr) {
        return jsfc.Color.fromStr(colorStr);
    } else {
        return this._lineColorSource.getColor(series, item);
    }
};

/**
 * Returns the color source that provides fill colors.
 * 
 * @returns {jsfc.ColorSource}
 */
jsfc.BaseXYRenderer.prototype.getFillColorSource = function() {
    return this._fillColorSource;
};

/**
 * Sets the color source that determines the fill color for each data item.
 * 
 * @param {jsfc.ColorSource} cs  the color source.
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.BaseXYRenderer.prototype.setFillColorSource = function(cs, notify) {
    this._fillColorSource = cs;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns the object that determines the line stroke to be used by the
 * renderer for a particular data item.
 * 
 * @returns {jsfc.StrokeSource}  the stroke source.
 */
jsfc.BaseXYRenderer.prototype.getStrokeSource = function() {
    return this._strokeSource;
};

/**
 * Sets the object that determines the line stroke to be used by the renderer
 * for a particular data item and notifies listeners that the renderer has
 * changed.
 * 
 * @param {jsfc.StrokeSource} ss  the stroke source.
 * @param {boolean} [notify]
 * @returns {undefined}
 */
jsfc.BaseXYRenderer.prototype.setStrokeSource = function(ss, notify) {
    this._strokeSource = ss;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns the number of passes required to render the data.  Most renderers
 * will make a single pass through the dataset, but there are cases where 
 * multiple passes will be required.
 * 
 * @returns {!number} The number of passes required.
 */
jsfc.BaseXYRenderer.prototype.passCount = function() {
    return 1;
};

/**
 * Returns the range required on the y-axis in order for this renderer to 
 * fully display all the data items in the dataset.
 * 
 * @param {jsfc.StandardXYDataset} dataset  the dataset.
 * @returns {jsfc.Range} The range (can be undefined if the dataset has no data
 *         values).
 */
jsfc.BaseXYRenderer.prototype.calcYRange = function(dataset) {
    var bounds = jsfc.XYDatasetUtils.ybounds(dataset);
    if (bounds[1] >= bounds[0]) {
        return new jsfc.Range(bounds[0], bounds[1]);
    }
    return;
};

/**
 * Registers a listener to receive notification of changes to the renderer.  
 * The listener is a function - it will be passed one argument (this plot).
 * 
 * @param {Function} f  the listener function.
 * @returns {undefined}
 */
jsfc.BaseXYRenderer.prototype.addListener = function(f) {
    this._listeners.push(f);  
};

/**
 * Notify each listener function that this plot has changed.
 * 
 * @returns {undefined}
 */
jsfc.BaseXYRenderer.prototype.notifyListeners = function() {
    var plot = this;
    this._listeners.forEach(function(f) {
        f(plot);
    });
};

/**
 * Creates a new state object for rendering. This state object is passed
 * to the drawItem() method and maintains context across the rendering
 * sequence (see XYItemRendererState).
 *
 * @param {Object} [plotRenderingInfo]  optional plot rendering info.
 * @returns {jsfc.XYItemRendererState} a new state object.
 */
jsfc.BaseXYRenderer.prototype.createState = function(plotRenderingInfo) {
    return new jsfc.XYItemRendererState(plotRenderingInfo);
};

/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Creates a new renderer for generating scatter plots.
 * @constructor
 * @implements {jsfc.XYRenderer}
 * @param {jsfc.XYPlot} plot  the plot that the renderer is assigned to
 * @returns {jsfc.ScatterRenderer}
 */
jsfc.ScatterRenderer = function(plot) {
    if (!(this instanceof jsfc.ScatterRenderer)) {
        throw new Error("Use 'new' for constructors.");
    }
    jsfc.BaseXYRenderer.init(this);
    this._plot = plot;
    this._radius = 3;
};

// extend BaseXYRenderer (see also the init call in the constructor)
jsfc.ScatterRenderer.prototype = new jsfc.BaseXYRenderer();

/**
 * Returns the fill color string for an item.
 * 
 * @param {string} seriesKey  the series key.
 * @param {string} itemKey  the item key.
 * @returns {string} A color string.
 */
jsfc.ScatterRenderer.prototype.itemFillColorStr = function(seriesKey, 
        itemKey) {
    var dataset = this._plot.getDataset();
    var c = dataset.getProperty(seriesKey, itemKey, "color");
    if (c) {
        return c;
    } 
    var color = this.itemFillColor(seriesKey, itemKey);
    return color.rgbaStr();
};
    
/**
 * Returns the item fill color.
 * 
 * @param {string} seriesKey  the series key.
 * @param {string|number} itemKey  the item key.
 * @returns {jsfc.Color}
 */
jsfc.ScatterRenderer.prototype.itemFillColor = function(seriesKey, itemKey) {
    var dataset = this._plot.getDataset();
    var seriesIndex = dataset.seriesIndex(seriesKey);
    var itemIndex = dataset.itemIndex(seriesKey, itemKey);
    return this._lineColorSource.getColor(seriesIndex, itemIndex);
};

jsfc.ScatterRenderer.prototype.itemStrokeColor = function(seriesKey, itemKey) {
    if (this._plot._dataset.isSelected("select", seriesKey, itemKey)) {
        return "red";
    } 
    return "none";
};

/**
 * Draws one item.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context.
 * @param {!jsfc.Rectangle} dataArea  the data area.
 * @param {!jsfc.XYPlot} plot  the plot.
 * @param {!jsfc.XYDataset} dataset  the dataset.
 * @param {!number} seriesIndex
 * @param {!number} itemIndex
 * @param {!number} pass
 * @returns {undefined}
 */
jsfc.ScatterRenderer.prototype.drawItem = function(ctx, dataArea, plot, 
        dataset, seriesIndex, itemIndex, pass) {

    var seriesKey = dataset.seriesKey(seriesIndex);
    var itemKey = dataset.getItemKey(seriesIndex, itemIndex);
    
    // fetch the x and y values
    var x = dataset.x(seriesIndex, itemIndex);
    var y = dataset.y(seriesIndex, itemIndex);
    
    // convert these to target coordinates using the plot's axes
    var xx = plot.getXAxis().valueToCoordinate(x, dataArea.minX(), 
            dataArea.maxX());
    var yy = plot.getYAxis().valueToCoordinate(y, dataArea.maxY(), 
            dataArea.minY());

    // fill color - first check if it is defined as a property in the dataset
    var str = dataset.getItemProperty(seriesKey, itemKey, "color");
    var color;
    if (typeof str === "string") {
        color = jsfc.Color.fromStr(str);
    } else {
        color = this.itemFillColor(seriesKey, itemKey);
    }
    var r = this._radius;
    if (dataset.isSelected("selection", seriesKey, itemKey)) {
        r = r * 2;
    }
    ctx.setFillColor(color);
    ctx.setLineStroke(new jsfc.Stroke(0.2));
    ctx.setLineColor(jsfc.Colors.BLACK);
    ctx.setHint("ref", [seriesKey, itemKey]);
    ctx.drawCircle(xx, yy, r);
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Creates a new renderer for generating line charts.
 * 
 * @returns {jsfc.XYLineRenderer}
 * 
 * @constructor
 */
jsfc.XYLineRenderer = function() {
    if (!(this instanceof jsfc.XYLineRenderer)) {
        return new jsfc.XYLineRenderer();
    }
    jsfc.BaseXYRenderer.init(this);
    this._drawSeriesAsPath = true;
};

jsfc.XYLineRenderer.prototype = new jsfc.BaseXYRenderer();

/**
 * Returns the number of passes required to render the data.  In this case,
 * two passes are required, the first draws the lines and the second overlays
 * the shapes on top.
 * 
 * @returns {!number}
 */
jsfc.XYLineRenderer.prototype.passCount = function() {
    return 2;
};

/**
 * Draws a path for one series to the specified graphics context.
 * 
 * @param {jsfc.Context2D} ctx  the graphics context.
 * @param {jsfc.Rectangle} dataArea
 * @param {jsfc.XYPlot} plot
 * @param {jsfc.XYDataset} dataset
 * @param {number} seriesIndex
 * @returns {undefined}
 */
jsfc.XYLineRenderer.prototype.drawSeries = function(ctx, dataArea, plot,
        dataset, seriesIndex) {
    var itemCount = dataset.itemCount(seriesIndex);
    if (itemCount == 0) {
        return;
    }
    var connect = false;
    ctx.beginPath();
    for (var i = 0; i < itemCount; i++) {
        var x = dataset.x(seriesIndex, i);
        var y = dataset.y(seriesIndex, i);
        if (y === null) {
            connect = false;
            continue;
        }

        // convert these to target coordinates using the plot's axes
        var xx = plot.getXAxis().valueToCoordinate(x, dataArea.x(), dataArea.x() 
                + dataArea.width());
        var yy = plot.getYAxis().valueToCoordinate(y, dataArea.y() 
                + dataArea.height(), dataArea.y());
        if (!connect) {
            ctx.moveTo(xx, yy);
            connect = true;
        } else {
            ctx.lineTo(xx, yy);
        }
    }
    ctx.setLineColor(this.lookupLineColor(dataset, seriesIndex, i));
    ctx.setLineStroke(this._strokeSource.getStroke(seriesIndex, 0));
    ctx.stroke();
};

/**
 * Draws one data item to the specified graphics context.
 * 
 * @param {jsfc.Context2D} ctx  the graphics context.
 * @param {jsfc.Rectangle} dataArea
 * @param {jsfc.XYPlot} plot
 * @param {jsfc.XYDataset} dataset
 * @param {number} seriesIndex
 * @param {number} itemIndex
 * @returns {undefined}
 */
jsfc.XYLineRenderer.prototype.drawItem = function(ctx, dataArea, plot, 
        dataset, seriesIndex, itemIndex, pass) {

    if (pass === 0 && this._drawSeriesAsPath) {
        var itemCount = dataset.itemCount(seriesIndex);
        if (itemIndex === itemCount - 1) {
            this.drawSeries(ctx, dataArea, plot, dataset, seriesIndex);
        }
        return;
    }
    var x = dataset.x(seriesIndex, itemIndex);
    var y = dataset.y(seriesIndex, itemIndex);

    // convert these to target coordinates using the plot's axes
    var xx = plot.getXAxis().valueToCoordinate(x, dataArea.x(), dataArea.x() 
            + dataArea.width());
    var yy = plot.getYAxis().valueToCoordinate(y, dataArea.y() 
            + dataArea.height(), dataArea.y());
    
    if (pass === 0) { // in the FIRST pass draw lines
        if (itemIndex > 0) {
            // get the previous item
            var x0 = dataset.x(seriesIndex, itemIndex - 1);
            var y0 = dataset.y(seriesIndex, itemIndex - 1);
            var xx0 = plot.getXAxis().valueToCoordinate(x0, dataArea.x(), 
                    dataArea.x() + dataArea.width());
            var yy0 = plot.getYAxis().valueToCoordinate(y0, dataArea.y() 
                    + dataArea.height(), dataArea.y());
            // connect with a line
            ctx.setLineColor(this.lookupLineColor(dataset, seriesIndex, 
                    itemIndex));
            ctx.setLineStroke(this._strokeSource.getStroke(seriesIndex, 
                    itemIndex));
            ctx.drawLine(xx0, yy0, xx, yy);
        }
    } else if (pass === 1) { // in the second pass draw shapes if there are any
        //ctx.setFillColor(this.fillColors[seriesIndex]);
        //ctx.drawCircle(xx, yy, 4);
    }
  
};
/*
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Special renderer for CombinedDomainXYPlot that uses XYItemRendererState
 * to maintain proper rendering context across multiple subplots.
 */

"use strict";

/**
 * Creates a new special renderer for CombinedDomainXYPlot that properly
 * manages rendering state across multiple subplots with a shared domain axis.
 *
 * This renderer uses XYItemRendererState to maintain context and is designed
 * specifically for rendering series with a global color palette that doesn't
 * repeat across subplots.
 *
 * @constructor
 * @returns {jsfc.CombinedDomainXYItemRenderer}
 */
jsfc.CombinedDomainXYItemRenderer = function() {
    if (!(this instanceof jsfc.CombinedDomainXYItemRenderer)) {
        return new jsfc.CombinedDomainXYItemRenderer();
    }
    jsfc.BaseXYRenderer.init(this);
    this._drawSeriesAsPath = true;
};

jsfc.CombinedDomainXYItemRenderer.prototype = new jsfc.BaseXYRenderer();

/**
 * Returns the number of passes required to render the data. Two passes are
 * required: first for lines, second for shapes/markers.
 *
 * @returns {number}
 */
jsfc.CombinedDomainXYItemRenderer.prototype.passCount = function() {
    return 2;
};

/**
 * Draws a path for one series to the specified graphics context.
 * Uses the state object to access series boundary information.
 *
 * @param {jsfc.Context2D} ctx  the graphics context.
 * @param {jsfc.XYItemRendererState} state  the renderer state.
 * @param {jsfc.Rectangle} dataArea  the data area.
 * @param {jsfc.XYPlot} plot  the plot.
 * @param {jsfc.XYDataset} dataset  the dataset.
 * @param {number} seriesIndex  the series index (potentially global).
 * @returns {undefined}
 */
jsfc.CombinedDomainXYItemRenderer.prototype.drawSeries = function(ctx, state,
        dataArea, plot, dataset, seriesIndex) {
    // Use local series index for dataset access, but global index for colors
    var localSeriesIndex = state.localSeriesIndex;
    var itemCount = dataset.itemCount(localSeriesIndex);
    if (itemCount === 0) {
        return;
    }
    var connect = false;
    ctx.beginPath();
    for (var i = 0; i < itemCount; i++) {
        var x = dataset.x(localSeriesIndex, i);
        var y = dataset.y(localSeriesIndex, i);
        if (y === null) {
            connect = false;
            continue;
        }

        // convert these to target coordinates using the plot's axes
        var xx = plot.getXAxis().valueToCoordinate(x, dataArea.x(),
                dataArea.x() + dataArea.width());
        var yy = plot.getYAxis().valueToCoordinate(y, dataArea.y()
                + dataArea.height(), dataArea.y());
        if (!connect) {
            ctx.moveTo(xx, yy);
            connect = true;
        } else {
            ctx.lineTo(xx, yy);
        }
    }
    // Use global seriesIndex for color lookup (colors don't repeat across subplots)
    // Access color source directly using global index (avoids dataset.seriesKey call)
    ctx.setLineColor(this._lineColorSource.getColor(seriesIndex, itemCount - 1));
    ctx.setLineStroke(this._strokeSource.getStroke(seriesIndex, 0));
    ctx.stroke();
};

/**
 * Draws one data item to the specified graphics context using proper
 * state management.
 *
 * This is the main drawItem method that respects XYItemRendererState
 * for proper context management across subplots.
 *
 * @param {jsfc.Context2D} ctx  the graphics context.
 * @param {jsfc.XYItemRendererState} state  the renderer state.
 * @param {jsfc.Rectangle} dataArea  the data area.
 * @param {jsfc.XYPlot} plot  the plot.
 * @param {jsfc.XYDataset} dataset  the dataset.
 * @param {number} seriesIndex  the series index (potentially global).
 * @param {number} itemIndex  the item index.
 * @param {number} pass  the render pass.
 * @returns {undefined}
 */
jsfc.CombinedDomainXYItemRenderer.prototype.drawItem = function(ctx, state,
        dataArea, plot, dataset, seriesIndex, itemIndex, pass) {

    // Use local series index for dataset access, but global index for colors
    var localSeriesIndex = state.localSeriesIndex;

    if (pass === 0 && this._drawSeriesAsPath) {
        // Draw entire series as path in first pass if enabled
        var lastItem = state.getLastItemIndex();
        if (itemIndex === lastItem) {
            this.drawSeries(ctx, state, dataArea, plot, dataset, seriesIndex);
        }
        return;
    }

    var x = dataset.x(localSeriesIndex, itemIndex);
    var y = dataset.y(localSeriesIndex, itemIndex);

    // convert these to target coordinates using the plot's axes
    var xx = plot.getXAxis().valueToCoordinate(x, dataArea.x(),
            dataArea.x() + dataArea.width());
    var yy = plot.getYAxis().valueToCoordinate(y, dataArea.y()
            + dataArea.height(), dataArea.y());

    if (pass === 0) { // FIRST pass: draw lines
        var firstItem = state.getFirstItemIndex();
        if (itemIndex > firstItem) {
            // get the previous item using LOCAL series index
            var x0 = dataset.x(localSeriesIndex, itemIndex - 1);
            var y0 = dataset.y(localSeriesIndex, itemIndex - 1);
            var xx0 = plot.getXAxis().valueToCoordinate(x0, dataArea.x(),
                    dataArea.x() + dataArea.width());
            var yy0 = plot.getYAxis().valueToCoordinate(y0, dataArea.y()
                    + dataArea.height(), dataArea.y());

            // Use the state's working line object (memory optimization)
            state.workingLine.setLine(xx0, yy0, xx, yy);

            // connect with a line using the GLOBAL series index for color lookup
            // Access color source directly using global index (avoids dataset.seriesKey call)
            ctx.setLineColor(this._lineColorSource.getColor(seriesIndex,
                    itemIndex));
            ctx.setLineStroke(this._strokeSource.getStroke(seriesIndex,
                    itemIndex));
            ctx.drawLine(xx0, yy0, xx, yy);
        }
    } else if (pass === 1) { // SECOND pass: draw shapes/markers if any
        // Currently not drawing shapes, but hook is available
    }
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * @interface
 */
jsfc.Format = function() {
    throw new Error("Documents an interface only.");
};

/**
 * Returns a formatted version of the supplied number.
 * 
 * @param {!number} n  the number to format.
 * @returns {!string} A string representing the formatted number.
 */
jsfc.Format.prototype.format = function(n) {
};

/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Creates a new number formatter.  By default, a comma is used for the
 * decimal separator.
 * 
 * @constructor
 * @implements {jsfc.Format}
 * @param {!number} dp  the number of decimal places.
 * @param {boolean} [exponential]  show in exponential format (defaults to 
 *         false).
 * @returns {!jsfc.NumberFormat}
 */
jsfc.NumberFormat = function(dp, exponential) {
    if (!(this instanceof jsfc.NumberFormat)) {
        throw new Error("Use 'new' for construction.");
    }    
    this._dp = dp;
    this.separator = ",";
    this._exponential = exponential || false;
};

/**
 * Returns a formatted version of the supplied number based on the current
 * configuration of this instance.
 * 
 * @param {!number} n  the number to format.
 * @returns {!string} A string representing the formatted number.
 */
jsfc.NumberFormat.prototype.format = function(n) {
    jsfc.Args.requireNumber(n, "n");
    if (this._exponential) {
        return n.toExponential(this._dp);
    }
    var str;
    if (this._dp === Number.POSITIVE_INFINITY) {
        str = n.toString();
    } else {
        str = n.toFixed(this._dp); 
    }
    var i = str.indexOf(".");
    if (i >= 0) {
        var pre = str.slice(0, i);
        var post = str.slice(i);
        // http://blog.tompawlak.org/number-currency-formatting-javascript
        if (this.separator) {
            pre = pre.replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1" + this.separator);
        }
        str = pre + post;
    }
    return str;
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * Creates a new object representing the insets for a rectangular shape.
 * 
 * @constructor 
 * @classdesc A record of the space reserved around a data area for drawing
 *     axes.  THis object has the same methods as jsfc.Insets but is mutable.
 *     
 * @param {number} top  the insets for the top edge.
 * @param {number} left  the insets for the left edge.
 * @param {number} bottom  the insets for the bottom edge.
 * @param {number} right  the insets for the right edge.
 * @returns {jsfc.Insets} The new instance.
 */
jsfc.AxisSpace = function(top, left, bottom, right) {
    if (!(this instanceof jsfc.AxisSpace)) {
        throw new Error("Use 'new' for constructor.");
    }
    jsfc.Args.requireNumber(top, "top");
    jsfc.Args.requireNumber(left, "left");
    jsfc.Args.requireNumber(bottom, "bottom");
    jsfc.Args.requireNumber(right, "right");
    this._top = top;
    this._left = left;
    this._bottom = bottom;
    this._right = right;
};

/**
 * Returns the insets for the top edge.
 * @returns {number} The top insets.
 */
jsfc.AxisSpace.prototype.top = function() {
    return this._top;
};

/**
 * Returns the insets for the left edge.
 * @returns {number} The left insets.
 */
jsfc.AxisSpace.prototype.left = function() {
    return this._left;
};

/**
 * Returns the insets for the bottom edge.
 * @returns {number} The bottom insets.
 */
jsfc.AxisSpace.prototype.bottom = function() {
    return this._bottom;
};

/**
 * Returns the insets for the right edge.
 * @returns {number} The right insets.
 */
jsfc.AxisSpace.prototype.right = function() {
    return this._right;
};

/**
 * Extends the amount of space on the specified edge.
 * 
 * @param {!number} space  the amount of space to add.
 * @param {!string} edge  the edge to add to.
 * @returns {jsfc.AxisSpace} This object (for chaining method calls).
 */
jsfc.AxisSpace.prototype.extend = function(space, edge) {
    jsfc.Args.requireNumber(space, "space");
    if (edge === jsfc.RectangleEdge.TOP) {
        this._top += space;
    } else if (edge === jsfc.RectangleEdge.BOTTOM) {
        this._bottom += space;
    } else if (edge === jsfc.RectangleEdge.LEFT) {
        this._left += space;
    } else if (edge === jsfc.RectangleEdge.RIGHT) {
        this._right += space;
    } else {
        throw new Error("Unrecognised 'edge' code: " + edge);
    }
    return this;
};

/**
 * Returns a new rectangle computed from the 'source' rectangle by subtracting 
 * the reserved space from this object.
 * @param {!jsfc.Rectangle} source  the source rectangle.
 * @returns {!jsfc.Rectangle}
 */
jsfc.AxisSpace.prototype.innerRect = function(source) {
    var x = source.x() + this._left;
    var y = source.y() + this._top;
    var w = source.width() - this._left - this._right;
    var h = source.height() - this._top - this._bottom;
    return new jsfc.Rectangle(x, y, w, h);
};

/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

jsfc.LabelOrientation = {
    
    PERPENDICULAR: "PERPENDICULAR",
    
    PARALLEL: "PARALLEL"

};

if (Object.freeze) {
    Object.freeze(jsfc.LabelOrientation);
}/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * @class Represents a tick mark.
 * @constructor
 * @param {number} value  the data value.
 * @param {string} label  the label.
 * @returns {jsfc.TickMark}
 */
jsfc.TickMark = function(value, label) {
    if (!(this instanceof jsfc.TickMark)) {
        throw new Error("Use 'new' for constructor.");
    }
    this.value = value;
    this.label = label;
};

jsfc.TickMark.prototype.toString = function() {
    return this.label;
};


/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Creates a new NumberTickSelector instance.
 * @param {boolean} percentage  show values as percentages?
 * @returns {jsfc.NumberTickSelector}
 * @constructor
 * @classdesc 
 */
jsfc.NumberTickSelector = function(percentage) {
    if (!(this instanceof jsfc.NumberTickSelector)) {
        throw new Error("Use 'new' for constructor.");
    }
    this._power = 0;
    this._factor = 1;
    this._percentage = percentage;
    this._formats = [];
    for (var i = 0; i < 16; i++) {
        this._formats[i] = new jsfc.NumberFormat(i);
    }
};

/**
 * Selects and returns a standard tick size that is greater than or equal to 
 * the specified reference value and, ideally, as close to it as possible 
 * (to minimise the number of iterations used by axes to determine the tick
 * size to use).
 * 
 * @param {number} reference  the reference value.
 * @returns {number} The selected value.
 */
jsfc.NumberTickSelector.prototype.select = function(reference) {
    this._power = Math.ceil(Math.LOG10E * Math.log(reference));
    this._factor = 1;
    return this.currentTickSize();    
};

/**
 * Returns the current tick size.
 * 
 * @returns {number} The current tick size.
 */
jsfc.NumberTickSelector.prototype.currentTickSize = function() {
    return this._factor * Math.pow(10.0, this._power);
};

/**
 * Returns a formatter that is appropriate for the current tick size.
 * 
 * @returns {jsfc.NumberFormat}
 */
jsfc.NumberTickSelector.prototype.currentTickFormat = function() {
    if (this._power < 0 && this._power > -16) {
        return this._formats[Math.abs(this._power)];
    }
    if (this._power < -15) {
        return new jsfc.NumberFormat(Number.POSITIVE_INFINITY);
    }
    if (this._power > 8) {
        return new jsfc.NumberFormat(1, true);
    }
    return this._formats[0];
};

/**
 * Moves the pointer to the next available (larger) standard tick size and
 * returns true (the contract for this method says to return false if there 
 * is no larger tick size).
 * 
 * @returns {boolean}
 */
jsfc.NumberTickSelector.prototype.next = function() {
    if (this._power === 300 && this._factor === 5) {
        return false;
    }
    if (this._factor === 1) {
        this._factor = 2;
        return true;
    } 
    if (this._factor === 2) {
        this._factor = 5;
        return true;  
    } 
    if (this._factor === 5) {
        this._power++;
        this._factor = 1;
        return true;
    } 
    // it should not be possible to get a factor that is not equal to 1, 2 or 5
    throw new Error("Factor should be 1, 2 or 5: " + this._factor);
};

/**
 * Moves the pointer to the previous available (smaller) standard tick size and
 * returns true (the contract for this method says to return false if there 
 * is no larger tick size).
 * 
 * @returns {boolean}
 */
jsfc.NumberTickSelector.prototype.previous = function() {
    if (this._power === -300 && this._factor === 1) {
        return false;
    }
    if (this._factor === 1) {
        this._factor = 5;
        this._power--;
        return true;
    } 
    if (this._factor === 2) {
        this._factor = 1;
        return true;  
    } 
    if (this._factor === 5) {
        this._factor = 2;
        return true;
    } 
    // it should not be possible to get a factor that is not equal to 1, 2 or 5
    throw new Error("Factor should be 1, 2 or 5: " + this._factor);
};

/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * @interface
 */
jsfc.ValueAxis = function() {
    throw new Error("This object documents an interface.");
};

/**
 * Sets the label for the axis and sends a change notification to registered
 * listeners (unless 'notify' is set to false).
 * 
 * @param {string} label  the new label (null is permitted).
 * @param {boolean} [notify]  notify listeners (defaults to true).
 * @returns {undefined}
 */
jsfc.ValueAxis.prototype.setLabel = function(label, notify) {
};

/**
 * Returns the lower bound of the axis (the minimum data value that will be
 * displayed).
 * 
 * @returns {!number} The lower bound.
 */
jsfc.ValueAxis.prototype.getLowerBound = function() {
};

/**
 * Returns the upper bound of the axis (the maximum data value that will be
 * displayed).
 * 
 * @returns {!number} The lower bound.
 */
jsfc.ValueAxis.prototype.getUpperBound = function() {
};

/**
 * Returns the length of the axis (the difference between the upper bound and
 * the lower bound).
 * 
 * @returns {!number}
 */
jsfc.ValueAxis.prototype.length = function() {
};

/**
 * Returns true if the current axis range contains the specified value, and
 * false otherwise.
 * 
 * @param {!number} value  the data value.
 * @returns {!boolean}
 */
jsfc.ValueAxis.prototype.contains = function(value) {  
};

/**
 * Configures this axis for use as an x-axis for the specified plot.
 * 
 * @param {!jsfc.XYPlot} plot  the plot.
 * @returns {undefined}
 */
jsfc.ValueAxis.prototype.configureAsXAxis = function(plot) {    
};

/**
 * Configures this axis for use as a y-axis for the specified plot.
 * 
 * @param {jsfc.CategoryPlot|jsfc.XYPlot} plot  the plot.
 * @returns {undefined}
 */
jsfc.ValueAxis.prototype.configureAsYAxis = function(plot) {
};

/**
 * Converts a data value to a coordinate in the range r0 to r1, assuming that
 * these are equivalent to the current axis range.
 * 
 * @param {!number} value  the data value.
 * @param {!number} r0  the starting coordinate of the target range.
 * @param {!number} r1  the ending coordinate of the target range.
 * @returns {!number} The coordinate.
 */
jsfc.ValueAxis.prototype.valueToCoordinate = function(value, r0, r1) {  
};

/**
 * Converts a coordinate to a data value, assuming that the coordinate range
 * r0 to r1 corresponds to the current axis bounds.
 * 
 * @param {!number} coordinate  the coordinate.
 * @param {!number} r0  the starting coordinate.
 * @param {!number} r1  the ending coordinate.
 * @returns {!number} The data value.
 */
jsfc.ValueAxis.prototype.coordinateToValue = function(coordinate, r0, r1) {  
};

jsfc.ValueAxis.prototype.resizeRange = function(factor, anchorValue, notify) {
};
    
jsfc.ValueAxis.prototype.pan = function(percent, notify) {
};

/**
 * Calculates the amount of space to reserve for drawing the axis.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context.
 * @param {jsfc.CategoryPlot|jsfc.XYPlot} plot  the plot.
 * @param {!jsfc.Rectangle} bounds  the plot bounds.
 * @param {!jsfc.Rectangle} area  the estimated data area.
 * @param {!string} edge  the edge that denotes the axis position.
 * @returns {!number} The space to reserve for the axis.
 */
jsfc.ValueAxis.prototype.reserveSpace = function(ctx, plot, bounds, area, 
        edge) {
};

/**
 * Draws the axis.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context.
 * @param {!jsfc.CategoryPlot|jsfc.XYPlot} plot
 * @param {!jsfc.Rectangle} bounds
 * @param {!jsfc.Rectangle} dataArea
 * @param {!number} offset
 * @returns {undefined}
 */
jsfc.ValueAxis.prototype.draw = function(ctx, plot, bounds, dataArea, offset) {
};

/**
 * Registers a listener to receive notification of changes to the axis.
 * 
 * @param {Function} listener  the listener.
 * @returns {undefined}
 */
jsfc.ValueAxis.prototype.addListener = function(listener) {
};/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * @classdesc A base class for value axes.
 * @constructor
 * @param {string|null|undefined} [label]  the axis label (null permitted).
 * @param {jsfc.BaseValueAxis} [instance] The instance object (optional).
 */
jsfc.BaseValueAxis = function(label, instance) {
    if (!(this instanceof jsfc.BaseValueAxis)) {
        throw new Error("Use 'new' for construction.");
    }
    if (!instance) {
        instance = this;
    }
    if (!label) {
        label = null;
    }
    jsfc.BaseValueAxis.init(label, instance);
};

/**
 * Initialises the attributes for an instance.
 * 
 * @param {string|null|undefined} label  the label (null permitted).
 * @param {!jsfc.BaseValueAxis} instance  the instance.
 * @returns {undefined}
 */
jsfc.BaseValueAxis.init = function(label, instance) {
    instance._label = label;
    instance._listeners = [];
    instance._labelFont = new jsfc.Font("Palatino;serif", 12, true, false);
    instance._labelColor = new jsfc.Color(0, 0, 0);
    instance._labelMargin = new jsfc.Insets(2, 2, 2, 2);
    instance._tickLabelFont = new jsfc.Font("Palatino;serif", 12);
    instance._tickLabelColor = new jsfc.Color(0, 0, 0);
    instance._axisLineColor = new jsfc.Color(100, 100, 100);
    instance._axisLineStroke = new jsfc.Stroke(0.5);
    instance._gridLinesVisible = true;
    instance._gridLineStroke = new jsfc.Stroke(1);
    instance._gridLineColor = new jsfc.Color(255, 255, 255);
};

/**
 * Returns the axis label.
 * 
 * @returns {string} The axis label (possibly null).
 */
jsfc.BaseValueAxis.prototype.getLabel = function() {
    return this._label;
};

/**
 * Sets the axis label and sends a change notification to all registered
 * listeners (unless 'notify' is set to false).
 * 
 * @param {string} label  the label (null permitted).
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.BaseValueAxis.prototype.setLabel = function(label, notify) {
    this._label = label;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns the font for the axis label.
 * 
 * @returns {jsfc.Font} The font.
 */
jsfc.BaseValueAxis.prototype.getLabelFont = function() {
    return this._labelFont;
};

/**
 * Sets the font for the axis label and sends a change notification to 
 * registered listeners (unless 'notify' is set to false).
 * 
 * @param {jsfc.Font} font  the font.
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.BaseValueAxis.prototype.setLabelFont = function(font, notify) {
    this._labelFont = font;
    if (notify !== false) {
        this.notifyListeners();   
    };
};

/**
 * Returns the color for the axis label.  The default color is black.
 * 
 * @returns {jsfc.Color} The color (never null).
 */
jsfc.BaseValueAxis.prototype.getLabelColor = function() {
    return this._labelColor;
};

/**
 * Sets the color for the axis label and sends a change notification to 
 * registered listeners (unless 'notify' is set to false).
 * 
 * @param {!jsfc.Color} color  the color.
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.BaseValueAxis.prototype.setLabelColor = function(color, notify) {
    this._labelColor = color;
    if (notify !== false) {
        this.notifyListeners();   
    };
};

/**
 * Returns the label margin (the number of pixels to leave around the edges
 * of the axis label (this can be used to control the spacing between the axis
 * label and the tick labels).  The default value is Insets(2, 2, 2, 2).  
 * 
 * Note that the insets are applied in the regular screen orientation, even if
 * the label is rotated (that is, left is always to the left side of the 
 * screen, top is always to the top of the screen).
 * 
 * @returns {jsfc.Insets} The margin.
 */
jsfc.BaseValueAxis.prototype.getLabelMargin = function() {
    return this._labelMargin;
};

/**
 * Sets the label margin and sends a change notification to all registered
 * listeners (unless 'notify' is set to false).
 * 
 * @param {jsfc.Insets} margin  the new margin.
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.BaseValueAxis.prototype.setLabelMargin = function(margin, notify) {
    this._labelMargin = margin;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns the font used to display the tick labels.
 * 
 * @returns {jsfc.Font} The font (never null).
 */
jsfc.BaseValueAxis.prototype.getTickLabelFont = function() {
    return this._tickLabelFont;
};

/**
 * Sets the font used to display tick labels and sends a change event to 
 * all registered listeners (unless 'notify' is set to false).
 * 
 * @param {jsfc.Font} font  the font.
 * @param {boolean} notify
 * @returns {undefined}
 */
jsfc.BaseValueAxis.prototype.setTickLabelFont = function(font, notify) {
    this._tickLabelFont = font;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns the color used to display the tick labels.
 * 
 * @returns {jsfc.Color}
 */
jsfc.BaseValueAxis.prototype.getTickLabelColor = function() {
    return this._tickLabelColor;
};

/**
 * Sets the color for the tick labels and sends a change notification to 
 * all registered listeners (unless 'notify' is set to false).
 * 
 * @param {!jsfc.Color} color  the color.
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.BaseValueAxis.prototype.setTickLabelColor = function(color, notify) {
    this._tickLabelColor = color;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns the axis line color.
 * 
 * @returns {jsfc.Color} The color (never null).
 */
jsfc.BaseValueAxis.prototype.getAxisLineColor = function() {
    return this._axisLineColor;
};

/**
 * Sets the axis line color and sends a change notification to all registered
 * listeners (unless 'notify' is set to false).
 * 
 * @param {!jsfc.Color} color  the new color (null not permitted).
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.BaseValueAxis.prototype.setAxisLineColor = function(color, notify) {
    this._axisLineColor = color;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns the stroke used to draw the axis line.
 * 
 * @returns {jsfc.Stroke} The stroke (never null).
 */
jsfc.BaseValueAxis.prototype.getAxisLineStroke = function() {
    return this._axisLineStroke;
};

/**
 * Sets the axis line stroke and sends a change notification to registered
 * listeners (unless 'notify' is set to false).
 * 
 * @param {jsfc.Stroke} stroke  the stroke.
 * @param {boolean} notify  notify listeners.
 * @returns {undefined}
 */
jsfc.BaseValueAxis.prototype.setAxisLineStroke = function(stroke, notify) {
    this._axisLineStroke = stroke;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Registers a listener to receive notification of changes to the axis.
 * 
 * @param {Function} listener  the listener.
 * @returns {undefined}
 */
jsfc.BaseValueAxis.prototype.addListener = function(listener) {
    this._listeners.push(listener);  
};

/**
 * Removes a listener so that it no longer receives event notifications from 
 * this axis.
 * 
 * @param {!Function} listener  the listener function.
 * 
 * @returns {jsfc.BaseValueAxis} This object for chaining method calls.
 */
jsfc.BaseValueAxis.prototype.removeListener = function(listener) {
    var i = this._listeners.indexOf(listener);
    if (i >= 0) {
        this._listeners.splice(i, 1);
    }
    return this;    
};

/**
 * Notify each listener function that this axis has changed.
 * 
 * @returns {undefined}
 */
jsfc.BaseValueAxis.prototype.notifyListeners = function() {
    var axis = this;
    this._listeners.forEach(function(listener) {
        listener(axis);
    });
};

/**
 * Returns the flag that controls whether or not gridlines are drawn for this
 * axis.
 * 
 * @returns {Boolean} A boolean.
 */
jsfc.BaseValueAxis.prototype.isGridLinesVisible = function() {
    return this._gridLinesVisible;
};

/**
 * Sets the flag that controls whether or not gridlines are drawn for this
 * axis and sends a change notification to all registered listeners (unless
 * 'notify' is set to false).
 * 
 * @param {boolean} visible  the new flag value.
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.BaseValueAxis.prototype.setGridLinesVisible = function(visible, notify) {
    this._gridLinesVisible = visible !== false;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns the stroke for the gridlines.
 * 
 * @returns {jsfc.Stroke} The stroke.
 */
jsfc.BaseValueAxis.prototype.getGridLineStroke = function() {
    return this._gridLineStroke;
};

/**
 * Sets the stroke for the gridlines and sends a change notification to all
 * registered listeners (unless 'notify' is set to false).
 * 
 * @param {jsfc.Stroke} stroke  the stroke (null not permitted).
 * @param {boolean} notify  notify listeners?
 * @returns {undefined}
 */
jsfc.BaseValueAxis.prototype.setGridLineStroke = function(stroke, notify) {
    this._gridLineStroke = stroke;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns the color for the gridlines.
 * 
 * @returns {jsfc.Color} The color.
 */
jsfc.BaseValueAxis.prototype.getGridLineColor = function() {
    return this._gridLineColor;
};

/**
 * Sets the color for the gridlines and sends a change notification to all
 * registered listeners (unless 'notify' is set to false).
 * 
 * @param {jsfc.Color} color  the color (null not permitted).
 * @param {boolean} notify  notify listeners?
 * @returns {undefined}
 */
jsfc.BaseValueAxis.prototype.setGridLineColor = function(color, notify) {
    this._gridLineColor = color;
    if (notify !== false) {
        this.notifyListeners();
    }
};




/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Creates a new instance.
 * @constructor  
 * @implements {jsfc.ValueAxis}
 * @param {string} [label]  the axis label.
 * @param {jsfc.LinearAxis} [instance]  the instance.
 * @returns {jsfc.LinearAxis}
 * 
 * @class A linear numerical axis.  Note that all properties having names 
 * beginning with an underscore should be treated as private.  Updating these 
 * properties directly is strongly discouraged.  Look for accessor methods 
 * instead.
 */
jsfc.LinearAxis = function(label, instance) {
    if (!(this instanceof jsfc.LinearAxis)) {
        throw new Error("Use 'new' with constructor.");
    }
    if (!instance) {
        instance = this;
    }
    jsfc.LinearAxis.init(label, instance);
};

/**
 * Initialise the attributes for this instance.
 * 
 * @param {string|undefined} label  the label (can be undefined).
 * @param {!jsfc.LinearAxis} instance  the instance.
 * @returns {undefined}
 */
jsfc.LinearAxis.init = function(label, instance) {

    // extend the BaseValueAxis object
    jsfc.BaseValueAxis.init(label, instance);
    
    // current axis bounds 
    instance._lowerBound = 0.0;
    instance._upperBound = 1.0;
   
    // do we automatically calculate the axis range based on the data and, if
    // yes, do we force the range to include zero? 
    instance._autoRange = true;  
    instance._autoRangeIncludesZero = false;
    instance._lowerMargin = 0.05;
    instance._upperMargin = 0.05;
    
    // default range (when there is no data), this can also be used for the
    // default axis length when there is just a single value
    instance._defaultRange = new jsfc.Range(0, 1);
    
    // the tick selector and tick formatter
    instance._tickSelector = new jsfc.NumberTickSelector(false);
    instance._formatter = new jsfc.NumberFormat(2);
    
    // tick mark attributes
    instance._tickMarkInnerLength = 0;
    instance._tickMarkOuterLength = 2;
    instance._tickMarkStroke = new jsfc.Stroke(0.5);
    instance._tickMarkColor = new jsfc.Color(100, 100, 100);
    
    // tick label attributes
    instance._tickLabelMargin = new jsfc.Insets(2, 2, 2, 2);
    instance._tickLabelFactor = 1.4;
    instance._tickLabelOrientation = null;
        // null means it will be derived, otherwise
        // it can be set to PARALLEL or PERPENDICULAR
        
    // if not null, this formatter overrides the one provided by the selector
    instance._tickLabelFormatOverride = null;
    
    instance._symbols = [];
};

// extend BaseValueAxis - see also the init() call in the constructor
jsfc.LinearAxis.prototype = new jsfc.BaseValueAxis();

/**
 * Returns the lower bound for the axis.
 * 
 * @returns {!number}
 */
jsfc.LinearAxis.prototype.getLowerBound = function() {
    return this._lowerBound;
};

/**
 * Returns the upper bound for the axis.
 * 
 * @returns {!number}
 */
jsfc.LinearAxis.prototype.getUpperBound = function() {
    return this._upperBound;
};

/**
 * Returns the length of the axis (upper bound minus the lower bound).
 * 
 * @returns {!number}
 */
jsfc.LinearAxis.prototype.length = function() {
    return this._upperBound - this._lowerBound;
};

/**
 * Returns true if the current axis range contains the specified value, and
 * false otherwise.  The test is inclusive of the axis end points (lower and
 * upper bounds).
 * 
 * @param {!number} value  the data value.
 * @returns {!boolean}
 */
jsfc.LinearAxis.prototype.contains = function(value) {
    return value >= this._lowerBound && value <= this._upperBound;
};

/**
 * Sets the upper and lower bounds for the axis, switches off the auto-range
 * calculation (if it was enabled) and sends a change notification to 
 * registered listeners.
 * 
 * @param {!number} lower  the lower bound.
 * @param {!number} upper  the upper bound.
 * @param {boolean} [notify]  notify listeners?
 * @param {boolean} [keepAutoRangeFlag]  preserve the autoRange flag setting?
 * 
 * @returns {jsfc.LinearAxis} This object for chaining method calls.
 */
jsfc.LinearAxis.prototype.setBounds = function(lower, upper, notify, 
        keepAutoRangeFlag) {
    if (lower >= upper) {
        throw new Error("Require upper > lower: " + lower + " > " + upper);
    }
    this._lowerBound = lower;
    this._upperBound = upper;
    if (!keepAutoRangeFlag) {
        this._autoRange = false;
    }
    if (notify !== false) {
        this.notifyListeners();
    }
    return this;
};

/**
 * Sets the axis bounds using percentage values relative to the current bounds.
 * 
 * @param {!number} lower  the lower percentage.
 * @param {!number} upper  the upper percentage.
 * @param {boolean} [notify]  notify listeners? (optional, defaults to true).
 * @param {boolean} [keepAutoRangeFlag]  don't reset the auto-range flag
 * @returns {jsfc.LinearAxis} This axis for chaining method calls.
 */
jsfc.LinearAxis.prototype.setBoundsByPercent = function(lower, upper, notify, 
        keepAutoRangeFlag) {
    var v0 = this._lowerBound;
    var v1 = this._upperBound;
    var len = v1 - v0;
    var b0 = v0 + lower * len;
    var b1 = v0 + upper * len;
    if (b1 > b0 && isFinite(b1 - b0)) {
        this._lowerBound = b0;
        this._upperBound = b1;
        if (!keepAutoRangeFlag) {
            this._autoRange = false;
        }
        if (notify !== false) {
            this.notifyListeners();
        }
    }
    return this;
};

/**
 * Returns the flag that controls whether the axis bounds are automatically 
 * updated whenever the dataset changes.  The default value is true.
 * 
 * @returns {Boolean} A boolean.
 */
jsfc.LinearAxis.prototype.isAutoRange = function() {
    return this._autoRange;
};

/**
 * Sets the flag that controls whether the axis bounds are automatically 
 * updated whenever the dataset changes and sends a change notification to
 * registered listeners (unless 'notify' is set to false).
 * 
 * @param {boolean} auto  the new flag value.
 * @param {boolean} [notify]  notify listeners?
 * @returns {jsfc.LinearAxis} This object for chaining method calls.
 */
jsfc.LinearAxis.prototype.setAutoRange = function(auto, notify) {
    this._autoRange = auto;
    if (notify !== false) {
        this.notifyListeners();
    }
    return this;
};

/**
 * Returns the flag that controls whether the auto-range is forced to include
 * zero.  The default value is false.
 * 
 * @returns {Boolean} A boolean.
 */
jsfc.LinearAxis.prototype.getAutoRangeIncludesZero = function() {
    return this._autoRangeIncludesZero;
};

/**
 * Sets the flag that controls whether the auto-range is forced to include
 * zero and sends a change notification to registered listeners (unless the
 * 'notify' flag is set to false).
 * 
 * @param {boolean} include  the new value.
 * @param {boolean} [notify]  notify listeners.
 * @returns {jsfc.LinearAxis} This object for chaining method calls.
 */
jsfc.LinearAxis.prototype.setAutoRangeIncludesZero = function(include, 
        notify) {
    this._autoRangeIncludesZero = include;
    if (notify !== false) {
        this.notifyListeners();
    }
    return this;
};

/**
 * Returns the lower margin, a percentage of the axis length that is added
 * as a margin during the auto-range calculation.  The default value is 0.05
 * (five percent).
 * 
 * @returns {!number} The lower margin.
 */
jsfc.LinearAxis.prototype.getLowerMargin = function() {
    return this._lowerMargin;
};

/**
 * Sets the lower margin and sends a change notification to all registered
 * listeners.
 * 
 * @param {!number} margin  the new margin.
 * @param {boolean} [notify]  notify listeners?
 * @returns {jsfc.LinearAxis} This object for chaining method calls.
 */
jsfc.LinearAxis.prototype.setLowerMargin = function(margin, notify) {
    this._lowerMargin = margin;
    if (notify !== false) {
        this.notifyListeners();
    }
    return this;
};

/**
 * Returns the upper margin, a percentage of the axis length that is added
 * as a margin during the auto-range calculation.  The default value is 0.05
 * (five percent).
 * 
 * @returns {!number} The upper margin.
 */
jsfc.LinearAxis.prototype.getUpperMargin = function() {
    return this._upperMargin;
};

/**
 * Sets the upper margin and sends a change notification to all registered
 * listeners.
 * 
 * @param {!number} margin  the new margin.
 * @param {boolean} [notify]  notify listeners?
 * @returns {jsfc.LinearAxis} This object for chaining method calls.
 */
jsfc.LinearAxis.prototype.setUpperMargin = function(margin, notify) {
    this._upperMargin = margin;
    if (notify !== false) {
        this.notifyListeners();
    }
    return this;
};

/**
 * Returns the override formatter for the tick labels.  The default value is
 * null.
 * 
 * @returns {jsfc.Format} The override formatter (possibly undefined/null).
 */
jsfc.LinearAxis.prototype.getTickLabelFormatOverride = function() {
    return this._tickLabelFormatOverride;
};

/**
 * Sets the override formatter for the tick labels and sends a change 
 * notification to registered listeners (unless 'notify' is false).
 * 
 * @param {jsfc.Format} formatter  the formatter (null permitted).
 * @param {boolean} [notify]  notify listeners?
 * @returns {jsfc.LinearAxis} This object for chaining method calls.
 */
jsfc.LinearAxis.prototype.setTickLabelFormatOverride = function(formatter, 
        notify) {
    this._tickLabelFormatOverride = formatter;
    if (notify !== false) {
        this.notifyListeners();
    }
    return this;
};

/**
 * Applies the auto-range (including the addition of margins, or the default
 * range length in the case where the supplied min and max are the same).
 * 
 * @param {number} min  the minimum data value.
 * @param {number} max  the maximum data value.
 * @returns {undefined}
 */
jsfc.LinearAxis.prototype._applyAutoRange = function(min, max) {
    if (this._autoRangeIncludesZero) {
        if (min > 0) min = 0;
        if (max < 0) max = 0;
    }
    var xrange = max - min;
    var lowAdj, highAdj;
    if (xrange > 0.0) {
        lowAdj = this._lowerMargin * xrange;
        highAdj = this._upperMargin * xrange;
    } else {
        lowAdj = 0.5 * this._defaultRange.length();
        highAdj = 0.5 * this._defaultRange.length();
    }
    this.setBounds(min - lowAdj, max + highAdj, false, true);
};

/**
 * Translates a data value to a coordinate in the given range.
 * 
 * @param {number} value  the value.
 * @param {number} r0  the lower bound of the coordinate (screen) range.
 * @param {number} r1  the upper bound of the coordinate (screen) range.
 * 
 * @returns {number} The coordinate value.
 */
jsfc.LinearAxis.prototype.valueToCoordinate = function(value, r0, r1) {
    jsfc.Args.requireNumber(r0, "r0");
    jsfc.Args.requireNumber(r1, "r1");
    // let's say the axis runs from a to b...
    var a = this._lowerBound;
    var b = this._upperBound;
    return r0 + ((value - a) / (b - a)) * (r1 - r0);
};

/**
 * Translates a coordinate from the given range to a value on the axis scale.
 * 
 * @param {number} coordinate  the coordinate value.
 * @param {number} r0  the lower bound of the coordinate (screen) range.
 * @param {number} r1  the upper bound of the coordinate (screen) range.
 * @returns {number} The data value.
 */
jsfc.LinearAxis.prototype.coordinateToValue = function(coordinate, r0, r1) {
    var a = this._lowerBound;
    var b = this._upperBound;
    return a + ((coordinate - r0) / (r1 - r0)) * (b - a);
};

/**
 * Calculates a good tick size for the axis assuming it is drawn along the
 * specified edge of the area.  This method should return NaN if there is
 * no good tick size (in which case the axis should just label the end points).
 * 
 * @param {jsfc.Context2D} ctx  the graphics context (used to measure string 
 *         dimensions).
 * @param {jsfc.Rectangle} area  the data area for the plot (the axis lies 
 *         along one edge).
 * @param {string} edge  the edge along which the axis lies.
 * @returns {number} The tick size.
 */
jsfc.LinearAxis.prototype._calcTickSize = function(ctx, area, edge) {
    var result = Number.NaN;
    var pixels = area.length(edge);
    var range = this._upperBound - this._lowerBound;
    if (range <= 0) {
        throw new Error("Can't have a zero range.");
    }
    var orientation = this._resolveTickLabelOrientation(edge);
    var selector = this._tickSelector;
    if (orientation === jsfc.LabelOrientation.PERPENDICULAR) {
        // work with the label height
        var textHeight = ctx.textDim("123").height();
        var maxTicks = pixels / (textHeight * this._tickLabelFactor);
        if (maxTicks > 2) {
            var tickSize = selector.select(range / 2);
            var tickCount = Math.floor(range / tickSize);
            var b = true;
            while (tickCount < maxTicks && b) {
                b = selector.previous();
                tickCount = Math.floor(range / selector.currentTickSize());
            }
            if (b) selector.next();
            result = selector.currentTickSize();
            this._formatter = selector.currentTickFormat();
        } else {
            // result remains Number.NaN
        }
    } else if (orientation === jsfc.LabelOrientation.PARALLEL) {
        // work with label widths (approximate by measuring the min and max).
        // If a tickLabelFormatOverride is set (e.g. a date/time formatter), use
        // it to measure label widths so the tick density reflects the actual
        // displayed text — otherwise wide overrides like "1970 Jan 01 11:29:00"
        // overlap because spacing is computed against the much narrower default
        // numeric format.
        selector.select(range);
        ctx.setFont(this._tickLabelFont);
        var override = this._tickLabelFormatOverride;
        var done = false;
        while (!done) {
            if (selector.previous()) {
                // estimate the label widths, and do they overlap?
                var f = selector.currentTickFormat();
                this._formatter = f;
                var measureFmt = override || f;
                var s0 = measureFmt.format(this._lowerBound);
                var s1 = measureFmt.format(this._upperBound);
                var w0 = ctx.textDim(s0).width();
                var w1 = ctx.textDim(s1).width();
                var w = Math.max(w0, w1);
                if (w == 0 && s0.length > 0 && s1.length > 0) {
                	// text could not be measured (could be IE bug)
                	return Number.NaN;
                }
                var n = Math.floor(pixels / (w * this._tickLabelFactor));
                if (n < range / selector.currentTickSize()) {
                    selector.next();
                    this._formatter = selector.currentTickFormat();
                    done = true;
                }
            } else {
                done = true;
            }
        }
        result = selector.currentTickSize();
    }
    return result;
};

/**
 * Returns the tick label orientation, which is either the value specified or
 * a default value derived from the edge.
 * 
 * @param {string} edge  the edge along which the axis is drawn.
 * @returns {number} The label orientation.
 */
jsfc.LinearAxis.prototype._resolveTickLabelOrientation = function(edge) {
    var result = this._tickLabelOrientation;
    if (!result) {
        if (edge === jsfc.RectangleEdge.LEFT 
                || edge === jsfc.RectangleEdge.RIGHT) {
           result = jsfc.LabelOrientation.PERPENDICULAR; 
        } else if (edge === jsfc.RectangleEdge.TOP 
                || edge === jsfc.RectangleEdge.BOTTOM) {
           result = jsfc.LabelOrientation.PARALLEL;
        } else {
            throw new Error("Unrecognised 'edge' code: " + edge);
        }
    }
    return result;
};

/**
 * Calculates and returns the space (width or height) required to draw this 
 * axis on one edge of the specified area.
 * 
 * This method will be called by the plot.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context.
 * @param {jsfc.CategoryPlot|jsfc.XYPlot} plot  the plot.
 * @param {!jsfc.Rectangle} bounds  the plot bounds.
 * @param {!jsfc.Rectangle} area  the estimated data area.
 * @param {!string} edge  the edge that denotes the axis position.
 * @returns {!number} The space to reserve for the axis.
 */
jsfc.LinearAxis.prototype.reserveSpace = function(ctx, plot, bounds, area, 
        edge) {
            
    var space = this._tickMarkOuterLength;
    
    // if there is an axis label we need to include space for it 
    // plus its margins
    if (this._label) {
        ctx.setFont(this._labelFont);
        var dim = ctx.textDim(this._label);
        var lm = this._labelMargin;
        space += dim.height();
        if (jsfc.RectangleEdge.isTopOrBottom(edge)) {
            space += lm.top() + lm.bottom();
        } else if (jsfc.RectangleEdge.isLeftOrRight(edge)) {
            space += lm.left() + lm.right();
        } else {
            throw new Error("Unrecognised edge code: " + edge);
        }
    }
    
    // tick marks
    var tickSize = this._calcTickSize(ctx, area, edge);
    var ticks = this.ticks(tickSize, ctx, area, edge);
    ctx.setFont(this._tickLabelFont);
    var orientation = this._resolveTickLabelOrientation(edge);
    if (orientation === jsfc.LabelOrientation.PERPENDICULAR) {
        var max = 0;
        ticks.forEach(function(t) {
            max = Math.max(max, ctx.textDim(t.label).width());    
        });
        space += max;
    } else if (orientation === jsfc.LabelOrientation.PARALLEL) {
        // just add the height of one label, because they are all the same
        var dim = ctx.textDim("123");
        space += dim.height();
    }
    if (jsfc.RectangleEdge.isTopOrBottom(edge)) {
        space += this._tickLabelMargin.top() + this._tickLabelMargin.bottom();
    } else if (jsfc.RectangleEdge.isLeftOrRight(edge)) {
        space += this._tickLabelMargin.left() + this._tickLabelMargin.right();
    } else {
        throw new Error("Unrecognised edge code: " + edge);
    }
    return space;   
};

/**
 * Returns the number of symbols having a value within the specified range.
 * 
 * @param {!jsfc.Range} range  the range.
 * @returns {number} The number of symbols with values visible in the range.
 * @private
 */
jsfc.LinearAxis.prototype._symbolCount = function(range) {
    var c = 0;
    this._symbols.forEach(function(s) {
        if (range.contains(s.value)) {
            c++;
        }
    });
    return c;
};

/**
 * Returns a list of ticks for the axis.
 * 
 * @param {number} tickSize  the tick size.
 * @param {jsfc.Context2D} ctx  the graphics context.
 * @param {jsfc.Rectangle} area  the data area.
 * @param {string} edge  the edge.
 * 
 * @returns {Array} An array of jsfc.TickMark instances.
 */
jsfc.LinearAxis.prototype.ticks = function(tickSize, ctx, area, edge) {

    // special case - if symbols were defined in the dataset
    var b0 = this._lowerBound;
    var b1 = this._upperBound;
    var r = new jsfc.Range(b0, b1);
    if (this._symbolCount(r) > 0) {
        var result = [];
        this._symbols.forEach(function(s) {
            if (s.value > b0 && s.value < b1) {
                result.push(new jsfc.TickMark(s.value, s.symbol));
            }
        });
        return result;
    }

    var formatter = this._tickLabelFormatOverride || this._formatter;
    var result = [];
    if (!isNaN(tickSize)) {
        var t = Math.ceil(b0 / tickSize) * tickSize;
        var t0 = t;
        var count = 0;
        while (t < b1) {
            var tprev = t;
            var tm = new jsfc.TickMark(t, formatter.format(t));
            result.push(tm);
            while (t === tprev) {
                t = t0 + (count * tickSize);
                count++;
            }
        }
    } 
    if (result.length < 2) { 
        var tm0 = new jsfc.TickMark(b0, formatter.format(b0));
        var tm1 = new jsfc.TickMark(b1, formatter.format(b1));
        result = [tm0, tm1];            
    }
    return result;
};

/**
 * Draws the axis.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context.
 * @param {!jsfc.CategoryPlot|jsfc.XYPlot} plot
 * @param {!jsfc.Rectangle} bounds
 * @param {!jsfc.Rectangle} dataArea
 * @param {!number} offset
 * @returns {undefined}
 */
jsfc.LinearAxis.prototype.draw = function(ctx, plot, bounds, dataArea, offset) {
    var edge = plot.axisPosition(this);
    var tickSize = this._calcTickSize(ctx, dataArea, edge);
    var ticks = this.ticks(tickSize, ctx, dataArea, edge);
    var x = dataArea.x();
    var y = dataArea.y();
    var w = dataArea.width();
    var h = dataArea.height();
    
    var isLeft = edge === jsfc.RectangleEdge.LEFT;
    var isRight = edge === jsfc.RectangleEdge.RIGHT;
    var isTop = edge === jsfc.RectangleEdge.TOP;
    var isBottom = edge === jsfc.RectangleEdge.BOTTOM;
    if (isLeft || isRight) {
        // draw the tick marks and labels
        ctx.setFont(this._tickLabelFont);
        ctx.setFillColor(this._tickLabelColor);
        var maxTickLabelWidth = 0;
        for (var i = 0; i < ticks.length; i++) {
            var tick = ticks[i];
            var yy = this.valueToCoordinate(tick.value, y + h, y);
            if (this._gridLinesVisible) {
                ctx.setLineStroke(this._gridLineStroke);
                ctx.setLineColor(this._gridLineColor);
                ctx.drawLine(x, Math.round(yy), x + w, Math.round(yy));
            }
            if (this._tickMarkInnerLength + this._tickMarkOuterLength > 0) {
                ctx.setLineStroke(this._tickMarkStroke);
                ctx.setLineColor(this._tickMarkColor);
                if (isRight) {
                    ctx.drawLine(x + w + offset - this._tickMarkInnerLength, yy, 
                            x + w + offset + this._tickMarkOuterLength, yy);
                } else {
                    ctx.drawLine(x - offset - this._tickMarkOuterLength, yy, 
                            x - offset + this._tickMarkInnerLength, yy);
                }
            }
            if (isRight) {
                var adj = offset + this._tickMarkOuterLength 
                        + this._tickLabelMargin.left();
                var dim = ctx.drawAlignedString(tick.label, x + w + adj, yy, 
                        jsfc.TextAnchor.CENTER_LEFT);                
            } else {
                var adj = offset + this._tickMarkOuterLength 
                        + this._tickLabelMargin.right();
                var dim = ctx.drawAlignedString(tick.label, x - adj, yy, 
                        jsfc.TextAnchor.CENTER_RIGHT);
            }
            maxTickLabelWidth = Math.max(maxTickLabelWidth, dim.width());
        }
        ctx.setLineColor(this._axisLineColor);
        ctx.setLineStroke(this._axisLineStroke);
        if (isRight) {
            ctx.drawLine(x + w + offset, y, x + w + offset, 
                    y + dataArea.height());                    
        } else {
            ctx.drawLine(x - offset, y, x - offset, y + dataArea.height());        
        }
        if (this._label) {
            ctx.setFont(this._labelFont);
            ctx.setFillColor(this._labelColor);
            if (isRight) {
                var adj = offset + maxTickLabelWidth + this._tickMarkOuterLength 
                    + this._tickLabelMargin.left() + this._tickLabelMargin.right() 
                    + this._labelMargin.left();
                ctx.drawRotatedString(this._label, x + w + adj, y + h / 2, 
                        jsfc.TextAnchor.BOTTOM_CENTER, Math.PI / 2);                
            } else {
                var adj = offset + maxTickLabelWidth + this._tickMarkOuterLength 
                    + this._tickLabelMargin.left() + this._tickLabelMargin.right() 
                    + this._labelMargin.right();
                ctx.drawRotatedString(this._label, x - adj, y + h / 2, 
                        jsfc.TextAnchor.BOTTOM_CENTER, -Math.PI / 2);
            }
        }
    } else if (isTop || isBottom) {
        ctx.setFont(this._tickLabelFont);
        ctx.setFillColor(this._tickLabelColor);
        var gap = offset + this._tickMarkOuterLength;
        if (isTop) {
            gap += this._tickLabelMargin.bottom();
        } else {
            gap += this._tickLabelMargin.top();
        }
        for (var i = 0; i < ticks.length; i++) {
            var tick = ticks[i];
            var xx = this.valueToCoordinate(tick.value, x, x + w);
            if (this._gridLinesVisible) {
                ctx.setLineStroke(this._gridLineStroke);
                ctx.setLineColor(this._gridLineColor);
                ctx.drawLine(Math.round(xx), y, Math.round(xx), y + h);
            }
            if (this._tickMarkInnerLength + this._tickMarkOuterLength > 0) {
                ctx.setLineStroke(this._tickMarkStroke);
                ctx.setLineColor(this._tickMarkColor);
                if (isTop) {
                    ctx.drawLine(xx, y - offset - this._tickMarkOuterLength, xx, 
                            y - offset + this._tickMarkInnerLength);                    
                    ctx.drawAlignedString(tick.label, xx, y - gap, 
                            jsfc.TextAnchor.BOTTOM_CENTER);
                } else {
                    ctx.drawLine(xx, y + h + offset - this._tickMarkInnerLength, 
                            xx, y + h + offset + this._tickMarkOuterLength);
                    ctx.drawAlignedString(tick.label, xx, y + h + gap, 
                            jsfc.TextAnchor.TOP_CENTER);
                }
            }
        }
        ctx.setLineColor(this._axisLineColor);
        ctx.setLineStroke(this._axisLineStroke);
        if (isTop) {
            ctx.drawLine(x, y - offset, x + w, y - offset);            
        } else {
            ctx.drawLine(x, y + h + offset, x + w, y + h + offset);
        }
        // if the axis has a label, draw it
        if (this._label) {
            ctx.setFont(this._labelFont);
            ctx.setFillColor(this._labelColor);
            if (isTop) {
                ctx.drawAlignedString(this._label, x + w / 2, 
                        y - gap - this._tickLabelMargin.bottom() 
                        - this._labelMargin.top() - this._tickLabelFont.size, 
                        jsfc.TextAnchor.BOTTOM_CENTER);                
            } else {
                ctx.drawAlignedString(this._label, x + w / 2, 
                        y + h + gap + this._tickLabelMargin.bottom() 
                        + this._labelMargin.top() + this._tickLabelFont.size, 
                        jsfc.TextAnchor.TOP_CENTER);
            }
        }
    }
};

/**
 * Configures this axis to function as an x-axis for the specified plot.
 * 
 * @param {Object} plot  the plot (XYPlot).
 * @returns {undefined}
 */
jsfc.LinearAxis.prototype.configureAsXAxis = function(plot) {
    var dataset = plot.getDataset();
    if (this._autoRange && dataset) {
        var bounds = plot.getDataset().xbounds();
        if (bounds[0] <= bounds[1]) {
            this._applyAutoRange(bounds[0], bounds[1]);
        }
    }
    
    // auto-detect symbols in dataset
    if (dataset) {
        var s = plot.getDataset().getProperty("x-symbols");
        if (s) {
            this._symbols = s.map(function(e) { return e; });
        } else {
            this._symbols = [];
        }
    }

};

/**
 * Configures this axis to function as a y-axis for the specified plot.
 * If the plot has Y-axis constraint bounds set, they will be combined with
 * the auto-calculated data range (constraints act as soft limits that expand
 * when data exceeds them).
 *
 * @param {Object} plot  the plot (XYPlot or, later, CategoryPlot).
 * @returns {undefined}
 */
jsfc.LinearAxis.prototype.configureAsYAxis = function(plot) {
    var dataset = plot.getDataset();
    if (this._autoRange && dataset) {
        var range = plot.getRenderer().calcYRange(dataset);
        var dataMin, dataMax;

        if (range) {
            dataMin = range.lowerBound();
            dataMax = range.upperBound();
        } else {
            dataMin = this._defaultRange.lowerBound();
            dataMax = this._defaultRange.upperBound();
        }

        // Apply plot's Y-axis constraints if they exist
        // Constraints are combined with data range: they expand if data exceeds them
        var finalMin = dataMin;
        var finalMax = dataMax;

        if (plot._yAxisConstraintMin !== null &&
            plot._yAxisConstraintMin !== undefined) {
            finalMin = plot._yAxisConstraintHard
                ? plot._yAxisConstraintMin                      // hard: fixed, ignore data
                : Math.min(plot._yAxisConstraintMin, dataMin);  // soft: expand if data is lower
        }

        if (plot._yAxisConstraintMax !== null &&
            plot._yAxisConstraintMax !== undefined) {
            finalMax = plot._yAxisConstraintHard
                ? plot._yAxisConstraintMax                      // hard: fixed, ignore data
                : Math.max(plot._yAxisConstraintMax, dataMax);  // soft: expand if data is higher
        }

        this._applyAutoRange(finalMin, finalMax);
    }
    // auto-detect symbols in dataset
    if (dataset) {
        var s = plot.getDataset().getProperty("y-symbols");
        if (s) {
            this._symbols = s.map(function(e) { return e; });
        } else {
            this._symbols = [];
        }
    }
};

/**
 * Resizes the axis range by the specified factor (values above 1.0 will 
 * increase the range, values below 1.0 will decrease the range).  If the 
 * factor is not positive, the axis range will be reset to the auto-calculated
 * range.  If the resize would cause the axis range to become zero or infinite,
 * then no resize will be performed.
 * 
 * @param {number} factor  the factor.
 * @param {number} anchorValue  the anchor value.
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.LinearAxis.prototype.resizeRange = function(factor, anchorValue, 
        notify) {
    jsfc.Args.requireNumber(factor, "factor");
    if (factor > 0.0) {
        var left = anchorValue - this._lowerBound;
        var right = this._upperBound - anchorValue;
        var b0 = anchorValue - left * factor;
        var b1 = anchorValue + right * factor;
        if (b1 > b0 && isFinite(b1 - b0)) {
            this._lowerBound = b0;
            this._upperBound = b1;
            this._autoRange = false;
            if (notify !== false) {
                this.notifyListeners();
            }
        }
    }
    else {
        this.setAutoRange(true);
    }
};

/**
 * Pans the axis by the specified percentage (positive values will increase
 * the axis bounds, negative values will decrease the axis bounds) and sends a 
 * change notification to registered listeners (unless 'notify' is set to 
 * false).
 * 
 * @param {number} percent  the percentage.
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.LinearAxis.prototype.pan = function(percent, notify) {
    jsfc.Args.requireNumber(percent, "percent");
    var length = this._upperBound - this._lowerBound;
    var adj = percent * length;
    var b0 = this._lowerBound + adj;
    var b1 = this._upperBound + adj;
    if (isFinite(b0) && isFinite(b1)) {
        this._lowerBound = b0;
        this._upperBound = b1;
        this._autoRange = false;
        if (notify !== false) {
            this.notifyListeners();
        }
    }
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * Creates a new label generator with the default template string 
 * "{X}, {Y} / {S}".
 * 
 * @constructor
 * @implements {jsfc.XYLabelGenerator}
 * @classdesc A label generator that creates a label for an item in a XYDataset. 
 * The labels are generated from a template string that can contain the 
 * following tokens (each occurrence of the token will be replaced by the 
 * actual data value): {X} the x-value, {Y} the y-value and {S} the series key.
 */
jsfc.StandardXYLabelGenerator = function(format, xdp, ydp) {
    if (!(this instanceof jsfc.StandardXYLabelGenerator)) {
        throw new Error("Use 'new' with constructor.");
    }
    this._format = format || "{X}, {Y} / {S}";
    this._xDP = xdp || 2;
    this._yDP = ydp || 2;
};

/**
 * Creates a label for an item in the specified dataset.
 * 
 * @param {jsfc.XYDataset} dataset  the dataset.
 * @param {string} seriesKey  the series key.
 * @param {string|number} itemKey  the item index.
 * @returns {string} The item label.
 */
jsfc.StandardXYLabelGenerator.prototype.itemLabel = function(dataset, 
        seriesKey, itemKey) {
    var labelStr = new String(this._format);
    var seriesKeyStr = seriesKey;
    var item = dataset.itemByKey(seriesKey, itemKey);
    var xStr = item.x.toFixed(this._xDP);
    var yStr = item.y.toFixed(this._yDP);
    labelStr = labelStr.replace(/{X}/g, xStr);
    labelStr = labelStr.replace(/{Y}/g, yStr);
    labelStr = labelStr.replace(/{S}/g, seriesKeyStr);
    return labelStr;
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * @interface
 */
jsfc.LegendBuilder = function() {
};
    
/**
 * Creates a legend containing items representing the content of the specified
 * plot.
 * 
 * @param {jsfc.XYPlot|jsfc.CategoryPlot} plot  the plot.
 * @param {jsfc.Anchor2D} anchor  the legend anchor (used to determine 
 *     default item alignment).
 * @param {string} orientation  the orientation ("horizontal" or "vertical").
 * @param {Object} style  the style (currently ignored).
 * 
 * @returns {jsfc.TableElement} The legend (a table element).
 */
jsfc.LegendBuilder.prototype.createLegend = function(plot, anchor, 
        orientation, style) {
};/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * @class An object containing the core info for one item in a legend.  Each
 * plot object (CategoryPlot, PiePlot and XYPlot) has a legendInfo() method
 * that returns a list of LegendItemInfo instances for the plot.
 * @constructor
 */
jsfc.LegendItemInfo = function(key, color) {
    this.seriesKey = key || "";
    this.label = key || "";
    this.description = "";
    this.shape = null;
    this.color = color;
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * Creates a new StandardLegendBuilder instance.
 * 
 * @constructor
 * @implements {jsfc.LegendBuilder}
 * @classdesc An object that constructs a legend (a table element) to represent
 *         the items in a plot's dataset.
 * @param {jsfc.LegendBuilder} [instance]
 * @returns {jsfc.LegendBuilder} The new instance.
 */
jsfc.StandardLegendBuilder = function(instance) {
    if (!(this instanceof jsfc.StandardLegendBuilder)) {
        throw new Error("Use 'new' for constructor.");
    }
    if (!instance) {
        instance = this;
    }
    jsfc.StandardLegendBuilder.init(instance);
};

jsfc.StandardLegendBuilder.init = function(instance) {
    instance._font = new jsfc.Font("Palatino, serif", 12);
};

/**
 * Returns the font for the legend items.
 * 
 * @returns {jsfc.Font} The font.
 */
jsfc.StandardLegendBuilder.prototype.getFont = function() {
    return this._font; 
};

/**
 * Sets the font for the legend items.  There is no change notification.
 * @param {jsfc.Font} font  the new font (null not permitted).
 * @returns {undefined}
 */
jsfc.StandardLegendBuilder.prototype.setFont = function(font) {
    this._font = font;
};

/**
 * Creates a legend containing items representing the content of the specified
 * plot.
 * 
 * @param {jsfc.XYPlot|jsfc.CategoryPlot} plot  the plot.
 * @param {jsfc.Anchor2D} anchor  the legend anchor (used to determine 
 *     default item alignment).
 * @param {string} orientation  the orientation ("horizontal" or "vertical").
 * @param {Object} style  the style (currently ignored).
 * @returns {jsfc.TableElement} The legend (a table element).
 */
jsfc.StandardLegendBuilder.prototype.createLegend = function(plot, anchor, 
        orientation, style) {
    var info = plot.legendInfo();
    var result = new jsfc.FlowElement();
    var me = this;
    info.forEach(function(info) {
        var shape = new jsfc.RectangleElement(8, 5)
                .setFillColor(info.color);
        var text = new jsfc.TextElement(info.label).setFont(me._font);
        var item = new jsfc.GridElement();
        item.add(shape, "R1", "C1");
        item.add(text, "R1", "C2");
        result.add(item);
    });
    return result;
};/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Creates a new plot for the specified dataset.
 * 
 * @class An XYPlot is a two-dimensional plot where both the x and y axes are
 * numerical.
 * 
 * @constructor 
 * @param {!jsfc.XYDataset} dataset  the dataset (null not permitted).
 * @returns {jsfc.XYPlot}
 */
jsfc.XYPlot = function(dataset) {
    if (!(this instanceof jsfc.XYPlot)) {
        throw new Error("Use 'new' for construction.");
    }
    this._listeners = [];
    this._notify = true;
    this._plotBackground = null;
    this._dataBackground = new jsfc.StandardRectanglePainter(
            new jsfc.Color(230, 230, 230), new jsfc.Color(0, 0, 0, 0));
    this._dataArea = new jsfc.Rectangle(0, 0, 0, 0);
    this._renderer = new jsfc.ScatterRenderer(this);
    this._axisOffsets = new jsfc.Insets(0, 0, 0, 0);
    this._xAxis = new jsfc.LinearAxis();
    this._xAxisPosition = jsfc.RectangleEdge.BOTTOM;
    this._xAxis.configureAsXAxis(this);
    this._xAxisListener = function(p) {
        var plot = p;
        return function(axis) {
            if (axis.isAutoRange()) {
                axis.configureAsXAxis(plot);    
            }
            plot.notifyListeners();
        };
    }(this);
    this._xAxis.addListener(this._xAxisListener);
    
    this._yAxis = new jsfc.LinearAxis();
    this._yAxisPosition = jsfc.RectangleEdge.LEFT;
    this._yAxis.configureAsYAxis(this);
    this._yAxisListener = function(p) {
        var plot = p;
        return function(axis) {
            if (axis.isAutoRange()) {
                axis.configureAsYAxis(plot);    
            }
            plot.notifyListeners();
        };
    }(this);
    this._yAxis.addListener(this._yAxisListener);
    this.setDataset(dataset);
    
    this._staggerRendering = false;
    this._drawMS = 150; // milliseconds on then off
    this._pauseMS = 100;
    this._staggerID = null; // id of setTimeout so we can cancel if necessary
    this._progressColor1 = new jsfc.Color(100, 100, 200, 200);
    this._progressColor2 = new jsfc.Color(100, 100, 100, 100);
    this._progressLabelFont = new jsfc.Font("sans-serif", 12);
    this._progressLabelColor = jsfc.Colors.WHITE;
    this._progressLabelFormatter = new jsfc.NumberFormat(0);

    // Y-axis constraint bounds (applied during configureAsYAxis if set)
    this._yAxisConstraintMin = null;
    this._yAxisConstraintMax = null;
    // When true, constraints are hard limits (fixed, data cannot expand them).
    // When false (default), constraints are soft (scale expands if data exceeds them).
    this._yAxisConstraintHard = false;
};

/**
 * Returns the dataset.
 * 
 * @returns {!jsfc.XYDataset} The XY dataset (never null).
 */
jsfc.XYPlot.prototype.getDataset = function() {
    return this._dataset;
};

/**
 * Sets the dataset for the plot and sends a change notification to 
 * registered listeners (unless 'notify' is set to false).
 * 
 * @param {!jsfc.XYDataset} dataset  the new dataset (null not permitted).
 * @param {boolean} [notify]  notify listeners? (the default is true).
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.setDataset = function(dataset, notify) {
    if (this._datasetListener) {
        this._dataset.removeListener(this._datasetListener);
    }
    this._dataset = dataset;
    
    // keep a reference to the listener so we can deregister it when changing
    // the dataset
    this._datasetListener = function(plot) {
        var me = plot;
        return function(dataset) {
            me.datasetChanged();
        };
    }(this);
    this._dataset.addListener(this._datasetListener);
    
    // reconfigure the axes
    this._xAxis.configureAsXAxis(this);
    this._yAxis.configureAsYAxis(this);
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Sets Y-axis constraint bounds that will be applied during axis configuration.
 * When set, these bounds will be combined with the auto-calculated data range
 * to ensure the axis displays at least these bounds while allowing expansion
 * if data exceeds them.
 *
 * @param {number} [min]  the minimum Y-axis bound (null to unset).
 * @param {number} [max]  the maximum Y-axis bound (null to unset).
 * @param {boolean} [reconfigure]  reconfigure Y-axis after setting bounds?
 *                                  (default is true).
 * @returns {jsfc.XYPlot} This plot instance for chaining.
 */
jsfc.XYPlot.prototype.setYAxisConstraints = function(min, max, reconfigure) {
    this._yAxisConstraintMin = min;
    this._yAxisConstraintMax = max;
    if (reconfigure !== false) {
        this._yAxis.configureAsYAxis(this);
        this.notifyListeners();
    }
    return this;
};

/**
 * Returns the background painter for the plot.  The default value is
 * 'undefined' (which means that no background is painted for the plot - the
 * chart background color will be visible).
 *
 * @returns {jsfc.RectanglePainter} The background painter.
 */
jsfc.XYPlot.prototype.getBackground = function() {
    return this._plotBackground;
};

/**
 * Sets the background painter and sends a change event to registered listeners
 * (unless 'notify' is set to false).
 * 
 * @param {jsfc.RectanglePainter} painter  the painter.
 * @param {boolean} [notify]  notify listeners? (the default is true).
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.setBackground = function(painter, notify) {
    this._plotBackground = painter;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Sets the background color for the plot and sends a change notification to 
 * all registered listeners.
 * 
 * @param {jsfc.Color} color  the new color.
 * @param {boolean} [notify]  notify listeners? (the default is true).
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.setBackgroundColor = function(color, notify) {
    var painter = new jsfc.StandardRectanglePainter(color, null);
    this.setBackground(painter, notify);
};

/**
 * Returns the background painter for the data area.
 * 
 * @returns {jsfc.RectanglePainter} The painter.
 */
jsfc.XYPlot.prototype.getDataBackground = function() {
    return this._dataBackground;
};

/**
 * Sets the background painter for the data area and sends a change event to 
 * registered listeners (unless 'notify' is set to false).
 * 
 * @param {jsfc.RectanglePainter} painter  the painter.
 * @param {boolean} [notify]  notify listeners? (the default is true).
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.setDataBackground = function(painter, notify) {
    this._dataBackground = painter;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Sets the background color for the data area and sends a change 
 * notification to all registered listeners (unless 'notify' is set to false).
 * 
 * @param {jsfc.Color} color  the new color.
 * @param {boolean} [notify]  notify listeners? (the default is true).
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.setDataBackgroundColor = function(color, notify) {
    var painter = new jsfc.StandardRectanglePainter(color, null);
    this.setDataBackground(painter, notify);
};

/**
 * Returns the renderer.
 * @returns {jsfc.XYRenderer}
 */
jsfc.XYPlot.prototype.getRenderer = function() {
    return this._renderer;
};

/**
 * Returns the flag that controls whether or not rendering is staggered (the
 * default value is false).
 * Staggered rendering will draw the chart in chunks with a pause in between
 * each chunk to allow the browser to process user events.
 * 
 * @returns {!boolean}
 */
jsfc.XYPlot.prototype.getStaggerRendering = function() {
    return this._staggerRendering;
};

/**
 * Sets the flag that controls whether or not rendering is staggered and sends
 * a change notification to all registered listeners.
 * 
 * @param {!boolean} stagger
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.setStaggerRendering = function(stagger) {
    this._staggerRendering = stagger;
    this.notifyListeners(); 
};

/**
 * Returns the number of milliseconds that the renderer aims to spend 
 * drawing each chunk.  The default value is 150.
 * 
 * @returns {!number}
 */
jsfc.XYPlot.prototype.getDrawMillis = function() {
    return this._drawMS;
};

/**
 * Sets the number of milliseconds as the target for each chunk when staggered
 * rendering is being used.
 * 
 * @param {!number} ms  the number of milliseconds.
 * 
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.setDrawMillis = function(ms) {
    this._drawMS = ms;
};

/**
 * Returns the number of milliseconds to pauses after drawing each chunk.  The 
 * default value is 100.
 * 
 * @returns {!number}
 */
jsfc.XYPlot.prototype.getPauseMillis = function() {
    return this._pauseMS;
};

/**
 * Sets the number of milliseconds to pause after drawing each chunk when 
 * staggered rendering is being used.
 * 
 * @param {!number} ms  the number of milliseconds.
 * 
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.setPauseMillis = function(ms) {
    this._pauseMS = ms;
};

jsfc.XYPlot.prototype.getProgressColor1 = function() {
    return this._progressColor1;
};

jsfc.XYPlot.prototype.setProgressColor1 = function(color) {
    this._progressColor1 = color;
};
jsfc.XYPlot.prototype.getProgressColor2 = function() {
    return this._progressColor2;
};

jsfc.XYPlot.prototype.setProgressColor2 = function(color) {
    this._progressColor2 = color;
};

jsfc.XYPlot.prototype.getProgressLabelFont = function() {
    return this._progressLabelFont;
};
jsfc.XYPlot.prototype.setProgressLabelFont = function(font) {
    this._progressLabelFont = font;
};
jsfc.XYPlot.prototype.getProgressLabelColor = function() {
    return this._progressLabelColor;
};
jsfc.XYPlot.prototype.setProgressLabelColor = function(color) {
    this._progressLabelColor = color;
};

jsfc.XYPlot.prototype.getProgressLabelFormatter = function() {
    return this._progressLabelFormatter;
};
jsfc.XYPlot.prototype.setProgressLabelFormatter = function(formatter) {
    this._progressLabelFormatter = formatter;
};

/**
 * Handles changes to the dataset (this method is called by the dataset 
 * change listener, you don't normally need to call this directly).
 * 
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.datasetChanged = function() {
    // if the x-axis is auto-range, then update the range
    if (this._xAxis.isAutoRange()) {
        this._xAxis.configureAsXAxis(this); 
    }
    // if the y-axis is auto-range, then update the range
    if (this._yAxis.isAutoRange()) {
        this._yAxis.configureAsYAxis(this); 
    }
    // notify listeners that the plot has changed
    this.notifyListeners();
};

/**
 * Returns the axis offsets (the gap between the data area and the axis line).
 * The default is Insets(0, 0, 0, 0).
 * 
 * @returns {jsfc.Insets} The axis offsets.
 */
jsfc.XYPlot.prototype.getAxisOffsets = function() {
    return this._axisOffsets;
};

/**
 * Sets the axis offsets and sends a change notification to all registered
 * listeners (unless 'notify' is false).
 * 
 * @param {jsfc.Insets} offsets  the new offsets.
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.setAxisOffsets = function(offsets, notify) {
    this._axisOffsets = offsets;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns the x-axis for the plot.
 * 
 * @returns {!jsfc.ValueAxis}
 */
jsfc.XYPlot.prototype.getXAxis = function() {
    return this._xAxis;
};

/**
 * Sets the x-axis and sends a change notification to registered listeners
 * (unless 'notify' is set to false).
 * 
 * @param {!jsfc.ValueAxis} axis  the new axis.
 * @param {boolean} [notify]  notify listeners? (defaults to true).
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.setXAxis = function(axis, notify) {
    this._xAxis.removeListener(this._xAxisListener);
    this._xAxis = axis;
    this._xAxis.addListener(this._xAxisListener);
    this._xAxis.configureAsXAxis(this);
    if (notify !== false) {
        this.notifyListeners();
    }  
};

/**
 * Returns the position of the x-axis (either "TOP" or "BOTTOM", see the
 * values defined in jsfc.RectangleEdge).
 * 
 * @returns {String} The position.
 */
jsfc.XYPlot.prototype.getXAxisPosition = function() {
    return this._xAxisPosition;
};

/**
 * Sets the x-axis position and sends a change notification to all registered
 * listeners (unless 'notify' is set to false).
 * 
 * @param {String} edge  the edge ("TOP" or "BOTTOM").
 * @param {boolean} [notify] notify listeners? (the default is true).
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.setXAxisPosition = function(edge, notify) {
    this.xAxisPosition = edge;
    if (notify !== false) {
        this.notifyListeners();
    }
};

jsfc.XYPlot.prototype.isXZoomable = function() { 
    return true;  // later we could allow the user to set this
};

/**
 * Returns the y-axis for the plot.
 * 
 * @returns {jsfc.ValueAxis}
 */
jsfc.XYPlot.prototype.getYAxis = function() {
    return this._yAxis;
};

/**
 * Sets the y-axis and sends a change notification to registered listeners
 * (unless 'notify' is set to false).
 * 
 * @param {!jsfc.ValueAxis} axis  the new axis.
 * @param {boolean} [notify]  notify listeners? (defaults to true).
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.setYAxis = function(axis, notify) {
    this._yAxis.removeListener(this._yAxisListener);
    this._yAxis = axis;
    this._yAxis.addListener(this._yAxisListener);
    this._yAxis.configureAsYAxis(this);
    if (notify !== false) {
        this.notifyListeners();
    }  
};

/**
 * Returns the position of the y-axis (either "LEFT" or "RIGHT", see the
 * values defined in jsfc.RectangleEdge).
 * 
 * @returns {String} The position.
 */
jsfc.XYPlot.prototype.getYAxisPosition = function() {
    return this._yAxisPosition;
};

/**
 * Sets the y-axis position and sends a change notification to all registered
 * listeners (unless 'notify' is set to false).
 * 
 * @param {String} edge  the edge ("TOP" or "BOTTOM").
 * @param {boolean} [notify] notify listeners.
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.setYAxisPosition = function(edge, notify) {
    this.yAxisPosition = edge;
    if (notify !== false) {
        this.notifyListeners();
    }
};

jsfc.XYPlot.prototype.isYZoomable = function() {
    return true;  // later we could allow the user to set this
};

/**
 * Performs a zoom (in or out) on the x-axis about the specified anchor point
 * (which is a coordinate from document space).
 * 
 * @param {number} factor  the zoom factor.
 * @param {number} anchor  the anchor point (in document space).
 * @param {boolean} [notify]  notify listeners? (optional).
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.zoomXAboutAnchor = function(factor, anchor, notify) {
    // convert anchor to an axis value
    var x0 = this._dataArea.minX();
    var x1 = this._dataArea.maxX();
    var anchorX = this._xAxis.coordinateToValue(anchor, x0, x1);
    this._xAxis.resizeRange(factor, anchorX, notify !== false);
};

jsfc.XYPlot.prototype.zoomX = function(lowpc, highpc, notify) {
    this._xAxis.setBoundsByPercent(lowpc, highpc, notify);    
};

/**
 * Performs a zoom (in or out) on the y-axis about the specified anchor point
 * (which is a coordinate from document space).
 * 
 * @param {number} factor  the zoom factor.
 * @param {number} anchor  the anchor point (in document space).
 * @param {boolean} [notify]  notify listeners? (optional).
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.zoomYAboutAnchor = function(factor, anchor, notify) {
    // convert anchor to an axis value
    var y0 = this._dataArea.minY();
    var y1 = this._dataArea.maxY();
    var anchorY = this._yAxis.coordinateToValue(anchor, y1, y0);
    this._yAxis.resizeRange(factor, anchorY, notify !== false);
};

jsfc.XYPlot.prototype.zoomY = function(lowpc, highpc, notify) {
    this._yAxis.setBoundsByPercent(lowpc, highpc, notify);    
};

/**
 * Slides the x-axis values (up or down) by the specified percentage and
 * notifies registered listeners (unless 'notify' is set to false).
 * 
 * @param {number} percent  the percentage.
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.panX = function(percent, notify) {
    this._xAxis.pan(percent, notify !== false);
};

/**
 * Slides the x-axis values (up or down) by the specified percentage and
 * notifies registered listeners (unless 'notify' is set to false).
 * 
 * @param {number} percent  the percentage.
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.panY = function(percent, notify) {
    this._yAxis.pan(percent, notify !== false);    
};

/**
 * Sets the renderer and sends a change notification to all registered 
 * listeners (unless 'notify' is set to false).
 * 
 * @param {Object} renderer  the new renderer.
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.setRenderer = function(renderer, notify) {
    this._renderer = renderer;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Draws the plot on a 2D rendering context (such as the HTML5 canvas). This
 * provides an alternative rendering approach.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context.
 * @param {!jsfc.Rectangle} bounds  the chart bounds.
 * @param {!jsfc.Rectangle} plotArea  the area for drawing the plot.
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.draw = function(ctx, bounds, plotArea) {
    
    if (this._staggerID) {
        clearTimeout(this._staggerID);
        ctx.setHint("layer", "progress");
        ctx.clear();
        ctx.setHint("layer", "default");
    }
    // fill the plot background if there is one (very often this is not defined
    // so that the chart background shows through, and note that there is also
    // a 'dataBackground' painter that is used for the area inside the axes).
    if (this._plotBackground) {
        this._plotBackground.paint(ctx, plotArea);
    }

    // compute the data area by getting the space required for the axes
    var space = new jsfc.AxisSpace(0, 0, 0, 0);
    var edge = this.axisPosition(this._xAxis);
    var xspace = this._xAxis.reserveSpace(ctx, this, bounds, plotArea, edge);
    space.extend(xspace, edge);
    
    var adjArea = space.innerRect(plotArea);
    edge = this.axisPosition(this._yAxis);
    var yspace = this._yAxis.reserveSpace(ctx, this, bounds, adjArea, edge);
    space.extend(yspace, edge);
    
    this._dataArea = space.innerRect(plotArea);
    if (this._dataBackground) {
        this._dataBackground.paint(ctx, this._dataArea);
    }
    this.drawAxes(ctx, bounds, this._dataArea);    

    
    // get the renderer to draw the data points - this may involve multiple
    // passes through the data
    if (this._staggerRendering) {
        this._renderDataItemsByChunks(ctx);
    } else {
        this._renderAllDataItems(ctx);
    }
};

/**
 * Render all the data items at once.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context.
 * @returns {undefined}
 */
jsfc.XYPlot.prototype._renderAllDataItems = function(ctx) {
    // for SVG we are setting the clip via hints
    ctx.setHint("clip", this._dataArea);
    ctx.setHint("glass", this._dataArea);
    ctx.beginGroup("dataArea");
    ctx.save();
    ctx.setClip(this._dataArea);
    var passCount = this._renderer.passCount();
    for (var pass = 0; pass < passCount; pass++) {
        for (var s = 0; s < this._dataset.seriesCount(); s++) {
            for (var i = 0; i < this._dataset.itemCount(s); i++) {
                this._renderer.drawItem(ctx, this._dataArea, this, 
                        this._dataset, s, i, pass);
            }
        }
    }    
    ctx.restore();
    ctx.endGroup();
};

/**
 * Renders the data items in multiple chunks, pausing between each chunk to 
 * allow the browser to process user events.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context.
 * @returns {undefined}
 */
jsfc.XYPlot.prototype._renderDataItemsByChunks = function(ctx) {
    var chunkSize = 200;  // we could ask the renderer for a default, so that if
        // a renderer does something complex, it could suggest a lower number
        
    // if we have a small number of items, just go for regular rendering
    var itemCount = jsfc.XYDatasetUtils.itemCount(this._dataset);
    if (itemCount <= chunkSize * 2) {
        this._renderAllDataItems(ctx);
        return;
    }
    var cursor = {"series": 0, "item": 0};
    // first chunk is drawn immediately
    this._processChunk(ctx, this, chunkSize * 2, cursor);
    // remaining chunks are staggered
    this._processChunkAndSubmitAnother(ctx, this, chunkSize, cursor);

};

/**
 * Renders a chunk of data items starting from the item designated by the 
 * cursor.
 * @param {!jsfc.XYPlot} plot
 * @param {!jsfc.Context2D} ctx  the graphics context (null not permitted).
 * @param {!number} chunkSize  the chunk size (number of data items).
 * @param {!Object} cursor  the cursor.
 * @returns {undefined}
 */
jsfc.XYPlot.prototype._processChunk = function(ctx, plot, chunkSize, cursor) {
    ctx.setHint("clip", this._dataArea);
    ctx.setHint("glass", this._dataArea);
    ctx.beginGroup("chunk");
    var dataset = plot.getDataset();
    var moreItems = true;
    for (var i = 0; i < chunkSize && moreItems; i++) {
        plot._renderer.drawItem(ctx, plot._dataArea, plot, 
                dataset, cursor.series, cursor.item, 0);
        moreItems = plot._advanceCursor(cursor, dataset);
    }  
    ctx.endGroup();
};

/**
 * Processes one chunk of data items then submits a job to process the next 
 * chunk after a short delay.
 * 
 * @param {!jsfc.Context2D} ctx
 * @param {!jsfc.XYPlot} plot
 * @param {!number} chunkSize  the number of data items to process in each chunk
 * @param {!Object} cursor  pointer to the current data item.
 * @returns {undefined}
 */
jsfc.XYPlot.prototype._processChunkAndSubmitAnother = function(ctx, plot, 
        chunkSize, cursor) {
    
    var f = function(plot, ctx, chunkSize, cursor) {
        return function() {
            var start = Date.now();
            plot._processChunk(ctx, plot, chunkSize, cursor);
            var elapsed = Date.now() - start;
            // if there is more to do, call plot._processChunkAndSubmitAnother
            if (cursor.series !== plot._dataset.seriesCount()) {
                chunkSize = chunkSize * (plot._drawMS / elapsed);
                plot._processChunkAndSubmitAnother(ctx, plot, chunkSize, cursor);
            } else {
                ctx.setHint("layer", "progress");
                ctx.clear();
                ctx.setHint("layer", "default");
            }
        };
    };
    this._staggerID = setTimeout(f(plot, ctx, chunkSize, cursor), 
            plot._pauseMS);
    
    // switch to the "progress" layer and draw a progress indicator
    this._drawProgressIndicator(ctx, plot.dataArea(), cursor, plot.getDataset());
    
};

/**
 * Draws a progress indicator for the render-by-chunk process.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context.
 * @param {!jsfc.Rectangle} area  the data area.
 * @param {!Object} cursor  the cursor (has 'series' and 'item' properties).
 * @param {!jsfc.XYDataset} dataset  the dataset (required to calculate the
 *         number of items *before* the cursor (that is, already processed).
 * @returns {undefined}
 */
jsfc.XYPlot.prototype._drawProgressIndicator = function(ctx, area, cursor, 
        dataset) {
    ctx.setHint("layer", "progress");
    ctx.clear();
    var itemCount = jsfc.XYDatasetUtils.itemCount(this._dataset);
    var processed = this._itemsProcessed(cursor, this._dataset);
    var x = area.centerX();
    var y = area.maxY() - (0.1 * area.height());
    var width = area.width() / 1.2;
    var height = this._progressLabelFont.size + 4;
    var percent = processed / itemCount;
    var x0 = x - width / 2;
    var y0 = y - height / 2;
    var x1 = x + width / 2;
    var px = x0 + (width * percent);
    ctx.setFillColor(this._progressColor1);
    ctx.fillRect(x0, y0, px - x0, height);
    ctx.setFillColor(this._progressColor2);
    ctx.fillRect(px, y0, x1 - px, height);
    ctx.setFillColor(this._progressLabelColor);
    ctx.setFont(this._progressLabelFont);
    var text = this._progressLabelFormatter.format(percent * 100) + "%";
    ctx.drawAlignedString(text, x, y0, jsfc.TextAnchor.TOP_CENTER);
    ctx.setHint("layer", "default");    
};

/**
 * Calculates the number of data items that precede the cursor.
 * 
 * @param {!Object} cursor  the cursor.
 * @param {!jsfc.XYDataset} dataset  the dataset.
 * @returns {!number} The number of items that precede the item that the cursor 
 *     is pointing to.
 */
jsfc.XYPlot.prototype._itemsProcessed = function(cursor, dataset) {   
    var result = cursor.item;
    for (var s = 0 ; s < cursor.series; s++) {
        result += dataset.itemCount(s);
    }
    return result;
};

/**
 * Advances the cursor to the next item in the dataset, returning true if 
 * the cursor is advanced and false if the cursor was already pointing at the
 * last item in the dataset.
 * 
 * @param {Object} cursor
 * @param {!jsfc.XYDataset} dataset
 * @returns {!boolean}
 */
jsfc.XYPlot.prototype._advanceCursor = function(cursor, dataset) {
    var itemCount = dataset.itemCount(cursor.series);
    if (cursor.item === itemCount - 1) {
        var seriesCount = dataset.seriesCount();
        if (cursor.series === seriesCount - 1) {
            cursor.series++;
            return false;
        } else {
            cursor.series++;
            cursor.item = 0;
            return true;
        }
    } else {
        cursor.item++;
        return true;
    }
};

/**
 * Returns the data area from the most recent rendering of the plot.  If the
 * plot has never been rendered, this method will return a rectangle with
 * zero width and height.
 * 
 * @returns {!jsfc.Rectangle} The data area (never null).
 */
jsfc.XYPlot.prototype.dataArea = function() { 
    return this._dataArea;
};

/**
 * Draws the plot's axes around the specified dataArea.
 * 
 * @param {!jsfc.Context2D} ctx  the graphics context.
 * @param {!jsfc.Rectangle} bounds  the bounds.
 * @param {!jsfc.Rectangle} dataArea  the data area.
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.drawAxes = function(ctx, bounds, dataArea) {
    var offset = this._axisOffsets.value(this._xAxisPosition);
    this._xAxis.draw(ctx, this, bounds, dataArea, offset);
    offset = this._axisOffsets.value(this._yAxisPosition);
    this._yAxis.draw(ctx, this, bounds, dataArea, offset);
};

/**
 * Returns the edge location of the specified axis.
 * @param {jsfc.ValueAxis} axis  the axis.
 * @returns {string} The axis position (refer to jsfc.RectangleEdge).
 */
jsfc.XYPlot.prototype.axisPosition = function(axis) {
    if (axis === this._xAxis) {
        return this._xAxisPosition;
    } else if (axis === this._yAxis) {
        return this._yAxisPosition;
    }
    throw new Error("The axis does not belong to this plot.");
};

/**
 * Returns a list of items that should be included in the plot's legend (each
 * item is an instance of jsfc.LegendItemInfo).  
 * 
 * @returns {Array} The legend items.
 */
jsfc.XYPlot.prototype.legendInfo = function() {
    var info = [];
    var plot = this;
    this._dataset.seriesKeys().forEach(function(key) {
        var dataset = plot._dataset;
        var index = dataset.seriesIndex(key);
        var color = plot._renderer.lookupLineColor(dataset, index, 0);
        var item = new jsfc.LegendItemInfo(key, color);
        item.label = key;
        info.push(item);
    });
    return info;
};

/**
 * Finds the nearest visible data item to the location (x, y) and returns
 * an object containing the "seriesKey" and "itemKey" for that data item.
 * 
 * @param {!number} x  the x-value.
 * @param {!number} y  the y-value.
 * @param {number} [xscale]  the scale factor for the x-values (used in the 
 *         distance calculation, this defaults to 1).
 * @param {number} [yscale]  the scale factor for the y-values (used in the 
 *         distance calculation, this defaults to 1).
 * @returns {Object|undefined} A key for the data item.
 */
jsfc.XYPlot.prototype.findNearestDataItem = function(x, y, xscale, yscale) {
    xscale = xscale || 1;
    yscale = yscale || 1;
    var minD = Number.MAX_VALUE;
    var nearest;
    for (var s = 0; s < this._dataset.seriesCount(); s++) {
        for (var i = 0; i < this._dataset.itemCount(s); i++) {
            var xy = this._dataset.item(s, i);
            var xx = xy.x;
            var yy = xy.y;
            if (this._xAxis.contains(xx) && this._yAxis.contains(yy)) {
                var dx = (x - xx) / xscale;
                var dy = (y - yy) / yscale;
                var d = Math.sqrt(dx * dx + dy * dy);
                if (d < minD) {
                    nearest = { "seriesKey": this._dataset.seriesKey(s), 
                            "itemKey": this._dataset.itemKey(s, i) };
                    minD = d;
                }
            }
        }
    }
    return nearest;
};

/**
 * Registers a listener to receive notification of changes to the plot.  The
 * listener is a function - it will be passed one argument (this plot).
 * 
 * @param {Function} f  the listener function.
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.addListener = function(f) {
    this._listeners.push(f);  
};

/**
 * Notify each listener function that this plot has changed.
 * 
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.notifyListeners = function() {
    if (!this._notify) {
        return;
    }
    var plot = this;
    this._listeners.forEach(function(f) {
        f(plot);
    });
};

/**
 * Returns the flag that controls whether or not notifications are forwarded 
 * to registered listeners.  The default value is true.  This flag can be used
 * to temporarily disable event notifications.
 * 
 * @returns {!boolean}
 */
jsfc.XYPlot.prototype.getNotify = function() {
    return this._notify;
};

/**
 * Sets the notify flag.  If the new value is true, this method also sends a 
 * change notification to all registered listeners (it is usually the case
 * that multiple changes have been made, but it is possible that no changes
 * have occurred).
 * 
 * @param {!boolean} notify  notify listeners?
 * @returns {undefined}
 */
jsfc.XYPlot.prototype.setNotify = function(notify) {
    this._notify = notify;
    if (notify) {
        this.notifyListeners();
    }
};

/*
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * Based on CombinedDomainXYPlot from AFreeChart (Android port of JFreeChart)
 */

"use strict";

/**
 * Creates a new combined plot that shares a domain (x) axis among multiple
 * subplots, which are stacked vertically.
 *
 * @classdesc A plot that contains multiple XYPlot subplots that share a
 * common domain (x) axis. Each subplot has its own range (y) axis. The
 * subplots are stacked vertically with configurable spacing.
 *
 * @constructor
 * @param {jsfc.ValueAxis} [domainAxis]  the shared domain axis (optional).
 * @returns {jsfc.CombinedDomainXYPlot}
 */
jsfc.CombinedDomainXYPlot = function(domainAxis) {
    if (!(this instanceof jsfc.CombinedDomainXYPlot)) {
        throw new Error("Use 'new' for construction.");
    }

    this._listeners = [];
    this._notify = true;
    this._plotBackground = null;
    this._dataBackground = null;

    /** The shared renderer applied to all subplots */
    this._renderer = null;

    /** The shared domain (x) axis */
    this._xAxis = domainAxis || new jsfc.LinearAxis();
    this._xAxisPosition = jsfc.RectangleEdge.BOTTOM;

    /** Storage for the subplots */
    this._subplots = [];

    /** The gap between subplots in pixels */
    this._gap = 5.0;

    /** Temporary storage for subplot areas (calculated during draw) */
    this._subplotAreas = [];

    /** Axis offsets */
    this._axisOffsets = new jsfc.Insets(0, 0, 0, 0);

    // Set up axis listener
    this._xAxisListener = function(p) {
        var plot = p;
        return function(axis) {
            if (axis.isAutoRange()) {
                axis.configureAsXAxis(plot);
            }
            plot.notifyListeners();
        };
    }(this);
    this._xAxis.addListener(this._xAxisListener);
};

/**
 * Returns the shared domain (x) axis.
 *
 * @returns {jsfc.ValueAxis} The domain axis.
 */
jsfc.CombinedDomainXYPlot.prototype.getXAxis = function() {
    return this._xAxis;
};

/**
 * Sets the shared domain (x) axis.
 *
 * @param {jsfc.ValueAxis} axis  the new domain axis.
 * @param {boolean} [notify]  notify listeners? (default is true).
 * @returns {undefined}
 */
jsfc.CombinedDomainXYPlot.prototype.setXAxis = function(axis, notify) {
    if (this._xAxisListener) {
        this._xAxis.removeListener(this._xAxisListener);
    }
    this._xAxis = axis;
    this._xAxis.addListener(this._xAxisListener);
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns the renderer (if one has been set) that will be applied to all
 * subplots.
 *
 * @returns {jsfc.XYRenderer} The renderer (or null).
 */
jsfc.CombinedDomainXYPlot.prototype.getRenderer = function() {
    return this._renderer;
};

/**
 * Sets the renderer that will be applied to all subplots in the combined
 * plot. This follows the pattern from Java's CombinedDomainXYPlot which
 * applies a single renderer to all subplots for consistent rendering.
 *
 * @param {jsfc.XYRenderer} renderer  the renderer.
 * @param {boolean} [notify]  notify listeners? (default is true).
 * @returns {undefined}
 */
jsfc.CombinedDomainXYPlot.prototype.setRenderer = function(renderer, notify) {
    this._renderer = renderer;
    // Apply the renderer to all existing subplots
    for (var i = 0; i < this._subplots.length; i++) {
        this._subplots[i].setRenderer(renderer);
    }
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns the gap between subplots in pixels.
 *
 * @returns {number} The gap in pixels.
 */
jsfc.CombinedDomainXYPlot.prototype.getGap = function() {
    return this._gap;
};

/**
 * Sets the gap between subplots in pixels.
 *
 * @param {number} gap  the gap in pixels.
 * @param {boolean} [notify]  notify listeners? (default is true).
 * @returns {undefined}
 */
jsfc.CombinedDomainXYPlot.prototype.setGap = function(gap, notify) {
    this._gap = gap;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Adds a subplot with default weight of 1.
 *
 * @param {jsfc.XYPlot} subplot  the subplot (null not permitted).
 * @returns {undefined}
 */
jsfc.CombinedDomainXYPlot.prototype.add = function(subplot) {
    this.addWithWeight(subplot, 1);
};

/**
 * Adds a subplot with the specified weight. The weight determines how much
 * vertical space is allocated to the subplot relative to other subplots.
 *
 * @param {jsfc.XYPlot} subplot  the subplot (null not permitted).
 * @param {number} weight  the weight (must be >= 1).
 * @returns {undefined}
 */
jsfc.CombinedDomainXYPlot.prototype.addWithWeight = function(subplot, weight) {
    if (!subplot) {
        throw new Error("Null 'subplot' argument.");
    }
    if (weight < 1) {
        throw new Error("Weight must be >= 1.");
    }

    // Store weight on the subplot
    subplot._weight = weight;

    // Set up listener to propagate changes from subplot
    var subplotListener = function(parentPlot) {
        return function(subplot) {
            parentPlot.notifyListeners();
        };
    }(this);
    subplot._parentListener = subplotListener;
    subplot.addListener(subplotListener);

    // Apply the shared renderer to the new subplot (if one has been set)
    if (this._renderer) {
        subplot.setRenderer(this._renderer);
    }

    this._subplots.push(subplot);

    // Configure the shared axis
    this._xAxis.configureAsXAxis(this);

    this.notifyListeners();
};

/**
 * Removes a subplot from the combined plot.
 *
 * @param {jsfc.XYPlot} subplot  the subplot to remove.
 * @returns {undefined}
 */
jsfc.CombinedDomainXYPlot.prototype.remove = function(subplot) {
    if (!subplot) {
        throw new Error("Null 'subplot' argument.");
    }

    var index = this._subplots.indexOf(subplot);
    if (index !== -1) {
        this._subplots.splice(index, 1);
        if (subplot._parentListener) {
            subplot.removeListener(subplot._parentListener);
        }
        this._xAxis.configureAsXAxis(this);
        this.notifyListeners();
    }
};

/**
 * Returns the list of subplots.
 *
 * @returns {Array} An array of subplots (possibly empty, never null).
 */
jsfc.CombinedDomainXYPlot.prototype.getSubplots = function() {
    return this._subplots.slice(); // return a copy
};

/**
 * Returns the number of subplots.
 *
 * @returns {number} The subplot count.
 */
jsfc.CombinedDomainXYPlot.prototype.getSubplotCount = function() {
    return this._subplots.length;
};

/**
 * Returns the subplot at the specified index.
 *
 * @param {number} index  the subplot index.
 * @returns {jsfc.XYPlot} The subplot.
 */
jsfc.CombinedDomainXYPlot.prototype.getSubplot = function(index) {
    return this._subplots[index];
};

/**
 * Configures the domain axis based on the data from all subplots.
 * This is called internally by the axis when auto-range is enabled.
 *
 * @param {jsfc.ValueAxis} axis  the axis to configure.
 * @returns {undefined}
 */
jsfc.CombinedDomainXYPlot.prototype.configureRangeAxes = function(axis) {
    if (axis === this._xAxis) {
        // Find the combined range from all subplots
        var xmin = Number.POSITIVE_INFINITY;
        var xmax = Number.NEGATIVE_INFINITY;

        for (var i = 0; i < this._subplots.length; i++) {
            var subplot = this._subplots[i];
            var dataset = subplot.getDataset();
            if (dataset) {
                var bounds = jsfc.XYDatasetUtils.bounds(dataset);
                if (bounds) {
                    xmin = Math.min(xmin, bounds.xmin);
                    xmax = Math.max(xmax, bounds.xmax);
                }
            }
        }

        if (xmin < Number.POSITIVE_INFINITY && xmax > Number.NEGATIVE_INFINITY) {
            axis.setAutoRange(xmin, xmax);
        }
    }
};

/**
 * Returns the background painter for the plot.
 *
 * @returns {jsfc.RectanglePainter} The background painter (possibly undefined).
 */
jsfc.CombinedDomainXYPlot.prototype.getBackground = function() {
    return this._plotBackground;
};

/**
 * Sets the background painter for the plot.
 *
 * @param {jsfc.RectanglePainter} painter  the background painter.
 * @param {boolean} [notify]  notify listeners? (default is true).
 * @returns {undefined}
 */
jsfc.CombinedDomainXYPlot.prototype.setBackground = function(painter, notify) {
    this._plotBackground = painter;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Draws the combined plot with all subplots.
 *
 * @param {jsfc.Context2D} ctx  the graphics context.
 * @param {jsfc.Rectangle} bounds  the overall bounds.
 * @param {jsfc.Rectangle} plotArea  the plot area.
 * @returns {undefined}
 */
jsfc.CombinedDomainXYPlot.prototype.draw = function(ctx, bounds, plotArea) {

    console.log("=== CombinedDomainXYPlot.draw() START ===");
    console.log("plotArea: x=" + plotArea.x() + ", y=" + plotArea.y() +
                ", w=" + plotArea.width() + ", h=" + plotArea.height());
    console.log("Number of subplots:", this._subplots.length);

    // Fill plot background if defined
    if (this._plotBackground) {
        this._plotBackground.paint(ctx, plotArea);
    }

    if (this._subplots.length === 0) {
        return; // nothing to draw
    }

    // Calculate space needed for the shared x-axis
    var space = new jsfc.AxisSpace(0, 0, 0, 0);
    var edge = jsfc.RectangleEdge.BOTTOM; // shared axis at bottom
    var xspace = this._xAxis.reserveSpace(ctx, this, bounds, plotArea, edge);
    console.log("X-axis reserved space:", xspace);
    space.extend(xspace, edge);
    console.log("After X-axis, space:", "top=" + space.top() + ", left=" + space.left() +
                ", bottom=" + space.bottom() + ", right=" + space.right());

    // Calculate the area available after accounting for x-axis
    var adjustedArea = space.innerRect(plotArea);
    console.log("adjustedArea after X-axis: x=" + adjustedArea.x() + ", y=" + adjustedArea.y() +
                ", w=" + adjustedArea.width() + ", h=" + adjustedArea.height());

    // Calculate space needed for y-axes of all subplots
    var maxLeftSpace = 0;
    var maxRightSpace = 0;
    var maxTopSpace = 0;
    var maxBottomSpace = 0;

    var n = this._subplots.length;
    var totalWeight = 0;
    for (var i = 0; i < n; i++) {
        totalWeight += this._subplots[i]._weight || 1;
    }

    // Calculate subplot areas
    this._subplotAreas = [];
    var usableHeight = adjustedArea.height() - this._gap * (n - 1);
    var y = adjustedArea.y();

    // First pass: configure y-axes, calculate each subplot's area and collect y-axis space requirements
    console.log("\n--- PASS 1: Measuring Y-axis space for each subplot ---");
    for (var i = 0; i < n; i++) {
        var subplot = this._subplots[i];
        var weight = subplot._weight || 1;
        var h = usableHeight * weight / totalWeight;

        var subplotArea = new jsfc.Rectangle(adjustedArea.x(), y,
                adjustedArea.width(), h);
        this._subplotAreas.push(subplotArea);
        console.log("Subplot " + i + " preliminary area: x=" + subplotArea.x() + ", y=" + subplotArea.y() +
                    ", w=" + subplotArea.width() + ", h=" + subplotArea.height());

        // Configure and get space needed for this subplot's y-axis
        var yAxis = subplot.getYAxis();
        if (yAxis) {
            console.log("  Y-axis label:", yAxis.getLabel());
            // Configure the y-axis for auto-ranging
            yAxis.configureAsYAxis(subplot);

            var yEdge = subplot.axisPosition(yAxis);
            console.log("  Y-axis edge:", yEdge);
            var yspace = yAxis.reserveSpace(ctx, subplot, bounds, subplotArea, yEdge);
            console.log("  Y-axis reserved space:", yspace);

            // yspace is a number, not an object - use it directly based on edge
            if (yEdge === jsfc.RectangleEdge.LEFT) {
                maxLeftSpace = Math.max(maxLeftSpace, yspace);
                console.log("  Updated maxLeftSpace:", maxLeftSpace);
            } else if (yEdge === jsfc.RectangleEdge.RIGHT) {
                maxRightSpace = Math.max(maxRightSpace, yspace);
                console.log("  Updated maxRightSpace:", maxRightSpace);
            } else if (yEdge === jsfc.RectangleEdge.TOP) {
                maxTopSpace = Math.max(maxTopSpace, yspace);
                console.log("  Updated maxTopSpace:", maxTopSpace);
            } else if (yEdge === jsfc.RectangleEdge.BOTTOM) {
                maxBottomSpace = Math.max(maxBottomSpace, yspace);
                console.log("  Updated maxBottomSpace:", maxBottomSpace);
            }
        } else {
            console.log("  No Y-axis found!");
        }

        y += h + this._gap;
    }

    // Add the maximum y-axis space to our total space
    console.log("\n--- Applying maximum Y-axis space ---");
    console.log("maxLeftSpace:", maxLeftSpace);
    console.log("maxRightSpace:", maxRightSpace);
    console.log("maxTopSpace:", maxTopSpace);
    console.log("maxBottomSpace:", maxBottomSpace);

    // Use private properties since AxisSpace doesn't have setters
    space._left = Math.max(space.left(), maxLeftSpace);
    space._right = Math.max(space.right(), maxRightSpace);
    space._top = Math.max(space.top(), maxTopSpace);
    space._bottom = Math.max(space.bottom(), maxBottomSpace);

    console.log("Final space:", "top=" + space.top() + ", left=" + space.left() +
                ", bottom=" + space.bottom() + ", right=" + space.right());

    // Calculate the final data area (after accounting for Y-axis space)
    var dataArea = space.innerRect(plotArea);
    console.log("Final dataArea: x=" + dataArea.x() + ", y=" + dataArea.y() +
                ", w=" + dataArea.width() + ", h=" + dataArea.height());

    // Recalculate subplot areas with proper positioning based on final dataArea
    // Now that Y-axis space has been accounted for, recalculate usableHeight
    console.log("\n--- PASS 2: Recalculating subplot positions with alignment ---");
    usableHeight = dataArea.height() - this._gap * (n - 1);
    y = dataArea.y();
    for (var i = 0; i < n; i++) {
        var subplot = this._subplots[i];
        var weight = subplot._weight || 1;
        var h = usableHeight * weight / totalWeight;

        this._subplotAreas[i] = new jsfc.Rectangle(dataArea.x(), y,
                dataArea.width(), h);
        var area = this._subplotAreas[i];
        console.log("Subplot " + i + " final area: x=" + area.x() + ", y=" + area.y() +
                    ", w=" + area.width() + ", h=" + area.height());

        y += h + this._gap;
    }

    // Draw the shared x-axis
    console.log("\n--- Drawing shared X-axis ---");
    var xOffset = this._axisOffsets.value(this._xAxisPosition);
    console.log("X-axis offset:", xOffset);
    this._xAxis.draw(ctx, this, bounds, dataArea, xOffset);

    // Draw each subplot (backgrounds, y-axes, and data)
    console.log("\n--- Drawing subplots ---");
    var globalSeriesIndex = 0;  // Track global series index across all subplots
    for (var i = 0; i < n; i++) {
        var subplot = this._subplots[i];
        var subplotArea = this._subplotAreas[i];
        console.log("Drawing subplot " + i + " in area: x=" + subplotArea.x() + ", y=" + subplotArea.y() +
                    ", w=" + subplotArea.width() + ", h=" + subplotArea.height());

        // Fill subplot background if defined
        if (subplot._dataBackground) {
            subplot._dataBackground.paint(ctx, subplotArea);
        }

        // Draw the subplot's y-axis
        var yAxis = subplot.getYAxis();
        if (yAxis) {
            var yOffset = subplot._axisOffsets.value(subplot.axisPosition(yAxis));
            console.log("  Drawing Y-axis for subplot " + i + ", label:", yAxis.getLabel());
            console.log("  Y-axis offset:", yOffset);
            console.log("  Y-axis drawing area: x=" + subplotArea.x() + ", y=" + subplotArea.y() +
                        ", w=" + subplotArea.width() + ", h=" + subplotArea.height());
            yAxis.draw(ctx, subplot, bounds, subplotArea, yOffset);
        } else {
            console.log("  No Y-axis for subplot " + i);
        }

        // Draw the subplot's data with global series offset for shared renderer
        var seriesCountThisSubplot = this._drawSubplotData(ctx, subplot, subplotArea, globalSeriesIndex);
        globalSeriesIndex += seriesCountThisSubplot;
    }

    // Draw vertical grid lines across all subplots AFTER everything else, so they're on top
    console.log("\n--- Drawing X-axis grid lines across all subplots (on top) ---");
    this._drawXAxisGridLines(ctx, dataArea);
    console.log("=== CombinedDomainXYPlot.draw() END ===\n");
};

/**
 * Draws vertical grid lines from the X-axis across all subplots.
 * This provides visual alignment aids similar to a regular XYPlot.
 *
 * @param {jsfc.Context2D} ctx  the graphics context.
 * @param {jsfc.Rectangle} dataArea  the combined data area for all subplots.
 * @returns {undefined}
 */
jsfc.CombinedDomainXYPlot.prototype._drawXAxisGridLines = function(ctx, dataArea) {
    // Only draw if the X-axis has grid lines enabled
    console.log("_drawXAxisGridLines called");
    console.log("X-axis grid lines visible:", this._xAxis._gridLinesVisible);

    if (!this._xAxis._gridLinesVisible) {
        console.log("Grid lines not visible, returning");
        return;
    }

    // Get the X-axis tick values
    var xAxis = this._xAxis;
    console.log("X-axis:", xAxis);
    console.log("dataArea:", dataArea);

    var tickSize = xAxis._calcTickSize(ctx, dataArea, jsfc.RectangleEdge.BOTTOM);
    console.log("tickSize:", tickSize);

    var ticks = xAxis.ticks(tickSize, ctx, dataArea, jsfc.RectangleEdge.BOTTOM);
    console.log("Number of ticks:", ticks.length);
    console.log("Ticks:", ticks);

    // Calculate the Y coordinates for the grid lines
    // Grid lines should span from top of first subplot to bottom of last subplot
    var topY = this._subplotAreas[0].y();
    var bottomY = this._subplotAreas[this._subplotAreas.length - 1].y() +
                  this._subplotAreas[this._subplotAreas.length - 1].height();

    console.log("Grid line Y range: topY=" + topY + ", bottomY=" + bottomY);
    console.log("Number of subplot areas:", this._subplotAreas.length);

    // Draw vertical grid lines at each tick
    ctx.setLineStroke(xAxis._gridLineStroke);
    console.log("Grid line stroke set:", xAxis._gridLineStroke);

    ctx.setLineColor(xAxis._gridLineColor);
    console.log("Grid line color set:", xAxis._gridLineColor);

    for (var i = 0; i < ticks.length; i++) {
        var tick = ticks[i];
        var xx = xAxis.valueToCoordinate(tick.value, dataArea.x(), dataArea.x() + dataArea.width());
        console.log("Drawing grid line " + i + " at x=" + Math.round(xx) + ", tick value=" + tick.value);
        ctx.drawLine(Math.round(xx), topY, Math.round(xx), bottomY);
    }
    console.log("Grid lines drawing complete");
};

/**
 * Draws the data for a single subplot using proper state management.
 *
 * @param {jsfc.Context2D} ctx  the graphics context.
 * @param {jsfc.XYPlot} subplot  the subplot.
 * @param {jsfc.Rectangle} dataArea  the data area for the subplot.
 * @param {number} [globalSeriesIndex]  the global series index offset for shared renderers.
 * @returns {number} the number of series in this subplot's dataset.
 */
jsfc.CombinedDomainXYPlot.prototype._drawSubplotData = function(ctx, subplot, dataArea, globalSeriesIndex) {
    var dataset = subplot.getDataset();
    if (!dataset) {
        return 0;
    }

    var renderer = subplot.getRenderer();
    if (!renderer) {
        return 0;
    }

    // Use global series index if provided (for shared renderers with global color palette)
    globalSeriesIndex = globalSeriesIndex || 0;

    // Set clipping to the data area
    ctx.setHint("clip", dataArea);
    ctx.setHint("glass", dataArea);
    ctx.beginGroup("subplot-" + this._subplots.indexOf(subplot));
    ctx.save();
    ctx.setClip(dataArea);

    // Temporarily set the subplot's data area (needed for rendering)
    var originalDataArea = subplot._dataArea;
    subplot._dataArea = dataArea;

    // Also temporarily set the subplot's x-axis to use the shared axis
    var originalXAxis = subplot._xAxis;
    subplot._xAxis = this._xAxis;

    // Create a state object for this subplot's rendering session
    // This maintains context across the rendering sequence
    var state = renderer.createState(null);

    // Render all data items with proper state management
    var passCount = renderer.passCount();
    for (var pass = 0; pass < passCount; pass++) {
        for (var s = 0; s < dataset.seriesCount(); s++) {
            // Use global series index if renderer is shared across subplots
            var effectiveSeriesIndex = (this._renderer === renderer) ? globalSeriesIndex + s : s;

            // Store the local series index in state for dataset access
            state.localSeriesIndex = s;

            // Notify renderer of series pass start
            var firstItem = 0;
            var lastItem = dataset.itemCount(s) - 1;
            state.startSeriesPass(dataset, effectiveSeriesIndex, firstItem, lastItem, pass, passCount);

            // Render each item in this series
            for (var i = firstItem; i <= lastItem; i++) {
                renderer.drawItem(ctx, state, dataArea, subplot, dataset,
                    effectiveSeriesIndex, i, pass);
            }

            // Notify renderer of series pass end
            state.endSeriesPass(dataset, effectiveSeriesIndex, firstItem, lastItem, pass, passCount);
        }
    }

    // Restore original values
    subplot._dataArea = originalDataArea;
    subplot._xAxis = originalXAxis;

    ctx.restore();
    ctx.endGroup();

    // Return the number of series in this subplot for global index tracking
    return dataset.seriesCount();
};

/**
 * Returns the edge location of the x-axis.
 *
 * @param {jsfc.ValueAxis} axis  the axis.
 * @returns {string} The axis position (refer to jsfc.RectangleEdge).
 */
jsfc.CombinedDomainXYPlot.prototype.axisPosition = function(axis) {
    if (axis === this._xAxis) {
        return this._xAxisPosition;
    }
    throw new Error("The axis does not belong to this plot.");
};

/**
 * Returns legend items for all subplots.
 *
 * @returns {Array} Array of legend item info objects.
 */
jsfc.CombinedDomainXYPlot.prototype.legendInfo = function() {
    var info = [];

    // If using a shared renderer, use global series indices for consistent colors
    if (this._renderer) {
        var globalSeriesIndex = 0;
        for (var s = 0; s < this._subplots.length; s++) {
            var subplot = this._subplots[s];
            var dataset = subplot.getDataset();
            if (dataset) {
                for (var i = 0; i < dataset.seriesCount(); i++) {
                    var seriesKey = dataset.seriesKey(i);
                    // Use global index with shared renderer to get correct color
                    var color = this._renderer._lineColorSource.getColor(globalSeriesIndex, 0);
                    var item = new jsfc.LegendItemInfo(seriesKey, color);
                    item.label = seriesKey;
                    info.push(item);
                    globalSeriesIndex++;
                }
            }
        }
    } else {
        // Fall back to original behavior if no shared renderer
        for (var i = 0; i < this._subplots.length; i++) {
            var subplotInfo = this._subplots[i].legendInfo();
            info = info.concat(subplotInfo);
        }
    }
    return info;
};

/**
 * Registers a listener to receive notification of changes to the plot.
 *
 * @param {Function} listener  the listener function.
 * @returns {undefined}
 */
jsfc.CombinedDomainXYPlot.prototype.addListener = function(listener) {
    this._listeners.push(listener);
};

/**
 * Removes a listener so that it no longer receives notification of changes
 * to the plot.
 *
 * @param {Function} listener  the listener function.
 * @returns {undefined}
 */
jsfc.CombinedDomainXYPlot.prototype.removeListener = function(listener) {
    var i = this._listeners.indexOf(listener);
    if (i >= 0) {
        this._listeners.splice(i, 1);
    }
};

/**
 * Notifies all registered listeners that the plot has changed.
 *
 * @returns {undefined}
 */
jsfc.CombinedDomainXYPlot.prototype.notifyListeners = function() {
    if (!this._notify) {
        return;
    }
    for (var i = 0; i < this._listeners.length; i++) {
        this._listeners[i](this);
    }
};

/**
 * Returns a composite dataset view that aggregates data from all subplots.
 * This is required for axis configuration compatibility.
 *
 * @returns {Object} A composite dataset object with xbounds() and getProperty() methods.
 */
jsfc.CombinedDomainXYPlot.prototype.getDataset = function() {
    var plot = this;

    return {
        /**
         * Returns the x-axis bounds across all subplot datasets.
         * @returns {Array} Array with [xmin, xmax].
         */
        xbounds: function() {
            var xmin = Number.POSITIVE_INFINITY;
            var xmax = Number.NEGATIVE_INFINITY;

            for (var i = 0; i < plot._subplots.length; i++) {
                var subplot = plot._subplots[i];
                var dataset = subplot.getDataset();
                if (dataset && dataset.xbounds) {
                    var bounds = dataset.xbounds();
                    if (bounds && bounds.length === 2) {
                        xmin = Math.min(xmin, bounds[0]);
                        xmax = Math.max(xmax, bounds[1]);
                    }
                }
            }

            if (xmin === Number.POSITIVE_INFINITY || xmax === Number.NEGATIVE_INFINITY) {
                return [0, 1]; // default range if no data
            }
            return [xmin, xmax];
        },

        /**
         * Returns a property value from the first subplot's dataset that has it.
         * @param {string} key The property key.
         * @returns {*} The property value or undefined.
         */
        getProperty: function(key) {
            for (var i = 0; i < plot._subplots.length; i++) {
                var subplot = plot._subplots[i];
                var dataset = subplot.getDataset();
                if (dataset && dataset.getProperty) {
                    var value = dataset.getProperty(key);
                    if (value !== undefined) {
                        return value;
                    }
                }
            }
            return undefined;
        }
    };
};

/**
 * The configureAsXAxis function for compatibility with axis configuration.
 * This gathers data range from all subplots.
 *
 * @returns {Object} An object with xmin, xmax, ymin, ymax properties.
 */
jsfc.CombinedDomainXYPlot.prototype.getDataBounds = function() {
    var xmin = Number.POSITIVE_INFINITY;
    var xmax = Number.NEGATIVE_INFINITY;
    var ymin = Number.POSITIVE_INFINITY;
    var ymax = Number.NEGATIVE_INFINITY;

    for (var i = 0; i < this._subplots.length; i++) {
        var subplot = this._subplots[i];
        var dataset = subplot.getDataset();
        if (dataset) {
            var bounds = jsfc.XYDatasetUtils.bounds(dataset);
            if (bounds) {
                xmin = Math.min(xmin, bounds.xmin);
                xmax = Math.max(xmax, bounds.xmax);
                ymin = Math.min(ymin, bounds.ymin);
                ymax = Math.max(ymax, bounds.ymax);
            }
        }
    }

    return { xmin: xmin, xmax: xmax, ymin: ymin, ymax: ymax };
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * Creates a new chart containing the specified plot.
 * 
 * @classdesc Represents a chart which has an optional title and subtitle,
 *   a plot where the data is presented, and an optional legend.  Different
 *   types of plot are supported to represent different types of data.
 *   
 * @constructor
 * @param {jsfc.CategoryPlot|jsfc.XYPlot} plot  the plot.
 * @returns {jsfc.Chart}
 */
jsfc.Chart = function(plot) {
    if (!(this instanceof jsfc.Chart)) {
        throw new Error("Use 'new' for construction.");
    } 
    this._size = new jsfc.Dimension(400, 240);
    var white = new jsfc.Color(255, 255, 255);
    this._backgroundPainter = new jsfc.StandardRectanglePainter(white, null);

    /** The margin around the edges of the plot. */
    this._padding = new jsfc.Insets(4, 4, 4, 4);
    
    /**
     * The title for the chart.
     * @type {jsfc.TableElement}
     */
    this._titleElement = null;
    
    /** The anchor point for the title. */
    this._titleAnchor = new jsfc.Anchor2D(jsfc.RefPt2D.TOP_LEFT);
    
    /** 
     * @type {jsfc.CategoryPlot|jsfc.XYPlot} 
     * @private 
     */
    this._plot = plot;
    
    /**
     * @type {jsfc.LegendBuilder}
     * @private
     */
    this._legendBuilder = new jsfc.StandardLegendBuilder();
    
    /**
     * @type {jsfc.Anchor2D}
     * @private
     */
    this._legendAnchor = new jsfc.Anchor2D(jsfc.RefPt2D.BOTTOM_RIGHT);
    
    this._listeners = [];
     
    // listen for changes to the plot
    var plotListener = function(c) {
        var chart = c;
        return function(plot) {
            chart.notifyListeners();
        };
    }(this);
    plot.addListener(plotListener);
    plot.chart = this;
};

jsfc.Chart.prototype.getElementID = function() {
    return this._elementId;
};

jsfc.Chart.prototype.setElementID = function(id) {
    this._elementId = id;
};

/**
 * Returns the size of the chart.
 * 
 * @returns {!jsfc.Dimension} The size.
 */
jsfc.Chart.prototype.getSize = function() {
    return this._size;
};

/**
 * Sets the dimensions of the chart and sends a change notification to 
 * registered listeners (unless 'notify' is set to false).
 * 
 * @param {!number} width  the new width.
 * @param {!number} height  the new height.
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.Chart.prototype.setSize = function(width, height, notify) {
    this._size = new jsfc.Dimension(width, height);
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns the painter for the chart's background.  The default value will draw
 * a white background for the chart.
 * 
 * @returns {jsfc.RectanglePainter} The background painter.
 */
jsfc.Chart.prototype.getBackground = function() {
    return this._backgroundPainter;
};

/**
 * Sets the background painter for the chart and sends a change notification
 * to all registered listeners (unless 'notify' is set to false).
 * 
 * @param {jsfc.RectanglePainter} painter  the new painter.
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.Chart.prototype.setBackground = function(painter, notify) {
    this._backgroundPainter = painter;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Sets the background color for the chart and sends a change event to 
 * registered listeners (unless 'notify' is set to false.  This is a 
 * convenience method that creates a new 'StandardRectanglePainter' and passes 
 * it to the setBackground(painter, notify) method.
 * 
 * @param {jsfc.Color} color  the background color.
 * @param {boolean} [notify]  notify listeners.
 * @returns {undefined}
 */
jsfc.Chart.prototype.setBackgroundColor = function(color, notify) {
    var painter = new jsfc.StandardRectanglePainter(color);
    this.setBackground(painter, notify);
};

/**
 * Returns the current padding.
 * 
 * @returns {jsfc.Insets} The padding.
 */
jsfc.Chart.prototype.getPadding = function() {
    return this._padding;
};

/**
 * Sets the padding around the edges of the chart and sends a change 
 * notification to all registered listeners (unless 'notify' is set to false).
 * 
 * @param {!number} top  the padding at the top.
 * @param {!number} left  the padding at the left.
 * @param {!number} bottom  the padding at the bottom.
 * @param {!number} right  the padding at the right.
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.Chart.prototype.setPadding = function(top, left, bottom, right, notify) {
    this._padding = new jsfc.Insets(top, left, bottom, right);
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns the chart title (this is a table element structure of arbitrary
 * complexity, the typical case contains a title and subtitle).
 * 
 * @returns {jsfc.TableElement} The chart title (possibly null/undefined).
 */
jsfc.Chart.prototype.getTitleElement = function() {
    return this._titleElement;
};

/**
 * Sets the chart title and sends a change notification to registered listeners
 * (unless 'notify' is set to false).
 * 
 * @param {jsfc.TableElement} title  the chart title (null permitted).
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.Chart.prototype.setTitleElement = function(title, notify) {
    this._titleElement = title;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Sets the chart title and subtitle (this builds a table element representing
 * the title and calls setTitleElement()).
 * 
 * @param {!string} title  the title.
 * @param {string} [subtitle]  the subtitle (null permitted).
 * @param {jsfc.Anchor2D} [anchor]  the anchor point (null permitted).
 * @param {boolean} [notify]  notify listeners.
 * @returns {jsfc.Chart} This object for chaining method calls.
 */
jsfc.Chart.prototype.setTitle = function(title, subtitle, anchor, 
        notify) {
    var element = jsfc.Charts.createTitleElement(title, subtitle, anchor);
    this.setTitleElement(element, notify);
    return this;
};

/**
 * Updates the text, font and color for the existing title.
 * 
 * @param {string} title  the new title text.
 * @param {jsfc.Font} [font]  the new title font.
 * @param {jsfc.Color} [color]  the new title color.
 * @returns {undefined}
 */
jsfc.Chart.prototype.updateTitle = function(title, font, color) {
    if (!this._titleElement) {
        return;
    }
    this._titleElement.receive(function(e) {
        if (e instanceof jsfc.TextElement && e.isTitle) {
            if (title) {
                e.setText(title);
            }
            if (font) {
                e.setFont(font);
            }
            if (color) {
                e.setColor(color);
            }
        }    
    });
};

jsfc.Chart.prototype.updateSubtitle = function(subtitle, font, color) {  
    if (!this._titleElement) {
        return;
    }
    this._titleElement.receive(function(e) {
        if (e instanceof jsfc.TextElement && e.isSubtitle) {
            if (subtitle) {
                e.setText(subtitle);
            }
            if (font) {
                e.setFont(font);
            }
            if (color) {
                e.setColor(color);
            }
        }    
    });
};

/**
 * Returns the title anchor.
 * 
 * @returns {jsfc.Anchor2D} The title anchor.
 */
jsfc.Chart.prototype.getTitleAnchor = function() {
    return this._titleAnchor;
};

/**
 * Sets the title anchor and sends a change notification to all registered
 * listeners (unless 'notify' is set to false).
 * 
 * @param {!jsfc.Anchor2D} anchor  the anchor point.
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.Chart.prototype.setTitleAnchor = function(anchor, notify) {
    this._titleAnchor = anchor;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns the plot, the object that manages the dataset, axes and renderer
 * for the chart.  The plot is set via the constructor.
 * 
 * @returns {Object} The plot (never null).
 */
jsfc.Chart.prototype.getPlot = function() {
    return this._plot;    
};

/**
 * Returns the object that builds the legend for this chart.  The default
 * builder will create a legend that matches the dataset (with colors from 
 * the plot or renderer).  If the legend builder is null, no legend will be
 * drawn for the chart.
 * 
 * @returns {jsfc.LegendBuilder} The legend builder (possibly null).
 */
jsfc.Chart.prototype.getLegendBuilder = function() {
    return this._legendBuilder;
};

/**
 * Sets the legend builder for the chart and sends a change notification to
 * all registered listeners (unless 'notify' is set to false).  Set this 
 * builder to null if you don't require a legend.
 * 
 * @param {jsfc.LegendBuilder} builder  the legend builder (null permitted).
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.Chart.prototype.setLegendBuilder = function(builder, notify) {
    this._legendBuilder = builder;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns the legend anchor point.  The default value is BOTTOM_RIGHT.
 * 
 * @returns {jsfc.Anchor2D} The anchor point.
 */
jsfc.Chart.prototype.getLegendAnchor = function() {
    return this._legendAnchor;
};

/**
 * Sets the legend anchor point and sends a change notification to all 
 * registered listeners (unless 'notify' is set to false).
 * 
 * @param {!jsfc.Anchor2D} anchor  the anchor point (null not permitted).
 * @param {boolean} [notify]  notify listeners?
 * @returns {undefined}
 */
jsfc.Chart.prototype.setLegendAnchor = function(anchor, notify) {
    this._legendAnchor = anchor;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Applies an increment to the margins to accommodate an item with the 
 * specified dimensions at the given position (anchor).
 * 
 * @param {Object} margin  the margin object to adjust.
 * @param {jsfc.Dimension} dim  the dimensions for the adjustment.
 * @param {jsfc.Anchor2D} anchor  the anchor point.
 * 
 * @returns {undefined}
 */
jsfc.Chart.prototype._adjustMargin = function(margin, dim, anchor) {
    if (jsfc.RefPt2D.isTop(anchor.refPt())) {
        margin.top += dim.height();
    } else if (jsfc.RefPt2D.isBottom(anchor.refPt())) {
        margin.bottom += dim.height();
    };
};
    
/**
 * Draws the chart on a 2D drawing context.
 * 
 * @param {!jsfc.Context2D} ctx  the drawing context.
 * @param {!jsfc.Rectangle} bounds  the drawing bounds.
 * @returns {undefined}
 */
jsfc.Chart.prototype.draw = function(ctx, bounds) {

    // fill in the chart background
    if (this._backgroundPainter) {
        this._backgroundPainter.paint(ctx, bounds);
    }
        
    var titleDim = new jsfc.Dimension(0, 0);
    var legendDim = new jsfc.Dimension(0, 0);
    if (this._titleElement) {
        titleDim = this._titleElement.preferredSize(ctx, bounds);
    }
    var legend;
    if (this._legendBuilder) {
        legend = this._legendBuilder.createLegend(this._plot, 
                this._legendAnchor, "orientation", {});
        legendDim = legend.preferredSize(ctx, bounds); 
    }
    var padding = this.getPadding();
    var px = padding.left();
    var py = padding.top() + titleDim.height();
    var pw = this._size.width() - padding.left() - padding.right();
    var ph = this._size.height() - padding.top() - padding.bottom() 
            - titleDim.height() - legendDim.height();
        // draw the axes and plot the data
    this._plotArea = new jsfc.Rectangle(px, py, pw, ph);
    this._plot.draw(ctx, bounds, this._plotArea);
        
    // draw the legend
    if (legend) {
        var fitter = new jsfc.Fit2D(this._legendAnchor);
        var dest = fitter.fit(legendDim, bounds);
        legend.draw(ctx, dest);
    }
    if (this._titleElement) {
        var fitter = new jsfc.Fit2D(this._titleAnchor);
        var dest = fitter.fit(titleDim, bounds);
        this._titleElement.draw(ctx, dest);
    }
};

/**
 * Returns the plot area from the most recent rendering of the chart.
 * 
 * @returns {jsfc.Rectangle} The plot area.
 */
jsfc.Chart.prototype.plotArea = function() {
    return this._plotArea;
};

/**
 * Registers a listener to receive notification of changes to the chart.  The
 * listener is a function - it will be passed one argument (this chart).
 * 
 * @param {Function} f  the listener function.
 * @returns {undefined}
 */
jsfc.Chart.prototype.addListener = function(f) {
    this._listeners.push(f);  
};

/**
 * Notify each listener function that this chart has changed.
 * 
 * @returns {undefined}
 */
jsfc.Chart.prototype.notifyListeners = function() {
    var chart = this;
    this._listeners.forEach(function(f) {
        f(chart);
    });
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * @namespace
 */
jsfc.Charts = {};

/**
 * Creates a table element containing the specified title and subtitle.
 *  
 * @param {!string} title  the title.
 * @param {string} [subtitle]  the subtitle (optional).
 * @param {jsfc.Anchor2D} [anchor]  the title anchor (optional, used to 
 *         determine the default text alignment).
 * 
 * @returns {jsfc.TableElement}
 */
jsfc.Charts.createTitleElement = function(title, subtitle, anchor) {
    jsfc.Args.requireString(title, "title");
    var titleFont = new jsfc.Font("Palatino, serif", 16, true, false);
    var halign = jsfc.HAlign.LEFT;
    var refPt = anchor ? anchor.refPt() : jsfc.RefPt2D.TOP_LEFT;
    if (jsfc.RefPt2D.isHorizontalCenter(refPt)) {
        halign = jsfc.HAlign.CENTER;
    } else if (jsfc.RefPt2D.isRight(refPt)) {
        halign = jsfc.HAlign.RIGHT;
    }
    var titleElement = new jsfc.TextElement(title);
    titleElement.setFont(titleFont);
    titleElement.halign(halign);
    titleElement.isTitle = true;
    if (subtitle) {
        var subtitleFont = new jsfc.Font("Palatino, serif", 12, false, true);
        var subtitleElement = new jsfc.TextElement(subtitle);
        subtitleElement.setFont(subtitleFont);
        subtitleElement.halign(halign);
        subtitleElement.isSubtitle = true;
        var composite = new jsfc.GridElement();
        composite.setInsets(new jsfc.Insets(0, 0, 0, 0));
        composite.add(titleElement, "R1", "C1");
        composite.add(subtitleElement, "R2", "C1");
        return composite;
    } else {
        return titleElement;
    }    
};

/**
 * Creates a bar chart based on the supplied dataset (any object that
 * implements the jsfc.Values2DDataset interface).
 * 
 * @param {string} title  the chart title (null permitted).
 * @param {string} subtitle  the chart subtitle (null permitted).
 * @param {!jsfc.Values2DDataset} dataset  the dataset.
 * @param {string} [xAxisLabel]  the x-axis label (defaults to 'Category').
 * @param {string} [yAxisLabel]  the y-axis label (defaults to 'Value').
 * @returns {jsfc.Chart}
 */
jsfc.Charts.createBarChart = function(title, subtitle, dataset, xAxisLabel, 
        yAxisLabel) {
    var plot = new jsfc.CategoryPlot(dataset);
    var renderer = new jsfc.BarRenderer(plot);
    plot.setRenderer(renderer);
    var xAxis = plot.getXAxis();
    xAxis.setLabel(xAxisLabel || "Category");
    var yAxis = plot.getYAxis();
    yAxis.setLabel(yAxisLabel || "Value");    
    yAxis.setAutoRangeIncludesZero(true);
    return new jsfc.Chart(plot)
            .setTitle(title, subtitle);
};

/**
 * Creates a stacked bar chart based on the supplied dataset (any object that
 * implements the jsfc.Values2DDataset interface).
 * 
 * @param {string} title  the chart title (null permitted).
 * @param {string} subtitle  the chart subtitle (null permitted).
 * @param {!jsfc.Values2DDataset} dataset  the dataset.
 * @param {string} [xAxisLabel]  the x-axis label (defaults to 'Category').
 * @param {string} [yAxisLabel]  the y-axis label (defaults to 'Value').
 * @returns {jsfc.Chart}
 */
jsfc.Charts.createStackedBarChart = function(title, subtitle, dataset, 
        xAxisLabel, yAxisLabel) {
    var plot = new jsfc.CategoryPlot(dataset);
    plot.setRenderer(new jsfc.StackedBarRenderer(plot));
    var xAxis = plot.getXAxis();
    xAxis.setLabel(xAxisLabel || "Category");
    var yAxis = plot.getYAxis();
    yAxis.setLabel(yAxisLabel || "Value");    
    yAxis.setAutoRangeIncludesZero(true);
    return new jsfc.Chart(plot)
            .setTitle(title, subtitle);
};

// Creates a line chart based on the supplied dataset (KeyedValues2DDataset)
jsfc.Charts.createLineChart = function(title, subtitle, dataset, 
        xAxisLabel, yAxisLabel) {
//    jsfc.Args.requireKeyedValues2DDataset(dataset, "dataset");
//    var plot = new jsfc.CategoryPlot(dataset);
//    plot.xAxis.label = xAxisLabel;
//    plot.yAxis.label = yAxisLabel;
//    plot.renderer = new jsfc.LineRenderer();
//    var chart = new jsfc.Chart(plot);
//    chart.initMargin({ top: 5, right: 5, left: 30, bottom: 20});
//    chart.title(jsfc.Charts.createTitleElement(title, subtitle, 
//            chart.titleAnchor()));
//    return chart;
};

/**
 * Creates a scatter chart with the supplied dataset.
 * 
 * @param {string} title  the chart title (null permitted).
 * @param {string} subtitle  the chart subtitle (null permitted).
 * @param {!jsfc.XYDataset} dataset  the dataset (null not permitted).
 * @param {string} xAxisLabel  the x-axis label.
 * @param {string} yAxisLabel  the y-axis label.
 * @returns {jsfc.Chart} A chart.
 */
jsfc.Charts.createScatterChart = function(title, subtitle, dataset, 
        xAxisLabel, yAxisLabel) {
    jsfc.Args.requireXYDataset(dataset, "dataset");
    var plot = new jsfc.XYPlot(dataset);
    plot.getXAxis().setLabel(xAxisLabel);
    plot.getYAxis().setLabel(yAxisLabel);
    plot.setRenderer(new jsfc.ScatterRenderer(plot));
    var chart = new jsfc.Chart(plot);
    chart.setPadding(5, 5, 5, 5);
    chart.setTitle(title, subtitle, chart.getTitleAnchor());
    return chart;
};

/**
 * Creates a line chart based on the supplied dataset (XYDataset).
 * 
 * @param {string} title  the chart title (null permitted).
 * @param {string} subtitle  the chart subtitle (null permitted).
 * @param {!jsfc.XYDataset} dataset  the dataset (null not permitted).
 * @param {string} xAxisLabel  the x-axis label.
 * @param {string} yAxisLabel  the y-axis label.
 * @returns {jsfc.Chart} A chart.
 */
jsfc.Charts.createXYLineChart = function(title, subtitle, dataset, 
        xAxisLabel, yAxisLabel) {
    jsfc.Args.requireXYDataset(dataset, "dataset");
    var plot = new jsfc.XYPlot(dataset);
    plot.getXAxis().setLabel(xAxisLabel);
    plot.getYAxis().setLabel(yAxisLabel);
    var renderer = new jsfc.XYLineRenderer();
    var chart = new jsfc.Chart(plot);
    chart.setTitleElement(jsfc.Charts.createTitleElement(title, subtitle, 
            chart.getTitleAnchor()));
    plot.setRenderer(renderer);
    return chart;
};

/**
 * Creates a bar chart from the specified dataset (IntervalXYDataset).
 * 
 * @param {string} title  the chart title (null permitted).
 * @param {string} subtitle  the chart subtitle (null permitted).
 * @param {!jsfc.XYDataset} dataset  the dataset (null not permitted).
 * @param {string} xAxisLabel  the x-axis label.
 * @param {string} yAxisLabel  the y-axis label.
 * @returns {jsfc.Chart} A chart.
 */
jsfc.Charts.createXYBarChart = function(title, subtitle, dataset, xAxisLabel,
        yAxisLabel) {
    var plot = new jsfc.XYPlot(dataset);
    plot.getXAxis().setLabel(xAxisLabel);
    plot.getYAxis().setLabel(yAxisLabel);
    var renderer = new jsfc.XYBarRenderer();
    plot.setRenderer(renderer);
    var chart = new jsfc.Chart(plot);
    var titleAnchor = new jsfc.Anchor2D(jsfc.RefPt2D.TOP_LEFT);
    chart.setTitle(title, subtitle, titleAnchor);
    return chart;
};

/*
   chartDisplay.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Exports:    window.ChartDisplay class
// Depends on: jsfreechart library (JSFreeChart, Charts, LinearAxis, XYPlot, etc. — loaded before
//             this file in bundle), window.csvCollector (loadCSVData reads CSV lines)
// Called by:  keepAliveAndHttp.js initializeMessageViewer (new ChartDisplay() → window.chartDisplay),
//             chartAndRawData.js (all chart display operations via window.chartDisplay),
//             messageViewer.js ChartConfigViewer (applyChartCommand, populate)

/**
 * TimeFormatter - Implements jsfc.Format interface for time values
 * Wraps TimeFormatUtil to provide format() method compatible with jsfreechart
 */
class TimeFormatter {
  constructor(timeFormatUtil) {
    this.timeFormatter = timeFormatUtil;
  }

  format(value) {
    return this.timeFormatter.format(value);
  }
}

/**
 * TimeFormatUtil - Formats millisecond timestamps according to specified formats
 * Supports elapsed time formats (ss, mm:ss, HH:mm:ss, d HH:mm:ss)
 * and Java SimpleDateFormat patterns (yyyy/MM/dd, etc)
 */
class TimeFormatUtil {
  /**
   * @param {string} formatString  Java SimpleDateFormat or elapsed-time pattern,
   *                               optionally suffixed with " UTC" or " DATE".
   * @param {number} [baseTimeMs]  Local-time anchor used for relative-ms
   *                               timestamps (< 2^40 ms).  Replaces the {@}
   *                               reference, which pfodWeb does not send.
   *                               Caller should pass csvCollector.firstLineTimeMs.
   *                               If null/undefined, format() falls back to
   *                               Date.now() at render time (legacy behaviour).
   */
  constructor(formatString, baseTimeMs = null) {
    this.formatString = formatString;
    this.baseTimeMs = baseTimeMs;
    this.isUTC = false;
    // Set when "UTC" or "DATE" trailing suffix forces an otherwise-elapsed
    // pattern (e.g. "HH:mm:ss") to be reinterpreted as a Java SimpleDateFormat
    // pattern rendering a wall-clock time.  Per pfod spec.
    this.forceDateFormat = false;

    let workingFormat = formatString;
    if (workingFormat) {
      const upper = workingFormat.toUpperCase();
      if (upper.endsWith('UTC')) {
        this.isUTC = true;
        this.forceDateFormat = true;
        workingFormat = workingFormat.substring(0, workingFormat.length - 3).trim();
      } else if (upper.endsWith('DATE')) {
        this.forceDateFormat = true;
        workingFormat = workingFormat.substring(0, workingFormat.length - 4).trim();
      }
    }

    // Extract decimal places before normalizing the format
    this.decimalPlaces = 0;
    const decimalMatch = workingFormat && workingFormat.match(/\.S+$/);
    if (decimalMatch) {
      this.decimalPlaces = decimalMatch[0].length - 1; // Count S's
      // Remove decimal specification for base format matching
      workingFormat = workingFormat.substring(0, workingFormat.length - decimalMatch[0].length).trim();
    }

    this.baseFormat = workingFormat;
    this.isSpecialFormat = this.checkIsSpecialFormat(this.baseFormat);
    // forceDateFormat (UTC / DATE suffix) overrides elapsed-pattern detection
    // so e.g. "HH:mm:ss UTC" renders as wall-clock UTC, not elapsed time.
    this.isElapsedFormat = !this.forceDateFormat
                        && !this.isSpecialFormat
                        && this.isElapsedTimeFormat(this.baseFormat);
    this.dateFormatter = (!this.isElapsedFormat && !this.isSpecialFormat)
                        ? this.createDateFormatter(this.baseFormat) : null;
  }

  /**
   * Check if format is an elapsed time format (ss, mm:ss, HH:mm:ss, d HH:mm:ss)
   */
  isElapsedTimeFormat(format) {
    if (!format) throw new Error(`[CHART_DISPLAY] isElapsedTimeFormat: format is required`);
    const normalized = format.replace(/\.S+$/, ''); // Remove decimal places
    return /^(ss|mm:ss|HH:mm:ss|d\s+HH:mm:ss)$/.test(normalized);
  }

  /**
   * Check if format is a special display format handled before pattern matching:
   *   ms          - display raw value as integer milliseconds
   *   unix-dt     - unix timestamp (ms) → "YYYY Mon DD HH:mm:ss"
   *   unix-ddd-hm - unix timestamp (ms) → "DDD HH:mm"
   *   unix-ddd-hms- unix timestamp (ms) → "DDD HH:mm:ss"
   */
  checkIsSpecialFormat(format) {
    return format === 'ms' || format === 'unix-dt' || format === 'unix-ddd-hm' || format === 'unix-ddd-hms';
  }

  /**
   * Create a date formatter from Java SimpleDateFormat pattern
   */
  createDateFormatter(format) {
    if (!format) throw new Error(`[CHART_DISPLAY] createDateFormatter: format is required`);
    return {
      pattern: format,
      // Map common patterns to methods
      formatDate: (ms) => this.formatDateByPattern(ms, format)
    };
  }

  /**
   * Parse a CSV X-axis value string into a numeric value.
   *
   * Behaviour matches pfodApp's raw-data interpretation:
   *   - Plain numeric strings ("1234", "1234.5") → returned via parseFloat.
   *     For elapsed-time formats these are seconds; for absolute date/time
   *     formats they are millisecond timestamps (interpreted by format()
   *     against the 2^40 ms threshold to decide relative vs absolute).
   *   - Absolute date/time strings using Java SimpleDateFormat-like patterns
   *     are auto-detected and converted to milliseconds since 1970-01-01:
   *       "2019/03/31"
   *       "2019/03/31 00:35:01"
   *       "2019-03-31T00:35:01"          (ISO 8601 separator)
   *       "2019-03-31T00:35:01.123"      (with millis)
   *
   * If the chart's format string ends with "UTC" the absolute date is
   * interpreted as UTC (matching the DISPLAY side); otherwise local time.
   *
   * Returns NaN for unparseable input.
   *
   * @param {string} str           - CSV field value
   * @param {string} [formatString] - Chart time format (used only to detect UTC suffix)
   * @returns {number} numeric value (ms since epoch for absolute dates, else raw number)
   */
  /**
   * Quick check — does the string look like an absolute date (yyyy/MM/dd
   * or yyyy-MM-dd, optionally with time)?  Used by chart-display callers
   * to detect when the X-axis column contains date strings so a default
   * date formatter can be installed even if the chart cmd omits a
   * ~timeFormat plot option.  Same regex as parseValue() uses to
   * detect absolute dates.
   *
   * @param {string} str
   * @returns {boolean}
   */
  static isDateLikeString(str) {
    if (str === null || str === undefined) return false;
    const trimmed = String(str).trim();
    if (trimmed === '') return false;
    return /^(\d{4})[/-](\d{1,2})[/-](\d{1,2})(?:[T ](\d{1,2}):(\d{1,2})(?::(\d{1,2})(?:\.(\d{1,3}))?)?)?$/
      .test(trimmed);
  }

  static parseValue(str, formatString) {
    if (str === null || str === undefined) return NaN;
    const trimmed = String(str).trim();
    if (trimmed === '') return NaN;

    // Plain numeric (millisecond timestamp or elapsed seconds — caller decides)
    if (/^-?\d+(?:\.\d+)?$/.test(trimmed)) {
      return parseFloat(trimmed);
    }

    // Absolute date/time: yyyy{/-}MM{/-}dd[ T HH:mm[:ss[.SSS]]]
    const m = trimmed.match(
      /^(\d{4})[/-](\d{1,2})[/-](\d{1,2})(?:[T ](\d{1,2}):(\d{1,2})(?::(\d{1,2})(?:\.(\d{1,3}))?)?)?$/
    );
    if (m) {
      const y  = parseInt(m[1], 10);
      const mo = parseInt(m[2], 10) - 1;
      const d  = parseInt(m[3], 10);
      const h  = m[4] !== undefined ? parseInt(m[4], 10) : 0;
      const mi = m[5] !== undefined ? parseInt(m[5], 10) : 0;
      const s  = m[6] !== undefined ? parseInt(m[6], 10) : 0;
      const ms = m[7] !== undefined ? parseInt((m[7] + '000').substring(0, 3), 10) : 0;
      const isUTC = !!formatString && formatString.toUpperCase().endsWith('UTC');
      return isUTC ? Date.UTC(y, mo, d, h, mi, s, ms)
                   : new Date(y, mo, d, h, mi, s, ms).getTime();
    }

    // Native Date.parse fallback (handles full ISO 8601 with timezone, RFC 2822 etc)
    const native = Date.parse(trimmed);
    if (!isNaN(native)) return native;

    // Last resort — leading numeric prefix (preserves prior behaviour for partly-numeric strings)
    return parseFloat(trimmed);
  }

  /**
   * Format millisecond timestamp according to the specified format
   */
  format(ms) {
    if (ms === null || ms === undefined) return '';

    const timestamp = parseFloat(ms);
    if (isNaN(timestamp)) return String(ms);

    // 'ms' format: raw integer milliseconds, no conversion.
    if (this.baseFormat === 'ms') {
      return String(Math.round(timestamp));
    }

    // Elapsed-time patterns: render the ms value directly as a duration.
    if (this.isElapsedFormat) {
      return this.formatElapsedTime(timestamp);
    }

    // Calendar paths (unix-* presets and Java SimpleDateFormat patterns)
    // share the relative-time anchor.
    //
    //   THRESHOLD: < 2^40 ms ≈ Nov 2004 UTC.  Values below it are treated
    //   as relative offsets (typical device-uptime / since-stream-start).
    //   Values >= 2^40 are absolute ms-since-epoch and rendered as-is.
    //
    //   For relative values, this.baseTimeMs is precomputed by chartDisplay
    //   as
    //       firstLineTimeMs - firstLineMs
    //   where firstLineMs and firstLineTimeMs are captured from the first
    //   parseable CSV line — its X-field value and its arrival Date.now()
    //   respectively.  Adding lineMs gives back firstLineTimeMs for the
    //   first line (so it maps to its arrival instant) and shifts every
    //   subsequent line by (lineMs - firstLineMs) from that anchor.
    //
    //   No fallback: if baseTimeMs isn't set we leave the timestamp
    //   unmodified.  Small ms values then render as 1970-era dates,
    //   which is a clear signal that the anchor wasn't plumbed through —
    //   better than silently shifting against today's clock and looking
    //   correct.
    const THRESHOLD = Math.pow(2, 40);
    const isRelativeTime = Math.abs(timestamp) < THRESHOLD;
    let actualTime = timestamp;
    if (isRelativeTime
     && this.baseTimeMs !== null
     && this.baseTimeMs !== undefined) {
      actualTime = this.baseTimeMs + timestamp;
    }

    // unix-* presets: render via day-of-week / month / etc helper.
    if (this.baseFormat === 'unix-dt'
     || this.baseFormat === 'unix-ddd-hm'
     || this.baseFormat === 'unix-ddd-hms') {
      return this.formatUnixMs(actualTime, this.baseFormat);
    }

    // Java SimpleDateFormat pattern.
    if (this.dateFormatter) {
      return this.dateFormatter.formatDate(actualTime);
    }

    // No format specified — return raw value.
    return String(timestamp);
  }

  /**
   * Format elapsed time in various formats
   */
  formatElapsedTime(ms) {
    const absMs = Math.abs(ms);
    const sign = ms < 0 ? '-' : '';

    // Convert to seconds and extract components
    let totalSeconds = absMs / 1000;
    let days = Math.floor(totalSeconds / 86400);
    let hours = Math.floor((totalSeconds % 86400) / 3600);
    let minutes = Math.floor((totalSeconds % 3600) / 60);
    let seconds = totalSeconds % 60;

    // Format based on pattern
    switch (this.baseFormat) {
      case 'ss':
        return sign + this.formatNumber(totalSeconds, this.decimalPlaces);

      case 'mm:ss': {
        const totalMins = Math.floor(totalSeconds / 60);
        const secsStr = this.decimalPlaces > 0
          ? (() => { const s = seconds.toFixed(this.decimalPlaces); const d = s.indexOf('.'); return s.substring(0, d).padStart(2, '0') + s.substring(d); })()
          : this.padZero(seconds);
        return sign + totalMins + ':' + secsStr;
      }

      case 'HH:mm:ss': {
        const totalHours = Math.floor(totalSeconds / 3600);
        const mins = Math.floor((totalSeconds % 3600) / 60);
        const secsStr2 = this.decimalPlaces > 0
          ? (() => { const s = seconds.toFixed(this.decimalPlaces); const d = s.indexOf('.'); return s.substring(0, d).padStart(2, '0') + s.substring(d); })()
          : this.padZero(seconds);
        return sign + totalHours + ':' + this.padZero(mins) + ':' + secsStr2;
      }

      case 'd HH:mm:ss': {
        const hoursPart = Math.floor((totalSeconds % 86400) / 3600);
        const minsPart = Math.floor((totalSeconds % 3600) / 60);
        const secsStr3 = this.decimalPlaces > 0
          ? (() => { const s = seconds.toFixed(this.decimalPlaces); const d = s.indexOf('.'); return s.substring(0, d).padStart(2, '0') + s.substring(d); })()
          : this.padZero(seconds);
        return sign + days + 'd ' + this.padZero(hoursPart) + ':' + this.padZero(minsPart) + ':' + secsStr3;
      }

      default:
        return String(ms);
    }
  }

  /**
   * Format a unix timestamp (milliseconds since epoch) into a human-readable
   * date/time string.  Matches the rest of the pfodWeb chart pipeline —
   * everything else also operates on ms — so the value is fed straight into
   * the Date constructor without a seconds-to-ms conversion.
   *
   * @param {number} epochMs - Unix timestamp in milliseconds
   * @param {string} format - 'unix-dt', 'unix-ddd-hm', or 'unix-ddd-hms'
   * @returns {string} - Formatted date/time label
   */
  formatUnixMs(epochMs, format) {
    const date = new Date(epochMs);
    const DAYS   = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const ddd = DAYS[date.getDay()];
    const mon = MONTHS[date.getMonth()];
    const yyyy = date.getFullYear();
    const dd   = this.padZero(date.getDate());
    const HH   = this.padZero(date.getHours());
    const mm   = this.padZero(date.getMinutes());
    const ss   = this.padZero(date.getSeconds());
    switch (format) {
      case 'unix-dt':      return `${yyyy} ${mon} ${dd} ${HH}:${mm}:${ss}`;
      case 'unix-ddd-hm':  return `${ddd} ${HH}:${mm}`;
      case 'unix-ddd-hms': return `${ddd} ${HH}:${mm}:${ss}`;
      default:             return String(date);
    }
  }

  /**
   * Format a millisecond timestamp using a Java SimpleDateFormat-style pattern.
   *
   * Supported tokens (consecutive letters of the same kind form one token):
   *   y, yy, yyyy           — year (last 2 digits / 4 digits)
   *   M, MM                 — month number (no pad / zero-padded)
   *   MMM                   — month abbreviation ("Jan")
   *   MMMM                  — full month name ("January")
   *   d, dd                 — day-of-month
   *   E, EE, EEE            — day-of-week abbreviation ("Mon")
   *   EEEE                  — full day-of-week name ("Monday")
   *   H, HH                 — hour 0-23
   *   h, hh                 — hour 1-12
   *   m, mm                 — minute
   *   s, ss                 — second
   *   S, SS, SSS            — millisecond (truncated to width)
   *   a                     — AM / PM
   *
   * Single-quoted runs are emitted literally; '' is an escaped single quote.
   * Unrecognized letter tokens pass through unchanged.
   * UTC vs local time follows this.isUTC (set from the trailing "UTC" suffix
   * on the format string).
   */
  formatDateByPattern(ms, pattern) {
    const date = new Date(ms);
    const utc  = this.isUTC;

    const year   = utc ? date.getUTCFullYear()      : date.getFullYear();
    const month  = utc ? date.getUTCMonth()         : date.getMonth();      // 0-11
    const day    = utc ? date.getUTCDate()          : date.getDate();
    const dow    = utc ? date.getUTCDay()           : date.getDay();        // 0=Sun
    const hour24 = utc ? date.getUTCHours()         : date.getHours();
    const minute = utc ? date.getUTCMinutes()       : date.getMinutes();
    const second = utc ? date.getUTCSeconds()       : date.getSeconds();
    const millis = utc ? date.getUTCMilliseconds()  : date.getMilliseconds();

    const MONTHS_SHORT = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const MONTHS_LONG  = ['January','February','March','April','May','June',
                          'July','August','September','October','November','December'];
    const DAYS_SHORT   = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
    const DAYS_LONG    = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

    const pad = (n, w) => String(n).padStart(w, '0');

    const renderToken = (ch, len) => {
      switch (ch) {
        case 'y':
          if (len === 2) return pad(year % 100, 2);
          return pad(year, len);                    // y / yyyy / longer
        case 'M':
          if (len === 1) return String(month + 1);
          if (len === 2) return pad(month + 1, 2);
          if (len === 3) return MONTHS_SHORT[month];
          return MONTHS_LONG[month];                // 4+
        case 'd':
          return pad(day, len);
        case 'E':
          return len >= 4 ? DAYS_LONG[dow] : DAYS_SHORT[dow];
        case 'H':
          return pad(hour24, len);
        case 'h': {
          const h12 = ((hour24 + 11) % 12) + 1;     // 1..12
          return pad(h12, len);
        }
        case 'm':
          return pad(minute, len);
        case 's':
          return pad(second, len);
        case 'S':
          return pad(millis, 3).substring(0, len);  // truncate to width
        case 'a':
          return hour24 < 12 ? 'AM' : 'PM';
        default:
          return ch.repeat(len);                    // unknown — pass through
      }
    };

    // Walk the pattern, grouping runs of the same letter and honouring '...' quoted literals.
    let out = '';
    let i = 0;
    while (i < pattern.length) {
      const c = pattern.charAt(i);

      if (c === "'") {
        // Quoted literal.  '' inside a quoted run = literal ', and '' alone = literal '
        if (i + 1 < pattern.length && pattern.charAt(i + 1) === "'") {
          out += "'";
          i += 2;
          continue;
        }
        i++; // skip opening quote
        while (i < pattern.length) {
          const q = pattern.charAt(i);
          if (q === "'") {
            if (i + 1 < pattern.length && pattern.charAt(i + 1) === "'") {
              out += "'";        // escaped quote inside quoted run
              i += 2;
              continue;
            }
            i++;                 // closing quote
            break;
          }
          out += q;
          i++;
        }
        continue;
      }

      if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) {
        // Pattern letter — count run length
        let j = i + 1;
        while (j < pattern.length && pattern.charAt(j) === c) j++;
        out += renderToken(c, j - i);
        i = j;
        continue;
      }

      out += c;
      i++;
    }
    return out;
  }

  /**
   * Format number with specified decimal places
   */
  formatNumber(num, decimalPlaces) {
    if (decimalPlaces === 0) {
      return Math.floor(num).toString();
    }
    return num.toFixed(decimalPlaces);
  }

  /**
   * Pad number with leading zero
   */
  padZero(num) {
    return String(Math.floor(num)).padStart(2, '0');
  }
}

/**
 * ChartDisplay - Handles chart creation, rendering, and updates
 * Works with JSFreeChart library for XY plotting
 * Supports limiting displayed data points to manageable dataset size
 */
class ChartDisplay {
  constructor() {
    this.currentChart = null;           // Current chart instance
    this.currentDataset = null;         // Current dataset
    this.currentLabels = null;          // Current field labels
    this.dataPointLimit = 500;          // Default limit for displayed points
    this.lastDataLineCount = 0;         // Track processed CSV lines
    this.frozenStartRow = null;         // null = live, number = frozen at this CSV row index
    this.multiSubplotUpdateInterval = null; // Multi-subplot polling interval handle
    this.currentCanvas = null;          // Reference to active chart canvas
    this.lastCanvasWidth = 0;           // Track previous canvas width for resize detection
    this.lastCanvasHeight = 0;          // Track previous canvas height for resize detection
    this.currentTimeFormatter = null;   // TimeFormatUtil for X-axis labels
    this.crosshairOverlay = null;       // Transparent overlay canvas for crosshair line
    this.crosshairTooltip = null;       // Floating tooltip div
    this.lastMouseX = null;             // Last mouse pixel X within overlay canvas
    this.lastMouseY = null;             // Last mouse pixel Y within overlay canvas
    this.lastClientX = null;            // Last mouse clientX (viewport coords) for tooltip placement
    this.lastClientY = null;            // Last mouse clientY (viewport coords) for tooltip placement
    this._mouseMoveHandler = null;      // Stored handler ref for removeEventListener
    this._mouseLeaveHandler = null;     // Stored handler ref for removeEventListener
    console.log('[CHART_DISPLAY] ChartDisplay instance created');
  }

  /**
   * Parse chart labels from response message format
   * Handles JSON parser array format where pipes split the response:
   * {=Test Data|count|l1|l2} becomes ["{=Test Data", "|count", "|l1", "|l2"]
   *
   * Supports:
   * a) {=Title|field1|field2|...} - Charts data with field labels
   * b) {=Title| | } - Empty labels between pipes, treated as raw data
   * c) {=Title} - No pipes at all, treated as raw data
   *
   * Output: {title: "Title", labels: ["field1", "field2"], fieldCount: 3, limit: 500}
   *         or null for raw data display
   *
   * @param {array} cmdArray - The cmd array from JSON-parsed response
   * @returns {object|null} - Chart info object or null for raw data display
   */
  parseChartLabels(cmdArray) {
    console.log('[CHART_DISPLAY] parseChartLabels called with array:', cmdArray);

    if (!Array.isArray(cmdArray) || cmdArray.length === 0) {
      throw new Error(`[CHART_DISPLAY] parseChartLabels: cmdArray must be a non-empty array`);
    }

    // Parse first element to extract title
    // Format: {=Title
    const firstElem = cmdArray[0];
    const eqIdx = firstElem.indexOf('=');
    if (eqIdx === -1) {
      console.log('[CHART_DISPLAY] No "=" found in first element, returning null');
      return null;
    }

    const title = firstElem.substring(eqIdx + 1).trim();
    console.log('[CHART_DISPLAY] Extracted title:', title);

    // If only first element, no fields - this is raw data
    if (cmdArray.length === 1) {
      console.log('[CHART_DISPLAY] Only title, no fields - this is raw data');
      return null;
    }

    // Extract field labels from remaining array elements
    // Only elements with | prefix are field labels: "|count", "|l1", "|l2"
    // Elements without | (like closing "}") are not field labels

    // IMPORTANT: Count pipe-delimited elements to match CSV field count
    const pipeElements = cmdArray.slice(1).filter(elem => typeof elem === 'string' && elem.startsWith('|'));
    console.log('[CHART_DISPLAY] Found', pipeElements.length, 'pipe-delimited elements');

    // Extract ALL labels including empty ones to preserve field positions
    // For example: {=Plot|time|temperature|  |humidity} gives ["time", "temperature", "", "humidity"]
    const allLabels = pipeElements
      .map(elem => elem.substring(1).trim());

    console.log('[CHART_DISPLAY] Extracted all field labels (including blanks):', allLabels);

    // Get list of non-blank labels for display
    const nonBlankLabels = allLabels.filter(label => label.length > 0);
    console.log('[CHART_DISPLAY] Non-blank labels:', nonBlankLabels);

    // Check for empty labels between pipes: {=Title| | } case
    // If we have pipe elements but all labels are empty, treat as raw data
    if (pipeElements.length > 0 && nonBlankLabels.length === 0) {
      console.log('[CHART_DISPLAY] Pipe elements found but all labels are empty (e.g., {=Title| | }) - treating as raw data');
      return null;
    }

    if (nonBlankLabels.length === 0) {
      // No non-blank fields - treat as raw data
      console.log('[CHART_DISPLAY] No non-blank field labels found, returning null');
      return null;
    }

    // fieldCount is based on ALL labels (including blanks) to match CSV field count
    const fieldCount = allLabels.length;
    const limit = 500; // Default limit (500 CSV lines)

    // Check if there's only one non-blank label
    const useCountFlag = nonBlankLabels.length === 1;
    if (useCountFlag) {
      console.log('[CHART_DISPLAY] Single non-blank label detected: "' + nonBlankLabels[0] + '", setting useCountFlag=true');
      console.log('[CHART_DISPLAY] X-axis will be "Count", Y-axis will be "' + nonBlankLabels[0] + '"');
    }

    console.log('[CHART_DISPLAY] Parsed chart - title:', title, 'allLabels:', allLabels, 'nonBlankLabels:', nonBlankLabels, 'fieldCount:', fieldCount, 'limit:', limit, 'CSV lines, useCountFlag:', useCountFlag);
    return {
      title: title,
      allLabels: allLabels,           // All labels including blanks: ["time", "temp", "", "humidity"]
      nonBlankLabels: nonBlankLabels, // Only non-blank: ["time", "temp", "humidity"]
      fieldCount: fieldCount,         // 4 (for CSV matching based on pipe count)
      limit: limit,
      useCountFlag: useCountFlag      // true if single non-blank field (x-axis will be "Count", y-axis will be the field)
    };
  }

  /**
   * Parse a single field specification to extract label, plotNo, max, min, and unit
   * Format: fieldName[~max][~min][~unit][`plotNo] or other combinations
   * Examples:
   *   - temp
   *   - temp`2
   *   - temp~100~-10
   *   - temp`2~100~-10
   *   - temp~100~-10`2
   *   - temp~100~~DegC
   *   - temp~~-10
   *
   * @param {string} content - The field specification content
   * @returns {object} - {label, plotNo, max, min, unit}
   */
  parseFieldSpec(content) {
    let label = '';
    let plotNo = null;
    let max = null;
    let min = null;
    let unit = null;

    // Find first tilde to split label from values
    const tildeIdx = content.indexOf('~');
    const backtickIdx = content.indexOf('`');

    // Find first delimiter
    const firstDelimIdx = Math.min(
      tildeIdx >= 0 ? tildeIdx : Infinity,
      backtickIdx >= 0 ? backtickIdx : Infinity
    );

    // Extract label and initial plotNo
    if (firstDelimIdx === Infinity) {
      // No special characters
      label = content.trim();
    } else {
      label = content.substring(0, firstDelimIdx).trim();

      // If backtick comes first and before tilde, extract plotNo
      if (backtickIdx >= 0 && (tildeIdx < 0 || backtickIdx < tildeIdx)) {
        const endIdx = tildeIdx >= 0 ? tildeIdx : content.length;
        const plotNoStr = content.substring(backtickIdx + 1, endIdx).trim();
        const plotNoNum = parseInt(plotNoStr);
        if (!isNaN(plotNoNum)) {
          plotNo = Math.abs(plotNoNum);
        }
      }
    }

    // Parse tilde-separated values (max, min, unit)
    if (tildeIdx >= 0) {
      const valueStr = content.substring(tildeIdx); // Starts with ~
      const parts = valueStr.split('~').slice(1); // Skip first empty element

      for (let i = 0; i < parts.length; i++) {
        const part = parts[i];

        // Check if this part contains backtick (plotNo at end)
        const backtickInPart = part.indexOf('`');
        let value = part;

        if (backtickInPart >= 0) {
          value = part.substring(0, backtickInPart).trim();
          // Only extract plotNo from constraints if not already set by label`plotNo
          if (plotNo === null) {
            const plotNoStr = part.substring(backtickInPart + 1).trim();
            const plotNoNum = parseInt(plotNoStr);
            if (!isNaN(plotNoNum)) {
              plotNo = Math.abs(plotNoNum);
            }
          }
        } else {
          value = value.trim();
        }

        if (value.length === 0) continue; // Skip empty values (e.g., ~~)

        if (i === 0) {
          const maxNum = parseFloat(value);
          if (!isNaN(maxNum)) max = maxNum;
        } else if (i === 1) {
          const minNum = parseFloat(value);
          if (!isNaN(minNum)) min = minNum;
        } else if (i === 2) {
          unit = value;
        }
      }
    }

    return { label, plotNo, max, min, unit };
  }

  /**
   * Parse chart labels with plotNo parameters for multi-subplot support
   * Extended format with optional plotNo:
   * {=Title| [fieldName][ `plotNo] [ | [fieldName][ `plotNo] ]* }
   *
   * Examples:
   * 1. {=Weather|time`0|temp`1|pressure`1|humidity`2}
   *    → X-axis: "time" (plotNo 0)
   *    → Subplot 1: temp, pressure (plotNo 1)
   *    → Subplot 2: humidity (plotNo 2)
   *
   * 2. {=Data|count`0|a|b`1|c}
   *    → X-axis: "count" (plotNo 0)
   *    → Subplot [unassigned]: a, c (no plotNo, fields without plotNo plotted together)
   *    → Subplot 1: b (plotNo 1)
   *
   * 3. {=Mixed|count|a`0|b|c`0|d`5|e`5}
   *    → X-axis: a (first plotNo 0)
   *    → Subplot [unassigned]: b, c (no plotNo or repeated plotNo 0)
   *    → Subplot 5: d, e (plotNo 5)
   *
   * 4. {=Mixed| `1|`0| |}
   *    → No field names, all blank labels → ignore plotNo, treat as raw data
   *
   * @param {array} cmdArray - The cmd array from JSON-parsed response
   * @returns {object|null} - Subplot info with organization by plotNo, or null for raw data
   */
  parseChartLabelsWithPlotNo(cmdArray) {
    console.log('[CHART_DISPLAY] parseChartLabelsWithPlotNo called with array:', cmdArray);

    if (!Array.isArray(cmdArray) || cmdArray.length === 0) {
      throw new Error(`[CHART_DISPLAY] parseChartLabelsWithPlotNo: cmdArray must be a non-empty array`);
    }

    // Parse first element to extract title and maxPoints
    const firstElem = cmdArray[0];
    const eqIdx = firstElem.indexOf('=');
    if (eqIdx === -1) {
      console.log('[CHART_DISPLAY] No "=" found in first element, returning null');
      return null;
    }

    const titleWithMaxPoints = firstElem.substring(eqIdx + 1).trim();

    // Extract maxPoints and optional time format from the header element after '='.
    // Both maxPoints (backtick-prefixed) and plotOptions (tilde-prefixed) are optional
    // and may appear in either order relative to each other:
    //   "name`maxPoints~timeFormat"  e.g. "Chart`500~mm:ss"
    //   "name~timeFormat`maxPoints"  e.g. "Chart~mm:ss`500"
    //   "name`maxPoints"             e.g. "Chart`500"
    //   "name~timeFormat"            e.g. "Chart~mm:ss"
    //   "name"                       e.g. "Chart"
    // The title ends at whichever of '`' or '~' appears first.
    let title = titleWithMaxPoints;
    let maxPoints = 500; // Default when no backtick present
    let timeFormat = null;
    let clearData = false; // ~C : clear CSV/raw collectors before display
    let sortData  = false; // ~S : sort X-axis data before display

    // Scan a list of '~'-separated plot-option parts.  Single-letter options
    // are flags ("C" → clearData, "S" → sortData, others ignored).  The first
    // non-single-letter part is the date/time or elapsed-time format.
    const scanPlotOptions = (parts) => {
      for (const part of parts) {
        const trimmed = part.trim();
        if (trimmed.length === 1) {
          if (trimmed === 'C') clearData = true;
          else if (trimmed === 'S') sortData = true;
          // any other single-letter option is silently ignored per spec
        } else if (trimmed.length > 1 && timeFormat === null) {
          timeFormat = trimmed;
        }
      }
    };

    const backtickIdx = titleWithMaxPoints.indexOf('`');
    const tildeIdx    = titleWithMaxPoints.indexOf('~');

    if (backtickIdx === -1 && tildeIdx === -1) {
      // Plain title, no maxPoints or plotOptions
      title = titleWithMaxPoints.trim();
    } else if (backtickIdx !== -1 && (tildeIdx === -1 || backtickIdx < tildeIdx)) {
      // Backtick comes first: "name`maxPoints[~plotOption...]"
      title = titleWithMaxPoints.substring(0, backtickIdx).trim();
      const afterBacktick = titleWithMaxPoints.substring(backtickIdx + 1);

      const tildeInRest = afterBacktick.indexOf('~');
      if (tildeInRest !== -1) {
        // maxPoints before tilde, plotOptions after
        const maxPointsNum = parseInt(afterBacktick.substring(0, tildeInRest).trim());
        if (!isNaN(maxPointsNum) && maxPointsNum > 0) maxPoints = maxPointsNum;
        scanPlotOptions(afterBacktick.substring(tildeInRest + 1).split('~'));
      } else {
        // maxPoints only, no plotOptions
        const maxPointsNum = parseInt(afterBacktick.trim());
        if (!isNaN(maxPointsNum) && maxPointsNum > 0) maxPoints = maxPointsNum;
      }
    } else {
      // Tilde comes first (or no backtick): "name~plotOption[`maxPoints]"
      // e.g. "Chart Label~mm:ss`500" or "Chart Label~mm:ss"
      title = titleWithMaxPoints.substring(0, tildeIdx).trim();
      const afterTilde = titleWithMaxPoints.substring(tildeIdx + 1);

      const backtickInRest = afterTilde.indexOf('`');
      const plotOptionStr = backtickInRest !== -1
        ? afterTilde.substring(0, backtickInRest)
        : afterTilde;

      scanPlotOptions(plotOptionStr.split('~'));

      // Extract maxPoints after backtick if present
      if (backtickInRest !== -1) {
        const maxPointsNum = parseInt(afterTilde.substring(backtickInRest + 1).trim());
        if (!isNaN(maxPointsNum) && maxPointsNum > 0) maxPoints = maxPointsNum;
      }
    }

    console.log('[CHART_DISPLAY] Extracted title:', title, 'maxPoints:', maxPoints, 'timeFormat:', timeFormat);

    if (cmdArray.length === 1) {
      console.log('[CHART_DISPLAY] Only title, no fields - this is raw data');
      return null;
    }

    // Extract pipe-delimited elements
    const pipeElements = cmdArray.slice(1).filter(elem => typeof elem === 'string' && elem.startsWith('|'));
    console.log('[CHART_DISPLAY] Found', pipeElements.length, 'pipe-delimited elements');

    if (pipeElements.length === 0) {
      console.log('[CHART_DISPLAY] No pipe elements found, treating as raw data');
      return null;
    }

    // Parse each field label and extract plotNo, max, min, unit if present
    // Format: |fieldName[~max][~min][~unit][`plotNo] or variants
    const fieldCount = pipeElements.length;
    const fieldSpecs = []; // Array of {label, plotNo, max, min, unit, index}

    for (let i = 0; i < pipeElements.length; i++) {
      const elem = pipeElements[i];
      const content = elem.substring(1); // Remove leading |

      // Use helper function to parse field specification
      const spec = this.parseFieldSpec(content);

      console.log('[CHART_DISPLAY] parseFieldSpec result - Field', i, ': label="' + spec.label + '" plotNo=' + spec.plotNo + ' max=' + spec.max + ' min=' + spec.min + ' unit="' + spec.unit + '" from content="' + content + '"');

      // Skip blank fields (empty labels) - they are padding in the format
      if (spec.label.length === 0) {
        console.log('[CHART_DISPLAY] Skipping blank field at index', i);
        continue;
      }

      fieldSpecs.push({
        label: spec.label,
        plotNo: spec.plotNo,
        max: spec.max,
        min: spec.min,
        unit: spec.unit,
        index: i
      });
    }

    // Check if any field has a non-zero plotNo specified
    // If all plotNo's are null or 0, use legacy single-subplot mode
    const hasNonZeroPlotNo = fieldSpecs.some(spec => spec.plotNo !== null && spec.plotNo !== 0);
    console.log('[CHART_DISPLAY] hasNonZeroPlotNo:', hasNonZeroPlotNo);

    // DEFAULT MODE: No plot numbers specified — one subplot per Y-field
    // (first field is X-axis, each remaining field gets its own subplot)
    if (!hasNonZeroPlotNo) {
      console.log('[CHART_DISPLAY] No plotNo specified, assigning one subplot per Y-field');
      const allLabels = fieldSpecs.map(spec => spec.label);
      const nonBlankLabels = allLabels.filter(label => label.length > 0);

      if (nonBlankLabels.length === 0) {
        console.log('[CHART_DISPLAY] No non-blank labels, treating as raw data');
        return null;
      }

      const useCountFlag = nonBlankLabels.length === 1;

      // First non-blank field is the X-axis; each remaining field is its own subplot
      const nonBlankSpecs = fieldSpecs.filter(spec => spec.label.length > 0);
      const ySpecs = nonBlankSpecs.slice(1);

      return {
        title: title,
        maxPoints: maxPoints,
        timeFormat: timeFormat,
        clearData: clearData,
        sortData: sortData,
        allLabels: allLabels,
        nonBlankLabels: nonBlankLabels,
        fieldCount: fieldCount,
        hasPlotNo: false,
        useCountFlag: useCountFlag,
        xAxisFieldIndex: 0,
        xAxisFieldLabel: nonBlankSpecs[0].label,
        subplots: ySpecs.map((spec, i) => ({
          plotNo: i + 1,
          fieldSpecs: [spec],
          fieldLabels: [spec.label]
        }))
      };
    }

    // MULTI-SUBPLOT MODE: At least one non-zero plotNo is specified
    console.log('[CHART_DISPLAY] Multi-subplot mode detected');

    // Find X-axis field (first field with plotNo 0, or use data count if none)
    // Use spec.index (pipe position = CSV column index), not i (position in filtered array)
    let xAxisFieldIndex = -1;
    for (let i = 0; i < fieldSpecs.length; i++) {
      if (fieldSpecs[i].plotNo === 0) {
        xAxisFieldIndex = fieldSpecs[i].index;
        console.log('[CHART_DISPLAY] Found X-axis field at pipe index', xAxisFieldIndex, ':', fieldSpecs[i].label);
        break; // Use first plotNo 0 if multiple
      }
    }

    // If no plotNo 0, use data count as X-axis
    const useCountAsXAxis = (xAxisFieldIndex === -1);
    console.log('[CHART_DISPLAY] useCountAsXAxis:', useCountAsXAxis);

    // Organize fields into subplots by plotNo
    // Fields without plotNo or with plotNo 0 (non-first) get grouped together
    const subplotMap = {}; // {plotNo: [fieldSpec, ...]}
    const unassignedFields = []; // Fields without plotNo or repeated plotNo 0

    for (let i = 0; i < fieldSpecs.length; i++) {
      const spec = fieldSpecs[i];

      // Skip X-axis field — compare pipe position (spec.index) not fieldSpecs array index
      if (spec.index === xAxisFieldIndex) {
        console.log('[CHART_DISPLAY] Skipping X-axis field at pipe index', spec.index);
        continue;
      }

      if (spec.plotNo === null || spec.plotNo === 0) {
        // Unassigned or secondary zero - goes to unassigned group
        unassignedFields.push(spec);
      } else {
        // Assign to subplot by plotNo (already Math.abs'd during parsing)
        const plotNo = spec.plotNo;
        if (!subplotMap[plotNo]) {
          subplotMap[plotNo] = [];
        }
        subplotMap[plotNo].push(spec);
        console.log('[CHART_DISPLAY] Assigned field', spec.label, 'to subplot', plotNo);
      }
    }

    // Add unassigned fields as their own subplot if any exist
    if (unassignedFields.length > 0) {
      // Use -1 for unassigned group (displayed before numbered subplots)
      subplotMap[-1] = unassignedFields;
      console.log('[CHART_DISPLAY] Added', unassignedFields.length, 'unassigned fields to subplot -1');
    }

    // Create subplot array, sorted by plotNo for consistent ordering
    // Unassigned (-1) comes first, then numbered subplots in numeric order
    const subplots = [];
    const sortedPlotNos = Object.keys(subplotMap).map(Number).sort((a, b) => {
      if (a === -1) return -1; // Unassigned goes first
      if (b === -1) return 1;
      return a - b; // Numbered subplots in numeric order
    });

    for (const plotNo of sortedPlotNos) {
      const fields = subplotMap[plotNo];
      const displayPlotNo = plotNo === -1 ? '[unassigned]' : plotNo;

      subplots.push({
        plotNo: plotNo,
        fieldSpecs: fields,
        fieldLabels: fields.filter(spec => spec.label.length > 0).map(spec => spec.label)
      });

      console.log('[CHART_DISPLAY] Subplot', displayPlotNo, ':',
        fields.map(f => f.label).join(', '));
    }

    const xAxisSpec = fieldSpecs.find(spec => spec.index === xAxisFieldIndex);
    const xAxisFieldLabel = useCountAsXAxis ? "Count" : (xAxisSpec ? xAxisSpec.label : '');

    console.log('[CHART_DISPLAY] Parsed multi-subplot chart:',
      'title:', title,
      'X-axis:', xAxisFieldLabel,
      'subplots:', subplots.length,
      'fieldCount:', fieldCount);

    return {
      title: title,
      maxPoints: maxPoints,
      timeFormat: timeFormat,
      clearData: clearData, // ~C : caller should clear collectors before display
      sortData: sortData,   // ~S : caller should sort by X before display
      allLabels: fieldSpecs.map(spec => spec.label),
      fieldCount: fieldCount,
      hasPlotNo: true,
      useCountAsXAxis: useCountAsXAxis,
      xAxisFieldIndex: xAxisFieldIndex,
      xAxisFieldLabel: xAxisFieldLabel,
      fieldSpecs: fieldSpecs,
      subplots: subplots,
      useCountFlag: false // Not used in multi-subplot mode
    };
  }

  /**
   * Parse CSV data for multi-subplot mode
   * Creates separate datasets for each subplot based on plotNo assignments
   *
   * @param {array} csvLines - Array of CSV line strings
   * @param {object} chartInfo - Result from parseChartLabelsWithPlotNo
   * @param {number} limit - Maximum number of CSV lines to include
   * @returns {object} - {datasets: [dataset1, dataset2, ...], subplotInfo: [...]} or null
   */
  parseCSVToDatasetWithPlotNo(csvLines, chartInfo, limit = 500) {
    if (!csvLines) throw new Error('[CHART_DISPLAY] parseCSVToDatasetWithPlotNo: csvLines is required');
    if (!chartInfo) throw new Error('[CHART_DISPLAY] parseCSVToDatasetWithPlotNo: chartInfo is required');
    if (csvLines.length === 0) {
      return null;
    }

    console.log('[CHART_DISPLAY] parseCSVToDatasetWithPlotNo called with', csvLines.length, 'CSV lines');

    // Use maxPoints from chartInfo if available, otherwise use limit parameter
    const maxPoints = chartInfo.maxPoints !== undefined ? chartInfo.maxPoints : limit;
    console.log('[CHART_DISPLAY] Using maxPoints:', maxPoints);

    // Get X-axis data source
    const useCountAsXAxis = chartInfo.useCountAsXAxis;
    const xAxisFieldIndex = chartInfo.xAxisFieldIndex;

    // xIsDate: set when ANY row's X-field is an absolute date string (e.g.
    // "2019/04/02 17:23:01").  Lets createAndDisplayMultiSubplotChart
    // install a default date formatter even when the chart cmd omits a
    // ~timeFormat plot option — so devices streaming yyyy/MM/dd HH:mm:ss
    // values don't render as raw 1.55e12 millisecond ticks on the axis.
    let xIsDate = false;
    let parsedRows = [];

    if (chartInfo.sortData && !useCountAsXAxis) {
      // ~S: parse ALL collected lines, sort ascending by x-value (oldest→newest),
      // then keep only the last maxPoints — so the displayed window always
      // contains the most-recent maxPoints data points in chronological order.
      // This is correct even when the device sends data newest-first (e.g. a
      // history buffer dump) or interleaves multiple interval streams, where
      // "last N rows by buffer position" would select the wrong (oldest) window.
      for (const line of csvLines) {
        const fields = line.split(',').map(f => f.trim());
        if (fields.length < chartInfo.allLabels.length) continue;
        const xField = fields[xAxisFieldIndex];
        if (!xIsDate && TimeFormatUtil.isDateLikeString(xField)) xIsDate = true;
        const xValue = TimeFormatUtil.parseValue(xField, chartInfo.timeFormat);
        if (isNaN(xValue)) continue;
        parsedRows.push({ xValue, fields });
      }
      parsedRows.sort((a, b) => a.xValue - b.xValue);
      if (parsedRows.length > maxPoints) {
        parsedRows = parsedRows.slice(-maxPoints);
      }
      console.log('[CHART_DISPLAY] ~S sort: showing', parsedRows.length, 'most-recent of', csvLines.length, 'collected points');
      if (parsedRows.length > 0) {
        console.error('[FREEZE_DBG] displayed block X range (sorted): first ms=', parsedRows[0].xValue,
          'first raw=', parsedRows[0].fields[xAxisFieldIndex],
          '| last ms=', parsedRows[parsedRows.length - 1].xValue,
          'last raw=', parsedRows[parsedRows.length - 1].fields[xAxisFieldIndex]);
      }
    } else {
      // No sort: limit to last N rows by buffer arrival order, then parse.
      const limitedLines = this.getLimitedLines(csvLines, maxPoints);
      console.log('[CHART_DISPLAY] Using', limitedLines.length, 'of', csvLines.length, 'CSV lines (maxPoints:', maxPoints, ')');

      // Line number offset used for count-as-x-axis mode so the first
      // displayed line gets the correct 1-based sequence number. Must be the
      // actual window-start index getLimitedLines used (this.lastLimitedLinesStart),
      // not csvLines.length - limitedLines.length — that formula only matches
      // the true start when the window is at the live/latest position; once
      // frozen and shifted away from there, it would stay stuck reporting the
      // latest-window's label range regardless of where the window actually is.
      const lineNumberOffset = this.lastLimitedLinesStart;
      console.error('[FREEZE_DBG] Line number offset:', lineNumberOffset,
        '-> count labels', lineNumberOffset + 1, 'to', lineNumberOffset + limitedLines.length);

      // Show the displayed row-number range next to the freeze prev/next
      // arrows, updated on every redraw — lets the user see exactly which
      // rows are on screen as they navigate, independent of axis labelling.
      const freezeRowMinEl = document.getElementById('freeze-row-min');
      const freezeRowMaxEl = document.getElementById('freeze-row-max');
      const rowMinText = limitedLines.length > 0 ? String(lineNumberOffset + 1) : '';
      const rowMaxText = limitedLines.length > 0 ? String(lineNumberOffset + limitedLines.length) : '';
      if (freezeRowMinEl) freezeRowMinEl.textContent = rowMinText;
      if (freezeRowMaxEl) freezeRowMaxEl.textContent = rowMaxText;

      if (limitedLines.length > 0 && !useCountAsXAxis) {
        const firstField = limitedLines[0].split(',').map(f => f.trim())[xAxisFieldIndex];
        const lastField = limitedLines[limitedLines.length - 1].split(',').map(f => f.trim())[xAxisFieldIndex];
        console.error('[FREEZE_DBG] displayed block X range (no sort, buffer order): first raw=', firstField,
          'parsed ms=', TimeFormatUtil.parseValue(firstField, chartInfo.timeFormat),
          '| last raw=', lastField,
          'parsed ms=', TimeFormatUtil.parseValue(lastField, chartInfo.timeFormat));
      }

      for (let i = 0; i < limitedLines.length; i++) {
        const line = limitedLines[i];
        const fields = line.split(',').map(f => f.trim());
        if (fields.length < chartInfo.allLabels.length) {
          console.warn('[CHART_DISPLAY] Line has fewer fields than expected, skipping:', line);
          continue;
        }
        let xValue;
        if (useCountAsXAxis) {
          xValue = lineNumberOffset + (i + 1); // 1-indexed line number in csv file
        } else {
          const xField = fields[xAxisFieldIndex];
          if (!xIsDate && TimeFormatUtil.isDateLikeString(xField)) {
            xIsDate = true;
          }
          xValue = TimeFormatUtil.parseValue(xField, chartInfo.timeFormat);
          if (isNaN(xValue)) {
            console.warn('[CHART_DISPLAY] Invalid X value:', xField);
            continue;
          }
        }
        parsedRows.push({ xValue, fields });
      }
    }

    // Create a dataset for each subplot
    const datasets = [];
    const subplotInfo = [];

    for (const subplot of chartInfo.subplots) {
      console.log('[CHART_DISPLAY] Creating dataset for subplot', subplot.plotNo);

      const dataset = new jsfc.StandardXYDataset();
      const fieldSpecs = subplot.fieldSpecs;

      // Filter to non-blank fields for this subplot
      const nonBlankSpecs = fieldSpecs.filter(spec => spec.label.length > 0);
      console.log('[CHART_DISPLAY] Subplot', subplot.plotNo, 'has', nonBlankSpecs.length, 'non-blank fields');

      if (nonBlankSpecs.length === 0) {
        console.log('[CHART_DISPLAY] Subplot has no non-blank fields, skipping');
        continue;
      }

      // Add Y values for each row (already sorted if ~S was set)
      for (const row of parsedRows) {
        for (const spec of nonBlankSpecs) {
          const yValue = parseFloat(row.fields[spec.index]);
          if (!isNaN(yValue)) {
            dataset.add(spec.label, row.xValue, yValue);
          }
        }
      }

      console.log('[CHART_DISPLAY] Subplot', subplot.plotNo, 'dataset created with series:', dataset.seriesCount());

      datasets.push(dataset);
      subplotInfo.push({
        plotNo: subplot.plotNo,
        dataset: dataset,
        fieldLabels: nonBlankSpecs.map(spec => spec.label),
        yAxisLabel: nonBlankSpecs.map(spec => spec.label).join(', ')
      });
    }

    console.log('[CHART_DISPLAY] Created', datasets.length, 'datasets for', chartInfo.subplots.length, 'subplots');

    return {
      datasets: datasets,
      subplotInfo: subplotInfo,
      xAxisLabel: chartInfo.xAxisFieldLabel,
      useCountAsXAxis: useCountAsXAxis,
      xIsDate: xIsDate
    };
  }

  /**
   * Calculate minimum value from a dataset series
   * Used to determine axis ranges for charting
   * @param {object} dataset - jsfc.StandardXYDataset
   * @param {number} seriesIndex - Series index to analyze
   * @returns {number} - Minimum x-value or undefined if no data
   */
  calculateMinValue(dataset, seriesIndex) {
    if (!dataset) throw new Error('[CHART_DISPLAY] calculateMinValue: dataset is required');
    if (dataset.itemCount(seriesIndex) === 0) {
      return undefined;
    }
    let min = Number.MAX_VALUE;
    for (let i = 0; i < dataset.itemCount(seriesIndex); i++) {
      const val = dataset.x(seriesIndex, i);
      if (val !== null && !isNaN(val)) {
        min = Math.min(min, val);
      }
    }
    return min === Number.MAX_VALUE ? undefined : min;
  }

  /**
   * Calculate maximum value from a dataset series
   * Used to determine axis ranges for charting
   * @param {object} dataset - jsfc.StandardXYDataset
   * @param {number} seriesIndex - Series index to analyze
   * @returns {number} - Maximum x-value or undefined if no data
   */
  calculateMaxValue(dataset, seriesIndex) {
    if (!dataset) throw new Error('[CHART_DISPLAY] calculateMaxValue: dataset is required');
    if (dataset.itemCount(seriesIndex) === 0) {
      return undefined;
    }
    let max = Number.MIN_VALUE;
    for (let i = 0; i < dataset.itemCount(seriesIndex); i++) {
      const val = dataset.x(seriesIndex, i);
      if (val !== null && !isNaN(val)) {
        max = Math.max(max, val);
      }
    }
    return max === Number.MIN_VALUE ? undefined : max;
  }

  /**
   * Load CSV data from collector for specified field count
   * @param {number} fieldCount - Number of fields to match
   * @returns {array} - Array of CSV line strings (each line terminated by newline in original)
   */
  loadCSVData(fieldCount) {
    if (!window.csvCollector) {
      throw new Error('[CHART_DISPLAY] loadCSVData: csvCollector not available');
    }
    if (!window.csvCollector.getFieldCounts().includes(fieldCount)) {
      return [];
    }
    const csvLines = window.csvCollector.getCSVLines(fieldCount);
    console.log('[CHART_DISPLAY] Loaded', csvLines.length, 'CSV lines for field count', fieldCount);
    return csvLines;
  }

  /**
   * Get limited subset of CSV lines (last N lines)
   * Keeps only the most recent N lines (last N newline-terminated records)
   * @param {array} csvLines - Full array of CSV lines
   * @param {number} limit - Maximum number of lines to return
   * @returns {array} - Limited array (last N lines)
   */
  getLimitedLines(csvLines, limit) {
    if (this.frozenStartRow !== null) {
      // Frozen: show `limit` lines starting from the frozen row
      const start = Math.min(this.frozenStartRow, Math.max(0, csvLines.length - limit));
      console.error('[FREEZE_DBG] getLimitedLines: csvLines.length=', csvLines.length,
        'limit=', limit, 'frozenStartRow=', this.frozenStartRow, '-> start=', start,
        'slice=[', start, ',', start + limit, ')');
      // Expose the actual window-start index (0-based) so callers building
      // 1-based row/count labels (e.g. useCountAsXAxis) reflect where the
      // frozen window really is, not just "as if live at the latest window".
      this.lastLimitedLinesStart = start;
      return csvLines.slice(start, start + limit);
    }
    if (csvLines.length <= limit) {
      this.lastLimitedLinesStart = 0;
      return csvLines;
    }
    const startIdx = csvLines.length - limit;
    this.lastLimitedLinesStart = startIdx;
    return csvLines.slice(startIdx);
  }

  /**
   * Freeze the chart at the current display start row.
   * @param {array} allLines - All CSV lines currently collected.
   * @param {number} maxPoints - Current display window size.
   */
  freezeChart(allLines, maxPoints) {
    this.frozenStartRow = Math.max(0, allLines.length - maxPoints);
    console.error('[FREEZE_DBG] freezeChart: allLines.length=', allLines.length,
      'maxPoints=', maxPoints, '-> frozenStartRow=', this.frozenStartRow);
  }

  /**
   * Unfreeze the chart and resume live updates.
   */
  unfreezeChart() {
    console.error('[FREEZE_DBG] unfreezeChart: was frozenStartRow=', this.frozenStartRow);
    this.frozenStartRow = null;
    this.lastDataLineCount = 0; // Force immediate redraw from current data
  }

  /**
   * Shift the frozen start row by half the display window.
   * @param {array} allLines - All CSV lines currently collected.
   * @param {number} maxPoints - Current display window size.
   * @param {number} direction - -1 to move back, +1 to move forward.
   */
  shiftFrozenRow(allLines, maxPoints, direction) {
    const shift = Math.max(1, Math.floor(maxPoints * 0.4));
    const maxStart = Math.max(0, allLines.length - maxPoints);
    const before = this.frozenStartRow;
    this.frozenStartRow = Math.max(0, Math.min(this.frozenStartRow + direction * shift, maxStart));
    console.error('[FREEZE_DBG] shiftFrozenRow: allLines.length=', allLines.length,
      'maxPoints=', maxPoints, 'direction=', direction, 'shift=', shift, 'maxStart=', maxStart,
      'frozenStartRow', before, '->', this.frozenStartRow);
  }


  /**
   * Parse CSV data and create StandardXYDataset
   * First field becomes X-axis data, remaining fields become Y-axis series
   * Only uses last N CSV lines based on limit
   * @param {array} csvLines - Array of CSV line strings
   * @param {array} labels - Field labels [xFieldName, yField1Name, yField2Name, ...]
   * @param {number} limit - Maximum number of CSV lines to include
   * @returns {object} - jsfc.StandardXYDataset with data
   */
  parseCSVToDataset(csvLines, labels, limit = 500) {
    if (!csvLines) throw new Error('[CHART_DISPLAY] parseCSVToDataset: csvLines is required');
    if (csvLines.length === 0) {
      return null;
    }

    // Limit to last N CSV lines (newline-terminated records)
    const limitedLines = this.getLimitedLines(csvLines, limit);
    console.log('[CHART_DISPLAY] Using', limitedLines.length, 'of', csvLines.length, 'CSV lines (limit:', limit, ')');

    const dataset = new jsfc.StandardXYDataset();
    const xFieldName = labels[0];
    const yFieldNames = labels.slice(1);

    console.log('[CHART_DISPLAY] Creating dataset with X-axis:', xFieldName, 'Y-series:', yFieldNames);

    // Parse each CSV line
    for (const line of limitedLines) {
      const fields = line.split(',').map(f => f.trim());

      if (fields.length < labels.length) {
        console.warn('[CHART_DISPLAY] Line has fewer fields than labels, skipping:', line);
        continue;
      }

      // First field is X value
      const xValue = parseFloat(fields[0]);
      if (isNaN(xValue)) {
        console.warn('[CHART_DISPLAY] Invalid X value:', fields[0]);
        continue;
      }

      // Remaining fields are Y values for each series
      for (let i = 0; i < yFieldNames.length; i++) {
        const yValue = parseFloat(fields[i + 1]);
        if (!isNaN(yValue)) {
          dataset.add(yFieldNames[i], xValue, yValue);
        }
      }
    }

    console.log('[CHART_DISPLAY] Dataset created with', limitedLines.length, 'data points');
    console.log('[CHART_DISPLAY] Dataset series count:', dataset.seriesCount());
    for (let s = 0; s < dataset.seriesCount(); s++) {
      console.log('[CHART_DISPLAY] Series', s, ':', dataset.seriesKey(s));
    }
    return dataset;
  }

  /**
   * Create and display chart with multiple subplots based on plotNo assignments
   * Creates CombinedDomainXYPlot with separate subplots for each plotNo group
   * Handles both cases: with data (parseResult provided) and without data (parseResult null)
   *
   * @param {string} title - Chart title
   * @param {object} chartInfo - Result from parseChartLabelsWithPlotNo
   * @param {object} parseResult - Result from parseCSVToDatasetWithPlotNo, or null for empty chart
   * @param {HTMLCanvasElement} canvas - Target canvas element
   * @returns {object} - Chart instance
   */
  createAndDisplayMultiSubplotChart(title, chartInfo, parseResult, canvas) {
    if (!canvas) throw new Error('[CHART_DISPLAY] createAndDisplayMultiSubplotChart: canvas element not provided');
    if (!chartInfo) throw new Error('[CHART_DISPLAY] createAndDisplayMultiSubplotChart: chartInfo not provided');

    const hasData = parseResult !== null;
    console.log('[CHART_DISPLAY] Creating multi-subplot chart:', title, '(hasData:', hasData, ')');

    try {
      // Store canvas reference
      this.currentCanvas = canvas;
      this.resizeCanvasToFitSpace(canvas);

      // Defensive: ensure no stale pixels carry over from a previous chart
      // session.  jsfreechart's chart.draw() does not issue a clearRect.
      const ctx2d = canvas.getContext('2d');
      ctx2d.clearRect(0, 0, canvas.width, canvas.height);

      const ctx = new jsfc.CanvasContext2D(canvas);
      const canvasWidth = canvas.width;
      const canvasHeight = canvas.height;

      console.log('[CHART_DISPLAY] Canvas dimensions:', canvasWidth, 'x', canvasHeight);

      // Create shared X-axis (use chartInfo for structure, parseResult only for data)
      const xAxisLabel = chartInfo.xAxisFieldLabel;
      console.log('[CHART_DISPLAY] Creating shared X axis with label:', xAxisLabel);
      const xAxis = new jsfc.LinearAxis(xAxisLabel);
      xAxis.setAutoRange(true);

      // Set up time formatter for X-axis.
      //
      // 1. If the chart cmd specified ~timeFormat, use it.
      // 2. Otherwise, if parseCSVToDatasetWithPlotNo detected that the
      //    X-axis column contains absolute date strings (e.g.
      //    "2019/04/02 17:23:01"), default to "yyyy/MM/dd HH:mm:ss" so
      //    the axis renders as readable dates instead of raw 1.55e12 ms
      //    ticks.  Otherwise leave the axis on JSFreeChart's NumberFormat.
      let effectiveTimeFormat = chartInfo.timeFormat;
      if (!effectiveTimeFormat && parseResult && parseResult.xIsDate) {
        effectiveTimeFormat = 'yyyy/MM/dd HH:mm:ss';
        console.log('[CHART_DISPLAY] No timeFormat in chart cmd but X-axis values are date strings — defaulting to:',
                    effectiveTimeFormat);
        // Persist the auto-default back onto chartInfo so the Chart Config
        // dropdown shows the format actually being displayed.  The cmd
        // emitter (Apply button) re-uses chartInfo.timeFormat, so an
        // unedited Apply round-trips the same default into the new chart
        // cmd — making the implicit default explicit in the next request.
        chartInfo.timeFormat = effectiveTimeFormat;
      }
      if (effectiveTimeFormat) {
        // Pull the per-fieldCount time anchor off the CSV collector and
        // derive baseTimeMs = firstLineTimeMs - firstLineMs.  Adding any
        // line's ms to baseTimeMs then gives that line's wall-clock time,
        // with the first parseable CSV line of this fieldCount mapping
        // exactly to its arrival instant.  Only applied when firstLineMs
        // is itself relative (< 2^40 ms); for absolute timestamps the
        // values render as-is so we leave baseTimeMs null.
        const anchor = (window.csvCollector && window.csvCollector.firstAnchors)
                     ? window.csvCollector.firstAnchors[chartInfo.fieldCount]
                     : null;
        const THRESHOLD = Math.pow(2, 40);
        let baseTimeMs = null;
        if (anchor && Math.abs(anchor.firstLineMs) < THRESHOLD) {
          baseTimeMs = anchor.firstLineTimeMs - anchor.firstLineMs;
        }
        console.log('[CHART_DISPLAY] Setting X-axis time format:', effectiveTimeFormat,
                    'fieldCount:', chartInfo.fieldCount,
                    'anchor:', anchor,
                    'baseTimeMs:', baseTimeMs);
        const timeFormatUtil = new TimeFormatUtil(effectiveTimeFormat, baseTimeMs);
        this.currentTimeFormatter = timeFormatUtil;

        // Create formatter that implements jsfc.Format interface
        const formatter = new TimeFormatter(timeFormatUtil);
        xAxis.setTickLabelFormatOverride(formatter);
      }

      // Create CombinedDomainXYPlot with shared x-axis
      console.log('[CHART_DISPLAY] Creating CombinedDomainXYPlot for multi-subplot mode');
      const combinedPlot = new jsfc.CombinedDomainXYPlot(xAxis);
      combinedPlot.setGap(10); // 10 pixel gap between subplots

      // Base palette indexed by CSV field index (spec.index) so colors stay fixed
      // as fields move between subplots.  Black is reserved for the X-axis label in Chart Config.
      const palette = [
        new jsfc.Color(0, 0, 255),      // Blue
        new jsfc.Color(255, 0, 0),      // Red
        new jsfc.Color(0, 128, 0),      // Green
        new jsfc.Color(255, 128, 0),    // Orange
        new jsfc.Color(128, 0, 128),    // Purple
        new jsfc.Color(0, 128, 128),    // Teal
        new jsfc.Color(255, 105, 180),  // Hot Pink
        new jsfc.Color(165, 42, 42),    // Brown
        new jsfc.Color(255, 127, 80),   // Coral
        new jsfc.Color(255, 255, 0)     // Yellow
      ];
      // Build orderedColors in global-series order but keyed by spec.index
      const orderedColors = [];
      for (const subplot of chartInfo.subplots) {
        for (const spec of subplot.fieldSpecs) {
          orderedColors.push(palette[spec.index % palette.length]);
        }
      }

      // Create special renderer for CombinedDomainXYPlot
      const renderer = new jsfc.CombinedDomainXYItemRenderer();
      const colorSource = new jsfc.ColorSource(orderedColors);
      renderer.setLineColorSource(colorSource);
      combinedPlot.setRenderer(renderer);

      console.log('[CHART_DISPLAY] Creating', chartInfo.subplots.length, 'subplots (hasData:', hasData, ')');

      // Create a subplot for each subplot defined in chartInfo
      // Use chartInfo for structure, parseResult only for datasets
      for (let i = 0; i < chartInfo.subplots.length; i++) {
        const subplotInfo = chartInfo.subplots[i];

        // Get dataset: from parseResult if available, otherwise empty
        let dataset;
        if (hasData && parseResult.subplotInfo && i < parseResult.subplotInfo.length) {
          // Use dataset from parseResult (same index order)
          dataset = parseResult.subplotInfo[i].dataset;
        } else {
          // Create empty dataset for this subplot
          dataset = new jsfc.StandardXYDataset();
        }

        console.log('[CHART_DISPLAY] Creating subplot', i, 'with', dataset.seriesCount(), 'data series (plotNo:', subplotInfo.plotNo, ')');

        // Create XYPlot for this subplot
        const subplot = new jsfc.XYPlot(dataset);

        // Extract unit and range constraints from field specs
        // Use first field's unit (if multiple fields share a subplot)
        let yAxisLabel = subplotInfo.fieldLabels.join(', ') || 'Y';
        let minRange = null;
        let maxRange = null;
        let unit = null;

        if (subplotInfo.fieldSpecs && subplotInfo.fieldSpecs.length > 0) {
          // Get unit from first field that has one
          for (const fieldSpec of subplotInfo.fieldSpecs) {
            if (fieldSpec.unit) {
              unit = fieldSpec.unit;
              break;
            }
          }

          // Get min/max constraints from fields
          // When multiple fields share a subplot, combine constraints to show all fields
          for (const fieldSpec of subplotInfo.fieldSpecs) {
            console.log('[CHART_DISPLAY] Subplot', i, 'processing field "' + fieldSpec.label + '" with max=' + fieldSpec.max + ' min=' + fieldSpec.min);
            if (fieldSpec.max !== null && fieldSpec.max !== undefined) {
              if (maxRange === null) {
                maxRange = fieldSpec.max;
                console.log('[CHART_DISPLAY] Subplot', i, 'set maxRange=' + maxRange);
              } else {
                // Use the larger max value to accommodate all fields
                maxRange = Math.max(maxRange, fieldSpec.max);
                console.log('[CHART_DISPLAY] Subplot', i, 'updated maxRange to ' + maxRange);
              }
            }
            if (fieldSpec.min !== null && fieldSpec.min !== undefined) {
              if (minRange === null) {
                minRange = fieldSpec.min;
                console.log('[CHART_DISPLAY] Subplot', i, 'set minRange=' + minRange);
              } else {
                // Use the smaller min value to accommodate all fields
                minRange = Math.min(minRange, fieldSpec.min);
                console.log('[CHART_DISPLAY] Subplot', i, 'updated minRange to ' + minRange);
              }
            }
          }
        }

        // Add unit to y-axis label if present
        if (unit) {
          yAxisLabel = yAxisLabel + ' (' + unit + ')';
        }

        console.log('[CHART_DISPLAY] Subplot', i, 'Y-axis label:', yAxisLabel, 'min:', minRange, 'max:', maxRange);
        const yAxis = new jsfc.LinearAxis(yAxisLabel);

        // Y-axis constraint mode:
        //   applyHardConstraints true  → fixed at spec min/max (set by APPLY
        //                                in Chart Config); data outside the
        //                                spec range is clipped off-axis.
        //   applyHardConstraints false → soft constraints; spec min/max acts
        //                                as a minimum visible range but the
        //                                axis auto-expands to include data.
        //
        // Freeze alone does NOT enable hard constraints — see chart docstring
        // Hard mode: Y-axis is fixed at the Max/Min values set in Chart Config.
        // Controlled solely by the per-field autoScale checkbox — unchecking it
        // enables hard constraints; checking it keeps the axis soft. Freeze/unfreeze
        // has no effect on this setting.
        const subplotAllAutoScale = !subplotInfo.fieldSpecs ||
          subplotInfo.fieldSpecs.every(fs => fs.autoScale !== false);
        const hardMode = !subplotAllAutoScale;
        let hardMax = null;
        let hardMin = null;
        if (hardMode && subplotInfo.fieldSpecs) {
          for (const fieldSpec of subplotInfo.fieldSpecs) {
            if (fieldSpec.max !== null && fieldSpec.max !== undefined) {
              hardMax = hardMax === null ? fieldSpec.max : Math.max(hardMax, fieldSpec.max);
            }
            if (fieldSpec.min !== null && fieldSpec.min !== undefined) {
              hardMin = hardMin === null ? fieldSpec.min : Math.min(hardMin, fieldSpec.min);
            }
          }
          // Ensure hardMin < hardMax; swap if user entered them the wrong way around
          if (hardMin !== null && hardMax !== null && hardMin > hardMax) {
            const tmp = hardMin; hardMin = hardMax; hardMax = tmp;
          }

          // When only one bound is specified, fill the other from the actual
          // data range so the single hard limit is reliably honored.
          if (hardMax !== null && hardMin === null) {
            const dataRange = subplot.getRenderer().calcYRange(subplot.getDataset());
            if (dataRange) hardMin = dataRange.lowerBound();
          } else if (hardMin !== null && hardMax === null) {
            const dataRange = subplot.getRenderer().calcYRange(subplot.getDataset());
            if (dataRange) hardMax = dataRange.upperBound();
          }
        }
        yAxis.setAutoRange(true);
        subplot.setYAxis(yAxis);
        subplot._yAxisConstraintHard = hardMode;
        subplot.setYAxisConstraints(
          hardMode ? hardMin : minRange,
          hardMode ? hardMax : maxRange,
          false
        );

        // Set axis offsets
        subplot.setAxisOffsets(new jsfc.Insets(4, 4, 4, 4));

        // Add subplot to combined plot
        combinedPlot.add(subplot);
        console.log('[CHART_DISPLAY] Subplot', i, 'added to CombinedDomainXYPlot');
      }

      // Create chart
      console.log('[CHART_DISPLAY] Creating Chart instance with CombinedDomainXYPlot');
      const chart = new jsfc.Chart(combinedPlot);
      chart.setTitle(title);

      // Store chart reference
      this.currentChart = chart;
      this.currentChartInfo = chartInfo;
      console.log('[CHART_DISPLAY] Chart stored in this.currentChart');

      // Set chart size and draw
      console.log('[CHART_DISPLAY] Setting chart size and drawing');
      chart.setSize(canvasWidth-10, canvasHeight);

      const bounds = new jsfc.Rectangle(0, 0, canvasWidth, canvasHeight);
      chart.draw(ctx, bounds);

      console.log('[CHART_DISPLAY] Multi-subplot chart rendered successfully');
      return chart;

    } catch (error) {
      console.error('[CHART_DISPLAY] Error creating multi-subplot chart:', error);
      console.error('[CHART_DISPLAY] Error stack:', error.stack);
      throw error;
    }
  }

  /**
   * Update multi-subplot chart with new CSV data
   * Updates all subplots with new data and rescales shared X-axis
   * Uses this.currentChart, this.currentChartInfo and this.currentCanvas for rendering
   *
   * @param {array} allCSVLines - All CSV lines (including new ones)
   */
  updateMultiSubplotChart(allCSVLines) {
    // Safety check
    if (document.body.className !== 'chart-mode') {
      return;
    }

    const chart = this.currentChart;
    const chartInfo = this.currentChartInfo;

    // Check if we have new data
    if (allCSVLines.length <= this.lastDataLineCount) {
      return; // No new data
    }

    console.log('[CHART_DISPLAY] Updating multi-subplot chart with new data. Previous:', this.lastDataLineCount, 'Current:', allCSVLines.length);
    console.log('[CHART_DISPLAY] Current chart isDummy:', chartInfo.isDummy, 'fieldCount:', chartInfo.fieldCount);

    const maxPoints = chartInfo.maxPoints;

    // Check if this is a dummy chart and data has different field count
    if (chartInfo.isDummy) {
      // Get actual field counts from csvCollector (data files)
      const fieldCounts = window.csvCollector ? window.csvCollector.getFieldCounts() : [];
      if (!fieldCounts || fieldCounts.length === 0) {
        console.log('[CHART_DISPLAY] Dummy chart: no field counts available from csvCollector');
        return;
      }

      const maxFieldCount = Math.max(...fieldCounts.map(f => parseInt(f)));

      console.log('[CHART_DISPLAY] Dummy chart detected. Chart fieldCount:', chartInfo.fieldCount, 'csvCollector fieldCounts:', fieldCounts, 'maxFieldCount:', maxFieldCount);

      if (maxFieldCount !== chartInfo.fieldCount) {
        // Field count mismatch - recreate chart with actual data structure
        console.log('[CHART_DISPLAY] Field count mismatch! Recreating chart with fieldCount:', maxFieldCount);

        // Create new chartInfo matching actual data
        const useCountFlag = maxFieldCount === 1;
        const allLabels = Array.from({length: maxFieldCount}, (_, i) => `field${i + 1}`);
        const xAxisFieldLabel = useCountFlag ? 'Count' : allLabels[0];

        let yFieldLabels;
        let fieldSpecs;
        if (useCountFlag) {
          yFieldLabels = allLabels;
          fieldSpecs = allLabels.map((label, idx) => ({
            label: label,
            plotNo: null,
            index: idx
          }));
        } else {
          yFieldLabels = allLabels.slice(1);
          fieldSpecs = allLabels.slice(1).map((label, idx) => ({
            label: label,
            plotNo: null,
            index: idx + 1
          }));
        }

        const newChartInfo = {
          title: chartInfo.title,
          maxPoints: limit,
          allLabels: allLabels,
          nonBlankLabels: allLabels,
          fieldCount: maxFieldCount,
          hasPlotNo: false,
          useCountFlag: useCountFlag,
          useCountAsXAxis: useCountFlag,
          xAxisFieldIndex: useCountFlag ? -1 : 0,
          xAxisFieldLabel: xAxisFieldLabel,
          isDummy: false, // Now it's real data
          subplots: [{
            plotNo: 1,
            fieldSpecs: fieldSpecs,
            fieldLabels: yFieldLabels
          }]
        };

        // Reparse with new chartInfo
        const parseResult = this.parseCSVToDatasetWithPlotNo(allCSVLines, newChartInfo, maxPoints);
        if (parseResult) {
          // Recreate chart with new structure
          const newChart = this.createAndDisplayMultiSubplotChart(chartInfo.title, newChartInfo, parseResult, this.currentCanvas);
          if (newChart) {
            this.currentChart = newChart;
            this.currentChartInfo = newChartInfo;
            this.lastDataLineCount = allCSVLines.length;
            console.log('[CHART_DISPLAY] Dummy chart replaced with real chart structure');
            return;
          }
        }
        console.warn('[CHART_DISPLAY] Failed to recreate chart with new field count');
        return;
      }
    }

    // Normal update: parse CSV data with current chartInfo
    const parseResult = this.parseCSVToDatasetWithPlotNo(allCSVLines, chartInfo, maxPoints);
    if (!parseResult) {
      console.warn('[CHART_DISPLAY] parseCSVToDatasetWithPlotNo returned null');
      return;
    }

    // Get the plot - always a CombinedDomainXYPlot with our unified architecture
    const combinedPlot = chart.getPlot();
    const subplots = combinedPlot.getSubplots();
    if (!subplots || subplots.length === 0) {
      console.warn('[CHART_DISPLAY] No subplots found');
      return;
    }

    // Update each subplot with new data
    for (let i = 0; i < Math.min(subplots.length, parseResult.subplotInfo.length); i++) {
      const subplot = subplots[i];
      const subplotInfo = parseResult.subplotInfo[i];

      console.log('[CHART_DISPLAY] Updating subplot', i, 'with new dataset');
      subplot.setDataset(subplotInfo.dataset);
    }

    // Update shared X-axis range based on new data
    // Get X-axis data bounds from first subplot's first series
    if (subplots.length > 0 && parseResult.subplotInfo.length > 0) {
      const firstSubplot = subplots[0];
      const firstDataset = firstSubplot.getDataset();

      if (firstDataset && firstDataset.seriesCount() > 0) {
        const xMin = this.calculateMinValue(firstDataset, 0);
        const xMax = this.calculateMaxValue(firstDataset, 0);

        if (xMin !== undefined && xMax !== undefined) {
          console.log('[CHART_DISPLAY] X-axis data range: min=', xMin, 'max=', xMax);

          const xAxis = combinedPlot.getXAxis();
          if (xAxis) {
            // Ensure upper > lower (add small padding if equal)
            let boundsMin = xMin;
            let boundsMax = xMax;
            if (boundsMin === boundsMax) {
              const padding = Math.abs(boundsMin) * 0.1 || 1;
              boundsMin -= padding;
              boundsMax += padding;
            }
            xAxis.setBounds(boundsMin, boundsMax);
            console.log('[CHART_DISPLAY] Updated X-axis bounds: min=', boundsMin, 'max=', boundsMax);
          }
        }
      }
    }

    // Redraw chart.  Clear the pixel buffer first so polling-tick redraws
    // don't accumulate stale plot ink over time.
    this.currentCanvas.getContext('2d').clearRect(0, 0, this.currentCanvas.width, this.currentCanvas.height);
    const ctx = new jsfc.CanvasContext2D(this.currentCanvas);
    chart.setSize(this.currentCanvas.width-10, this.currentCanvas.height);
    const bounds = new jsfc.Rectangle(0, 0, this.currentCanvas.width, this.currentCanvas.height);
    chart.draw(ctx, bounds);

    // Crosshair geometry changed with the redraw — refresh if mouse is over the chart.
    if (this.lastClientX !== null) this._updateCrosshairFromStored();

    this.lastDataLineCount = allCSVLines.length;
    const limitedLines = this.getLimitedLines(allCSVLines, maxPoints);
    console.log('[CHART_DISPLAY] Multi-subplot chart updated - showing', limitedLines.length, 'of', allCSVLines.length, 'CSV lines (maxPoints:', maxPoints, ')');
  }

  /**
   * Start polling for multi-subplot chart updates.
   * Reads the chart to update from this.currentChartInfo on every tick.
   * @param {number} interval - Polling interval in milliseconds (default 500)
   */
  startMultiSubplotUpdatePolling(interval = 500) {
    if (this.multiSubplotUpdateInterval) {
      clearInterval(this.multiSubplotUpdateInterval);
    }

    console.log('[CHART_DISPLAY] Starting multi-subplot update polling with interval:', interval, 'ms, isDummy:', this.currentChartInfo.isDummy);

    this.multiSubplotUpdateInterval = setInterval(() => {
      // Check if still in chart mode
      if (document.body.className !== 'chart-mode') {
        return;
      }

      if (!window.csvCollector) {
        return;
      }

      const chartInfo = this.currentChartInfo;
      let allLines;

      // For dummy charts, check ALL field counts from csvCollector, not just the dummy's fieldCount
      // This allows dummy charts to detect and adopt data with different field counts
      if (chartInfo.isDummy) {
        // Get all available field counts
        const fieldCounts = window.csvCollector.getFieldCounts();
        if (fieldCounts && fieldCounts.length > 0) {
          // Get max field count and load its data
          const maxFieldCount = Math.max(...fieldCounts.map(f => parseInt(f)));
          allLines = window.csvCollector.getCSVLines(maxFieldCount);
        } else {
          allLines = [];
        }
      } else {
        // For non-dummy charts, load data for the specific fieldCount
        allLines = window.csvCollector.getFieldCounts().includes(chartInfo.fieldCount)
          ? window.csvCollector.getCSVLines(chartInfo.fieldCount) : [];
      }

      // Update "Display Points of N" label with current total line count —
      // do this even while frozen, since CSV data keeps accumulating in the
      // background while frozen; only the chart redraw below is skipped.
      const lbl = document.getElementById('ccv-maxpoints-label');
      if (lbl) lbl.textContent = 'Display Points of ' + allLines.length;

      // Frozen: CSV is still stored but chart display does not update
      if (this.frozenStartRow !== null) {
        return;
      }

      this.updateMultiSubplotChart(allLines);
    }, interval);
  }

  /**
   * Stop multi-subplot update polling
   */
  stopUpdatePolling() {
    if (this.multiSubplotUpdateInterval) {
      clearInterval(this.multiSubplotUpdateInterval);
      this.multiSubplotUpdateInterval = null;
      console.log('[CHART_DISPLAY] Stopped multi-subplot update polling');
    }
  }


  /**
   * Resize canvas to fill available space (accounting for layout and divider)
   * @param {HTMLCanvasElement} canvas - Canvas element to resize
   * @returns {boolean} - True if canvas was resized, false otherwise
   */
  resizeCanvasToFitSpace(canvas) {
    if (!canvas) {
      console.log('[CHART_DISPLAY] resizeCanvasToFitSpace: canvas is null/undefined');
      return false;
    }

    // Get the canvas wrapper's actual visible dimensions
    const wrapper = canvas.parentElement; // canvas-wrapper
    if (!wrapper) {
      console.log('[CHART_DISPLAY] resizeCanvasToFitSpace: parent wrapper not found');
      return false;
    }

    // Use getBoundingClientRect to get actual available dimensions
    const rect = wrapper.getBoundingClientRect();
    console.log('[CHART_DISPLAY] resizeCanvasToFitSpace: wrapper rect =', {
      width: rect.width,
      height: rect.height,
      left: rect.left,
      top: rect.top
    });

    // Calculate new dimensions (accounting for small margin)
    const newWidth = Math.max(Math.floor(rect.width - 2), 200);
    const newHeight = Math.max(Math.floor(rect.height - 2), 200);

    console.log('[CHART_DISPLAY] resizeCanvasToFitSpace: calculated dimensions =', {
      newWidth,
      newHeight,
      lastWidth: this.lastCanvasWidth,
      lastHeight: this.lastCanvasHeight
    });

    // Check if dimensions actually changed
    if (this.lastCanvasWidth === newWidth && this.lastCanvasHeight === newHeight) {
      console.log('[CHART_DISPLAY] resizeCanvasToFitSpace: dimensions unchanged, skipping');
      return false; // No resize needed
    }

    // Update canvas pixel dimensions
    canvas.width = newWidth;
    canvas.height = newHeight;

    // Track new dimensions
    this.lastCanvasWidth = newWidth;
    this.lastCanvasHeight = newHeight;

    console.log('[CHART_DISPLAY] Canvas resized to:', newWidth, 'x', newHeight);
    return true; // Canvas was resized
  }

  /**
   * Handle window resize event for chart display
   * Resizes canvas and redraws chart if dimensions changed
   * Calls chart.setSize() to inform chart of new dimensions (like LineChartDemo)
   * @param {HTMLCanvasElement} canvas - Canvas element
   */
  handleResize(canvas) {
    console.log('[CHART_DISPLAY] handleResize() called, canvas exists:', !!canvas, 'chart exists:', !!this.currentChart);

    if (!canvas || !this.currentChart) {
      console.log('[CHART_DISPLAY] handleResize: early return - canvas or chart missing');
      return;
    }

    // Attempt to resize canvas to fit available space
    const wasResized = this.resizeCanvasToFitSpace(canvas);
    console.log('[CHART_DISPLAY] handleResize: canvas was resized:', wasResized);

    if (wasResized) {
      // Canvas dimensions changed, tell chart about new size and redraw
      console.log('[CHART_DISPLAY] Redrawing chart after resize, new size:', canvas.width, 'x', canvas.height);
      try {
        // CRITICAL: Call chart.setSize() to recalculate chart internal layout
        // This tells JSFreeChart to recalculate axes, legend, plot area, etc.
        // without this, the chart won't visually resize even though canvas dimensions change
        this.currentChart.setSize(canvas.width-10, canvas.height);
        console.log('[CHART_DISPLAY] Called chart.setSize(' + (canvas.width-10) + ', ' + (canvas.height) + ')');

        // Clear the pixel buffer first — canvas resize already does this for
        // dimension changes, but be explicit so any future change that calls
        // handleResize without a dimension change still gets a clean draw.
        canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height);
        const ctx = new jsfc.CanvasContext2D(canvas);
        const bounds = new jsfc.Rectangle(0, 0, canvas.width-0, canvas.height-0);
        this.currentChart.draw(ctx, bounds);
        // Resize and reposition the crosshair overlay to match the new canvas dimensions.
        if (this.crosshairOverlay) {
          this._repositionOverlay(canvas);
          this._updateCrosshairFromStored();
        }
        console.log('[CHART_DISPLAY] Chart redrawn successfully after resize');
      } catch (error) {
        console.error('[CHART_DISPLAY] Error redrawing chart after resize:', error);
        throw error;
      }
    }
  }


  /**
   * Clear current chart state
   * Stops polling and resets all chart-related state
   */
  clear() {
    this.detachCrosshairOverlay();
    this.stopUpdatePolling();
    this.currentChart = null;
    this.currentDataset = null;
    this.currentLabels = null;
    this.currentCanvas = null;
    this.lastDataLineCount = 0;
    this.frozenStartRow = null;
    this.lastCanvasWidth = 0;
    this.lastCanvasHeight = 0;
    console.log('[CHART_DISPLAY] Cleared chart state');
  }

  /**
   * Attach a transparent overlay canvas for the crosshair line and value tooltip.
   * The overlay sits on top of the chart canvas and captures all mouse events.
   * @param {HTMLCanvasElement} chartCanvas - The main chart canvas element.
   */
  attachCrosshairOverlay(chartCanvas) {
    this.detachCrosshairOverlay();

    const wrapper = chartCanvas.parentElement;
    if (!wrapper) return;

    // Ensure wrapper is a positioning context so position:absolute on the overlay works.
    if (window.getComputedStyle(wrapper).position === 'static') {
      wrapper.style.position = 'relative';
    }

    // Overlay canvas: same pixel dimensions, stacked on top of the chart canvas.
    // The ID lets pfodCommon.css's "body.chart-mode canvas { background-color:white }"
    // be overridden with an explicit transparent background.
    const overlay = document.createElement('canvas');
    overlay.id     = 'chart-crosshair-overlay';
    overlay.width  = chartCanvas.width;
    overlay.height = chartCanvas.height;
    overlay.style.cssText = 'position:absolute;top:0;left:0;cursor:crosshair;background:transparent;';
    wrapper.appendChild(overlay);
    this.crosshairOverlay = overlay;

    // Tooltip div: fixed-position so it stays near the cursor regardless of scroll.
    const tooltip = document.createElement('div');
    tooltip.id = 'chart-crosshair-tooltip';
    tooltip.style.cssText = [
      'position:fixed',
      'display:none',
      'background:rgba(255,255,255,0.95)',
      'border:1px solid #888',
      'border-radius:4px',
      'padding:6px 10px',
      'font-family:Arial,sans-serif',
      'font-size:12px',
      'pointer-events:none',
      'z-index:9999',
      'box-shadow:0 2px 6px rgba(0,0,0,0.25)',
      'max-width:320px',
      'white-space:nowrap'
    ].join(';');
    document.body.appendChild(tooltip);
    this.crosshairTooltip = tooltip;

    this._mouseMoveHandler = (e) => {
      const rect   = overlay.getBoundingClientRect();
      // Scale CSS-pixel offset to canvas buffer coordinates.
      // When the side panel is open the CSS width differs from canvas.width.
      const scaleX = overlay.width  / rect.width;
      const scaleY = overlay.height / rect.height;
      this.lastMouseX  = (e.clientX - rect.left) * scaleX;
      this.lastMouseY  = (e.clientY - rect.top)  * scaleY;
      this.lastClientX = e.clientX;
      this.lastClientY = e.clientY;
      this._updateCrosshair(this.lastMouseX, this.lastMouseY, e.clientX, e.clientY);
    };
    this._mouseLeaveHandler = () => this._clearCrosshair();

    overlay.addEventListener('mousemove',  this._mouseMoveHandler);
    overlay.addEventListener('mouseleave', this._mouseLeaveHandler);
    console.log('[CHART_DISPLAY] Crosshair overlay attached');
  }

  /**
   * Remove the overlay canvas and tooltip, and detach all mouse listeners.
   */
  detachCrosshairOverlay() {
    if (this.crosshairOverlay) {
      if (this._mouseMoveHandler)  this.crosshairOverlay.removeEventListener('mousemove',  this._mouseMoveHandler);
      if (this._mouseLeaveHandler) this.crosshairOverlay.removeEventListener('mouseleave', this._mouseLeaveHandler);
      this.crosshairOverlay.remove();
      this.crosshairOverlay = null;
    }
    if (this.crosshairTooltip) {
      this.crosshairTooltip.remove();
      this.crosshairTooltip = null;
    }
    this._mouseMoveHandler  = null;
    this._mouseLeaveHandler = null;
    this.lastMouseX  = null;
    this.lastMouseY  = null;
    this.lastClientX = null;
    this.lastClientY = null;
  }

  /**
   * Resize and reposition the overlay canvas to match the chart canvas after a resize.
   * @param {HTMLCanvasElement} chartCanvas
   */
  _repositionOverlay(chartCanvas) {
    if (!this.crosshairOverlay) return;
    const wrapper = chartCanvas.parentElement;
    if (!wrapper) return;
    const canvasRect  = chartCanvas.getBoundingClientRect();
    const wrapperRect = wrapper.getBoundingClientRect();
    this.crosshairOverlay.style.top  = (canvasRect.top  - wrapperRect.top)  + 'px';
    this.crosshairOverlay.style.left = (canvasRect.left - wrapperRect.left) + 'px';
    this.crosshairOverlay.width  = chartCanvas.width;
    this.crosshairOverlay.height = chartCanvas.height;
  }

  /**
   * Re-run the crosshair update using the stored mouse position.
   * Called after chart.draw() completes so jsfreechart's geometry is fresh.
   */
  _updateCrosshairFromStored() {
    if (this.lastClientX === null || !this.crosshairOverlay) return;
    // Recompute canvas-buffer coordinates from viewport position every time so
    // the scale is correct even if the side panel opened since the last mousemove.
    const rect   = this.crosshairOverlay.getBoundingClientRect();
    const scaleX = this.crosshairOverlay.width  / rect.width;
    const scaleY = this.crosshairOverlay.height / rect.height;
    const pixelX = (this.lastClientX - rect.left) * scaleX;
    const pixelY = (this.lastClientY - rect.top)  * scaleY;
    this._updateCrosshair(pixelX, pixelY, this.lastClientX, this.lastClientY);
  }

  /**
   * Clear the crosshair line from the overlay canvas and hide the tooltip.
   */
  _clearCrosshair() {
    if (this.crosshairOverlay) {
      this.crosshairOverlay.getContext('2d')
        .clearRect(0, 0, this.crosshairOverlay.width, this.crosshairOverlay.height);
    }
    if (this.crosshairTooltip) this.crosshairTooltip.style.display = 'none';
    this.lastMouseX  = null;
    this.lastMouseY  = null;
    this.lastClientX = null;
    this.lastClientY = null;
  }

  /**
   * Format a numeric Y value for the crosshair tooltip.
   * Uses more decimal places for smaller magnitudes.
   * @param {number} val
   * @returns {string}
   */
  _formatCrosshairY(val) {
    if (val === null || val === undefined) return '—';
    if (!Number.isFinite(val)) return String(val);
    const abs = Math.abs(val);
    if (abs === 0)    return '0';
    if (abs >= 1000)  return val.toFixed(1);
    if (abs >= 100)   return val.toFixed(2);
    if (abs >= 1)     return val.toFixed(3);
    return val.toFixed(4);
  }

  /**
   * Draw the vertical crosshair line and populate the floating tooltip for the
   * given pixel position within the overlay canvas.
   *
   * @param {number} pixelX  - X pixel coordinate within the overlay canvas.
   * @param {number} pixelY  - Y pixel coordinate within the overlay canvas (unused but stored).
   * @param {number} clientX - Viewport-relative mouse X for tooltip placement.
   * @param {number} clientY - Viewport-relative mouse Y for tooltip placement.
   */
  _updateCrosshair(pixelX, pixelY, clientX, clientY) {
    if (!this.crosshairOverlay || !this.currentChart) return;

    const combinedPlot = this.currentChart.getPlot();
    const subplotAreas = combinedPlot._subplotAreas;
    if (!subplotAreas || subplotAreas.length === 0) return;

    // All subplots share the same X pixel range — read it from the first subplot area.
    const firstArea = subplotAreas[0];
    const xPixMin   = firstArea.x();
    const xPixMax   = firstArea.x() + firstArea.width();

    // If the cursor is outside the data area, clear and bail.
    if (pixelX < xPixMin || pixelX > xPixMax) {
      this._clearCrosshair();
      return;
    }

    const xAxis      = combinedPlot.getXAxis();
    const xDataValue = xAxis.coordinateToValue(pixelX, xPixMin, xPixMax);

    // --- Draw crosshair line spanning all subplot data areas ---
    const overlayCtx = this.crosshairOverlay.getContext('2d');
    overlayCtx.clearRect(0, 0, this.crosshairOverlay.width, this.crosshairOverlay.height);

    const topY    = subplotAreas[0].y();
    const lastA   = subplotAreas[subplotAreas.length - 1];
    const bottomY = lastA.y() + lastA.height();
    const lineX   = Math.round(pixelX) + 0.5;

    overlayCtx.save();
    overlayCtx.setLineDash([5, 4]);
    overlayCtx.strokeStyle = 'rgba(80,80,80,0.65)';
    overlayCtx.lineWidth   = 1;
    overlayCtx.beginPath();
    overlayCtx.moveTo(lineX, topY);
    overlayCtx.lineTo(lineX, bottomY);
    overlayCtx.stroke();
    overlayCtx.restore();

    // --- Build tooltip ---
    // CSS hex colors in the same order as chartDisplay's jsfc.Color palette.
    const PALETTE_CSS = [
      '#0000ff', '#ff0000', '#008000', '#ff8000', '#800080',
      '#008080', '#ff69b4', '#a52a2a', '#ff7f50', '#ffff00'
    ];

    const chartInfo = this.currentChartInfo;
    if (!chartInfo) return;

    // xLabel is set from the actual X of the first nearest data point found (snapped, not interpolated).
    let xLabel = '';
    let rows = '';
    const subplots = combinedPlot.getSubplots();

    for (let si = 0; si < subplots.length; si++) {
      const dataset = subplots[si].getDataset();
      if (!dataset) continue;

      const subplotSpec = chartInfo.subplots ? chartInfo.subplots[si] : null;

      for (let s = 0; s < dataset.seriesCount(); s++) {
        const itemCount = dataset.itemCount(s);
        if (itemCount === 0) continue;

        // Find the item with X closest to the cursor's data value.
        let nearestIdx  = 0;
        let nearestDist = Math.abs(dataset.x(s, 0) - xDataValue);
        for (let k = 1; k < itemCount; k++) {
          const d = Math.abs(dataset.x(s, k) - xDataValue);
          if (d < nearestDist) { nearestDist = d; nearestIdx = k; }
        }

        // Use the actual X of the first series found so the header snaps to a real sample.
        if (xLabel === '') {
          const snapX = dataset.x(s, nearestIdx);
          if (chartInfo.useCountAsXAxis) {
            xLabel = 'Count: ' + Math.round(snapX);
          } else if (this.currentTimeFormatter) {
            xLabel = this.currentTimeFormatter.format(snapX);
          } else {
            xLabel = String(parseFloat(snapX.toPrecision(6)));
          }
        }

        const yVal  = dataset.y(s, nearestIdx);
        const label = dataset.seriesKey(s);
        const fSpec = subplotSpec && subplotSpec.fieldSpecs ? subplotSpec.fieldSpecs[s] : null;
        const unit  = fSpec ? (fSpec.unit || '') : '';
        const cidx  = fSpec ? fSpec.index : s;
        const color = PALETTE_CSS[cidx % PALETTE_CSS.length];
        const yStr  = this._formatCrosshairY(yVal) + (unit ? ' ' + unit : '');

        rows +=
          '<div style="display:flex;align-items:center;margin-top:2px;">' +
          '<span style="display:inline-block;width:8px;height:8px;border-radius:50%;' +
            'background:' + color + ';margin-right:5px;flex-shrink:0;"></span>' +
          '<span style="color:' + color + ';flex:1;">' + label + ':</span>' +
          '<span style="margin-left:8px;font-weight:bold;">' + yStr + '</span>' +
          '</div>';
      }
    }

    const tooltip = this.crosshairTooltip;
    tooltip.innerHTML =
      '<div style="font-weight:bold;margin-bottom:4px;padding-bottom:3px;border-bottom:1px solid #ccc;">' +
        xLabel +
      '</div>' + rows;
    tooltip.style.display = 'block';

    // Position tooltip adjacent to the crosshair line.
    // Default: RIGHT edge of tooltip GAP px left of cursor — use CSS `right`
    // so the actual rendered width doesn't matter.
    // Flip to LEFT of cursor (use CSS `left`) only when too close to left edge.
    const GAP  = 8;
    const vpW  = window.innerWidth;
    const vpH  = window.innerHeight;
    let tipTop = Math.max(GAP, Math.min(clientY - 30, vpH - 180));
    tooltip.style.top = tipTop + 'px';
    if (clientX - GAP < 220) {
      // Near left edge — place tooltip to the right of the line.
      tooltip.style.left  = (clientX + GAP) + 'px';
      tooltip.style.right = '';
    } else {
      // Default — anchor right edge GAP px left of the line.
      tooltip.style.left  = '';
      tooltip.style.right = (vpW - clientX + GAP) + 'px';
    }
  }
}

// Single, always-available holder for the currently displayed chart's parsed
// info. A plain property on the real window global (not on any lazily
// constructed instance like chartDisplay/drawingViewer/csvCollector), so
// this accessor and DrawingViewer's matching one in chartAndRawData.js never
// need an existence guard, and the two classes' `currentChartInfo` can no
// longer drift apart the way they used to.
window.currentChartInfo = null;
Object.defineProperty(ChartDisplay.prototype, 'currentChartInfo', {
  get() { return window.currentChartInfo; },
  set(value) { window.currentChartInfo = value; }
});

// Same single-holder treatment for the rendered jsfc.Chart object — it had
// the identical drift problem (chartDisplay's copy updating on redraw while
// drawingViewer's separate copy went stale, worked around with `||` fallback
// reads in toolbarAndMenu.js).
window.currentChart = null;
Object.defineProperty(ChartDisplay.prototype, 'currentChart', {
  get() { return window.currentChart; },
  set(value) { window.currentChart = value; }
});

// Make class available globally for browser use
window.ChartDisplay = ChartDisplay;
