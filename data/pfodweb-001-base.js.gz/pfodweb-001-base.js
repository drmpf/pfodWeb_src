/*
   connectionManager.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// ConnectionManager — manages HTTP/Serial/BLE connections to pfod devices.
// Also defines pfodAlert(), the shared styled modal used throughout the app.
//
// Exports:    window.ConnectionManager class, window.pfodAlert(message, onClose) function
// Depends on: window.messageCollector, window.csvCollector, window.rawDataCollector
//             (set via ConnectionManager.setMessageCollector/setCSVCollector/setRawDataCollector)
// Called by:  pfodWeb.js constructor (new ConnectionManager(config) → this.connectionManager),
//             requestQueue.js (this.connectionManager.send(), getMaxRetries()),
//             keepAlive.js (reads connectionManager.protocol),
//             connectionSetup.js (builds config, calls adapter methods),
//             keepAliveAndHttp.js (ConnectionManager.setMessageCollector etc. static calls)

/**
 * Resolve after at least ms milliseconds. Used to enforce a minimum gap
 * between retry attempts (see each adapter's send() retry loop) so a
 * struggling device/link isn't hammered with back-to-back requests
 * regardless of which error triggered the retry.
 * @param {number} ms
 * @returns {Promise<void>}
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Custom alert modal with pfodWeb branding
 * Shows a styled modal dialog positioned lower on the page
 * @param {string} message - The message to display
 * @param {function} onClose - Optional callback when Close button is clicked
 */
function pfodAlert(message, onClose = null) {
  // Create modal overlay
  const overlay = document.createElement('div');
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: flex-start;
    justify-content: center;
    padding-top: 150px;
    z-index: 10000;
  `;

  // Create modal box
  const modal = document.createElement('div');
  modal.style.cssText = `
    background-color: white;
    border-radius: 10px;
    box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
    max-width: 500px;
    width: 90%;
    overflow: hidden;
  `;

  // Create title bar
  const titleBar = document.createElement('div');
  titleBar.style.cssText = `
    background-color: #4CAF50;
    color: white;
    padding: 15px 20px;
    font-size: 18px;
    font-weight: bold;
    font-family: Arial, sans-serif;
  `;
  titleBar.textContent = 'pfodWeb';

  // Create message area
  const messageArea = document.createElement('div');
  messageArea.style.cssText = `
    padding: 20px;
    font-family: Arial, sans-serif;
    font-size: 14px;
    line-height: 1.6;
    color: #333;
    white-space: pre-line;
  `;
  messageArea.textContent = message;

  // Assemble modal
  modal.appendChild(titleBar);
  modal.appendChild(messageArea);

  // Add Close button if callback provided
  if (onClose) {
    const buttonArea = document.createElement('div');
    buttonArea.style.cssText = `
      padding: 0 20px 20px 20px;
      text-align: center;
    `;

    const closeButton = document.createElement('button');
    closeButton.textContent = 'Close';
    closeButton.style.cssText = `
      background-color: #4CAF50;
      color: white;
      padding: 10px 30px;
      border: none;
      border-radius: 5px;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      font-family: Arial, sans-serif;
    `;
    const closeAction = () => {
      document.body.removeChild(overlay);
      onClose();
    };
    closeButton.onclick = closeAction;

    // Add Enter key handler for the overlay
    overlay.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        closeAction();
      }
    });

    buttonArea.appendChild(closeButton);
    modal.appendChild(buttonArea);

    // Focus the close button so Enter key works immediately
    setTimeout(() => closeButton.focus(), 100);
  }

  overlay.appendChild(modal);

  // Add to page
  document.body.appendChild(overlay);
}

/**
 * Optional pairing password read once from this page's own load URL
 * (e.g. file:///.../pfodWeb.html?pw=secret) and reused for every
 * request to pfodProxy for the rest of this page's lifetime. Read via
 * window.PFOD_PROXY_PW (guarded so it's safe regardless of whether
 * this script or pfodCommon.html's inline script runs first) rather
 * than re-reading location.search later, since updateURLFromForm() in
 * pfodCommon.html rewrites the URL from a fresh URLSearchParams as the
 * user fills the connect form, which would otherwise silently drop
 * it. Empty string means the page was loaded without one -- pfodProxy
 * treats "no &pw=" as "no password configured", not as an empty
 * password.
 */
if (typeof window.PFOD_PROXY_PW === 'undefined') {
  window.PFOD_PROXY_PW = new URLSearchParams(window.location.search).get('pw') || '';
}

/**
 * Shared dedup mechanism - used by all connection protocols
 * Rotating character prepended to commands to detect duplicates
 * Each send() call atomically gets a unique dedup character
 * Retries reuse the same cached dedup for that send() call
 */
let dedupCounter = 0;
const dedupChars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

/**
 * Get next dedup character - increments atomically
 * Each call guarantees a unique character for that send() call
 * Retries must cache and reuse the returned character
 * @returns {string} - The next dedup character
 */
function getCurrentDedupChar() {
  const char = dedupChars[dedupCounter];
  dedupCounter = (dedupCounter + 1) % dedupChars.length;
  return char;
}

/**
 * Find the index of the closing brace that matches the opening brace at startIdx
 * Handles nested braces by counting depth
 * @param {string} text - The text to search
 * @param {number} startIdx - Index of opening brace
 * @returns {number} Index of matching closing brace, or -1 if not found
 */
function findMatchingClosingBrace(text, startIdx) {
  if (startIdx < 0 || startIdx >= text.length || text[startIdx] !== '{') {
    return -1;
  }

  let depth = 0;
  for (let i = startIdx; i < text.length; i++) {
    if (text[i] === '{') {
      depth++;
    } else if (text[i] === '}') {
      depth--;
      if (depth === 0) {
        return i;
      }
    }
  }
  return -1; // No matching closing brace found
}

/**
 * ConnectionManager - Unified connection abstraction for multiple protocols
 *
 * Provides a protocol-agnostic interface for communicating with pfod devices.
 * Currently supports: HTTP, Serial, BLE
 */
class ConnectionManager {
  // Static message collector shared across all connection managers
  static messageCollector = null;
  // Static CSV collector shared across all connection managers
  static csvCollector = null;
  // Static raw data collector shared across all connection managers
  static rawDataCollector = null;

  static setMessageCollector(collector) {
    ConnectionManager.messageCollector = collector;
    console.log('[CONNECTION_MANAGER] Message collector set');
  }

  static setCSVCollector(collector) {
    ConnectionManager.csvCollector = collector;
    console.log('[CONNECTION_MANAGER] CSV collector set');
  }

  static setRawDataCollector(collector) {
    ConnectionManager.rawDataCollector = collector;
    console.log('[CONNECTION_MANAGER] Raw data collector set');
  }

  constructor(config = {}) {
    this.protocol = config.protocol || 'http';
    this.adapter = null;
    this.config = config;

    // Response timeout configuration
    // Default is 10 seconds; 0 means never timeout (no timer set).
    const timeoutSeconds = config.responseTimeoutSec !== undefined ? config.responseTimeoutSec : 10;

    // Validate and constrain timeout: 0-30 seconds
    const validatedTimeout = Math.max(0, Math.min(30, timeoutSeconds));

    // 0 = never timeout (responseTimeoutMs === 0); otherwise convert to ms.
    this.responseTimeoutMs = validatedTimeout * 1000;
    console.log(`[CONNECTION_MANAGER] Response timeout set to ${validatedTimeout === 0 ? 'never' : validatedTimeout + ' seconds'}`);

    // KeepAlive interval (TCP/IP Socket only).  Connection-prompt
    // dropdown offers 0/5/10/20/30 — 0 means disabled.  60 s is the
    // hard upper bound (no use-case beyond it; clamp guards against
    // bogus URL params).  Other transports ignore this field.
    const keepAliveRaw = config.keepAliveSec !== undefined ? config.keepAliveSec : 0;
    this.keepAliveSec = Math.max(0, Math.min(60, parseInt(keepAliveRaw, 10) || 0));
    if (this.protocol === 'tcp') {
      console.log(`[CONNECTION_MANAGER] keepAliveSec=${this.keepAliveSec}`);
    }

    // Set up max retries based on protocol.  Applies to both native
    // adapters (HTTPConnection, SerialConnection, BLEConnection) and
    // their proxy peers (SerialProxyConnection via 'serial',
    // BLEProxyConnection via 'ble', TCPProxyConnection via 'tcp').
    //   BLE     = 1 (unreliable radio, fail fast)
    //   HTTP    = 2 (network, can be slow)
    //   Serial  = 2 (DTR-reset / bootloader window may eat first cmd)
    //   TCP     = 2 (network via proxy, same retry budget as HTTP)
    const retryConfig = {
      'ble':      1,
      'http':     2,
      'serial':   2,
      'tcp':      2,
      'designer': 0  // in-browser virtual device; nothing to retry
    };
    // Use explicit check for protocol key to handle 0 values correctly, default to 0
    this.maxRetries = (this.protocol in retryConfig) ? retryConfig[this.protocol] : 0;
    console.log(`[CONNECTION_MANAGER] Max retries set to ${this.maxRetries} for protocol: ${this.protocol}`);

    console.log(`[CONNECTION_MANAGER] Creating connection manager with protocol: ${this.protocol}`);

    // Initialize the appropriate protocol adapter
    this.initializeAdapter();
  }

  initializeAdapter() {
    switch(this.protocol) {
      case 'http':
        this.adapter = new HTTPConnection(this.config, this);
        console.log(`[CONNECTION_MANAGER] Initialized HTTP adapter with targetIP: ${this.config.targetIP}`);
        break;

      case 'serial':
        // Two transports for the same protocol, chosen in the connection
        // prompt (see pfodCommon.html's "Connect via" radios):
        //   useProxy === false → native Web Serial API, no pfodProxy needed.
        //     Only offered when the browser exposes navigator.serial, and
        //     the SerialPort object itself is pre-selected by the prompt's
        //     Select button (requestPort() needs a user gesture) and passed
        //     in as config.nativeSerialPort.
        //   anything else      → pfodProxy (the default).
        if (this.config.useProxy === false) {
          this.adapter = new SerialConnection(this.config, this);
          console.log(`[CONNECTION_MANAGER] Initialized native Web Serial adapter for ${this.config.serialPath || 'selected port'} @ ${this.config.baudRate} baud`);
        } else {
          this.adapter = new SerialProxyConnection(this.config, this);
          console.log(`[CONNECTION_MANAGER] Initialized SerialProxy adapter via ${this.config.proxyHostPort} for ${this.config.serialPath} @ ${this.config.baudRate} baud`);
        }
        break;

      case 'ble':
        // Same two-transport split as serial, above: useProxy === false
        // uses the native Web Bluetooth API with the BluetoothDevice
        // pre-selected by the prompt (config.nativeBleDevice); otherwise
        // pfodProxy.
        if (this.config.useProxy === false) {
          this.adapter = new BLEConnection(this.config, this);
          console.log(`[CONNECTION_MANAGER] Initialized native Web Bluetooth adapter for ${this.config.bleName || this.config.bleAddress}`);
        } else {
          this.adapter = new BLEProxyConnection(this.config, this);
          console.log(`[CONNECTION_MANAGER] Initialized BLEProxy adapter via ${this.config.proxyHostPort} for ${this.config.bleAddress}`);
        }
        break;

      case 'tcp':
        // TCP/IP Socket — always via pfodProxy (browsers can't open raw
        // TCP sockets).  Proxy holds the persistent socket; we speak HTTP
        // to it with a ?ip= query param identifying the device — the
        // port is fixed at 4989 in pfodProxy itself, never sent.
        this.adapter = new TCPProxyConnection(this.config, this);
        console.log(`[CONNECTION_MANAGER] Initialized TCPProxy adapter via ${this.config.proxyHostPort} for ${this.config.targetIP}`);
        break;

      case 'designer':
        // In-browser virtual pfod device.  No wire, no proxy — pfod
        // commands are routed through a DesignerVirtualDevice (see
        // designer/index.js) that emits the designer-app menus from a
        // chosen board model.  Default board is the Uno + Serial pair
        // baked into designer/boards/Uno/Uno.json.
        this.adapter = new DesignerVirtualAdapter(this.config, this);
        console.log('[CONNECTION_MANAGER] Initialized DesignerVirtualAdapter (in-browser virtual device)');
        break;

      default:
        throw new Error(`Unknown protocol: ${this.protocol}`);
    }
  }

  /**
   * Send a command to the device and get response
   * @param {string} cmd - The pfod command (e.g., "{.}" or "{dwgName}")
   * @returns {Promise<string>} - Response text (usually JSON)
   */
  async send(cmd, respCallbacks) {
    if (!this.adapter) {
      throw new Error('No adapter initialized');
    }

    console.log(`[CONNECTION_MANAGER] Sending command: ${cmd}`);

    // Option B: hand the active adapter the per-request callbacks the byte
    // boundary uses to decide raw-vs-valid-response and to apply ~C.  Bound
    // to THIS request by the queue; consumed/cleared in processReadBuffer
    // when the valid response is matched.  Overwritten every send so a
    // stale bundle can't outlive its request.
    this.adapter._respCallbacks = respCallbacks || null;

    // {!} is always fire-and-forget — send without waiting for a device response.
    // Caller (processRequestQueue exitAbort path) handles screen transition after this returns.
    if (cmd === '{!}') {
      await this.sendAbort();
      return '';
    }

    const response = await this.adapter.send(cmd);
    console.log(`[CONNECTION_MANAGER] Received response (${response.length} bytes)`);

    return response;
  }

  /**
   * Connect to the device (if needed for the protocol)
   */
  async connect() {
    if (this.adapter && this.adapter.connect) {
      console.log(`[CONNECTION_MANAGER] Connecting via ${this.protocol}...`);
      await this.adapter.connect();
      console.log(`[CONNECTION_MANAGER] Connected`);
    }
  }

  /**
   * Disconnect from the device (if needed for the protocol)
   */
  async disconnect() {
    if (this.adapter && this.adapter.disconnect) {
      console.log(`[CONNECTION_MANAGER] Disconnecting...`);
      await this.adapter.disconnect();
      console.log(`[CONNECTION_MANAGER] Disconnected`);
    }
  }

  /**
   * Get a stable identifier string for this connection endpoint.
   * Used as the localStorage key for menu caching (PfodMenuCache).
   *
   * @returns {string} Identifier of the form 'http_<ip>', 'serial_<port>', or 'ble_<name>'
   */
  getConnectionId() {
    switch (this.protocol) {
      case 'http': {
        const rawIP = this.config.targetIP || 'unknown';
        const colonIdx = rawIP.lastIndexOf(':');
        const httpHost = colonIdx > 0 ? rawIP.slice(0, colonIdx) : rawIP;
        const httpPort = colonIdx > 0 ? rawIP.slice(colonIdx + 1) : '80';
        return 'http_' + httpHost + '_' + httpPort;
      }
      case 'serial':
        // Use the cache-stable id (COMn when known, otherwise VID/PID hex)
        // so per-USB-device cache entries stay separate even when Chrome
        // doesn't expose the COM port number.
        return 'serial_' + (this.adapter
          ? (this.adapter.cachePortId || this.adapter.portName || 'unknown')
          : 'unknown');
      case 'ble':
        // BLEProxyConnection carries bleAddress set from config.bleAddress.
        return 'ble_' + (this.adapter ? (this.adapter.bleAddress || 'unknown') : 'unknown');
      case 'tcp':
        // Port is fixed at 4989 (never user-supplied), so IP alone
        // uniquely identifies the target.
        return 'tcp_' + this.config.targetIP;
      case 'designer':
        // In-browser virtual device — keyed by the active design name
        // so the per-design pfod-menu cache stays separate from the
        // designer-state localStorage (DesignerState owns that one).
        // adapter + device + state + name are all guaranteed by the
        // DesignerVirtualAdapter / DesignerVirtualDevice / DesignerState
        // constructors — no fallback path.
        return 'designer_' + this.adapter.device.state.name;
      default:
        return 'unknown';
    }
  }

  /**
   * Check if connection is active
   */
  isConnected() {
    if (this.adapter && this.adapter.isConnected) {
      return this.adapter.isConnected();
    }
    return true; // HTTP doesn't need explicit connection
  }

  /**
   * Get response timeout in milliseconds for waiting for device response
   * Returns the configured timeout value
   * @returns {number} - Timeout in milliseconds
   */
  getResponseTimeout() {
    return this.responseTimeoutMs;
  }

  /**
   * Get the configured keepAlive interval, in seconds, for TCP/IP
   * connections.  0 means keepAlive is disabled.  Other transports may
   * call this safely but are expected to ignore the value (only the
   * keepAlive scheduler in keepAlive.js consults it, and it is gated
   * on protocol === 'tcp' in startKeepAlivePolling()).
   * @returns {number} - keepAlive interval in seconds (0 = disabled)
   */
  getKeepAliveSec() {
    return this.keepAliveSec;
  }

  /**
   * Get max retries for the current connection protocol
   * @returns {number} - Max retries (BLE: 1, HTTP: 2, Serial: 3)
   */
  getMaxRetries() {
    return this.maxRetries;
  }

  /**
   * Force re-engage the serial connection (for serial protocol only)
   * Closes and reopens the port to reset stuck communication
   * Returns false for non-serial protocols or if reconnect fails
   * @returns {Promise<boolean>} - true if reconnect succeeded, false otherwise
   */
  async forceReengageSerial() {
    if (this.protocol !== 'serial' || !this.adapter || !this.adapter.forceReconnect) {
      console.log(`[CONNECTION_MANAGER] forceReengageSerial: not a serial connection (protocol=${this.protocol})`);
      return false;
    }

    console.log('[CONNECTION_MANAGER] Force re-engaging serial connection');
    try {
      const result = await this.adapter.forceReconnect();
      return result;
    } catch (error) {
      console.error('[CONNECTION_MANAGER] Force re-engage failed:', error);
      return false;
    }
  }

  /**
   * Fire {!} via the adapter's own dedicated sendAbort() — fire-and-forget,
   * no response wait, keepalive:true so it survives a page unload (Exit's
   * reload, or a tab close). NOT the adapter's generic send() — that path
   * waits for a response with a non-keepalive fetch, which Exit's reload
   * (already in flight on the same call stack) reliably cancels before the
   * device ever receives it. Every adapter defines this method:
   * HTTPConnection; SerialProxyConnection/BLEProxyConnection/
   * TCPProxyConnection via their ProxyStreamConnection base; and the
   * native SerialConnection/BLEConnection, which write the bytes straight
   * at the port/characteristic (best-effort — a native write has no
   * keepalive equivalent, so on a page unload it may not make it out).
   */
  async sendAbort() {
    if (!this.adapter) return;
    this.adapter.sendAbort().catch(() => {});
  }
}

/**
 * PfodConnectionBase - Shared pfod protocol parsing for HTTP, Serial and BLE
 *
 * Provides pfodToJson() and processReadBuffer() used identically by all three
 * connection types.  Each subclass sets this.protocol ('http'|'serial'|'ble')
 * so that messageCollector entries are labelled correctly.
 */
class PfodConnectionBase {
  /// Show a modal "Connecting to <device>..." overlay with a
  /// rotating spinner.  Used by both proxy adapters (driven by
  /// proxy-emitted `progress` SSE events) and the native BLE
  /// adapter (driven by JS `await` boundaries between gatt.connect /
  /// getPrimaryService / startNotifications).  Idempotent.
  /// @param {string|null} name    — device name (shown on first line after "Connecting to")
  /// @param {string}      address — device address/UUID (shown on second line when name present)
  _showConnectingDialog(name, address) {
    if (document.getElementById('proxy-connect-overlay')) return;
    const overlay = document.createElement('div');
    overlay.id = 'proxy-connect-overlay';
    overlay.style.cssText =
      'position:fixed; inset:0; background:rgba(0,0,0,0.4);' +
      ' z-index:10001; display:flex; align-items:center;' +
      ' justify-content:center; font-family:Arial,sans-serif;';
    const panel = document.createElement('div');
    panel.style.cssText =
      'background:white; border-radius:8px;' +
      ' box-shadow:0 8px 32px rgba(0,0,0,0.25);' +
      ' padding:24px 28px; min-width:280px; text-align:center;';
    if (!document.getElementById('proxy-connect-spinner-style')) {
      const style = document.createElement('style');
      style.id = 'proxy-connect-spinner-style';
      style.textContent =
        '@keyframes proxyConnectSpin { to { transform: rotate(360deg); } }';
      document.head.appendChild(style);
    }
    const spinner = document.createElement('div');
    spinner.style.cssText =
      'width:36px; height:36px; margin:0 auto 14px;' +
      ' border:4px solid #e0e0e0; border-top-color:#4078ff;' +
      ' border-radius:50%;' +
      ' animation: proxyConnectSpin 0.9s linear infinite;';
    panel.appendChild(spinner);
    const title = document.createElement('div');
    title.style.cssText = 'font-size:14px; font-weight:600; margin-bottom:6px;';
    title.textContent = 'Connecting to ' + (name || address || 'device') + '…';
    if (name && address) {
      const addrLine = document.createElement('div');
      addrLine.style.cssText = 'font-size:11px; color:#888; font-weight:normal; margin-top:2px;';
      addrLine.textContent = address;
      title.appendChild(addrLine);
    }
    panel.appendChild(title);
    const status = document.createElement('div');
    status.id = 'proxy-connect-status';
    status.style.cssText = 'font-size:12px; color:#666;';
    // Neutral until the proxy actually confirms it's scanning (a real
    // "scanning" progress event) — showing "Scanning for device…" here
    // unconditionally was misleading when pfodProxy isn't even running.
    status.textContent = 'Connecting to proxy…';
    panel.appendChild(status);
    const cancelBtn = document.createElement('button');
    cancelBtn.textContent = 'Cancel';
    cancelBtn.style.cssText =
      'margin-top:14px; padding:6px 20px; font-size:12px; cursor:pointer;' +
      ' border:1px solid #ccc; border-radius:4px; background:#f5f5f5;';
    cancelBtn.onclick = () => { if (this._cancelConnect) this._cancelConnect(); };
    panel.appendChild(cancelBtn);
    overlay.appendChild(panel);
    document.body.appendChild(overlay);
  }

  _updateConnectingDialogName(name, address) {
    const title = document.querySelector('#proxy-connect-overlay div div');
    if (!title) return;
    title.childNodes[0].textContent = 'Connecting to ' + name + '…';
    let addrLine = title.querySelector('.proxy-connect-addr');
    if (!addrLine) {
      addrLine = document.createElement('div');
      addrLine.className = 'proxy-connect-addr';
      addrLine.style.cssText = 'font-size:11px; color:#888; font-weight:normal; margin-top:2px;';
      title.appendChild(addrLine);
    }
    addrLine.textContent = address;
  }

  _updateConnectingDialog(step) {
    const status = document.getElementById('proxy-connect-status');
    if (!status) return;
    const labels = {
      scanning:    'Scanning for device…',
      connecting:  'Connecting (BLE link setup)…',
      discovering: 'Discovering services…',
      subscribing: 'Subscribing to notifications…',
    };
    status.textContent = labels[step] || step;
  }

  _hideConnectingDialog() {
    this._cancelConnect = null;
    const overlay = document.getElementById('proxy-connect-overlay');
    if (overlay && overlay.parentNode) {
      overlay.parentNode.removeChild(overlay);
    }
  }

  /**
   * Convert a pfod command string into the {"cmd":[...]} JSON format expected
   * by pfodWeb.js.
   * e.g. "{,~`0~V2|+A~z}" -> '{"cmd":["{,~`0~V2","|+A~z","}"]}'
   *
   * @param {string} pfodString - complete pfod command from { to }
   * @returns {string} JSON string
   */
  pfodToJson(pfodString) {
    const cmdArray = [];
    let currentElement = '';

    for (let i = 0; i < pfodString.length; i++) {
      const char = pfodString[i];
      if (char === '|' || char === '}') {
        if (currentElement.length > 0) {
          cmdArray.push(currentElement);
        }
        currentElement = char;
        if (char === '}') {
          cmdArray.push(currentElement);
          currentElement = '';
        }
      } else {
        currentElement += char;
      }
    }
    if (currentElement.length > 0) {
      cmdArray.push(currentElement);
    }
    return JSON.stringify({ cmd: cmdArray });
  }

  /**
   * Scan this.readBuffer for a complete pfod {..} command.
   * Text before { is logged to messageCollector.
   * When a complete command is found, pfodToJson() is called and
   * this.responseResolve() is called with the JSON string.
   * The buffer is trimmed to whatever follows the closing }.
   */
  // Feed an OUTSIDE (raw / CSV) text segment, in stream order, to the data
  // collectors and (optionally) the Raw Message viewer.  Collectors are NO
  // LONGER pre-fed the whole chunk by processIncoming — they only ever see
  // true OUTSIDE bytes, exactly between the {..} commands, so a {=..~C..}
  // clear (applied at the command boundary) drops only data that arrived
  // BEFORE it.
  _emitRaw(str, opts) {
    if (!str) return;
    const o = opts || {};
    const toCsv    = o.csv    !== false;
    const toRaw    = o.raw    !== false;
    const toViewer = o.viewer !== false;
    if (toCsv && ConnectionManager.csvCollector)     ConnectionManager.csvCollector.processCharacters(str);
    if (toRaw && ConnectionManager.rawDataCollector) ConnectionManager.rawDataCollector.processCharacters(str);
    if (toViewer && ConnectionManager.messageCollector) {
      ConnectionManager.messageCollector.addMessage('received', str, this.protocol);
    }
  }

  processReadBuffer() {
    if (this.readBuffer.length === 0) return;

    // Treat the readBuffer as a UTF-8 byte stream — pfod is byte-oriented
    // and the 1024-byte cmd cap from the spec counts wire bytes, not JS
    // string chars (`°` is 1 char / 2 bytes).  Decoder uses fatal:false so
    // a partial UTF-8 sequence at any cut becomes U+FFFD instead of
    // throwing.
    //
    // Single in-order state machine: OUTSIDE (raw → collectors) until a
    // '{' → INSIDE (command bytes) until '}' or the 1024 cap → OUTSIDE.
    // The command is processed COMPLETELY before the loop returns to the
    // stream for the bytes that follow it, so a {=..~C..} clear lands
    // between the old and the new data.  Each completed command, when it is
    // a *valid response to the pending request* (the byte boundary owns
    // that decision via the injected _respCallbacks), applies ~C
    // synchronously then resolves; otherwise it is treated as raw data and
    // the pending request is left waiting (times out / retries as before).
    const PFOD_MAX_BYTES = 1024;
    const enc = new TextEncoder();
    const dec = new TextDecoder('utf-8', { fatal: false });

    while (this.readBuffer.length > 0) {
      const bytes = enc.encode(this.readBuffer);

      // ── OUTSIDE: bytes before the next '{' are raw data → emit in order.
      let startIdx = 0;
      while (startIdx < bytes.length && bytes[startIdx] !== 0x7B /* '{' */) {
        startIdx++;
      }
      if (startIdx > 0) {
        this._emitRaw(dec.decode(bytes.subarray(0, startIdx)));
      }
      if (startIdx >= bytes.length) {
        // No '{' — whole buffer was raw and is now emitted.
        this.readBuffer = '';
        return;
      }

      // ── OUTSIDE → INSIDE: discard any partial CSV line.  Bytes before a
      // command are raw-only (already sent to rawData/messageCollector via
      // _emitRaw above); they must never become a CSV line nor glue onto
      // the bytes that follow the command.
      if (ConnectionManager.csvCollector) ConnectionManager.csvCollector.resetLine();

      // ── INSIDE: '}' within the 1024 cap, or auto-close at the cap.
      let endIdx = -1;
      const scanLimit = Math.min(bytes.length, startIdx + PFOD_MAX_BYTES);
      for (let i = startIdx; i < scanLimit; i++) {
        if (bytes[i] === 0x7D /* '}' */) { endIdx = i; break; }
      }

      let pfodBytes;
      let consumedThrough;
      let autoClosed = false;
      let excessRawStr = null;

      if (endIdx !== -1) {
        pfodBytes       = bytes.subarray(startIdx, endIdx + 1);
        consumedThrough = endIdx + 1;
      } else if ((bytes.length - startIdx) >= PFOD_MAX_BYTES) {
        // ≥1024 bytes, no '}'.  Keep the first 1023 wire bytes + an
        // implicit '}' as byte 1024.  The tail (bytes after 1024, up to &
        // including any late '}') is OUTSIDE raw — fed to the collectors
        // after the command, in order; anything past that '}' loops on.
        autoClosed = true;
        pfodBytes  = new Uint8Array(PFOD_MAX_BYTES);
        pfodBytes.set(bytes.subarray(startIdx, startIdx + PFOD_MAX_BYTES - 1));
        pfodBytes[PFOD_MAX_BYTES - 1] = 0x7D;

        const tailStart = startIdx + PFOD_MAX_BYTES;
        let tailEnd     = -1;
        for (let i = tailStart; i < bytes.length; i++) {
          if (bytes[i] === 0x7D) { tailEnd = i; break; }
        }
        let rawTailBytes;
        if (tailEnd !== -1) {
          rawTailBytes    = bytes.subarray(tailStart, tailEnd + 1);
          consumedThrough = tailEnd + 1;
        } else {
          rawTailBytes    = bytes.subarray(tailStart);
          consumedThrough = bytes.length;
        }
        if (rawTailBytes.length > 0) {
          excessRawStr = dec.decode(rawTailBytes);
        }
        console.error(`[${this.protocol.toUpperCase()}_CONNECTION] pfod cmd ≥${PFOD_MAX_BYTES} bytes without closing brace — auto-closed with implicit }; ${rawTailBytes.length} byte(s) of tail truncated from the command and logged after it as a separate raw-data message`);
      } else {
        // INSIDE, no '}' yet, < 1024 bytes — keep from '{' (partial
        // serial/BLE frame) and wait for the next chunk.
        this.readBuffer = dec.decode(bytes.subarray(startIdx));
        return;
      }

      const pfodString = dec.decode(pfodBytes);
      this.readBuffer  = dec.decode(bytes.subarray(consumedThrough));

      const receiveTime = Date.now();
      const elapsedMs   = this.sendTime ? (receiveTime - this.sendTime) : 0;
      console.log(`[${this.protocol.toUpperCase()}_CONNECTION] Received complete pfod command after ${elapsedMs}ms${autoClosed ? ' (auto-closed)' : ''}:`, pfodString);

      const jsonString = this.pfodToJson(pfodString);

      if (ConnectionManager.messageCollector) {
        ConnectionManager.messageCollector.addMessage('received', pfodString, this.protocol);
        if (excessRawStr !== null) {
          ConnectionManager.messageCollector.addMessage('excess >1024', excessRawStr, this.protocol);
        }
      }

      // ── INSIDE → OUTSIDE.  The byte boundary owns the valid-response
      // decision via the queue-supplied callbacks (Option B).  Valid only
      // when there is a pending request AND its requestType accepts this
      // command's shape.
      const cb = this._respCallbacks;
      let validResponse = false;
      if (cb && this.responseResolve) {
        try {
          validResponse = !!cb.isValidResponse(jsonString);
        } catch (e) {
          console.error('[STREAM] isValidResponse threw — treating cmd as raw:', e && e.message);
          validResponse = false;
        }
      }

      if (validResponse) {
        // Apply ~C (clear) synchronously NOW — before the loop feeds the
        // OUTSIDE bytes that follow this command — so the clear drops only
        // data that preceded the {=..~C..} marker.
        try {
          cb.applyClearOption(jsonString);
        } catch (e) {
          console.error('[STREAM] applyClearOption threw:', e && e.message);
        }
        if (this.timeoutId) {
          clearTimeout(this.timeoutId);
          this.timeoutId = null;
        }
        const resolve = this.responseResolve;
        this.responseResolve = null;
        this.responseReject  = null;
        this._respCallbacks  = null;
        resolve(jsonString);
      } else {
        // Not a valid response (no pending request, requestType mismatch,
        // or unsolicited) — usually a pfodDevice coding error.  Treat the
        // command as raw data so it isn't silently dropped (it is already
        // in the Raw Message viewer above; also feed it to rawData), and
        // leave any pending request waiting so it times out / retries
        // exactly as before.  NOT fed to csvCollector — a stray command is
        // not CSV (and resetLine() above already cleared any partial line).
        this._emitRaw(pfodString, { csv: false, viewer: false });
      }

      // The >1024 excess tail is OUTSIDE raw that followed the (truncated)
      // command — feed it to the collectors AFTER the command, in order.
      // It was already shown in the viewer as 'excess >1024' above.
      if (excessRawStr !== null) {
        this._emitRaw(excessRawStr, { viewer: false });
      }
      // loop: continue with whatever follows (next {..} or OUTSIDE CSV,
      // which is now collected AFTER any ~C clear applied just above).
    }
  }

  /**
   * Append newly received text and consume the stream strictly in order.
   * The collectors are fed by processReadBuffer from the OUTSIDE segments
   * BETWEEN pfod commands (not a separate whole-chunk pass) so a {=..~C..}
   * clear lands exactly between the old and new data.  Serial/BLE/TCP/HTTP
   * all go through this one path.
   *
   * @param {string} text - new characters received
   */
  processIncoming(text) {
    this.readBuffer += text;
    this.processReadBuffer();
  }
}

/**
 * HTTPConnection - Adapter for HTTP protocol
 *
 * Handles communication with pfod devices over HTTP.
 * Supports CORS for cross-origin requests.
 */
class HTTPConnection extends PfodConnectionBase {
  constructor(config, connectionManager) {
    super();
    this.protocol = 'http';
    this.config = config;
    this.connectionManager = connectionManager;
    this.targetIP = config.targetIP;
    this.baseURL = '';
    this.timeoutId = null;
    this.readBuffer = '';       // Shared with PfodConnectionBase.processReadBuffer
    this.responseResolve = null;
    this.responseReject = null;
    this._respCallbacks = null; // Option B: queue-bound {isValidResponse, applyClearOption}
    this.sendTime = null;
    this.dataRefreshInFlight = false;  // Guard against concurrent sendDataRefresh calls

    // Parse IP:port format, default to port 80 if not specified
    if (this.targetIP) {
      let ipAddress = this.targetIP;
      let port = 80;

      if (this.targetIP.includes(':')) {
        const parts = this.targetIP.split(':');
        ipAddress = parts[0];
        port = parseInt(parts[1], 10);
      }

      this.baseURL = `http://${ipAddress}:${port}`;
    }

    console.log(`[HTTP_CONNECTION] Created with baseURL: ${this.baseURL || '(relative)'}`);
  }

  /**
   * Build fetch options for plain-text HTTP responses.
   * No Accept: application/json — device sends plain text like serial/BLE.
   * @returns {object} - Fetch options object
   */
  buildFetchOptions() {
    return {
      mode: this.targetIP ? 'cors' : 'same-origin',
      credentials: this.targetIP ? 'omit' : 'same-origin',
      cache: 'no-cache'
    };
  }

  /**
   * Build the URL for a sendOnce() request.  Extracted so subclasses
   * (e.g. SerialProxyConnection) can prepend connection-target query
   * params on top of the standard ?cmd=.
   * @param {string} cmdWithPrefix - Command with dedup prefix
   * @returns {string} - Absolute URL for fetch()
   */
  _buildSendEndpoint(cmdWithPrefix) {
    return this.baseURL + `/pfodWeb?cmd=${encodeURIComponent(cmdWithPrefix)}`;
  }

  /**
   * Build the URL for a sendDataRefresh() request (idle CSV-collecting
   * poll, empty cmd).  Extracted for the same subclass-override reason
   * as _buildSendEndpoint().
   * @returns {string} - Absolute URL for fetch()
   */
  _buildDataRefreshEndpoint() {
    return this.baseURL + '/pfodWeb?cmd=';
  }

  /**
   * Send a command via HTTP with retry logic.
   * Each attempt calls sendOnce(), which feeds the plain-text response through
   * processIncoming() → processReadBuffer() → responseResolve(jsonString).
   * All retries use the same dedup character captured at the start.
   *
   * @param {string} cmd - The pfod command (e.g., "{.}" or "{dwgName}")
   * @returns {Promise<string>} - JSON string from pfodToJson, or '' if no pfod found
   */
  async send(cmd) {
    const cmdWithPrefix = getCurrentDedupChar() + cmd;
    // {!} is the exit/abort command — fire once, never retry.  Retrying {!}
    // only delays the user-visible page transition; the device will see it on
    // the first attempt or not at all, both acceptable.
    const maxRetries = (cmd === '{!}') ? 0 : this.connectionManager.getMaxRetries();
    let lastError = null;

    console.log(`[HTTP_CONNECTION] Allocated dedup='${cmdWithPrefix[0]}' for this send()`);

    // Reset read buffer at the start of each new send
    this.readBuffer = '';

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        console.log(`[HTTP_CONNECTION] Send attempt ${attempt + 1}/${maxRetries + 1}: ${cmdWithPrefix}`);
        const jsonString = await this.sendOnce(cmdWithPrefix, cmd);
        console.log(`[HTTP_CONNECTION] Success on attempt ${attempt + 1} with dedup='${cmdWithPrefix[0]}'`);
        return jsonString;
      } catch (error) {
        lastError = error;
        console.warn(`[HTTP_CONNECTION] Attempt ${attempt + 1}/${maxRetries + 1} failed: ${error.message}`);
        if (attempt >= maxRetries) {
          console.error(`[HTTP_CONNECTION] All ${maxRetries + 1} attempts exhausted with dedup='${cmdWithPrefix[0]}'. Throwing.`);
          throw error;
        }
        // User clicked Exit while we were retrying — abandon remaining attempts
        // so {!} can fire and the page can reload promptly.  Flag is set by
        // navigationAndQueue.js addToRequestQueue when exitAbort is enqueued.
        if (this.connectionManager.exitPending) {
          console.warn(`[HTTP_CONNECTION] exitPending — abandoning ${maxRetries - attempt} remaining retr${(maxRetries - attempt) === 1 ? 'y' : 'ies'}`);
          throw error;
        }
        // Always wait at least 1 s before retrying, regardless of which
        // error triggered the retry — gives a device draining a backlog
        // (e.g. accumulated raw/CSV data) time to finish before the next
        // request, instead of hammering it back-to-back.
        await sleep(1000);
        console.log(`[HTTP_CONNECTION] Retrying with same dedup='${cmdWithPrefix[0]}'...`);
      }
    }

  }

  /**
   * Single HTTP send attempt (no retries).
   * Returns a Promise resolved by processReadBuffer() when a complete pfod {..} command
   * is found in the response text. If no pfod command is present the Promise resolves ''.
   * CSV/raw data in the response are fed to csvCollector and rawDataCollector via
   * processIncoming() before the Promise resolves.
   *
   * @param {string} cmdWithPrefix - Command with dedup prefix to send
   * @param {string} originalCmd - Original command without dedup (for message logging)
   * @returns {Promise<string>} - JSON string or ''
   * @private
   */
  sendOnce(cmdWithPrefix, originalCmd) {
    return new Promise(async (resolve, reject) => {
      this.responseResolve = resolve;
      this.responseReject = reject;
      this.sendTime = Date.now();

      const endpoint = this._buildSendEndpoint(cmdWithPrefix);
      const options = this.buildFetchOptions();

      if (this.timeoutId) {
        clearTimeout(this.timeoutId);
        this.timeoutId = null;
      }

      const controller = new AbortController();
      const timeout = this.connectionManager.getResponseTimeout();
      console.log(`[HTTP_CONNECTION] Setting response timeout to ${timeout === 0 ? 'never' : timeout + 'ms'}`);
      if (timeout !== 0) this.timeoutId = setTimeout(() => controller.abort(), timeout);

      try {
        console.log(`[HTTP_CONNECTION] Fetching: ${endpoint}`);

        if (ConnectionManager.messageCollector) {
          ConnectionManager.messageCollector.addMessage('sent', cmdWithPrefix, 'http', originalCmd);
        }

        const response = await fetch(endpoint, { ...options, signal: controller.signal });

        console.log(`[HTTP_CONNECTION] Response status: ${response.status}`);

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        const responseText = await response.text();

        if (this.timeoutId) {
          clearTimeout(this.timeoutId);
          this.timeoutId = null;
        }

        // Any HTTP response body — even empty — signals the connection is alive.
        // Fire immediately so CSV polling starts without waiting for a valid pfod reply.
        if (this._respCallbacks && typeof this._respCallbacks.onAnyResponseReceived === 'function') {
          this._respCallbacks.onAnyResponseReceived();
        }

        console.log(`[HTTP_CONNECTION] Response received (${responseText.length} bytes)`);

        // Feed plain-text response through shared pipeline:
        // csvCollector + rawDataCollector + processReadBuffer.
        // processReadBuffer will call this.responseResolve(jsonString) if a pfod command is found.
        this.processIncoming(responseText);

        // The in-order OUTSIDE/INSIDE machine already emitted every OUTSIDE
        // (raw/CSV) segment and every complete command.  The only thing that
        // can remain is an INSIDE partial ('{...' with no '}' and < 1024) —
        // a truncated/garbled trailing fragment.  HTTP responses are
        // independent, so flush it to the Raw Message viewer and clear it so
        // it cannot mis-frame the next response.  (Serial/BLE keep partials
        // across chunks — they have no such flush.)
        if (this.readBuffer.length > 0 && ConnectionManager.messageCollector) {
          ConnectionManager.messageCollector.addMessage('received', this.readBuffer, this.protocol);
          this.readBuffer = '';
        }

        // processReadBuffer did not find a complete pfod {..} in the
        // response.  Every pfod cmd — including the bare keepalive {} —
        // must come back with some {..} reply per protocol; a missing or
        // truncated {..} is therefore always a transport-level failure
        // (HTTP body empty, dropped, truncated mid-cmd, or only non-pfod
        // bytes).  Note: a {..} body ≥1024 bytes without a `}` is auto-
        // closed by processReadBuffer (synthetic `}` appended at byte 1024)
        // and resolves NORMALLY — that path never reaches here.
        //
        // Log via console.error so the diagnostic survives in non-debug
        // mode (applyDebugLogging stubs console.log / warn / info but
        // leaves console.error intact), then reject the Promise with a
        // NO_PFOD_IN_RESPONSE error.  The outer send() retry loop
        // (lines ~794-809) catches the rejection and re-sends the same
        // cmd (same dedup char) up to maxRetries times before surfacing
        // the failure to the caller.
        if (this.responseResolve) {
          const bodyPreview = responseText.length > 512
            ? responseText.slice(0, 512) + '… (' + (responseText.length - 512) + ' more chars)'
            : responseText;
          console.error(
            `[HTTP_CONNECTION] No pfod {..} in response for cmd "${originalCmd}" — `
            + `body=${responseText.length} bytes, content=`,
            JSON.stringify(bodyPreview)
          );
          const err = new Error(
            `Empty/non-pfod response for cmd "${originalCmd}" (${responseText.length} bytes) — `
            + `transport drop or truncation; will retry if budget remains`
          );
          err.code = 'NO_PFOD_IN_RESPONSE';
          const reject = this.responseReject;
          this.responseResolve = null;
          this.responseReject = null;
          if (reject) reject(err);
        }
      } catch (error) {
        if (this.timeoutId) {
          clearTimeout(this.timeoutId);
          this.timeoutId = null;
        }
        const wrappedError = error.name === 'AbortError'
          ? new Error('HTTP response timeout - device may not be responding')
          : error;
        if (this.responseReject) {
          this.responseReject(wrappedError);
          this.responseResolve = null;
          this.responseReject = null;
        }
      }
    });
  }

  /**
   * Send a data-refresh request: GET pfodWeb?cmd= with no dedup character.
   * Used by the 1-second auto-polling cycle to collect streaming CSV data between pfod commands.
   * Feeds the response through processIncoming (csvCollector, rawDataCollector, processReadBuffer).
   * Any pfod {..} command in the response is logged but does not resolve a promise.
   * @returns {Promise<void>}
   */
  async sendDataRefresh() {
    // Lowest-level guard: prevent concurrent HTTP fetches regardless of higher-level queue state
    if (this.dataRefreshInFlight) {
      console.warn('[HTTP_CONNECTION] sendDataRefresh: already in flight, skipping');
      return;
    }
    this.dataRefreshInFlight = true;

    const endpoint = this._buildDataRefreshEndpoint();
    const options = this.buildFetchOptions();

    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
      this.timeoutId = null;
    }

    const controller = new AbortController();
    const timeout = this.connectionManager.getResponseTimeout();
    if (timeout !== 0) this.timeoutId = setTimeout(() => controller.abort(), timeout);

    try {
      console.log(`[HTTP_CONNECTION] dataRefresh: ${endpoint}`);
      if (ConnectionManager.messageCollector) {
        ConnectionManager.messageCollector.addMessage('sent', '', this.protocol, '');
      }
      const response = await fetch(endpoint, { ...options, signal: controller.signal });

      if (this.timeoutId) {
        clearTimeout(this.timeoutId);
        this.timeoutId = null;
      }

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const responseText = await response.text();
      console.log(`[HTTP_CONNECTION] dataRefresh response (${responseText.length} bytes)`);

      // Feed through shared pipeline: csvCollector, rawDataCollector, processReadBuffer
      this.processIncoming(responseText);

      // Flush any remaining buffer (CSV after pfod command) to messageCollector
      if (this.readBuffer.length > 0 && ConnectionManager.messageCollector) {
        ConnectionManager.messageCollector.addMessage('received', this.readBuffer, this.protocol);
        this.readBuffer = '';
      }
    } catch (error) {
      if (this.timeoutId) {
        clearTimeout(this.timeoutId);
        this.timeoutId = null;
      }
      if (error.name === 'AbortError') {
        throw new Error('dataRefresh timeout - device may not be responding');
      }
      throw error;
    } finally {
      this.dataRefreshInFlight = false;
    }
  }

  /**
   * HTTP doesn't need explicit connection
   */
  async connect() {
    // No-op for HTTP
  }

  /**
   * Fire `{!}` at the device without waiting for a response, so the device's
   * pfodParser resets its dedup state (see pfodParser::closeConnection())
   * before the next connect -- otherwise a reconnect whose first message
   * reuses the same dedup char as this connection's last message would be
   * wrongly dropped as a duplicate. Uses keepalive so the request can
   * outlive a page-unload event (mirrors ProxyStreamConnection.sendAbort()).
   */
  async sendAbort() {
    const cmdWithPrefix = getCurrentDedupChar() + '{!}';
    const url = this._buildSendEndpoint(cmdWithPrefix);
    try {
      fetch(url, { ...this.buildFetchOptions(), keepalive: true }).catch(() => {});
      console.log(`[HTTP_CONNECTION] sent {!} on abort to ${url}`);
    } catch (e) {
      // best-effort; page may be on its way out.
    }
  }

  /**
   * HTTP has no persistent connection to tear down, but still fire {!} so
   * the device resets its dedup state before the next connect.
   */
  async disconnect() {
    await this.sendAbort();
  }

  /**
   * HTTP is always "connected"
   */
  isConnected() {
    return true;
  }
}

/**
 * ProxyStreamConnection — shared base for all three pfodProxy adapters
 * (serial, TCP, BLE).
 *
 * After the all-SSE refactor the proxy is a *streaming* peer of the
 * native `SerialConnection` / `BLEConnection`: bytes flow from the
 * device through `pfodProxy` into a long-lived Server-Sent-Events
 * stream the browser holds open, and cmd writes go out as
 * fire-and-forget `fetch('?…&cmd=…')` calls.  The proxy returns
 * 200/empty for cmd writes immediately; the actual response bytes
 * arrive over the SSE stream a few milliseconds later and are parsed
 * by the inherited `PfodConnectionBase.processReadBuffer()`.
 *
 * The two HTTP requests in flight per session:
 *   • One persistent SSE `GET ?<target-params>` — held open by
 *     EventSource for the entire session, hex-encoded device byte
 *     chunks arrive as `data:` events.
 *   • One short `GET ?<target-params>&cmd=<…>` per cmd — fires the
 *     write to the proxy, returns 200+empty in ms, doesn't carry
 *     the response.
 *
 * Subclasses only override `_proxyTargetQuery()` (and pass their
 * protocol name + protocol-specific config in via the constructor).
 *
 * dataRefresh polling is **not** inherited from HTTPConnection here
 * (we extend `PfodConnectionBase` directly): the SSE byte stream
 * pushes streaming data live, so the 1 s dataRefresh poll the
 * direct-HTTP path uses is unnecessary and was actively harmful
 * (raced with menu refresh + keepAlive timers, see prior debug
 * sessions).  The request-queue's scheduleDataRefresh gates on
 * `protocol === 'http'` to keep it out of the proxy path.
 */
class ProxyStreamConnection extends PfodConnectionBase {
  constructor(config, connectionManager, protocol) {
    super();
    this.protocol          = protocol;     // 'serial' | 'tcp' | 'ble'
    this.config            = config;
    this.connectionManager = connectionManager;
    this.proxyHostPort     = config.proxyHostPort || 'localhost:4989';
    this.baseURL           = `http://${this.proxyHostPort}`;

    this.eventSource     = null;
    this.connected       = false;
    this.readBuffer      = '';
    this.responseResolve = null;
    this.responseReject  = null;
    this.timeoutId       = null;
    this.sendTime        = null;
    this._decoder        = new TextDecoder('utf-8', { fatal: false });
  }

  /// Subclasses MUST override.  Returns the target query (e.g.
  /// "serial=COM16&baud=115200" / "ip=10.0.0.1" / "ble=AA:BB:…"),
  /// plus any `&debug=` flag.
  _proxyTargetQuery() {
    throw new Error(`${this.constructor.name} must override _proxyTargetQuery()`);
  }

  /// `&pw=<password>` if this page was loaded with one, else ''.
  /// /pfodWeb is gated by pw_filter in pfodProxy_rs, so every request
  /// here needs it when one is configured.
  _pwQuery() {
    return window.PFOD_PROXY_PW ? ('&pw=' + encodeURIComponent(window.PFOD_PROXY_PW)) : '';
  }

  /// URL for the connection SSE (no `cmd=`).
  _connectionURL() {
    return this.baseURL + '/pfodWeb?' + this._proxyTargetQuery() + this._pwQuery();
  }

  /// URL for a cmd write (`&cmd=<encoded>` appended).
  _cmdURL(cmdWithPrefix) {
    return this.baseURL + '/pfodWeb?'
         + this._proxyTargetQuery()
         + this._pwQuery()
         + '&cmd=' + encodeURIComponent(cmdWithPrefix);
  }

  /// Open the SSE byte stream.  Idempotent — calling twice is a
  /// no-op after the first.  Resolves when the EventSource fires
  /// `open`; rejects if the initial connect fails.
  async connect() {
    if (this.connected && this.eventSource) {
      return;
    }
    // Reset the parser state for each fresh connect so stale
    // partial-UTF-8 from a previous session can't corrupt the
    // first bytes of the new one.
    this.readBuffer = '';
    this._decoder   = new TextDecoder('utf-8', { fatal: false });

    const url = this._connectionURL();
    console.log(`[${this.protocol.toUpperCase()}_PROXY] Opening SSE: ${url}`);

    // Show a progress dialog only for BLE proxy connections — that's
    // where the multi-step GATT setup can take ~10 s for sparsely-
    // advertising sensors.  Serial / TCP proxy opens are millisecond-
    // scale and a dialog would just flash.  See _showConnectingDialog
    // for the actual modal.
    const showDialog = (this.protocol === 'ble');
    if (showDialog) {
      const name    = this.bleName    || null;
      const address = this.bleAddress || '';
      this._showConnectingDialog(name, address);
    }

    return new Promise((resolve, reject) => {
      let settled = false;
      const settle = (fn) => { if (!settled) { settled = true; fn(); } };

      // Cancel wired to the dialog Cancel button.  Closes whatever
      // EventSource is current at the time the button is pressed.
      if (showDialog) {
        this._cancelConnect = () => {
          if (this.eventSource) { this.eventSource.close(); this.eventSource = null; }
          this.connected = false;
          this._hideConnectingDialog();
          settle(() => reject(new Error('Connection cancelled')));
        };
      }

      const startAttempt = () => {
        if (settled) return;   // cancelled while a retry was queued
        let es;
        try {
          es = new EventSource(url);
        } catch (err) {
          // `new EventSource(url)` can throw synchronously (e.g. a
          // malformed URL) — whatever the underlying cause, the
          // user-facing message should be the same actionable
          // "proxy not running" guidance the async never-opened path
          // below gives, not a raw DOMException like "An invalid or
          // illegal string was specified".
          if (showDialog) this._hideConnectingDialog();
          const hp = this.proxyHostPort || 'localhost:4989';
          const portPart = hp.indexOf(':') >= 0 ? hp.substring(hp.lastIndexOf(':') + 1) : '4989';
          settle(() => reject(new Error(
            `Cannot reach pfodProxy at ${hp}.\n\n` +
            `Start pfodProxy on port ${portPart} first — run:\n` +
            `    pfodProxy ${portPart}\n\n` +
            `then retry the connection.`
          )));
          return;
        }
        this.eventSource = es;
        let opened = false;

        es.onopen = () => {
          opened = true;
          this.connected = true;
          console.log(`[${this.protocol.toUpperCase()}_PROXY] SSE open`);
          // For serial: arm the post-connect grace flag (Arduino DTR reset
          // bootloader window) as soon as the port physically opens.
          // All transports resolve on `progress: ready` (not here) so a
          // second-connection refused error — sent before ready — is never
          // silently swallowed after the promise has already settled.
          if (this.protocol === 'serial') {
            this._postConnectGrace = true;
          }
        };

        es.onmessage = (e) => {
          // Hex-decode device chunk → bytes → UTF-8 string → parser.
          // hex-encoded by the proxy so the data: payload is plain
          // ASCII and free of any chars that could confuse SSE framing
          // (newlines, NUL, lone surrogates).
          const hex = e.data;
          if (!hex || (hex.length & 1)) return;  // skip empty/odd-length safety
          const bytes = new Uint8Array(hex.length >>> 1);
          for (let i = 0; i < bytes.length; i++) {
            bytes[i] = parseInt(hex.substr(i << 1, 2), 16);
          }
          const text = this._decoder.decode(bytes, { stream: true });
          this.processIncoming(text);
        };

        // Proxy echoes back the device name (from the ?name= query param)
        // so the dialog can show it even before the first progress step.
        es.addEventListener('device_name', (e) => {
          const n = (e.data || '').trim();
          if (n && showDialog) this._updateConnectingDialogName(n, this.bleAddress || '');
        });

        // Proxy emits `event: progress` with `data: "<step>"` during
        // the BLE GATT setup: "scanning" → "connecting" → "discovering"
        // → "subscribing" → "ready".  Update the dialog as each step
        // arrives; close on "ready" (or on the SSE error handler below).
        es.addEventListener('progress', (e) => {
          const step = (e.data || '').trim();
          console.log(`[${this.protocol.toUpperCase()}_PROXY] progress: ${step}`);
          if (step === 'ready') {
            if (showDialog) this._hideConnectingDialog();
            settle(() => resolve());
          } else {
            if (showDialog) this._updateConnectingDialog(step);
          }
        });

        es.addEventListener('lagged', (e) => {
          // Proxy broadcast channel reported a slow subscriber; we
          // skipped `e.data` chunks.  Surface as a warning — the
          // pfod parser can't recover lost middle bytes cleanly, but
          // the next complete `{…}` block will resync.
          console.warn(`[${this.protocol.toUpperCase()}_PROXY] SSE lagged — ${e.data} chunks skipped`);
        });

        es.addEventListener('error', (event) => {
          // Two distinct cases share this handler:
          //
          // 1. Named SSE `event: error` from the proxy (e.g. "device not found",
          //    "open failed: …").  These arrive as MessageEvent with a .data
          //    payload.
          //    "not found": device wasn't advertising — close and retry
          //    (the dialog stays open; user can Cancel at any time).
          //    Any other proxy error: fatal — dismiss dialog and reject.
          //
          // 2. EventSource network/transport error (plain Event, no .data).
          //    EventSource auto-reconnects on transient drops.  Only treat as
          //    fatal when readyState reaches CLOSED.
          if (event instanceof MessageEvent) {
            es.close();
            this.connected = false;
            const rawMsg = (event.data || `${this.protocol} connection failed`).replace(/^open failed:\s*/i, '');
            // Retry-without-erroring only ever made sense for BLE — a device
            // that hasn't started advertising yet might still show up on the
            // next scan.  A missing serial port or unreachable TCP host won't
            // fix itself by retrying, so this must stay BLE-only — otherwise
            // any other transport's error message that happens to contain
            // "not found" (e.g. serial's "Port not found") silently loops
            // forever instead of ever surfacing to the user.
            if (!settled && this.protocol === 'ble' && (/not found/i.test(rawMsg) || /not connected/i.test(rawMsg))) {
              // Device not advertising or BLE link failed — keep dialog open and retry.
              if (showDialog) this._updateConnectingDialog('scanning');
              startAttempt();
              return;
            }
            // pfodProxy's cached-connect backoff (ble.rs's ensure_open) —
            // "recent connection failure, retry in <n>s". Expected and
            // self-clearing, same as the "not found" case above: keep the
            // dialog open, show the wait, then retry after it elapses
            // instead of rejecting (which would close the dialog only for
            // the caller to immediately reopen a fresh one on its own retry).
            const backoffMatch = rawMsg.match(/recent connection failure, retry in (\d+)s/i);
            if (!settled && this.protocol === 'ble' && backoffMatch) {
              const waitSec = parseInt(backoffMatch[1], 10) || 2;
              if (showDialog) this._updateConnectingDialog(`Re-scanning in ${waitSec}s…`);
              setTimeout(() => {
                if (settled) return;   // cancelled while the wait was pending
                if (showDialog) this._updateConnectingDialog('scanning');
                startAttempt();
              }, waitSec * 1000);
              return;
            }
            if (showDialog) this._hideConnectingDialog();
            const name = this.bleName;
            const addr = this.bleAddress || '';
            const addrEsc = addr.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const msg = name
              ? rawMsg.replace(new RegExp(`device\\s+${addrEsc}`, 'i'), `${name} (${addr})`)
              : rawMsg;
            settle(() => reject(new Error(msg)));
            return;
          }
          if (es.readyState === EventSource.CLOSED) {
            this.connected = false;
            if (showDialog) this._hideConnectingDialog();
            if (!opened) {
              // The SSE never opened — almost always because pfodProxy isn't
              // running (or is on a different port).  Give an actionable
              // message naming the host:port and the command to start it,
              // instead of the opaque "SSE connection failed".
              const hp = this.proxyHostPort || 'localhost:4989';
              const portPart = hp.indexOf(':') >= 0 ? hp.substring(hp.lastIndexOf(':') + 1) : '4989';
              settle(() => reject(new Error(
                `Cannot reach pfodProxy at ${hp}.\n\n` +
                `Start pfodProxy on port ${portPart} first — run:\n` +
                `    pfodProxy ${portPart}\n\n` +
                `then retry the connection.`
              )));
            } else {
              // SSE opened but closed before progress:ready or named error arrived.
              // This happens when the proxy sends an error event + closes the stream
              // very quickly (e.g. COM port in use) and the browser bundles the
              // event data with the connection-close in the same TCP segment so the
              // named error event fires, but onerror may fire first on some paths.
              // Settle here as a fallback so send() is never left hanging.
              settle(() => reject(new Error(
                'Connection to proxy closed before ready — COM port may be in use'
              )));
            }
            if (this.responseReject) {
              this.responseReject(new Error('SSE disconnected'));
              this.responseResolve = null;
              this.responseReject  = null;
              if (this.timeoutId) { clearTimeout(this.timeoutId); this.timeoutId = null; }
            }
          }
        });
      };

      startAttempt();
    });
  }

  // _showConnectingDialog / _updateConnectingDialog /
  // _hideConnectingDialog are inherited from PfodConnectionBase so
  // the native BLEConnection can share the same UI.

  /// Send a cmd.  Allocates the dedup char, fires a fire-and-forget
  /// fetch to the proxy, and returns a Promise that resolves when
  /// the inherited `processReadBuffer()` surfaces the next complete
  /// `{…}` block on the SSE stream.
  ///
  /// `{!}` is a special case: route to `sendAbort()` and resolve
  /// immediately with empty string.  The device doesn't reply to
  /// its own abort, so awaiting a response would just block until
  /// the response-timeout fires — wasteful, and ConnectionManager
  /// .sendAbort() already does this.sendAbort().catch(noop) (this
  /// class's own dedicated sendAbort(), below) which would silently
  /// leak the rejected Promise.
  async send(cmd) {
    if (cmd === '{!}') {
      await this.sendAbort();
      return '';
    }

    if (!this.connected) {
      await this.connect();
    }

    // Allocate the dedup char ONCE per send — every retry reuses
    // the same prefix so the pfod device's protocol-level dedup
    // matches an identical retry to the original cmd and replies
    // with the same response (rather than re-running side effects).
    const cmdWithPrefix = getCurrentDedupChar() + cmd;
    const url           = this._cmdURL(cmdWithPrefix);
    const fullTimeoutMs = this.connectionManager.getResponseTimeout();
    const maxRetries    = this.connectionManager.getMaxRetries();
    const tag           = this.protocol.toUpperCase();

    console.log(`[${tag}_PROXY] Allocated dedup='${cmdWithPrefix[0]}'`);

    // Post-connect grace for serial proxy: same as native serial.
    // First cmd after opening the COM port waits 2.5 s (Arduino
    // DTR-reset bootloader window), probes with a 5 s timeout, then
    // resends with full timeout if no reply.  See
    // SerialConnection.sendOnceWithProgressiveTimeout for the
    // matching native-path behaviour.
    if (this.protocol === 'serial' && this._postConnectGrace) {
      this._postConnectGrace = false;
      console.log('[SERIAL_PROXY] Post-connect grace: waiting 2.5 s before first cmd...');
      await new Promise(r => setTimeout(r, 2500));

      // Probe with 5 s timeout.
      try {
        const json = await this._proxySendOnce(cmdWithPrefix, url, 5000, tag, 'probe');
        return json;
      } catch (e) {
        if (!`${e.message}`.includes('timeout') && !`${e.message}`.includes('cmd write failed')) {
          throw e;
        }
        console.warn(`[SERIAL_PROXY] First cmd timed out at 5 s — resending with full ${fullTimeoutMs} ms timeout`);
      }
      // Resend with full timeout — same dedup char.
      return await this._proxySendOnce(cmdWithPrefix, url, fullTimeoutMs, tag, 'resend');
    }

    let lastError = null;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      console.log(`[${tag}_PROXY] Send attempt ${attempt + 1}/${maxRetries + 1}: ${cmdWithPrefix}`);
      try {
        const json = await this._proxySendOnce(cmdWithPrefix, url, fullTimeoutMs, tag, `attempt ${attempt + 1}/${maxRetries + 1}`);
        return json;
      } catch (e) {
        lastError = e;
        console.warn(`[${tag}_PROXY] Attempt ${attempt + 1}/${maxRetries + 1} failed: ${e.message}`);
        if (attempt >= maxRetries) throw lastError;
        // Always wait at least 1 s before retrying, regardless of which
        // error triggered the retry — see sleep() doc comment.
        await sleep(1000);
      }
    }
    throw lastError || new Error(`${this.protocol} send exhausted retries`);
  }

  /// One cmd write + one response wait, with explicit timeout.
  /// Returns the JSON response string; throws on fetch/proxy error
  /// or response timeout.  Always pushes a SENT entry to the message
  /// panel so the raw-msg view shows every wire attempt.
  /// @private
  async _proxySendOnce(cmdWithPrefix, url, timeoutMs, tag, label) {
    if (ConnectionManager.messageCollector) {
      ConnectionManager.messageCollector.addMessage('sent', cmdWithPrefix, this.protocol);
    }
    const responsePromise = new Promise((resolve, reject) => {
      this.responseResolve = resolve;
      this.responseReject  = reject;
      if (timeoutMs !== 0) this.timeoutId = setTimeout(() => {
        if (this.responseReject) {
          const r = this.responseReject;
          if (this.readBuffer.length > 0 && ConnectionManager.messageCollector) {
            ConnectionManager.messageCollector.addMessage('timeout', this.readBuffer, this.protocol);
          }
          this.readBuffer      = '';
          this.responseResolve = null;
          this.responseReject  = null;
          this.timeoutId       = null;
          r(new Error(`${this.protocol} response timeout - device may not be responding`));
        }
      }, timeoutMs);
    });
    this.sendTime = Date.now();
    try {
      const resp = await fetch(url, {
        mode:        'cors',
        credentials: 'omit',
        cache:       'no-cache',
      });
      if (!resp.ok) {
        const body = await resp.text().catch(() => '');
        throw new Error(`proxy returned ${resp.status}${body ? ':\n' + body.trim() : ''}`);
      }
    } catch (e) {
      if (this.timeoutId) { clearTimeout(this.timeoutId); this.timeoutId = null; }
      this.responseResolve = null;
      this.responseReject  = null;
      throw new Error(`cmd write failed (${label}): ${e.message}`);
    }
    const json = await responsePromise;
    console.log(`[${tag}_PROXY] ${label} success with dedup='${cmdWithPrefix[0]}' (timeout was ${timeoutMs} ms)`);
    return json;
  }

  /// Fire `{!}` at the proxy without waiting.  Used by
  /// `ConnectionManager.send('{!}')` (the exitAbort path) and by
  /// `disconnect()`.  Uses `keepalive: true` so the request can
  /// outlive a page-unload event.
  async sendAbort() {
    const url = this._cmdURL('{!}');
    try {
      fetch(url, { mode: 'cors', keepalive: true }).catch(() => {});
      console.log(`[${this.protocol.toUpperCase()}_PROXY] sent {!} on abort to ${url}`);
    } catch (e) {
      // best-effort; page may be on its way out.
    }
  }

  /// Disconnect: tell the proxy to close the device session, then
  /// close our EventSource so the proxy's ScanGuard-style cleanup
  /// fires the cancel signal and the device socket actually goes
  /// away.  Both halves are best-effort — page may be unloading.
  async disconnect() {
    await this.sendAbort();
    if (this.eventSource) {
      try { this.eventSource.close(); } catch (_) {}
      this.eventSource = null;
    }
    this.connected = false;
    if (this.responseReject) {
      this.responseReject(new Error('disconnected'));
      this.responseResolve = null;
      this.responseReject  = null;
      if (this.timeoutId) { clearTimeout(this.timeoutId); this.timeoutId = null; }
    }
  }

  isConnected() {
    return this.connected && this.eventSource
        && this.eventSource.readyState !== EventSource.CLOSED;
  }
}

/**
 * SerialProxyConnection — fallback for browsers without the Web Serial API.
 * Uses pfodProxy's serial transport (`?serial=<path>&baud=<rate>`) over SSE.
 */
class SerialProxyConnection extends ProxyStreamConnection {
  constructor(config, connectionManager) {
    super(config, connectionManager, 'serial');
    this.serialPath  = config.serialPath;
    this.baudRate    = config.baudRate || 9600;
    this.portName    = config.serialPath || 'Unknown Port';
    this.cachePortId = config.serialPath || null;
    console.log(`[SERIAL_PROXY] Created for ${this.serialPath} @ ${this.baudRate} baud via ${this.baseURL}`);
  }

  _proxyTargetQuery() {
    let q = 'serial=' + encodeURIComponent(this.serialPath)
          + '&baud='  + this.baudRate;
    if (window.DEBUG) q += '&debug=';
    return q;
  }
}

/**
 * BLEProxyConnection — BLE transport via pfodProxy (Nordic UART).
 *
 * Fallback path for browsers without Web Bluetooth API (Firefox,
 * Safari).  Uses pfodProxy's BLE transport (`?ble=<address>`); the
 * proxy holds the GATT connection and pushes NUS-TX-characteristic
 * notifications onto the SSE stream.
 */
class BLEProxyConnection extends ProxyStreamConnection {
  constructor(config, connectionManager) {
    super(config, connectionManager, 'ble');
    this.bleAddress = config.bleAddress;
    this.bleName    = config.bleName || null;
    console.log(`[BLE_PROXY] Created for ${this.bleName || this.bleAddress} via ${this.baseURL}`);
  }

  _proxyTargetQuery() {
    let q = 'ble=' + encodeURIComponent(this.bleAddress);
    if (this.bleName) q += '&name=' + encodeURIComponent(this.bleName);
    if (window.DEBUG) q += '&debug=';
    return q;
  }
}

/**
 * TCPProxyConnection — raw-TCP transport via pfodProxy.
 *
 * Browsers can't open raw TCP sockets, so reaching a pfod device that
 * speaks TCP requires the local pfodProxy.  Uses `?ip=…`; the proxy
 * always connects on the standard pfod device port and holds the TCP
 * socket, pushing recv bytes onto the SSE stream. No `port` param is
 * sent — pfodProxy ignores/hangs on one if present (see pfodProxy_rs
 * tcp.rs), so this class must never add one back.
 */
class TCPProxyConnection extends ProxyStreamConnection {
  constructor(config, connectionManager) {
    super(config, connectionManager, 'tcp');
    this.deviceIP = config.targetIP;
    console.log(`[TCP_PROXY] Created for ${this.deviceIP} via ${this.baseURL}`);
  }

  _proxyTargetQuery() {
    let q = 'ip=' + encodeURIComponent(this.deviceIP);
    if (window.DEBUG) q += '&debug=';
    return q;
  }
}

/**
 * SerialConnection - Adapter for Serial protocol using the Web Serial API.
 *
 * Used when the connection prompt's Serial "Connect via" is set to "This
 * browser" — i.e. the browser exposes navigator.serial and the user opted
 * out of pfodProxy.  Selected in ConnectionManager.initializeAdapter()
 * by config.useProxy === false; otherwise SerialProxyConnection is used.
 *
 * The SerialPort object is NOT requested here: navigator.serial.requestPort()
 * needs transient user activation, so the prompt's "Select COM Port" button
 * calls it directly (inside the click handler) and hands the resulting port
 * over as config.nativeSerialPort.
 */
class SerialConnection extends PfodConnectionBase {
  constructor(config, connectionManager) {
    super();
    this.protocol = 'serial';
    this.config = config;
    this.connectionManager = connectionManager;
    // Pre-selected by the connection prompt (see class doc).  connect()
    // opens this port; it never runs the picker itself.
    this.port = config.nativeSerialPort || null;
    this.portName = config.serialPath || 'Unknown Port';  // Human-readable port name for UI / error messages
    this.cachePortId = config.serialPath || null;         // Stable identifier for localStorage cache keys
                                     // (refined during connect: COM number when available,
                                     // VID/PID hex pair otherwise — Chrome on Windows
                                     // doesn't expose COM numbers but always exposes
                                     // USB VID/PID via port.getInfo()).
    this.reader = null;
    this.writer = null;
    this.connected = false;
    this.readBuffer = '';
    this.responsePromise = null;
    this.responseResolve = null;
    this.responseReject = null;
    this.timeoutId = null;  // Store timeout ID so it can be cancelled
    this._decoder = null;
    this._readingPromise = null;
    this.firstRequest = true;  // Flag to track if this is the first request
    this.firstRequestAttemptTimeout = 3000;  // Start at 3 second for first request attempts

    // Serial configuration with defaults
    this.baudRate = config.baudRate || 9600;
    this.dataBits = config.dataBits || 8;
    this.stopBits = config.stopBits || 1;
    this.parity = config.parity || 'none';
    this.flowControl = 'none'; //'hardware' ;//config.flowControl || 'none';

    console.log(`[SERIAL_CONNECTION] Created with baud rate: ${this.baudRate}`);
  }

  /**
   * Open the port the connection prompt already picked for us.
   *
   * The picker itself runs in the prompt's "Select COM Port" click handler
   * (navigator.serial.requestPort() requires transient user activation, which
   * an await-laden connect() can no longer be relied on to have), so by the
   * time we get here this.port is a live SerialPort and all that remains is
   * open() + reader/writer setup.
   */
  async connect() {
    try {
      // Check if Web Serial API is supported
      if (!('serial' in navigator)) {
        const errorMsg = 'Web Serial API is not supported in this browser.\n\n' +
                        'Serial connections require:\n' +
                        '• Chrome (version 89 or later)\n' +
                        '• Edge (version 89 or later)\n' +
                        '• Opera (version 75 or later)\n\n' +
                        'Please use a supported browser for Serial connections,\n' +
                        'or switch "Connect via" back to pfodProxy.';
        throw new Error(errorMsg);
      }

      if (!this.port) {
        throw new Error('No serial port selected.\n\n' +
                        'Click "Select COM Port" and choose the port to use.');
      }

      try {
        // Derive the cache-stable identifier (used for localStorage menu-cache
        // keys) from the port's USB VID/PID.  Chrome on Windows does not expose
        // the COM number to the page at all, so the human-readable portName is
        // whatever label the prompt's picker showed; the VID/PID pair is what
        // actually keeps per-USB-device cache entries from colliding.
        const portInfo = this.port.getInfo();
        if (this.portName.match(/^COM\d+$/)) {
          this.cachePortId = this.portName;
        } else if (portInfo && portInfo.usbVendorId != null && portInfo.usbProductId != null) {
          const vid = portInfo.usbVendorId.toString(16).toUpperCase().padStart(4, '0');
          const pid = portInfo.usbProductId.toString(16).toUpperCase().padStart(4, '0');
          this.cachePortId = `VID${vid}_PID${pid}`;
        } else {
          this.cachePortId = this.portName;
        }
        console.log('[SERIAL_CONNECTION] Port name:', this.portName, '/ cache id:', this.cachePortId);

        console.log('[SERIAL_CONNECTION] Attempting to open port...');
        await this.port.open({
          baudRate: this.baudRate,
          dataBits: this.dataBits,
          stopBits: this.stopBits,
          parity: this.parity,
          flowControl: this.flowControl
        });
        console.log('[SERIAL_CONNECTION] Port opened successfully');
      } catch (openError) {
        console.error('[SERIAL_CONNECTION] Port opening failed:', openError);

        const errorMsg = 'Serial port could not be opened. Please ensure:\n' +
                        '1. The device is connected\n' +
                        '2. No other application is using the port\n' +
                        '3. You selected the correct port\n\n' +
                        openError.message;
        throw new Error(errorMsg);
      }

      // Get reader and writer
      this.reader = this.port.readable.getReader();
      this.writer = this.port.writable.getWriter();
      this.connected = true;

      // Reset first request flag for new connection
      this.firstRequest = true;
      console.log('[SERIAL_CONNECTION] Serial connection established successfully, firstRequest flag reset');

      // Fresh decoder for each connection so no stale partial-character state carries over
      this._decoder = new TextDecoder('utf-8', { fatal: false });

      // Start reading loop (don't await - let it run in background)
      this._readingPromise = this.startReading();

      // Give a moment for the read loop to actually start before returning
      // This ensures the reader is actively listening before we send commands
      await new Promise(resolve => setTimeout(resolve, 50));

    } catch (error) {
      console.error('[SERIAL_CONNECTION] Connection failed:', error);
      throw error;
    }
  }

  /**
   * Start continuous reading from serial port
   * Buffers incoming data until a complete response is received
   * Resets timeout each time data is received
   */
  async startReading() {
    console.log('[SERIAL_CONNECTION] Starting read loop...');

    try {
      while (this.connected && this.reader) {
        const { value, done } = await this.reader.read();

        if (done) {
          console.log('[SERIAL_CONNECTION] Reader closed');
          break;
        }

        // Decode using the persistent instance decoder (created/reset at connect time)
        // with stream:true so multi-byte UTF-8 characters split across chunks decode correctly.
        const text = this._decoder.decode(value, { stream: true });

        // NOTE: Do NOT reset timeout here - timeout should apply to the entire response,
        // not reset on partial data. Only clear timeout when complete response is received
        // in processReadBuffer()

        // Feed data through shared pipeline: csvCollector, rawDataCollector, processReadBuffer
        this.processIncoming(text);
      }
    } catch (error) {
      if (this.connected) {
        console.error('[SERIAL_CONNECTION] Read error:', error);
        if (this.responseReject) {
          this.responseReject(error);
          this.responseResolve = null;
          this.responseReject = null;
        }
      }
    }
  }

  /**
   * Send a command via serial with internal retry logic
   * Retries up to maxRetries times using the same dedup character
   * Only advances dedup on final success
   * @param {string} cmd - The pfod command (e.g., "{.}" or "{dwgName}")
   * @returns {Promise<string>} - Response text (usually JSON)
   */
  async send(cmd) {
    // Auto-connect if not already connected
    if (!this.connected || !this.writer) {
      console.log('[SERIAL_CONNECTION] Not connected, connecting now...');
      await this.connect();
    }

    // Diagnostic logging: Check if a previous request is still pending
    if (this.responseResolve || this.responseReject) {
      console.warn(`[SERIAL_CONNECTION] WARNING: send() called while previous request still pending`);
      console.warn(`[SERIAL_CONNECTION] This should not happen - queue protection may not be working`);
    }

    // Get dedup character atomically - getCurrentDedupChar() increments for next call
    const cmdWithPrefix = getCurrentDedupChar() + cmd;
    // {!} is the exit/abort command — fire once, never retry (see HTTPAdapter.send).
    const maxRetries = (cmd === '{!}') ? 0 : this.connectionManager.getMaxRetries();
    const isFirstRequest = this.firstRequest;
    let lastError = null;

    console.log(`[SERIAL_CONNECTION] Allocated dedup='${cmdWithPrefix[0]}' for this send()`);

    // Clear response state once at the start - keep accumulated data across retries
    this.readBuffer = '';

    // Retry loop: attempt up to (maxRetries + 1) times
    // Data continues to accumulate in readBuffer across retry attempts
    // All retries use the SAME cmdWithPrefix (dedup already captured)
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        console.log(`[SERIAL_CONNECTION] Send attempt ${attempt + 1}/${maxRetries + 1}: ${cmdWithPrefix}`);

        // Cancel any previous timeout
        if (this.timeoutId) {
          clearTimeout(this.timeoutId);
          console.log(`[SERIAL_CONNECTION] Cancelled previous timeout`);
          this.timeoutId = null;
        }

        let responseText;
        // For first request, use progressive timeout
        if (isFirstRequest && attempt === 0) {
          this.firstRequest = false;
          responseText = await this.sendOnceWithProgressiveTimeout(cmdWithPrefix, cmd);
        } else {
          // Normal send for subsequent requests or retries
          // NOTE: readBuffer is NOT cleared here - it persists across retries
          // This allows partial responses to accumulate if retries occur
          responseText = await this.sendOnceInternal(cmdWithPrefix, cmd, this.connectionManager.getResponseTimeout());
        }

        // Success! Return response (dedup already allocated and advanced at start)
        console.log(`[SERIAL_CONNECTION] Success on attempt ${attempt + 1} with dedup='${cmdWithPrefix[0]}'`);
        return responseText;
      } catch (error) {
        lastError = error;
        console.warn(`[SERIAL_CONNECTION] Attempt ${attempt + 1}/${maxRetries + 1} failed: ${error.message}`);

        // If this was the last attempt, close the port then throw the error.
        // forceReconnect() may have left the port open; closing it now ensures the next
        // connect() call can open it fresh (avoids "port is already open" on Reload).
        if (attempt >= maxRetries) {
          console.error(`[SERIAL_CONNECTION] All ${maxRetries + 1} attempts exhausted with dedup='${cmdWithPrefix[0]}'. Throwing error back to queue.`);
          await this.disconnect().catch(() => {});
          throw error;
        }
        // User clicked Exit while we were retrying — abandon remaining attempts.
        if (this.connectionManager.exitPending) {
          console.warn(`[SERIAL_CONNECTION] exitPending — abandoning ${maxRetries - attempt} remaining retr${(maxRetries - attempt) === 1 ? 'y' : 'ies'}`);
          await this.disconnect().catch(() => {});
          throw error;
        }

        // Always wait at least 1 s before retrying, regardless of which
        // error triggered the retry — see sleep() doc comment.
        await sleep(1000);

        // Close and reopen connection before retry, but only on subsequent timeouts (not first)
        if (attempt > 0) {
          console.log(`[SERIAL_CONNECTION] Closing and reopening serial connection before retry...`);
          try {
            await this.forceReconnect();
            console.log(`[SERIAL_CONNECTION] Connection re-engaged successfully, retrying with same dedup='${cmdWithPrefix[0]}'...`);
          } catch (reconnectError) {
            console.error(`[SERIAL_CONNECTION] Failed to re-engage connection during retry: ${reconnectError.message}`);
            // Continue to next retry attempt even if reconnect failed
            console.log(`[SERIAL_CONNECTION] Retrying with same dedup='${cmdWithPrefix[0]}'...`);
          }
        } else {
          // First timeout - just retry without reconnecting
          console.log(`[SERIAL_CONNECTION] First timeout - retrying without reconnect, dedup='${cmdWithPrefix[0]}'...`);
        }
      }
    }

  }

  /**
   * Post-connect grace handler for the FIRST cmd after opening the
   * port.  Serial (USB-CDC) devices typically reset on port open
   * (Arduino's DTR-toggle behaviour); during the bootloader window
   * any cmd sent is dropped on the floor.  Flow:
   *   1. Wait 2.5 s after connect before sending anything.
   *   2. Send the cmd with a 5 s response timeout (probes the device).
   *   3. If no response: resend (same dedup char) and wait the full
   *      response timeout (default 10 s).
   *   4. Subsequent sends use the normal path with full timeout.
   * @private
   */
  async sendOnceWithProgressiveTimeout(cmdWithPrefix, originalCmd) {
    const maxTimeout = this.connectionManager.getResponseTimeout();

    console.log('[SERIAL_CONNECTION] Post-connect grace: waiting 2.5 s before first cmd...');
    await new Promise(resolve => setTimeout(resolve, 2500));

    console.log(`[SERIAL_CONNECTION] First cmd attempt with 5 s timeout (Arduino-bootloader-window probe)`);
    try {
      const response = await this.sendOnceInternal(cmdWithPrefix, originalCmd, 5000);
      console.log('[SERIAL_CONNECTION] First cmd got response within 5 s');
      return response;
    } catch (error) {
      if (!error.message.includes('timeout')) {
        // Non-timeout error — propagate immediately, no resend.
        throw error;
      }
      console.warn(`[SERIAL_CONNECTION] First cmd timed out at 5 s — resending with full ${maxTimeout} ms timeout`);
    }

    // Resend with the full response timeout.  Same dedup char so the
    // device's protocol-level dedup matches if the first cmd actually
    // got through.
    try {
      const response = await this.sendOnceInternal(cmdWithPrefix, originalCmd, maxTimeout);
      console.log(`[SERIAL_CONNECTION] Second cmd succeeded within ${maxTimeout} ms`);
      return response;
    } catch (error) {
      // Throw a normalised timeout error to feed the outer retry loop.
      if (error.message.includes('timeout')) {
        throw new Error('Serial response timeout - device may not be responding');
      }
      throw error;
    }
  }

  /**
   * Send command once with specified timeout (internal - no retry)
   * @param {string} cmdWithPrefix - The command with dedup prefix already applied
   * @param {string} originalCmd - The original command without prefix
   * @param {number} timeout - Timeout in milliseconds
   * @returns {Promise<string>} - Response text
   * @private
   */
  async sendOnceInternal(cmdWithPrefix, originalCmd, timeout) {
    // Record send time for performance measurement
    this.sendTime = Date.now();
    this.currentTimeout = timeout;

    // Set up promise for response
    const responsePromise = new Promise((resolve, reject) => {
      this.responseResolve = resolve;
      this.responseReject = reject;

      console.log(`[SERIAL_CONNECTION] Setting timeout to ${timeout === 0 ? 'never' : timeout + 'ms'}`);
      if (timeout !== 0) this.timeoutId = setTimeout(() => {
        if (this.responseReject) {
          if (this.readBuffer.length > 0 && ConnectionManager.messageCollector) {
            ConnectionManager.messageCollector.addMessage('timeout', this.readBuffer, this.protocol);
          }
          this.readBuffer = '';
          this.responseReject(new Error('Serial response timeout - device may not be responding'));
          this.responseResolve = null;
          this.responseReject = null;
          this.timeoutId = null;
        }
      }, timeout);
    });

    // Send the command
    console.log(`[SERIAL_CONNECTION] Sending: ${cmdWithPrefix} at ${new Date(this.sendTime).toISOString()}`);

    // Record the command being sent (with the dedup prefix)
    if (ConnectionManager.messageCollector) {
      ConnectionManager.messageCollector.addMessage('sent', cmdWithPrefix, 'serial', originalCmd);
    }

    const encoder = new TextEncoder();
    const data = encoder.encode(cmdWithPrefix + '\n'); // Add newline for command termination
    await this.writer.write(data);

    // Wait for response
    return responsePromise;
  }

  /**
   * Fire `{!}` at the device without waiting for a response, so the device's
   * pfodParser resets its dedup state before the next connect (see
   * HTTPConnection.sendAbort() for the full rationale).
   *
   * Best-effort only: unlike the fetch-based adapters there is no `keepalive`
   * equivalent for a Web Serial write, so on a page unload the bytes may never
   * leave the host.  Every failure mode here (writer already released, port
   * closing, device gone) is expected on that path and is swallowed —
   * ConnectionManager.sendAbort() calls this fire-and-forget.
   */
  async sendAbort() {
    if (!this.writer) return;
    const cmdWithPrefix = getCurrentDedupChar() + '{!}';
    try {
      const encoder = new TextEncoder();
      await this.writer.write(encoder.encode(cmdWithPrefix + '\n'));
      console.log('[SERIAL_CONNECTION] sent {!} on abort');
    } catch (e) {
      // best-effort; port/page may be on its way out.
    }
  }

  /**
   * Disconnect from the serial port.
   * Fires {!} first (so the device resets its dedup state before the next
   * connect) then tears down reader / writer / port.
   */
  async disconnect() {
    console.log('[SERIAL_CONNECTION] Disconnecting...');

    await this.sendAbort();
    this.connected = false;

    try {
      // Cancel reader and wait for startReading() to exit before releasing the lock.
      // reader.cancel() causes the pending reader.read() to resolve with done:true, but
      // startReading() processes that as a microtask — awaiting _readingPromise ensures
      // the loop has fully exited before releaseLock() is called, avoiding the
      // "outstanding read requests" error that would prevent port.close() from running.
      if (this.reader) {
        await this.reader.cancel();
        if (this._readingPromise) {
          await this._readingPromise.catch(() => {});
          this._readingPromise = null;
        }
        this.reader.releaseLock();
        this.reader = null;
      }

      // Release writer
      if (this.writer) {
        this.writer.releaseLock();
        this.writer = null;
      }

      // Close port.  this.port is deliberately KEPT: a closed SerialPort can
      // be re-opened, and dropping it here would strand both
      // forceReconnect() (which logs "Port reference lost - cannot
      // reconnect") and send()'s auto-reconnect, since the picker can no
      // longer be re-run without a fresh user gesture.
      if (this.port) {
        await this.port.close();
      }

      console.log('[SERIAL_CONNECTION] Disconnected successfully');
    } catch (error) {
      console.error('[SERIAL_CONNECTION] Error during disconnect:', error);
      throw error;
    }
  }

  /**
   * Check if serial connection is active
   */
  isConnected() {
    return this.connected && this.port !== null;
  }

  /**
   * Force-close and re-open the serial port to reset communication
   * Used when connection appears stuck after timeout
   * Does not prompt user - reuses existing port with same settings
   */
  async forceReconnect() {
    console.error('[SERIAL_CONNECTION] Force-reconnecting serial port...');

    try {
      // Cancel and release reader
      if (this.reader) {
        try {
          await this.reader.cancel();
          this.reader.releaseLock();
        } catch (e) {
          console.error('[SERIAL_CONNECTION] Reader cancel/release error (may be stuck):', e);
        }
        this.reader = null;
      }

      // Release writer
      if (this.writer) {
        try {
          this.writer.releaseLock();
        } catch (e) {
          console.error('[SERIAL_CONNECTION] Writer release error:', e);
        }
        this.writer = null;
      }

      // Close port if open
      if (this.port) {
        try {
          await this.port.close();
          console.error('[SERIAL_CONNECTION] Port closed');
        } catch (e) {
          console.error('[SERIAL_CONNECTION] Port close error:', e);
        }
      }

      // Wait a moment for the port to fully close
      await new Promise(resolve => setTimeout(resolve, 100));

      // Re-open the port with same settings
      if (this.port) {
        try {
          await this.port.open({
            baudRate: this.baudRate,
            dataBits: this.dataBits,
            stopBits: this.stopBits,
            parity: this.parity,
            flowControl: this.flowControl
          });
          console.error('[SERIAL_CONNECTION] Port re-opened successfully');

          // Get new reader and writer
          this.reader = this.port.readable.getReader();
          this.writer = this.port.writable.getWriter();
          this.connected = true;

          // Reset first request flag for new connection
          this.firstRequest = true;
          console.error('[SERIAL_CONNECTION] Serial connection re-engaged, firstRequest flag reset');

          // Fresh decoder for each reconnect so no stale partial-character state carries over
          this._decoder = new TextDecoder('utf-8', { fatal: false });

          // Start reading loop
          this._readingPromise = this.startReading();

          return true;
        } catch (reopenError) {
          console.error('[SERIAL_CONNECTION] Failed to re-open port:', reopenError);
          this.connected = false;
          return false;
        }
      } else {
        console.error('[SERIAL_CONNECTION] Port reference lost - cannot reconnect');
        this.connected = false;
        return false;
      }
    } catch (error) {
      console.error('[SERIAL_CONNECTION] Force-reconnect error:', error);
      this.connected = false;
      return false;
    }
  }
}

/**
 * BLEConnection - Adapter for BLE protocol using the Web Bluetooth API.
 *
 * Used when the connection prompt's BLE "Connect via" is set to "This
 * browser" — i.e. the browser exposes navigator.bluetooth and the user opted
 * out of pfodProxy.  Selected in ConnectionManager.initializeAdapter() by
 * config.useProxy === false; otherwise BLEProxyConnection is used.
 *
 * As with SerialConnection, the device picker is NOT run here:
 * navigator.bluetooth.requestDevice() requires transient user activation, so
 * the prompt's "Select BLE Device" button calls it and passes the chosen
 * BluetoothDevice in as config.nativeBleDevice.
 */
class BLEConnection extends PfodConnectionBase {
  constructor(config, connectionManager) {
    super();
    this.protocol = 'ble';
    this.config = config;
    this.connectionManager = connectionManager;
    // Pre-selected by the connection prompt (see class doc).
    this.device = config.nativeBleDevice || null;
    // bleAddress feeds ConnectionManager.getConnectionId() (the per-device
    // localStorage menu-cache key) and bleName the connecting dialog.  Web
    // Bluetooth never exposes a real MAC, so the prompt passes device.id —
    // an opaque per-origin identifier, but stable for this browser profile,
    // which is exactly what the cache key needs.
    this.bleAddress = config.bleAddress || null;
    this.bleName    = config.bleName || null;
    this.server = null;
    this.service = null;
    this.characteristicTX = null;
    this.characteristicRX = null;
    this.connected = false;
    this.readBuffer = '';
    this.responseResolve = null;
    this.responseReject = null;
    // Persistent decoder so multi-byte UTF-8 characters split across BLE notifications decode correctly
    this._decoder = new TextDecoder('utf-8', { fatal: false });
    this.timeoutId = null;  // Store timeout ID so it can be cancelled

    // UART Service UUIDs (Nordic UART Service)
    this.UART_SERVICE_UUID = '6E400001-B5A3-F393-E0A9-E50E24DCCA9E'.toLowerCase();
    this.UART_TX_CHAR_UUID = '6E400002-B5A3-F393-E0A9-E50E24DCCA9E'.toLowerCase();
    this.UART_RX_CHAR_UUID = '6E400003-B5A3-F393-E0A9-E50E24DCCA9E'.toLowerCase();



    console.log(`[BLE_CONNECTION] Created with UART service filtering`);
  }

  /**
   * Connect to the BLE device the connection prompt already picked for us.
   * The picker runs in the prompt's "Select BLE Device" click handler
   * (requestDevice() requires transient user activation), so this only has to
   * run the GATT setup — see connectToDevice().
   */
  async connect() {
    // Fresh decoder for each connect so no stale partial-character state carries over
    this._decoder = new TextDecoder('utf-8', { fatal: false });
    try {
      // Check if Web Bluetooth API is supported
      if (!('bluetooth' in navigator)) {
        const errorMsg = 'Web Bluetooth API is not supported in this browser.\n\n' +
                        'Bluetooth connections require:\n' +
                        '• Chrome (version 56 or later)\n' +
                        '• Edge (version 79 or later)\n' +
                        '• Opera (version 43 or later)\n\n' +
                        'Please use a supported browser for Bluetooth connections,\n' +
                        'or switch "Connect via" back to pfodProxy.';
        throw new Error(errorMsg);
      }

      if (!this.device) {
        throw new Error('No BLE device selected.\n\n' +
                        'Click "Select BLE Device" and choose the device to use.');
      }

      try {
        await this.connectToDevice(this.device);
      } catch (connectError) {
        console.error('[BLE_CONNECTION] Device connection failed:', connectError);

        const errorMsg = 'BLE device could not be connected. Please ensure:\n' +
                        '1. The device is powered on\n' +
                        '2. The device is within range\n' +
                        '3. The device is advertising the UART service\n\n' +
                        connectError.message;
        throw new Error(errorMsg);
      }

      console.log('[BLE_CONNECTION] BLE connection established successfully');

    } catch (error) {
      console.error('[BLE_CONNECTION] Connection failed:', error);
      throw error;
    }
  }

  /**
   * Connect to a specific BLE device and set up characteristics
   */
  async connectToDevice(device) {
    console.log(`[BLE_CONNECTION] Connecting to device: ${device.name || 'Unknown Device'}`);

    // Set up disconnect listener
    device.addEventListener('gattserverdisconnected', () => this.onDisconnected());

    // Show the same connecting modal the proxy adapter uses, with
    // per-phase status text driven by the JS await boundaries here.
    // Hide on completion or any thrown error in this block.
    //
    // Address is passed as '' deliberately: Web Bluetooth never gives us a
    // MAC, only the opaque per-origin device.id, which means nothing to the
    // user — so the dialog shows the device name alone.
    this._showConnectingDialog(this.bleName || device.name || 'BLE device', '');
    // Cancel button: drop the GATT link.  Whichever step is currently
    // awaiting (gatt.connect / getPrimaryService / startNotifications)
    // rejects as a result, which propagates out of connect() as a normal
    // connection failure and returns the user to the prompt.
    this._cancelConnect = () => {
      try { device.gatt.disconnect(); } catch (_) {}
      this._hideConnectingDialog();
    };
    try {
      this._updateConnectingDialog('connecting');
      this.server = await device.gatt.connect();
      console.log('[BLE_CONNECTION] Connected to GATT Server');

      this._updateConnectingDialog('discovering');
      this.service = await this.server.getPrimaryService(this.UART_SERVICE_UUID);
      console.log('[BLE_CONNECTION] UART Service discovered');

      this.characteristicRX = await this.service.getCharacteristic(this.UART_RX_CHAR_UUID);
      console.log('[BLE_CONNECTION] RX Characteristic discovered');

      // Set up notification handler
      this.characteristicRX.addEventListener('characteristicvaluechanged', (event) => {
        this.handleCharacteristicChange(event);
      });

      this._updateConnectingDialog('subscribing');
      await this.characteristicRX.startNotifications();
      console.log('[BLE_CONNECTION] Notifications started');

      // Get TX characteristic (we transmit, device receives)
      this.characteristicTX = await this.service.getCharacteristic(this.UART_TX_CHAR_UUID);
      console.log('[BLE_CONNECTION] TX Characteristic discovered');

      this.connected = true;
      this.device = device;
    } finally {
      this._hideConnectingDialog();
    }
  }

  /**
   * Handle disconnect event
   */
  onDisconnected() {
    console.log('[BLE_CONNECTION] Device disconnected');
    this.connected = false;
    this.server = null;
    this.service = null;
    this.characteristicTX = null;
    this.characteristicRX = null;
    // Reset decoder so stale partial-character state from the dropped connection
    // doesn't corrupt the first bytes received on a subsequent reconnect.
    this._decoder = new TextDecoder('utf-8', { fatal: false });
  }

  /**
   * Handle incoming data from BLE device
   * Buffers data until complete response is received
   */
  handleCharacteristicChange(event) {
    const text = this._decoder.decode(event.target.value, { stream: true });
    console.log(`[BLE_CONNECTION] Received data: ${text}`);

    // NOTE: Do NOT reset timeout here - timeout should apply to the entire response,
    // not reset on partial data. Only clear timeout when complete response is received
    // in processReadBuffer()

    // Feed data through shared pipeline: csvCollector, rawDataCollector, processReadBuffer
    this.processIncoming(text);
  }

  /**
   * Send a command via BLE with internal retry logic
   * Retries up to maxRetries times using the same dedup character
   * Only advances dedup on final success
   * @param {string} cmd - The pfod command (e.g., "{.}" or "{dwgName}")
   * @returns {Promise<string>} - Response text (usually JSON)
   */
  async send(cmd) {
    // Auto-connect if not already connected
    if (!this.connected || !this.characteristicTX) {
      console.log('[BLE_CONNECTION] Not connected, connecting now...');
      await this.connect();
    }

    // Diagnostic logging: Check if a previous request is still pending
    if (this.responseResolve || this.responseReject) {
      console.warn(`[BLE_CONNECTION] WARNING: send() called while previous request still pending`);
      console.warn(`[BLE_CONNECTION] This should not happen - queue protection may not be working`);
    }

    // Get dedup character atomically - getCurrentDedupChar() increments for next call
    const cmdWithPrefix = getCurrentDedupChar() + cmd;
    // {!} is the exit/abort command — fire once, never retry (see HTTPAdapter.send).
    const maxRetries = (cmd === '{!}') ? 0 : this.connectionManager.getMaxRetries();
    let lastError = null;

    console.log(`[BLE_CONNECTION] Allocated dedup='${cmdWithPrefix[0]}' for this send()`);

    // Clear response state once at the start - keep accumulated data across retries
    this.readBuffer = '';

    // Retry loop: attempt up to (maxRetries + 1) times
    // Data continues to accumulate in readBuffer across retry attempts
    // All retries use the SAME cmdWithPrefix (dedup already captured)
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        console.log(`[BLE_CONNECTION] Send attempt ${attempt + 1}/${maxRetries + 1}: ${cmdWithPrefix}`);

        // Cancel any previous timeout
        if (this.timeoutId) {
          clearTimeout(this.timeoutId);
          console.log(`[BLE_CONNECTION] Cancelled previous timeout`);
          this.timeoutId = null;
        }

        // NOTE: readBuffer is NOT cleared here - it persists across retries
        // This allows partial responses to accumulate if retries occur

        const responseText = await this.sendOnceInternal(cmdWithPrefix, cmd);

        // Success! Return response (dedup already allocated and advanced at start)
        console.log(`[BLE_CONNECTION] Success on attempt ${attempt + 1} with dedup='${cmdWithPrefix[0]}'`);
        return responseText;
      } catch (error) {
        lastError = error;
        console.warn(`[BLE_CONNECTION] Attempt ${attempt + 1}/${maxRetries + 1} failed: ${error.message}`);

        // If this was the last attempt, throw the error
        if (attempt >= maxRetries) {
          console.error(`[BLE_CONNECTION] All ${maxRetries + 1} attempts exhausted with dedup='${cmdWithPrefix[0]}'. Throwing error back to queue.`);
          throw error;
        }
        // User clicked Exit while we were retrying — abandon remaining attempts.
        if (this.connectionManager.exitPending) {
          console.warn(`[BLE_CONNECTION] exitPending — abandoning ${maxRetries - attempt} remaining retr${(maxRetries - attempt) === 1 ? 'y' : 'ies'}`);
          throw error;
        }

        // Always wait at least 1 s before retrying, regardless of which
        // error triggered the retry — see sleep() doc comment.
        await sleep(1000);

        // Otherwise, retry with same dedup character
        console.log(`[BLE_CONNECTION] Retrying with same dedup='${cmdWithPrefix[0]}'...`);
      }
    }

  }

  /**
   * Send command once via BLE (no retries)
   * @private
   */
  async sendOnceInternal(cmdWithPrefix, originalCmd) {
    // Record send time for performance measurement
    this.sendTime = Date.now();

    // Set up promise for response
    const responsePromise = new Promise((resolve, reject) => {
      this.responseResolve = resolve;
      this.responseReject = reject;

      // Get timeout from connection manager (default 10 seconds)
      const timeout = this.connectionManager.getResponseTimeout();
      console.log(`[BLE_CONNECTION] Setting response timeout to ${timeout === 0 ? 'never' : timeout + 'ms'}`);
      if (timeout !== 0) this.timeoutId = setTimeout(() => {
        if (this.responseReject) {
          if (this.readBuffer.length > 0 && ConnectionManager.messageCollector) {
            ConnectionManager.messageCollector.addMessage('timeout', this.readBuffer, this.protocol);
          }
          this.readBuffer = '';
          this.responseReject(new Error('BLE response timeout - device may not be responding'));
          this.responseResolve = null;
          this.responseReject = null;
          this.timeoutId = null;
        }
      }, timeout);
    });

    // Send the command
    console.log(`[BLE_CONNECTION] Sending: ${cmdWithPrefix} at ${new Date(this.sendTime).toISOString()}`);

    // Record the command being sent (with the dedup prefix)
    if (ConnectionManager.messageCollector) {
      ConnectionManager.messageCollector.addMessage('sent', cmdWithPrefix, 'ble', originalCmd);
    }

    const encoder = new TextEncoder();
    const data = encoder.encode(cmdWithPrefix + '\n'); // Add newline for command termination
    await this.characteristicTX.writeValue(data);

    // Wait for response
    return responsePromise;
  }

  /**
   * Fire `{!}` at the device without waiting for a response so its pfodParser
   * resets its dedup state before the next connect — same purpose as
   * HTTPConnection.sendAbort(), and best-effort for the same reason as
   * SerialConnection.sendAbort() (a GATT write has no `keepalive` equivalent,
   * so on a page unload it may never go out).
   */
  async sendAbort() {
    if (!this.characteristicTX) return;
    const cmdWithPrefix = getCurrentDedupChar() + '{!}';
    try {
      const encoder = new TextEncoder();
      await this.characteristicTX.writeValue(encoder.encode(cmdWithPrefix + '\n'));
      console.log('[BLE_CONNECTION] sent {!} on abort');
    } catch (e) {
      // best-effort; link/page may be on its way out.
    }
  }

  /**
   * Disconnect from the BLE device.
   * Fires {!} first, then drops notifications and the GATT link.  this.device
   * is deliberately kept — the BluetoothDevice stays valid after a GATT
   * disconnect, so send()'s auto-reconnect can re-establish the link without
   * sending the user back through the picker.
   */
  async disconnect() {
    console.log('[BLE_CONNECTION] Disconnecting...');

    await this.sendAbort();
    this.connected = false;

    try {
      // Stop notifications
      if (this.characteristicRX) {
        await this.characteristicRX.stopNotifications();
        console.log('[BLE_CONNECTION] Notifications stopped');
      }

      // Disconnect GATT server
      if (this.server && this.server.connected) {
        this.server.disconnect();
        console.log('[BLE_CONNECTION] GATT server disconnected');
      }

      // Clear references
      this.server = null;
      this.service = null;
      this.characteristicTX = null;
      this.characteristicRX = null;

      console.log('[BLE_CONNECTION] Disconnected successfully');
    } catch (error) {
      console.error('[BLE_CONNECTION] Error during disconnect:', error);
      throw error;
    }
  }

  /**
   * Check if BLE connection is active
   */
  isConnected() {
    return this.connected && this.server && this.server.connected;
  }
}

// DesignerVirtualAdapter lives under designer/adapter.js — the entire
// designer subsystem stays self-contained.  The 'designer' case in
// initializeAdapter() above references it as a runtime global, which
// works as long as the build includes designer/adapter.js (it must
// load AFTER connectionManager.js because the adapter extends
// PfodConnectionBase, defined here).

// Make classes available globally for browser use
window.ConnectionManager = ConnectionManager;
window.HTTPConnection = HTTPConnection;
window.SerialConnection      = SerialConnection;      // native Web Serial (useProxy === false)
window.SerialProxyConnection = SerialProxyConnection;
window.TCPProxyConnection    = TCPProxyConnection;
window.BLEProxyConnection    = BLEProxyConnection;
window.BLEConnection         = BLEConnection;         // native Web Bluetooth (useProxy === false)
/*
   csvCollector.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Exports:    window.CSVCollector class
// Depends on: nothing (pure data collector, no DOM or other module dependencies)
// Called by:  connectionManager.js feeds characters via processCharacters();
//             keepAliveAndHttp.js creates window.csvCollector instance;
//             chartDisplay.js and chartAndRawData.js read data via window.csvCollector

/**
 * CSVCollector - Processes raw character stream to extract CSV data
 * Operates independently from message fragmentation
 *
 * CSV Data Detection:
 * - Starts after } (closing brace of pfod command) or after line terminator
 * - Ends at line terminator (\r, \n, or \r\n)
 * - Ignored inside {} (pfod commands)
 *
 * Organization:
 * - Separated into files by field count (# of commas + 1)
 * - Each CSV line stored with UTC arrival timestamp (ms since epoch)
 * - Timestamps NOT included in default export, available in 3 timestamp formats:
 *   * ms values (milliseconds since epoch)
 *   * Z timestamps (UTC ISO 8601)
 *   * Local time (browser local timezone)
 */
class CSVCollector {
  constructor() {
    this.csvByFieldCount = {}; // { fieldCount: [{line: "...", timestampMs: 1731693045123}, ...], ... }
    this.currentLine = '';     // Buffer for the current CSV line being built
                               // (only OUTSIDE bytes reach here; the
                               // connection layer owns {..} framing).

    // Per-fieldCount time anchor used by chartDisplay's TimeFormatUtil to
    // turn relative (< 2^40 ms) timestamps into wall-clock dates in place
    // of the pfod {@} response (which pfodWeb does not send).
    //
    // Each entry pairs:
    //   firstLineMs    — parsed numeric value of field[0] of the first
    //                    PARSEABLE line of this fieldCount.  field[0] is
    //                    assumed to be the X-axis (the typical layout for
    //                    streaming time-series CSVs).  Header rows that
    //                    don't parse as numeric / date are skipped.
    //   firstLineTimeMs — Date.now() when that same parseable line arrived.
    //
    // chartDisplay computes baseTimeMs = firstLineTimeMs - firstLineMs
    // and passes it to TimeFormatUtil; adding any later line's ms then
    // gives that line's wall-clock time, with the first parseable line
    // mapping exactly to its arrival instant.
    //
    // Cleared by clear() on reconnect so each session captures its own.
    this.firstAnchors = {};    // { fieldCount: {firstLineMs, firstLineTimeMs} }
    // console.log('[CSV_COLLECTOR Created - character-stream CSV extraction');
  }

  /**
   * Process a string character-by-character from raw device data
   * Called from SerialConnection.startReading() and BLEConnection.handleCharacteristicChange()
   * BEFORE message fragmentation for { } extraction
   * @param {string} text - Raw text from device
   */
  processCharacters(text) {
    for (let i = 0; i < text.length; i++) {
      this.processChar(text[i]);
    }
  }

  /**
   * Process a single character from the raw stream
   * @param {string} char - Single character
   */
  processChar(char) {
    // The connection-layer OUTSIDE/INSIDE byte state machine now owns all
    // {..} command framing — this collector is only ever handed OUTSIDE
    // (raw) bytes, never command bytes.  So no brace tracking here: a CSV
    // line is just text terminated by \r/\n.  The connection layer calls
    // resetLine() at every OUTSIDE->INSIDE boundary so a partial line
    // interrupted by a {..} command is discarded (raw-only), never glued to
    // the post-command bytes.
    if (char === '\r' || char === '\n') {
      if (this.currentLine.trim().length > 0) {
        this.addCSVLine(this.currentLine.trim());
      }
      this.currentLine = '';
      return;
    }
    this.currentLine += char;
  }

  /**
   * Discard the in-progress (non-newline-terminated) CSV line WITHOUT
   * emitting it.  Called by the connection-layer byte machine at every
   * OUTSIDE->INSIDE transition: bytes accumulated before a {..} command are
   * raw data only (already sent to rawData/messageCollector) and must never
   * become a CSV line nor concatenate with the bytes that follow the command.
   */
  resetLine() {
    this.currentLine = '';
  }

  /**
   * Add a complete CSV line to the appropriate bucket based on field count
   * Captures UTC arrival timestamp (ms since epoch)
   * @param {string} line - The complete CSV line (trimmed)
   */
  addCSVLine(line) {
    // Count fields: # of commas + 1
    const fields = line.split(',');
    const fieldCount = fields.length;

    // Initialize bucket if needed
    if (!this.csvByFieldCount[fieldCount]) {
      this.csvByFieldCount[fieldCount] = [];
      // console.log('[CSV_COLLECTOR New CSV format detected: ${fieldCount} fields`);
    }

    // Store line with arrival timestamp (ms since epoch)
    const timestampMs = Date.now();
    this.csvByFieldCount[fieldCount].push({
      line: line,
      timestampMs: timestampMs
    });

    // Capture this fieldCount's time anchor on the first parseable line.
    // Header rows whose first field doesn't parse (e.g. "date") are
    // skipped — the next line that parses sets the anchor.  Once set
    // for a given fieldCount, the anchor is sticky for the session.
    if (this.firstAnchors[fieldCount] === undefined) {
      const firstLineMs = this._parseAnchorValue(fields[0]);
      if (!isNaN(firstLineMs)) {
        this.firstAnchors[fieldCount] = {
          firstLineMs: firstLineMs,
          firstLineTimeMs: timestampMs
        };
      }
    }
    // console.log('[CSV_COLLECTOR Added line (${fieldCount} fields): ${line.substring(0, 60)}${line.length > 60 ? '...' : ''}`);
  }

  /**
   * Parse a CSV X-field (field[0]) for the time-anchor calculation.
   * Mirrors chartDisplay's TimeFormatUtil.parseValue() — kept inline so
   * CSVCollector doesn't depend on chartDisplay's bundle-load order.
   *
   * Returns NaN for unparseable input.  Numeric strings → parseFloat.
   * yyyy/MM/dd[ HH:mm[:ss[.SSS]]] / ISO-8601 → ms since epoch.
   *
   * @private
   */
  _parseAnchorValue(str) {
    if (str === null || str === undefined) return NaN;
    const trimmed = String(str).trim();
    if (trimmed === '') return NaN;
    if (/^-?\d+(?:\.\d+)?$/.test(trimmed)) return parseFloat(trimmed);
    const m = trimmed.match(
      /^(\d{4})[/-](\d{1,2})[/-](\d{1,2})(?:[T ](\d{1,2}):(\d{1,2})(?::(\d{1,2})(?:\.(\d{1,3}))?)?)?$/
    );
    if (m) {
      const y  = parseInt(m[1], 10);
      const mo = parseInt(m[2], 10) - 1;
      const d  = parseInt(m[3], 10);
      const h  = m[4] !== undefined ? parseInt(m[4], 10) : 0;
      const mi = m[5] !== undefined ? parseInt(m[5], 10) : 0;
      const s  = m[6] !== undefined ? parseInt(m[6], 10) : 0;
      const ms = m[7] !== undefined ? parseInt((m[7] + '000').substring(0, 3), 10) : 0;
      return new Date(y, mo, d, h, mi, s, ms).getTime();
    }
    const native = Date.parse(trimmed);
    if (!isNaN(native)) return native;
    return NaN;
  }

  /**
   * Get all field counts that have been collected
   * @returns {array} - Sorted array of field counts
   */
  getFieldCounts() {
    return Object.keys(this.csvByFieldCount)
      .map(k => parseInt(k))
      .sort((a, b) => a - b);
  }

  /**
   * Get CSV lines for a specific field count
   * @param {number} fieldCount - Number of fields
   * @returns {array} - Array of CSV line strings
   */
  getCSVLines(fieldCount) {
    if (!(fieldCount in this.csvByFieldCount)) {
      throw new Error(`[CSV_COLLECTOR] getCSVLines: no data collected for fieldCount ${fieldCount}`);
    }
    return this.csvByFieldCount[fieldCount].map(entry => entry.line);
  }

  /**
   * Get CSV entries (line + timestamp) for a specific field count
   * @param {number} fieldCount - Number of fields
   * @returns {array} - Array of {line, timestampMs} objects
   */
  getCSVEntriesWithTimestamps(fieldCount) {
    if (!(fieldCount in this.csvByFieldCount)) {
      throw new Error(`[CSV_COLLECTOR] getCSVEntriesWithTimestamps: no data collected for fieldCount ${fieldCount}`);
    }
    return this.csvByFieldCount[fieldCount];
  }

  /**
   * Get number of lines for a specific field count
   * @param {number} fieldCount - Number of fields
   * @returns {number} - Line count
   */
  getLineCount(fieldCount) {
    return this.getCSVLines(fieldCount).length;
  }

  /**
   * Export CSV data for a specific field count as plain text (DEFAULT - no timestamps)
   * Format: Line1\nLine2\nLine3...
   * NO timestamps, headers, or other metadata - just CSV lines
   * @param {number} fieldCount - Number of fields
   * @returns {string} - Plain text CSV data without timestamps
   */
  exportAsText(fieldCount) {
    const lines = this.getCSVLines(fieldCount);
    return lines.length > 0 ? lines.join('\n') : '';
  }

  /**
   * Export CSV data with ms timestamps prepended
   * Format: timestampMs,field1,field2...\ntimestampMs,field1,field2...
   * @param {number} fieldCount - Number of fields
   * @returns {string} - CSV data with ms timestamps as first column
   */
  exportAsTextWithMs(fieldCount) {
    const entries = this.getCSVEntriesWithTimestamps(fieldCount);
    if (entries.length === 0) return '';
    return entries.map(entry => {
      return `${entry.timestampMs},${entry.line}`;
    }).join('\n');
  }

  /**
   * Export CSV data with UTC Z timestamps prepended
   * Format: 2025-11-15T14:30:45.123Z,field1,field2...\n...
   * @param {number} fieldCount - Number of fields
   * @returns {string} - CSV data with Z timestamps (UTC) as first column
   */
  exportAsTextWithZTimestamps(fieldCount) {
    const entries = this.getCSVEntriesWithTimestamps(fieldCount);
    if (entries.length === 0) return '';
    return entries.map(entry => {
      const timestamp = new Date(entry.timestampMs).toISOString();
      return `${timestamp},${entry.line}`;
    }).join('\n');
  }

  /**
   * Export CSV data with local time timestamps prepended
   * Format: 2025-11-15 14:30:45.123,field1,field2...\n...
   * @param {number} fieldCount - Number of fields
   * @returns {string} - CSV data with local time timestamps as first column
   */
  exportAsTextWithLocalTimestamps(fieldCount) {
    const entries = this.getCSVEntriesWithTimestamps(fieldCount);
    if (entries.length === 0) return '';
    return entries.map(entry => {
      const date = new Date(entry.timestampMs);
      // Format: YYYY-MM-DD HH:MM:SS.mmm (local time)
      const year = date.getFullYear();
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const day = String(date.getDate()).padStart(2, '0');
      const hours = String(date.getHours()).padStart(2, '0');
      const minutes = String(date.getMinutes()).padStart(2, '0');
      const seconds = String(date.getSeconds()).padStart(2, '0');
      const ms = String(date.getMilliseconds()).padStart(3, '0');
      const localTimestamp = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}.${ms}`;
      return `${localTimestamp},${entry.line}`;
    }).join('\n');
  }

  /**
   * Export all CSV data organized by field count
   * @returns {object} - { fieldCount: "line1\nline2\n...", ... }
   */
  exportAll() {
    const result = {};
    for (const fieldCount of this.getFieldCounts()) {
      const text = this.exportAsText(fieldCount);
      if (text.length > 0) {
        result[fieldCount] = text;
      }
    }
    return result;
  }

  /**
   * Get statistics about collected CSV data
   * @returns {object} - Stats by field count
   */
  getStats() {
    const stats = {};
    for (const fieldCount of this.getFieldCounts()) {
      const lines = this.getCSVLines(fieldCount);
      stats[fieldCount] = {
        fieldCount: fieldCount,
        lineCount: lines.length,
        totalBytes: lines.reduce((sum, line) => sum + line.length, 0)
      };
    }
    return stats;
  }

  /**
   * Get total statistics
   * @returns {object} - Total counts
   */
  getTotalStats() {
    const stats = this.getStats();
    let totalLines = 0;
    let totalBytes = 0;
    for (const fieldCount of this.getFieldCounts()) {
      totalLines += stats[fieldCount].lineCount;
      totalBytes += stats[fieldCount].totalBytes;
    }
    return {
      totalLines: totalLines,
      totalBytes: totalBytes,
      formatCount: Object.keys(stats).length
    };
  }

  /**
   * Clear all collected CSV data
   */
  clear() {
    this.csvByFieldCount = {};
    this.currentLine = '';
    // Reset per-fieldCount anchors so a fresh session captures its own.
    this.firstAnchors = {};
    // console.log('[CSV_COLLECTOR Cleared all CSV data');
  }
}

// Make class available globally for browser use
window.CSVCollector = CSVCollector;
/*
   rawDataCollector.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Exports:    window.RawDataCollector class
// Depends on: nothing (pure data collector, no DOM or other module dependencies)
// Called by:  connectionManager.js feeds characters via processCharacters();
//             keepAliveAndHttp.js creates window.rawDataCollector instance;
//             chartAndRawData.js reads data via window.rawDataCollector;
//             responseHandlers.js reads data via window.rawDataCollector.getRawDataWithoutClearing()

/**
 * RawDataCollector - Processes raw character stream to collect ALL data outside {...}
 * Operates independently from message fragmentation
 *
 * Raw Data Collection:
 * - Collects ALL characters outside {} (pfod commands)
 * - Preserves all data including newlines, spaces, etc.
 * - Accumulates continuously as device sends data
 * - Resets when new raw data display session starts
 */
class RawDataCollector {
  constructor() {
    this.rawData = '';        // All collected raw data (OUTSIDE bytes only —
                              // the connection layer owns {..} framing).
    this.lastReturnedLength = 0; // Track how much data we've already returned for display
    // console.log('[RAW_DATA_COLLECTOR Created - character-stream raw data extraction');
  }

  /**
   * Process a string character-by-character from raw device data
   * Called from SerialConnection.startReading() and BLEConnection.handleCharacteristicChange()
   * BEFORE message fragmentation for { } extraction
   * @param {string} text - Raw text from device
   */
  processCharacters(text) {
    // console.log('[RAW_DATA_COLLECTOR processCharacters called with ${text.length} chars: ${JSON.stringify(text.substring(0, 50))}`);
    for (let i = 0; i < text.length; i++) {
      this.processChar(text[i]);
    }
  }

  /**
   * Process a single character from the raw stream
   * @param {string} char - Single character
   */
  processChar(char) {
    // The connection-layer OUTSIDE/INSIDE byte state machine owns all {..}
    // command framing — this collector is only ever handed OUTSIDE (raw)
    // bytes, so just accumulate every char verbatim (newlines, spaces, the
    // CSV/raw stream as the device sent it).
    this.rawData += char;
  }

  /**
   * Get all collected raw data
   * @returns {string} - All collected raw data
   */
  getRawData() {
    return this.rawData;
  }

  /**
   * Get raw data WITHOUT clearing it
   * The collector continues accumulating as more data arrives
   * @returns {string} - All collected raw data
   */
  getRawDataWithoutClearing() {
    // console.log('[RAW_DATA_COLLECTOR getRawDataWithoutClearing called - returning ${this.rawData.length} chars`);
    return this.rawData;
  }

  /**
   * Get ONLY new data since we started tracking for display
   * Used to append new chunks to the raw data display without duplication
   * @returns {string} - Only the newly arrived data since last display update
   */
  getNewData() {
    const newData = this.rawData.substring(this.lastReturnedLength);
    // console.log('[RAW_DATA_COLLECTOR getNewData called - returning ${newData.length} new chars (total: ${this.rawData.length}, returned before: ${this.lastReturnedLength})`);
    return newData;
  }

  /**
   * Mark that we've displayed data up to the current point
   * Call this after creating/updating the display to track progress
   */
  markDisplayedUpTo() {
    this.lastReturnedLength = this.rawData.length;
    // console.log('[RAW_DATA_COLLECTOR Marked display progress at ${this.lastReturnedLength} chars`);
  }

  /**
   * Get raw data and clear it (for consumption by raw data display)
   * @returns {string} - All collected raw data
   */
  extractAndClearRawData() {
    const data = this.rawData;
    this.rawData = '';
    // console.log('[RAW_DATA_COLLECTOR Extracted and cleared ${data.length} chars of raw data`);
    return data;
  }

  /**
   * Clear all collected raw data
   */
  clear() {
    this.rawData = '';
    this.lastReturnedLength = 0;
    // console.log('[RAW_DATA_COLLECTOR Cleared all raw data');
  }

  /**
   * Get statistics about collected data
   * @returns {object} - Stats about raw data
   */
  getStats() {
    return {
      totalBytes: this.rawData.length,
      lineCount: (this.rawData.match(/\n/g) || []).length
    };
  }
}

// Make class available globally for browser use
window.RawDataCollector = RawDataCollector;
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * @namespace
 */
var jsfc = {};

jsfc.JSFreeChart = { version: "0.5", NS: "http://www.jfree.org/jsfreechart" };
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

if (typeof define === "function" && define.amd) define(jsfc); else if (typeof module === "object" && module.exports) module.exports = jsfc;/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * A set of functions used to perform general argument checking.
 * @namespace
 */
jsfc.Args = {};

/**
 * Throws an error if the argument is undefined.
 * 
 * @param {*} arg  the argument.
 * @param {string} label  the argument name (displayed in the error message).
 * @returns {Object} This object (for chaining method calls).
 */
jsfc.Args.require = function(arg, label) {
    if (arg === null) {
        throw new Error("Require argument '" + label + "' to be specified.");
    }
    return jsfc.Args;
};

/**
 * Throws an error if the argument is not a number.
 * 
 * @param {*} arg  the argument.
 * @param {string} label  the argument name (displayed in the error message).
 * @returns {Object} This object (for chaining method calls).
 */
jsfc.Args.requireNumber = function(arg, label) {
    if (typeof arg !== "number") {
        throw new Error("Require '" + label + "' to be a number.");
    }
    return jsfc.Args;
};

/**
 * Throws an error if the argument is not a finite positive number.
 * 
 * @param {*} arg  the argument.
 * @param {string} label  the argument name (displayed in the error message).
 * @returns {Object} This object (for chaining method calls).
 */
jsfc.Args.requireFinitePositiveNumber = function(arg, label) {
    if (typeof arg !== "number" || arg <= 0) {
        throw new Error("Require '" + label + "' to be a positive number.");
    }
    return jsfc.Args;
};

/**
 * Checks that a number is in a required range (inclusive of the end points).
 * 
 * @param {!number} arg  the argument.
 * @param {!string} label  the label (used for the error message, if required).
 * @param {!number} min  the minimum permitted value.
 * @param {!number} max  the maximum permitted value.
 * @returns This object for chaining function calls.
 */
jsfc.Args.requireInRange = function(arg, label, min, max) {
    jsfc.Args.requireNumber(arg, label);
    if (arg < min || arg > max) {
        throw new Error("Require '" + label + "' to be in the range " + min 
                + " to " + max);
    }
    return jsfc.Args;
};

/**
 * Throws an error if the argument is not a string.
 * 
 * @param {*} arg  the argument.
 * @param {string} label  the argument name (displayed in the error message).
 * @returns {Object} This object (for chaining method calls).
 */
jsfc.Args.requireString = function(arg, label) {
    if (typeof arg !== "string") {
        throw new Error("Require '" + label + "' to be a string.");
    }
    return jsfc.Args;
};

/**
 * Throws an error if the argument is not a KeyedValuesDataset.
 * @param {*} arg  the argument.
 * @param {string} label  the argument name (used in the error message).
 * @returns {Object} This object (for chaining method calls).
 */
jsfc.Args.requireKeyedValuesDataset = function(arg, label) {
    if (!(arg instanceof jsfc.KeyedValuesDataset)) {
        throw new Error("Require '" + label 
                + "' to be an requireKeyedValuesDataset.");
    }
    return jsfc.Args;
};

/**
 * Throws an error if the argument is not a KeyedValues2DDataset.
 * @param {*} arg  the argument.
 * @param {string} label  the argument name (used in the error message).
 * @returns {Object} This object (for chaining method calls).
 */
jsfc.Args.requireKeyedValues2DDataset = function(arg, label) {
    if (!(arg instanceof jsfc.KeyedValues2DDataset)) {
        throw new Error("Require '" + label + "' to be a KeyedValues2DDataset.");
    }
    return jsfc.Args;
};

/**
 * Throws an error if the argument is not an XYDataset.
 * @param {*} arg
 * @param {string} label
 * @returns {Object} This object (for chaining method calls).
 */
jsfc.Args.requireXYDataset = function(arg, label) {
    //    FIXME: we'll support arbitrary implementations of the XYDataset interface
    //    so we need a way to test that the argument is really implementing this
    //    (or maybe give up trying to validate this)
//    if (!(arg instanceof jsfc.XYDataset)) {
//        throw new Error("Require '" + label + "' to be an XYDataset.");
//    }
    return jsfc.Args;
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * General utility functions.
 * @namespace
 */
jsfc.Utils = {};

/**
 * Creates an array of the specified length, with each element in the array
 * initialised to the specified value.
 * 
 * @param {*} value
 * @param {number} length
 * @returns {Array}
 */
jsfc.Utils.makeArrayOf = function(value, length) {
    var arr = [], i = length;
    while (i--) {
        arr[i] = value;
    }
    return arr;
};

/**
 * Returns the index of the first item in array for which the matcher function
 * returns true, or -1 if there is no match.
 * 
 * @param {Array} items  an array
 * @param {function(*, number)} matcher  a matching function (receives the array item and the array index as parameters), should return true or false.

 * @returns {number}  The index of the first item that matches, or -1.
 */
jsfc.Utils.findInArray = function(items, matcher) {
    var length = items.length;
    for (var i = 0; i < length; i++) {
        if (matcher(items[i], i)) {
            return i;
        }
    }
    return -1;
};

/**
 * Returns the index of an item within an array.
 * 
 * @param {*} item  the item.
 * @param {Array} arr  the array.
 * @returns {!number} The index of the item, or -1 if the item is not present
 *     in the array.
 */
jsfc.Utils.findItemInArray = function(item, arr) {
    return jsfc.Utils.findInArray(arr, function(x, i) {
        return x === item; 
    });
};

/**
 * Returns true if running on MacOS and false otherwise.
 * 
 * @returns {boolean} A boolean.
 */
jsfc.Utils.isMacOS = function() {
    return navigator.appVersion.indexOf("Mac") !== -1;
};

/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * Creates a new color.
 * @class Represents a color with red, green, blue and alpha components.
 * Color instances are intended to be immutable so that they can be shared
 * (for example, the jsfc.Colors class contains some predefined colors) - do 
 * not modify existing instances.
 * 
 * @constructor
 * @param {number} red  the red component (0-255).
 * @param {number} green  the green component (0-255).
 * @param {number} blue  the blue component (0-255).
 * @param {number} [alpha]  the alpha component (0-255), defaults to 255.
 * 
 * @returns {undefined}
 */
jsfc.Color = function(red, green, blue, alpha) {
    if (!(this instanceof jsfc.Color)) {
        throw new Error("Use 'new' for constructor.");
    }
    jsfc.Args.requireInRange(red, "red", 0, 255);
    this._red = red;
    this._green = green;
    this._blue = blue;
    this._alpha = alpha === 0 ? 0 : alpha || 255;
};

/**
 * Returns the red component for the color.
 * @returns {number} The red component (in the range 0 to 255). 
 */
jsfc.Color.prototype.getRed = function() {
    return this._red;
};

/**
 * Returns the green component for the color.
 * @returns {number} The green component (in the range 0 to 255).
 */
jsfc.Color.prototype.getGreen = function() {
    return this._green;
};

/**
 * Returns the blue component for the color.
 * @returns {number} The blue component (in the range 0 to 255).
 */
jsfc.Color.prototype.getBlue = function() {
    return this._blue;
};

/**
 * Returns the alpha (transparency) component for the color.
 * @returns {number} The alpha component (in the range 0 to 255).
 */
jsfc.Color.prototype.getAlpha = function() {
    return this._alpha;
};

/**
 * Creates a new color instance from a string.
 * @param {!string} s  the string.
 * @returns {jsfc.Color|undefined}
 */
jsfc.Color.fromStr = function(s) {
    if (s.length === 4) {
        // #RGB
        var rr = s[1] + s[1];
        var gg = s[2] + s[2];
        var bb = s[3] + s[3];
        var r = parseInt(rr, 16);
        var g = parseInt(gg, 16);
        var b = parseInt(bb, 16);
        return new jsfc.Color(r, g, b);
    } 
    if (s.length === 7) {
        // #RRGGBB 
        var rr = s[1] + s[2];
        var gg = s[3] + s[4];
        var bb = s[5] + s[6];
        var r = parseInt(rr, 16);
        var g = parseInt(gg, 16);
        var b = parseInt(bb, 16);
        return new jsfc.Color(r, g, b);
    }
    return undefined;
};

/**
 * Returns a string in the form 'rgba(RGBA)' that represents this color.
 * 
 * @returns {!string}
 */
jsfc.Color.prototype.rgbaStr = function() {
    var alphaPercent = this._alpha / 255;
    return "rgba(" + this._red + "," + this._green + "," + this._blue
        + "," + alphaPercent.toFixed(2) + ")";    
};

/**
 * Returns a string in the form 'rgba(RGBA)' that represents this color.
 * 
 * @returns {!string}
 */
jsfc.Color.prototype.rgbStr = function() {
    return "rgb(" + this._red + "," + this._green + "," + this._blue + ")";    
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

jsfc.Colors = {};

/** The color white. */
jsfc.Colors.WHITE = new jsfc.Color(255, 255, 255);

/** The color black. */
jsfc.Colors.BLACK = new jsfc.Color(0, 0, 0);

/** The color red. */
jsfc.Colors.RED = new jsfc.Color(255, 0, 0);

/** The color green. */
jsfc.Colors.GREEN = new jsfc.Color(0, 255, 0);

/** The color blue. */
jsfc.Colors.BLUE = new jsfc.Color(0, 0, 255);

/** The color yellow. */
jsfc.Colors.YELLOW = new jsfc.Color(255, 255, 0);

/** The color light gray. */
jsfc.Colors.LIGHT_GRAY = new jsfc.Color(192, 192, 192);

/**
 * Creates and returns an array of color strings.
 * 
 * @returns {Array} An array of color strings.
 */
jsfc.Colors.fancyLight = function() {
    return ["#64E1D5", "#E2D75E", "#F0A4B5", "#E7B16D", "#C2D58D", "#CCBDE4",
            "#6DE4A8", "#93D2E2", "#AEE377", "#A0D6B5"];
};

/**
 * Creates and returns an array of color strings.
 * 
 * @returns {Array} An array of color strings.
 */
jsfc.Colors.fancyDark = function() {
    return ["#3A6163", "#8A553A", "#4A6636", "#814C57", "#675A6F", "#384027",
            "#373B43", "#59372C", "#306950", "#665D31"];
};

/**
 * Creates and returns an array of color strings.
 * 
 * @returns {Array} An array of color strings.
 */
jsfc.Colors.iceCube = function() {
    return ["#4CE4B7", "#45756F", "#C2D9BF", "#58ADAF", "#4EE9E1", "#839C89",
            "#3E8F74", "#92E5C1", "#99E5E0", "#57BDAB"];
};

/**
 * Creates and returns an array of color strings.
 * 
 * @returns {Array} An array of color strings.
 */
jsfc.Colors.blueOcean = function() {
    return ["#6E7094", "#4F76DF", "#292E39", "#2E4476", "#696A72",  "#4367A6",
            "#5E62B7", "#42759A", "#2E3A59", "#4278CA"];
};

/**
 * Converts an array of color strings into an array of the corresponding
 * Color objects.
 * 
 * @param {Array} colors  the array of color strings.
 * 
 * @returns {Array} An array of color objects.
 */
jsfc.Colors.colorsAsObjects = function(colors) {
    return colors.map(function(s) {
        return jsfc.Color.fromStr(s);
    });    
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * Creates a new instance.
 * @class Represents a point in two dimensional space.  Instances are immutable.
 * 
 * @constructor
 * @param {!number} x  the x-coordinate.
 * @param {!number} y  the y-coordinate.
 * @returns {jsfc.Point2D}
 */
jsfc.Point2D = function(x, y) {
    if (!(this instanceof jsfc.Point2D)) {
        throw new Error("Use 'new' for constructor.");
    }
    jsfc.Args.requireNumber(x, "x");
    jsfc.Args.requireNumber(y, "y");
    this._x = x;
    this._y = y;
    Object.freeze(this);
};
    
/**
 * Returns the x-coordinate for this point.
 * 
 * @returns {number} The x-coordinate.
 */
jsfc.Point2D.prototype.x = function() {
    return this._x;
};
    
/**
 * Returns the y-coordinate for this point.
 * 
 * @returns {number} The y-coordinate.
 */
jsfc.Point2D.prototype.y = function() {
    return this._y;
};

/**
 * Returns the distance between this point and the point (x, y).
 * 
 * @param {!number} x  the x-coordinate.
 * @param {!number} y  the y-coordinate.
 * @returns {!number} The distance.
 */
jsfc.Point2D.prototype.distance = function(x, y) {
    var dx = x - this._x;
    var dy = y - this._y;
    return Math.sqrt(dx * dx + dy * dy);
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * @class Represents a rectangle in 2D space.
 * 
 * @param {!number} x  the x-coordinate.
 * @param {!number} y  the y-coordinate.
 * @param {!number} width  the width.
 * @param {!number} height  the height.
 * @constructor
 */
jsfc.Rectangle = function(x, y, width, height) {
    if (!(this instanceof jsfc.Rectangle)) {
        throw new Error("Use 'new' for constructor.");
    }
    jsfc.Args.requireNumber(x, "x");
    jsfc.Args.requireNumber(y, "y");
    jsfc.Args.requireNumber(width, "width");
    jsfc.Args.requireNumber(height, "height");
    
    this._x = x;
    this._y = y;
    this._width = width;
    this._height = height;
};

/**
 * Creates a new rectangle with the same coordinates and dimensions as the 
 * specified rectangle.
 * 
 * @param {jsfc.Rectangle} rect  the rectangle to copy.
 * 
 * @returns {!jsfc.Rectangle} The new rectangle.
 */
jsfc.Rectangle.copy = function(rect) {
    return new jsfc.Rectangle(rect.x(), rect.y(), rect.width(), 
            rect.height());
};

/**
 * Returns the x-coordinate.
 *
 * @returns {number}
 */
jsfc.Rectangle.prototype.x = function() {
    return this._x;
};
    
/**
 * Returns the y-coordinate.
 *
 * @returns {number}
 */
jsfc.Rectangle.prototype.y = function() {
    return this._y;
};
    
/**
 * Returns the width.
 *
 * @returns {number}
 */
jsfc.Rectangle.prototype.width = function() {
    return this._width;
};
    
/**
 * Returns the height.
 * 
 * @returns {number}
 */
jsfc.Rectangle.prototype.height = function() {
    return this._height;
};

/**
 * Returns the length of one side of the rectangle.
 * 
 * @param {!string} edge  the edge ("TOP", "LEFT", "BOTTOM" or "RIGHT").
 * 
 * @returns {number}
 */
jsfc.Rectangle.prototype.length = function(edge) {
    if (edge === jsfc.RectangleEdge.TOP 
            || edge === jsfc.RectangleEdge.BOTTOM) {
        return this._width;
    } else if (edge === jsfc.RectangleEdge.LEFT 
            || edge === jsfc.RectangleEdge.RIGHT) {
        return this._height;
    }
    throw new Error("Unrecognised 'edge' value: " + edge);
};
    
/**
 * Returns the x-coordinate for the center point of the rectangle.
 * 
 * @returns {number} The central x-coordinate.
 */
jsfc.Rectangle.prototype.centerX = function() {
    return this._x + (this._width / 2);
};

/**
 * Returns the minimum x-value for the rectangle.
 * 
 * @returns {number} The minimum x-value.
 */
jsfc.Rectangle.prototype.minX = function() {
    return Math.min(this._x, this._x + this._width);    
};
    
/**
 * Returns the maximum x-value for the rectangle.
 * 
 * @returns {number} The maximum x-value.
 */
jsfc.Rectangle.prototype.maxX = function() {
    return Math.max(this._x, this._x + this._width);
};

/**
 * Returns the y-coordinate for the center point of the rectangle.
 * 
 * @returns {number} The central y-coordinate.
 */
jsfc.Rectangle.prototype.centerY = function() {
    return this._y + (this._height / 2);
};
    
/**
 * Returns the minimum y-value for the rectangle.
 * 
 * @returns {number} The minimum y-value.
 */
jsfc.Rectangle.prototype.minY = function() {
    return Math.min(this._y, this._y + this._height);
};
    
/**
 * Returns the maximum y-value for the rectangle.
 * 
 * @returns {number} The maximum y-value.
 */
jsfc.Rectangle.prototype.maxY = function() {
    return Math.max(this._y, this._y + this._height);
};
    
/**
 * Returns the bounds for this shape.
 * 
 * @returns {jsfc.Rectangle} The bounds.
 */
jsfc.Rectangle.prototype.bounds = function() {
    return new jsfc.Rectangle(this._x, this._y, this._width, this._height);
};

/**
 * Updates the coordinates and dimensions for the rectangle.
 * 
 * @param {number} x  the new x-coordinate.
 * @param {number} y  the new y-coordinate.
 * @param {number} w  the new width.
 * @param {number} h  the new height.
 * @returns {jsfc.Rectangle} Returns this rectangle (for chaining method calls).
 */
jsfc.Rectangle.prototype.set = function(x, y, w, h) {
    this._x = x;
    this._y = y;
    this._width = w;
    this._height = h;
    return this;
};
    
/**
 * Returns the closest point on or inside the rectangle to the specified 
 * point (x, y).
 * 
 * @param {!number} x  the x-coordinate.
 * @param {!number} y  the y-coordinate.
 * @returns {!jsfc.Point2D} A new point.
 */
jsfc.Rectangle.prototype.constrainedPoint = function(x, y) {
    jsfc.Args.requireNumber(x, "x");
    jsfc.Args.requireNumber(y, "y");
    var xx = Math.max(this.minX(), Math.min(x, this.maxX()));
    var yy = Math.max(this.minY(), Math.min(y, this.maxY()));
    return new jsfc.Point2D(xx, yy);  
};

/**
 * Returns true if the specified point falls on or inside the rectangle,
 * and false otherwise.
 * 
 * @param {!number} x  the x-coordinate.
 * @param {!number} y  the y-coordinate.
 * @returns {!boolean} A boolean.
 */
jsfc.Rectangle.prototype.contains = function(x, y) {
    return x >= this._x && x <= this._x + this._width 
            && y >= this._y && y <= this._y + this._height;
};

/**
 * Returns true if the specified rectangle 'r' is contained within the bounds 
 * of this rectangle.
 * 
 * @param {!jsfc.Rectangle} r  the rectangle.
 * @returns {!boolean} A boolean.
 */
jsfc.Rectangle.prototype.containsRect = function(r) {
    return this.contains(r.minX(), r.minY()) 
            && this.contains(r.maxX(), r.maxY());  
};/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/** 
 * Creates a new object representing the dimensions of a shape in 2D space.
 * Instances of this class are immutable.
 * 
 * @constructor 
 * @classdesc The dimensions of a shape in 2D space.  Instances are immutable.
 * @param {!number} w  the width.
 * @param {!number} h  the height.
 * @returns {jsfc.Dimension} The new instance.
 */
jsfc.Dimension = function(w, h) {
    if (!(this instanceof jsfc.Dimension)) {
        throw new Error("Use 'new' for constructor.");
    }
    jsfc.Args.requireNumber(w, "w");
    jsfc.Args.requireNumber(h, "h");
    this._width = w;
    this._height = h;
    Object.freeze(this);
};
    
/**
 * Returns the width that was set in the constructor.
 * 
 * @returns {!number} The width.
 */
jsfc.Dimension.prototype.width = function() {
    return this._width;
};
    
/**
 * Returns the height that was set in the constructor.
 * 
 * @returns {!number} The height.
 */
jsfc.Dimension.prototype.height = function() {
    return this._height;
};

/**
 * Returns a string representation of this object, primarily for debugging 
 * purposes.
 * 
 * @returns {String}
 */
jsfc.Dimension.prototype.toString = function() {
    return "[Dimension(" + this._width + ", " + this._height + ")]";  
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

jsfc.HAlign = {
    
    LEFT: 1,
    
    CENTER: 2,
    
    RIGHT: 3

};

if (Object.freeze) {
    Object.freeze(jsfc.HAlign);
}/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * An enumeration of the four edges of a rectangle (TOP, BOTTOM, LEFT and 
 * RIGHT).
 */
jsfc.RectangleEdge = {
    
    TOP: "TOP",
    
    BOTTOM: "BOTTOM",
    
    LEFT: "LEFT",
    
    RIGHT: "RIGHT"

};

/**
 * Returns true if the specified edge is TOP or BOTTOM, and false otherwise.
 * 
 * @param {!string} edge  the edge.
 * @returns {!boolean} A boolean.
 */
jsfc.RectangleEdge.isTopOrBottom = function(edge) {
    jsfc.Args.requireString(edge, "edge");
    if (edge === jsfc.RectangleEdge.TOP 
            || edge === jsfc.RectangleEdge.BOTTOM) {
        return true;
    }
    return false;
};

/**
 * Returns true if the specified edge is "LEFT" or "RIGHT", and false otherwise.
 * 
 * @param {!string} edge  the edge code.
 * @returns {!boolean} A boolean.
 */
jsfc.RectangleEdge.isLeftOrRight = function(edge) {
    jsfc.Args.requireString(edge, "edge");
    if (edge === jsfc.RectangleEdge.LEFT || edge === jsfc.RectangleEdge.RIGHT) {
        return true;
    }
    return false;
};

if (Object.freeze) {
    Object.freeze(jsfc.RectangleEdge);
}/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * Creates a new object representing the insets for a rectangular 
 *         shape.
 *         
 * @classdesc The insets for a rectangular shape in 2D space.  Instances are
 *         immutable.
 * 
 * @constructor 
 * @param {!number} top  the insets for the top edge.
 * @param {!number} left  the insets for the left edge.
 * @param {!number} bottom  the insets for the bottom edge.
 * @param {!number} right  the insets for the right edge.
 * @returns {jsfc.Insets} The new instance.
 */
jsfc.Insets = function(top, left, bottom, right) {
    if (!(this instanceof jsfc.Insets)) {
        throw new Error("Use 'new' for constructor.");
    }
    jsfc.Args.requireNumber(top, "top");
    jsfc.Args.requireNumber(left, "left");
    jsfc.Args.requireNumber(bottom, "bottom");
    jsfc.Args.requireNumber(right, "right");
    this._top = top;
    this._left = left;
    this._bottom = bottom;
    this._right = right;
    Object.freeze(this);
};

/**
 * Returns the insets for the top edge.
 * @returns {!number} The top insets.
 */
jsfc.Insets.prototype.top = function() {
    return this._top;
};

/**
 * Returns the insets for the left edge.
 * @returns {!number} The left insets.
 */
jsfc.Insets.prototype.left = function() {
    return this._left;
};

/**
 * Returns the insets for the bottom edge.
 * @returns {!number} The bottom insets.
 */
jsfc.Insets.prototype.bottom = function() {
    return this._bottom;
};

/**
 * Returns the insets for the right edge.
 * @returns {!number} The right insets.
 */
jsfc.Insets.prototype.right = function() {
    return this._right;
};

/**
 * Returns the insets value for the specified edge (specified using the 
 * constants defined in jsfc.RectangleEdge).
 * 
 * @param {String} edge
 * @returns {!number} The insets value.
 */
jsfc.Insets.prototype.value = function(edge) {
    if (edge === jsfc.RectangleEdge.TOP) {
        return this._top;
    }
    if (edge === jsfc.RectangleEdge.BOTTOM) {
        return this._bottom;
    }
    if (edge === jsfc.RectangleEdge.LEFT) {
        return this._left;
    }
    if (edge === jsfc.RectangleEdge.RIGHT) {
        return this._right;
    }
    throw new Error("Unrecognised edge code: " + edge);
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/** 
 * Creates a new object representing an offset in 2D space. Instances are 
 * immutable.
 * 
 * @constructor 
 * @classdesc An offset in 2D space.  Instances are immutable.
 * @param {number} dx  the x-offset.
 * @param {number} dy  the y-offset.
 * @returns {jsfc.Offset2D} The new instance.
 */
jsfc.Offset2D = function(dx, dy) {
    if (!(this instanceof jsfc.Offset2D)) {
        throw new Error("Use 'new' for constructors.");
    }
    jsfc.Args.requireNumber(dx, "dx");
    jsfc.Args.requireNumber(dy, "dy");
    this._dx = dx;
    this._dy = dy;
    Object.freeze(this);
};
    
/**
 * Returns the x-offset that was set in the constructor.
 * 
 * @returns {number} The width.
 */
jsfc.Offset2D.prototype.dx = function() {
    return this._dx;
};
    
/**
 * Returns the y-offset that was set in the constructor.
 * 
 * @returns {number} The y-offset.
 */
jsfc.Offset2D.prototype.dy = function() {
    return this._dy;
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * An enumeration of the scaling options for a rectangular shape being fitted 
 * within 2D bounds.
 * 
 * @type Object
 */
jsfc.Scale2D = {
    
    /** No scaling. */
    NONE: 1,
    
    /** Scale horizontally (but not vertically). */
    SCALE_HORIZONTAL: 2,
    
    /** Scale vertically (but not horizontally). */
    SCALE_VERTICAL: 3, 
    
    /** Scale both horizontally and vertically. */
    SCALE_BOTH: 4

};

if (Object.freeze) {
    Object.freeze(jsfc.Scale2D);
}/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * @class A utility object that fits a source rectangle into a target 
 *     rectangle with optional scaling.
 * 
 * @constructor
 * @param {jsfc.Anchor2D} anchor  the anchor point.
 * @param {number} [scale]  the scaling type (optional, defaults to NONE).
 * 
 * @returns {jsfc.Fit2D}
 */
jsfc.Fit2D = function(anchor, scale) {
    if (!(this instanceof jsfc.Fit2D)) {
        throw new Error("Use 'new' for constructor.");
    }
    this._anchor = anchor;
    this._scale = scale || jsfc.Scale2D.NONE;
};
    
/**
 * Returns the anchor used for the fitting.
 * 
 * @returns {jsfc.Anchor2D}
 */
jsfc.Fit2D.prototype.anchor = function() {
    return this._anchor;
};
   
/**
 * Returns the scaling type (constants defined in jsfc.Scale2D).
 * 
 * @returns {number}
 */
jsfc.Fit2D.prototype.scale = function() {
    return this._scale;
};
    
/**
 * Returns a new rectangle that is fitted to the target according to the
 * anchor and scale attributes of this fitter.
 * 
 * @param {!jsfc.Dimension} srcDim  the dimensions of the source rectangle.
 * @param {!jsfc.Rectangle} target  the target rectangle.
 * @returns {!jsfc.Rectangle} The rectangle.
 */
jsfc.Fit2D.prototype.fit = function(srcDim, target) {
    if (this._scale === jsfc.Scale2D.SCALE_BOTH) {
        return jsfc.Rectangle.copy(target);
    }
    var w = srcDim.width();
    if (this._scale === jsfc.Scale2D.SCALE_HORIZONTAL) {
        w = target.width();
        if (!jsfc.RefPt2D.isHorizontalCenter(this._anchor.refPt())) {
            w -= 2 * this._anchor.offset().dx();
        }
    }
    var h = srcDim.height();
    if (this._scale === jsfc.Scale2D.SCALE_VERTICAL) {
        h = target.height();
        if (!jsfc.RefPt2D.isVerticalCenter(this._anchor.refPt())) {
            h -= 2 * this._anchor.offset().dy();
        }
    }
    var pt = this._anchor.anchorPoint(target);
    var x = Number.NaN; 
    if (jsfc.RefPt2D.isLeft(this._anchor.refPt())) {
        x = pt.x();
    } else if (jsfc.RefPt2D.isHorizontalCenter(this._anchor.refPt())) {
        x = target.centerX() - w / 2;
    } else if (jsfc.RefPt2D.isRight(this._anchor.refPt())) {
        x = pt.x() - w;
    }
    var y = Number.NaN;
    if (jsfc.RefPt2D.isTop(this._anchor.refPt())) {
        y = pt.y();
    } else if (jsfc.RefPt2D.isVerticalCenter(this._anchor.refPt())) {
        y = target.centerY() - h / 2;
    } else if (jsfc.RefPt2D.isBottom(this._anchor.refPt())) {
        y = pt.y() - h;
    }
    return new jsfc.Rectangle(x, y, w, h);    
};

/**
 * Creates an returns a fitter that performs no scaling and fits a rectangle
 * to the given anchor point.
 * 
 * @param {!jsfc.RefPt2D} refPt  the anchor.
 * @returns {!jsfc.Fit2D} The fitter.
 */
jsfc.Fit2D.prototype.noScalingFitter = function(refPt) {
    var anchor = new jsfc.Anchor2D(refPt, new jsfc.Offset2D(0, 0));
    return new jsfc.Fit2D(anchor, jsfc.Scale2D.NONE);
};/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/** 
 * Creates a new stroke instance with default attributes.
 * 
 * @classdesc A stroke represents the style used to draw a line or path.
 * 
 * @constructor 
 * @param {number} [lineWidth]  the line width (defaults to 1.0).
 * @returns {jsfc.Stroke} The new instance.
 */
jsfc.Stroke = function(lineWidth) {
    if (!(this instanceof jsfc.Stroke)) {
        throw new Error("Use 'new' for constructors.");
    }
    this.lineWidth = lineWidth || 1.0;
    this.lineCap = jsfc.LineCap.ROUND;
    this.lineJoin = jsfc.LineJoin.ROUND;
    this.miterLimit = 1.0;
    this.lineDash = [1.0];
    this.lineDashOffset = 0.0; 
};

jsfc.Stroke.prototype.setLineDash = function(dash) {
    this.lineDash = dash;
};

/**
 * Returns a string containing the SVG style string representing this stroke.
 * 
 * @returns {!string} The SVG style string.
 */
jsfc.Stroke.prototype.getStyleStr = function() {
    var s = "stroke-width: " + this.lineWidth + "; ";
    if (this.lineCap !== "butt") {
        s = s + "stroke-linecap: " + this.lineCap + "; ";
    }
    s = s + "stroke-linejoin: " + this.lineJoin + "; ";
    if (this.lineDash.length > 1) {
        s = s + "stroke-dasharray: " + "3, 3" + "; ";
    }
    return s;
};/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * An enumeration of the standard reference points for a single line text item.
 * @type Object
 */
jsfc.TextAnchor = {
    
    /** The top left corner of the text bounds. */
    TOP_LEFT: 0,

    /** The center of the top edge of the text bounds. */
    TOP_CENTER: 1,

    /** The top right corner of the text bounds. */
    TOP_RIGHT: 2,

    /**
     * The left edge of a horizontal line through the midpoint of the font's
     * ascent.
     */
    HALF_ASCENT_LEFT: 3,

    /**
     * The center point of a horizontal line through the midpoint of the font's
     * ascent.
     */
    HALF_ASCENT_CENTER: 4,

    /**
     * The right edge of a horizontal line through the midpoint of the font's
     * ascent.
     */
    HALF_ASCENT_RIGHT: 5,

    /** The mid-point of the left edge of the text bounding box. */
    CENTER_LEFT: 6,

    /** The center of the text bounding box. */
    CENTER: 7,

    /** The mid-point of the right edge of the text bounding box. */
    CENTER_RIGHT: 8,

    /** The left edge of the text baseline. */
    BASELINE_LEFT: 9,

    /** The mid-point of the text baseline. */
    BASELINE_CENTER: 10,

    /** The right edge of the text baseline. */
    BASELINE_RIGHT: 11,

    /** The bottom left corner of the text bounds. */
    BOTTOM_LEFT: 12,

    /** The center of the bottom edge of the text bounds. */
    BOTTOM_CENTER: 13,

    /** The bottom right corner of the text bounds. */
    BOTTOM_RIGHT: 14,

    /**
     * Returns true if the specified anchor is a "left" anchor, and false 
     * otherwise.
     * 
     * @param {!number} anchor  the anchor.
     * @returns {!boolean}
     */
    isLeft: function(anchor) {
        return anchor === jsfc.TextAnchor.TOP_LEFT 
                || anchor === jsfc.TextAnchor.CENTER_LEFT
                || anchor === jsfc.TextAnchor.HALF_ASCENT_LEFT 
                || anchor === jsfc.TextAnchor.BASELINE_LEFT
                || anchor === jsfc.TextAnchor.BOTTOM_LEFT;
    },

    /**
     * Returns true if the specified anchor is a "center" anchor, and false 
     * otherwise.
     * 
     * @param {!number} anchor  the anchor.
     * @returns {!boolean}
     */
    isHorizontalCenter: function(anchor) {
        return anchor === jsfc.TextAnchor.TOP_CENTER 
                || anchor === jsfc.TextAnchor.CENTER
                || anchor === jsfc.TextAnchor.HALF_ASCENT_CENTER 
                || anchor === jsfc.TextAnchor.BASELINE_CENTER
                || anchor === jsfc.TextAnchor.BOTTOM_CENTER;
    },

    /**
     * Returns true if the specified anchor is a "right" anchor, and false 
     * otherwise.
     * 
     * @param {!number} anchor  the anchor.
     * @returns {!boolean}
     */
    isRight: function(anchor) {
        return anchor === jsfc.TextAnchor.TOP_RIGHT 
                || anchor === jsfc.TextAnchor.CENTER_RIGHT
                || anchor === jsfc.TextAnchor.HALF_ASCENT_RIGHT 
                || anchor === jsfc.TextAnchor.BASELINE_RIGHT
                || anchor === jsfc.TextAnchor.BOTTOM_RIGHT;
    },

    /**
     * Returns true if the specified anchor is a "top" anchor, and false 
     * otherwise.
     * 
     * @param {!number} anchor  the anchor.
     * @returns {!boolean}
     */
    isTop: function(anchor) {
        return anchor === jsfc.TextAnchor.TOP_LEFT 
                || anchor === jsfc.TextAnchor.TOP_CENTER 
                || anchor === jsfc.TextAnchor.TOP_RIGHT;
    },

    /**
     * Returns true if the specified anchor is a "half ascent" anchor, and 
     * false otherwise.
     * 
     * @param {!number} anchor  the anchor.
     * @returns {!boolean}
     */
    isHalfAscent: function(anchor) {
        return anchor === jsfc.TextAnchor.HALF_ASCENT_LEFT 
                || anchor === jsfc.TextAnchor.HALF_ASCENT_CENTER
                || anchor === jsfc.TextAnchor.HALF_ASCENT_RIGHT;
    },

    /**
     * Returns true if the specified anchor is a "center" anchor (vertically), 
     * and false otherwise.
     * 
     * @param {!number} anchor  the anchor.
     * @returns {!boolean}
     */
    isHalfHeight: function(anchor) {
        return anchor === jsfc.TextAnchor.CENTER_LEFT 
                || anchor === jsfc.TextAnchor.CENTER 
                || anchor === jsfc.TextAnchor.CENTER_RIGHT;
    },

    /**
     * Returns true if the specified anchor is a "baseline" anchor (vertically), 
     * and false otherwise.
     * 
     * @param {!number} anchor  the anchor.
     * @returns {!boolean}
     */
    isBaseline: function(anchor) {
        return anchor === jsfc.TextAnchor.BASELINE_LEFT 
                || anchor === jsfc.TextAnchor.BASELINE_CENTER
                || anchor === jsfc.TextAnchor.BASELINE_RIGHT;
    },

    /**
     * Returns true if the specified anchor is a "bottom" anchor, 
     * and false otherwise.
     * 
     * @param {!number} anchor  the anchor.
     * @returns {!boolean}
     */
    isBottom: function(anchor) {
        return anchor === jsfc.TextAnchor.BOTTOM_LEFT 
                || anchor === jsfc.TextAnchor.BOTTOM_CENTER
                || anchor === jsfc.TextAnchor.BOTTOM_RIGHT;
    }
};

if (Object.freeze) {
    Object.freeze(jsfc.TextAnchor);
}/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/** 
 * Creates a new font instance.
 * 
 * @classdesc A font represents the font style used to draw text.
 * 
 * @constructor
 * @param {!string} family  the font family.
 * @param {!number} size  the size.
 * @param {boolean} [bold]  bold?
 * @param {boolean} [italic]  italic?
 * @returns {jsfc.Font} The new instance.
 */
jsfc.Font = function(family, size, bold, italic) {
    if (!(this instanceof jsfc.Font)) {
        throw new Error("Use 'new' for constructors.");
    }
    this.family = family;
    this.size = size;
    this.bold = bold || false;
    this.italic = italic || false;
};

/**
 * Returns a font style string derived from this font's settings.
 * 
 * @returns {string} The style string.
 */
jsfc.Font.prototype.styleStr = function() {
    var s = "font-family: " + this.family + "; ";
    s += "font-weight: " + (this.bold ? "bold" : "normal") + "; ";
    s += "font-style: " + (this.italic ? "italic" : "normal") + "; ";
    s += "font-size: " + this.size + "px";
    return s;
};

/**
 * Returns a font style string for use with an HTML5 Canvas context.
 * 
 * @returns {!string} The style string.
 */
jsfc.Font.prototype.canvasFontStr = function() {
    return this.size + "px " + this.family;
};/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

jsfc.LineCap = {
    
    BUTT: "butt",
    
    ROUND: "round",
    
    SQUARE: "square"

};

if (Object.freeze) {
    Object.freeze(jsfc.LineCap);
}/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

jsfc.LineJoin = {
    
    ROUND: "round",
    
    BEVEL: "bevel",
    
    MITER: "miter"

};

if (Object.freeze) {
    Object.freeze(jsfc.LineJoin);
}
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * An enumeration of the standard reference points for a rectangle.
 * @type Object
 */
jsfc.RefPt2D = {
    
    TOP_LEFT: 1,
  
    /** The middle of a rectangle at the top. */
    TOP_CENTER: 2,
  
    /** The top-right corner of a rectangle. */
    TOP_RIGHT: 3,
  
    /** The middle of a rectangle at the left side. */
    CENTER_LEFT: 4,
  
    /** The center of a rectangle. */
    CENTER: 5,
  
    /** The middle of a rectangle at the right side. */
    CENTER_RIGHT: 6,
  
    /** The bottom-left corner of a rectangle. */
    BOTTOM_LEFT: 7, 
  
    /** The middle of a rectangle at the bottom. */
    BOTTOM_CENTER: 8,
  
    /** The bottom-right corner of a rectangle. */
    BOTTOM_RIGHT : 9,

    /**
     * Returns true if refpt is one of the left-side points and false otherwise.
     * 
     * @param {!number} refpt  the reference point.
     * @returns {boolean}
     */
    isLeft: function(refpt) {
        return refpt === jsfc.RefPt2D.TOP_LEFT 
                || refpt === jsfc.RefPt2D.CENTER_LEFT 
                || refpt === jsfc.RefPt2D.BOTTOM_LEFT;
    },
    
    /**
     * Returns true if refpt is one of the right-side points and false otherwise.
     * 
     * @param {!number} refpt  the reference point.
     * @returns {boolean}
     */
    isRight: function(refpt) {
        return refpt === jsfc.RefPt2D.TOP_RIGHT 
                || refpt === jsfc.RefPt2D.CENTER_RIGHT 
                || refpt === jsfc.RefPt2D.BOTTOM_RIGHT;
    },
    
    /**
     * Returns true if refpt is one of the top points and false otherwise.
     * 
     * @param {!number} refpt  the reference point.
     * @returns {boolean}
     */
    isTop: function(refpt) {
        return refpt === jsfc.RefPt2D.TOP_LEFT 
                || refpt === jsfc.RefPt2D.TOP_CENTER 
                || refpt === jsfc.RefPt2D.TOP_RIGHT;
    },
    
    /**
     * Returns true if refpt is one of the bottom points and false otherwise.
     * 
     * @param {!number} refpt  the reference point.
     * @returns {boolean}
     */
    isBottom: function(refpt) {
        return refpt === jsfc.RefPt2D.BOTTOM_LEFT 
                || refpt === jsfc.RefPt2D.BOTTOM_CENTER 
                || refpt === jsfc.RefPt2D.BOTTOM_RIGHT;
    },

    /**
     * Returns true if refpt is one of the center (horizontally) points and 
     * false otherwise.
     * 
     * @param {!number} refpt  the reference point.
     * @returns {boolean}
     */
    isHorizontalCenter: function(refpt) {
        return refpt === jsfc.RefPt2D.TOP_CENTER 
                || refpt === jsfc.RefPt2D.CENTER 
                || refpt === jsfc.RefPt2D.BOTTOM_CENTER;  
    },
    
    /**
     * Returns true if refpt is one of the center (vertically) points and 
     * false otherwise.
     * 
     * @param {!number} refpt  the reference point.
     * @returns {boolean}
     */
    isVerticalCenter: function(refpt) {
        return refpt === jsfc.RefPt2D.CENTER_LEFT 
                || refpt === jsfc.RefPt2D.CENTER 
                || refpt === jsfc.RefPt2D.CENTER_RIGHT;
    }
};

if (Object.freeze) {
    Object.freeze(jsfc.RefPt2D);
}/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Creates a new anchor.
 * 
 * @class An anchor point defined relative to a rectangle in two-dimensional 
 * space (the point coordinates can be resolved once a concrete rectangle is 
 * provided).
 * @constructor 
 * @param {!number} refpt  the reference point on the rectangle.
 * @param {jsfc.Offset2D} [offset]  the offset to the rectangle (positive 
 *     deltas move to the interior of the rectangle).  If this argument is
 *     not supplied, it defaults to a zero offset.
 * @returns {jsfc.Anchor2D}
 */
jsfc.Anchor2D = function(refpt, offset) {
    if (!(this instanceof jsfc.Anchor2D)) {
        throw new Error("Use 'new' for constructor.");
    }
    jsfc.Args.requireNumber(refpt, "refpt"); 
    this._refpt = refpt;
    this._offset = offset || new jsfc.Offset2D(0, 0);
};

/**
 * Returns the reference point for the anchor (one of the numerical 
 * constants defined in jsfc.RefPt2D).
 * 
 * @return {number}
 */
jsfc.Anchor2D.prototype.refPt = function() {
    return this._refpt;
};
    
/**
 * Returns the offset for the anchor.
 * 
 * @returns {jsfc.Offset2D}
 */
jsfc.Anchor2D.prototype.offset = function() {
    return this._offset;
};

/**
 * Returns a Point2D that is the anchor point for the supplied rectangle.
 * @param {jsfc.Rectangle} rect  the reference rectangle.
 * @returns {jsfc.Point2D}
 */
jsfc.Anchor2D.prototype.anchorPoint = function(rect) {
    var x = 0.0;
    var y = 0.0;
    if (jsfc.RefPt2D.isLeft(this._refpt)) {
        x = rect.x() + this._offset.dx();
    } else if (jsfc.RefPt2D.isHorizontalCenter(this._refpt)) {
        x = rect.centerX();
    } else if (jsfc.RefPt2D.isRight(this._refpt)) {
        x = rect.maxX() - this._offset.dx();
    }
    if (jsfc.RefPt2D.isTop(this._refpt)) {
        y = rect.minY() + this._offset.dy();
    } else if (jsfc.RefPt2D.isVerticalCenter(this._refpt)) {
        y = rect.centerY();
    } else if (jsfc.RefPt2D.isBottom(this._refpt)) {
        y = rect.maxY() - this._offset.dy();
    }
    return new jsfc.Point2D(x, y);
};/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * @classdesc A base class for graphics context implementations.
 * @constructor
 * @param {jsfc.BaseContext2D} [instance] The instance object (optional).
 */
jsfc.BaseContext2D = function(instance) {
    if (!(this instanceof jsfc.BaseContext2D)) {
        throw new Error("Use 'new' for construction.");
    }
    if (!instance) {
        instance = this;
    }
    jsfc.BaseContext2D.init(instance);
};

/**
 * Initialises the attributes for an instance.
 * 
 * @param {!jsfc.BaseContext2D} instance  the instance.
 * @returns {undefined}
 */
jsfc.BaseContext2D.init = function(instance) {
    instance._hints = {};
    instance._lineColor = new jsfc.Color(255, 255, 255);
    instance._fillColor = new jsfc.Color(255, 0, 0);
    instance._font = new jsfc.Font("serif", 12);
};

/**
 * Returns the value of the rendering hint with the specified key.
 * @param {!string} key  the hint key.
 * @returns {*} The hint value.
 */
jsfc.BaseContext2D.prototype.getHint = function(key) {
    return this._hints[key];
};

/**
 * Sets a rendering hint.
 * 
 * @param {!string} key  the hint key.
 * @param {*} value  the hint value.
 * @returns {undefined}
 */
jsfc.BaseContext2D.prototype.setHint = function(key, value) {
    this._hints[key] = value;  
};

/**
 * Clears the rendering hints.
 * 
 * @returns {undefined}
 */
jsfc.BaseContext2D.prototype.clearHints = function() {
    this._hints = {};
};

/**
 * Sets the line stroke.
 * 
 * @param {!jsfc.Stroke} stroke  the line stroke.
 * @returns {undefined}
 */
jsfc.BaseContext2D.prototype.setLineStroke = function(stroke) {
    jsfc.Args.require(stroke, "stroke");
    this._stroke = stroke;  
};

/**
 * Sets the line color.
 * 
 * @param {!jsfc.Color} color  the color.
 * @returns {undefined}
 */
jsfc.BaseContext2D.prototype.setLineColor = function(color) {
    jsfc.Args.require(color, "color");
    this._lineColor = color;
};

/**
 * Sets the fill color.
 * 
 * @param {!jsfc.Color} color  the fill color (null not permitted).
 * @returns {undefined}
 */
jsfc.BaseContext2D.prototype.setFillColor = function(color) {
    jsfc.Args.require(color, "color");
    this._fillColor = color;
};

/**
 * Returns the font.  The default value is jsfc.Font("serif", 12).

 * @returns {jsfc.Font|!jsfc.Font}
 */
jsfc.BaseContext2D.prototype.getFont = function() {
    return this._font;    
};

/**
 * Sets the font used for text rendering.
 * 
 * @param {!jsfc.Font} font  the font.
 * @returns {undefined}
 */
jsfc.BaseContext2D.prototype.setFont = function(font) {
    this._font = font;
};

/**
 * Sets the clip.
 * @returns {undefined}
 */
jsfc.BaseContext2D.prototype.setClip = function(rect) {  
    // not currently supported
};

jsfc.BaseContext2D.prototype.save = function() {  
    // not currently supported
};

jsfc.BaseContext2D.prototype.restore = function() {  
    // not currently supported
};

/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Creates a new graphics context that targets the HTML5 canvas element.
 * @constructor
 * @implements {jsfc.Context2D}
 * @param {Element} canvas
 * @returns {jsfc.CanvasContext2D}
 */
jsfc.CanvasContext2D = function(canvas) {
    if (!(this instanceof jsfc.CanvasContext2D)) {
        throw new Error("Use 'new' with constructor.");
    }
    jsfc.BaseContext2D.init(this);
    this._canvas = canvas;
    this._ctx = canvas.getContext("2d");
};

jsfc.CanvasContext2D.prototype = new jsfc.BaseContext2D();

jsfc.CanvasContext2D.prototype.clear = function() {
    var w = this._canvas.width;
    var h = this._canvas.height;
    //this._ctx.fillStyle = "#FFFFFF";
    this._ctx.clearRect(0, 0, w, h);
};

/**
 * Sets the fill color.
 * 
 * @param {!jsfc.Color} color  the fill color (null not permitted).
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.setFillColor = function(color) {
    jsfc.BaseContext2D.prototype.setFillColor.call(this, color);
    this._ctx.fillStyle = color.rgbaStr();
};

/**
 * Sets the line color.
 * 
 * @param {!jsfc.Color} color  the line color.
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.setLineColor = function(color) {
    jsfc.BaseContext2D.prototype.setLineColor.call(this, color);
    this._ctx.strokeStyle = color.rgbaStr();
};

/**
 * Sets the line stroke.
 * 
 * @param {!jsfc.Stroke} stroke  the line stroke.
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.setLineStroke = function(stroke) {
    jsfc.BaseContext2D.prototype.setLineStroke.call(this, stroke);
    this._ctx.lineWidth = stroke.lineWidth;  
    this._ctx.lineCap = stroke.lineCap;
    this._ctx.lineJoin = stroke.lineJoin;
};



/**
 * Draws a line from (x0, y0) to (x1, y1) using the current line stroke and
 * color.
 * 
 * @param {!number} x0  the x-coordinate for the start point.
 * @param {!number} y0  the y-coordinate for the start point.
 * @param {!number} x1  the x-coordinate for the end point.
 * @param {!number} y1  the y-coordinate for the end point.
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.drawLine = function(x0, y0, x1, y1) {
    this._ctx.beginPath();
    this._ctx.moveTo(x0, y0);
    this._ctx.lineTo(x1, y1);
    this._ctx.stroke();
};

/**
 * Draws a rectangle with the current line stroke.
 * 
 * @param {!number} x  the x-coordinate.
 * @param {!number} y  the y-coordinate.
 * @param {!number} w  the width.
 * @param {!number} h  the height.
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.drawRect = function(x, y, w, h) {
    this._ctx.fillRect(x, y, w, h);
};

/**
 * Fills a rectangle with the current color.
 * 
 * @param {!number} x  the x-coordinate.
 * @param {!number} y  the y-coordinate.
 * @param {!number} width  the width.
 * @param {!number} height  the height.
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.fillRect = function(x, y, width, height) {
    this._ctx.fillRect(x, y, width, height);
};

/**
 * Draws a circle.
 * 
 * @param {!number} cx  the x-coordinate for the center point.
 * @param {!number} cy  the y-coordinate for the center point.
 * @param {!number} r  the radius.
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.drawCircle = function(cx, cy, r) {
    this._ctx.beginPath();
    this._ctx.arc(cx, cy, r, 0, Math.PI * 2);
    this._ctx.fill();
    this._ctx.stroke();
};

/**
 * Begins a new path.  The path can be defined using moveTo(), lineTo(), arc(),
 * arcTo() and closePath().  A defined path can be filled (see the fill()
 * method) or stroked (see the stroke() method).
 * 
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.beginPath = function() {
    this._ctx.beginPath();
};

/**
 * Closes the current path.
 * 
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.closePath = function() {
    this._ctx.closePath();
};

/**
 * Moves to the point (x, y).
 * 
 * @param {!number} x  the x-coordinate of the destination point.
 * @param {!number} y  the y-coordinate of the destination point.
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.moveTo = function(x, y) {
    this._ctx.moveTo(x, y);
};

/**
 * Adds a line to the current path connecting the most recent point in the 
 * path to the destination point (x, y).
 * 
 * @param {!number} x  the x-coordinate of the destination point.
 * @param {!number} y  the y-coordinate of the destination point.
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.lineTo = function(x, y) {
    this._ctx.lineTo(x, y);
};

// FIXME: arc methods

/**
 * Fills the current path with the current fill color.
 * 
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.fill = function() {
    this._ctx.fill();
};

/**
 * Draws an outline of the current path.
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.stroke = function() {
    this._ctx.stroke();
};

/**
 * Sets the font used for text rendering.
 * 
 * @param {!jsfc.Font} font  the font.
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.setFont = function(font) {
    this._font = font;
    this._ctx.font = font.canvasFontStr();
};

/**
 * Returns the dimensions of the specified text in the current font.
 * 
 * @param {!string} text  the text.
 * @returns {!jsfc.Dimension} The dimensions of the bounding rectangle for the 
 *     text.
 */
jsfc.CanvasContext2D.prototype.textDim = function(text) {
    var w = this._ctx.measureText(text).width;
    return new jsfc.Dimension(w, this._font.size); 
};

/**
 * Draws a string in the current font with the left baseline aligned with the 
 * point (x, y).  The color of the text is determined by the current fill color.
 * 
 * @param {!string} text  the string.
 * @param {!number} x  the x-coordinate.
 * @param {!number} y  the y-coordinate.
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.drawString = function(text, x, y) {
    this._ctx.fillText(text, x, y);
};

/**
 * Draws a string anchored to a point (x, y).
 * 
 * @param {!string} text  the text.
 * @param {!number} x  the x-coordinate.
 * @param {!number} y  the y-coordinate.
 * @param {!number} anchor  the anchor point (see jsfc.TextAnchor).
 * @returns {jsfc.Dimension} The dimensions of the string.
 */
jsfc.CanvasContext2D.prototype.drawAlignedString = function(text, x, y, anchor) {
    var dim = this.textDim(text);
    var xadj = 0;
    var yadj = this._font.size;
    if (jsfc.TextAnchor.isHorizontalCenter(anchor)) {
        xadj = -dim.width() / 2;
    } else if (jsfc.TextAnchor.isRight(anchor)) {
        xadj = -dim.width();
    }
    if (jsfc.TextAnchor.isBottom(anchor)) {
        yadj = 0;
    } else if (jsfc.TextAnchor.isHalfHeight(anchor)) {
        yadj = this._font.size / 2;
    }
    this._ctx.fillText(text, x + xadj, y + yadj);
    return dim;
};

/**
 * Draws a string at (x, y) rotated by 'angle' radians.
 * 
 * @param {!string} text  the text to draw (null not permitted).
 * @param {!number} x  the x-coordinate.
 * @param {!number} y  the y-coordinate.
 * @param {!number} anchor  the text anchor point (null not permitted).
 * @param {!number} angle  the rotation angle (in radians).
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.drawRotatedString = function(text, x, y, anchor, 
        angle) {
    this.translate(x, y);
    this.rotate(angle);
    this.drawAlignedString(text, 0, 0, anchor);
    this.rotate(-angle);
    this.translate(-x, -y);
};

/**
 * Draws the text.
 * 
 * @param {!string} text  the text.
 * @param {!number} x  the x-coordinate.
 * @param {!number} y  the y-coordinate.
 * @param {number} [maxWidth] ignored for now.
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.fillText = function(text, x, y, maxWidth) {
    this._ctx.fillText(text, x, y);
};


jsfc.CanvasContext2D.prototype.beginGroup = function(classStr) {
    
};

jsfc.CanvasContext2D.prototype.endGroup = function() {
    
};

/**
 * Applies a translation.
 * 
 * @param {!number} dx  the translation along the x-axis.
 * @param {!number} dy  the translation along the y-axis.
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.translate = function(dx, dy) {
    this._ctx.translate(dx, dy);
};

/**
 * Applies a rotation about (0, 0).
 * @param {!number} radians  the rotation angle in radians.
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.rotate = function(radians) {
    this._ctx.rotate(radians);
};

/**
 * Sets the clip.
 * @returns {undefined}
 */
jsfc.CanvasContext2D.prototype.setClip = function(rect) {  
    this._ctx.beginPath();
    this._ctx.rect(rect.x(), rect.y(), rect.width(), rect.height());
    this._ctx.clip();
};

jsfc.CanvasContext2D.prototype.save = function() {  
    this._ctx.save();
};

jsfc.CanvasContext2D.prototype.restore = function() {  
    this._ctx.restore();
};/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * Constructor for a new (empty) Map.
 * @classdesc A simple map implementation (with ideas taken from 
 *     https://github.com/rauschma/strmap/blob/master/strmap.js).
 * @constructor     
 */
jsfc.Map = function() {
    this._data = {};
};

/**
 * Escapes any special key instances.
 * 
 * @param {!string} key  the key.
 * @returns {!string} The escaped key.
 */
jsfc.Map.prototype._escapeKey = function(key) {
    if (key.indexOf("__proto__") === 0) {
        return key + "%";
    } else {
        return key;
    }
};

/**
 * Returns true if the map contains an entry for the specified key, and false
 * otherwise.
 * 
 * @param {!string} key  the key.
 * @returns {!boolean}
 */
jsfc.Map.prototype.contains = function(key) {
    return Object.prototype.hasOwnProperty.call(this._data, key);       
};

/**
 * Returns an array of the keys that are defined for this map.
 * @returns {Array}
 */
jsfc.Map.prototype.keys = function() {
    return Object.keys(this._data);
};

/**
 * Adds a (key, value) pair to the map or, if an item already exists for the
 * specified key, updates the value for that item.
 * 
 * @param {string} key  the key.
 * @param {*} value  the value.
 * @returns {undefined}
 */
jsfc.Map.prototype.put = function(key, value) {
    key = this._escapeKey(key);
    this._data[key] = value;
};

/**
 * Returns the value of the property with the specified key, or 'undefined'
 * if there is no property with that key.
 * 
 * @param {!string} key  the property key.
 * 
 * @returns {*} The property value.
 */
jsfc.Map.prototype.get = function(key) {
    key = this._escapeKey(key);
    return this._getOwnPropertyValue(this._data, key);
};

/**
 * Returns a property value defined on the specified object.
 * 
 * @param {!Object} obj  the object.
 * @param {!string} prop  the property name.
 * @returns {*} The property value.
 */
jsfc.Map.prototype._getOwnPropertyValue = function(obj, prop) {
    return Object.prototype.hasOwnProperty.call(obj, prop) ? obj[prop] 
            : undefined;    
};

/**
 * Removes the property with the specified key.
 * 
 * @param {!string} key  the property key.
 * 
 * @returns {*} The removed property entry.
 */
jsfc.Map.prototype.remove = function(key) {
    key = this._escapeKey(key);
    var value = this._getOwnPropertyValue(this._data, key);
    delete this._data[key];
    return value;
};
/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

"use strict";

/**
 * Creates a new Range instance.
 * @constructor
 * @param {!number} lowerBound  the lower bound for the range.
 * @param {!number} upperBound  the upper bound for the range.
 * @classdesc Represents a range of values.
 */
jsfc.Range = function(lowerBound, upperBound) {
    if (lowerBound >= upperBound) {
        throw new Error("Requires lowerBound to be less than upperBound: " + lowerBound + ", " + upperBound);
    }
    this._lowerBound = lowerBound;
    this._upperBound = upperBound;
};

/**
 * Returns the lower bound for the range.
 * 
 * @returns {!number} The lower bound.
 */
jsfc.Range.prototype.lowerBound = function() {
    return this._lowerBound;
};

/**
 * Returns the upper bound for the range.
 * 
 * @returns {!number} The upper bound.
 */
jsfc.Range.prototype.upperBound = function() {
    return this._upperBound;
};

/**
 * Returns the length of the range.
 * 
 * @returns {number}
 */
jsfc.Range.prototype.length = function() {
    return this._upperBound - this._lowerBound;
};

/**
 * Returns a percentage value reflecting the position of the value within the
 * range.
 * 
 * @param {number} value
 * @returns {number} The percentage.
 */
jsfc.Range.prototype.percent = function(value) {
    return (value - this._lowerBound) / this.length();
};

/**
 * Returns the value in the range corresponding to the specified percentage
 * value.
 * 
 * @param {!number} percent  the percentage (for example, 0.20 is twenty 
 *     percent).
 * @returns {number} The value.
 */
jsfc.Range.prototype.value = function(percent) {
    return this._lowerBound + percent * this.length();
};

/**
 * Returns true if the range contains the specified value, and false otherwise.
 * @param {!number} n  the value.
 * @returns {!boolean} A boolean.
 */
jsfc.Range.prototype.contains = function(n) {
    return n >= this._lowerBound && n <= this._upperBound;
};

/**
 * Returns a string representation of this object, primarily for debugging 
 * purposes.
 * 
 * @returns {String}
 */
jsfc.Range.prototype.toString = function() {
    return "[Range: " + this._lowerBound + ", " + this._upperBound + "]";
};/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Creates a new (empty) dataset instance.
 * 
 * @classdesc A dataset that stores one or more data series where each series
 *     consists of an arbitrary number of (x, y) data items.  The dataset also
 *     provides a selection state mechanism.  A typical dataset will serialise 
 *     to JSON format as follows:
 *     <blockquote>{"data":{"series":[{"seriesKey":"S1","items":[{"x":1.1,"y":10.1},{"x":2.2,"y":10.2},{"x":3.3,"y":10.3}]},{"seriesKey":"S2","items":[{"x":4.4,"y":10.4}]},{"seriesKey":"S3","items":[{"x":5.5,"y":10.5}]}]},"selections":[],"_listeners":[]}</blockquote>
 *
 * @constructor 
 * @implements {jsfc.XYDataset}
 */
jsfc.StandardXYDataset = function() {
    this.data = { "series": [] };
    this.properties = { "dataset": null, "series": [] };
    this.selections = [];
    
    // the index provides fast lookup of a series index from a series key,
    // and an item index from an item key.
    this._index = { "series": new jsfc.Map(), "items": [] };
    this._listeners = [];
};

/**
 * Returns the number of series in the dataset.
 * 
 * @returns {number} The series count.
 */
jsfc.StandardXYDataset.prototype.seriesCount = function() {
    return this.data.series.length;
};

/**
 * Returns an array containing the keys for all the series in the dataset.
 * 
 * @returns {Array} The series keys.
 */
jsfc.StandardXYDataset.prototype.seriesKeys = function() {
    return this.data.series.map(function(d) {
        return d.seriesKey;
    });
};

/**
 * Returns the key for the series with the specified index.
 * 
 * @param {!number} seriesIndex  the series index.
 * 
 * @returns {string} The series key.
 */
jsfc.StandardXYDataset.prototype.seriesKey = function(seriesIndex) {
    return this.data.series[seriesIndex].seriesKey;
};

/**
 * Returns the index for the series with the specified key, or -1.
 * 
 * @param {!string} seriesKey  the series key.
 * 
 * @returns {!number} The series index.
 */
jsfc.StandardXYDataset.prototype.seriesIndex = function(seriesKey) {
    jsfc.Args.requireString(seriesKey, "seriesKey");
    var index = +this._index.series.get(seriesKey);
    if (index >= 0) {
        return index;
    }
    return -1;
};

/**
 * Returns the number of items in the specified series.
 * 
 * @param {!number} seriesIndex  the series index.
 * 
 * @returns {!number} The item count.
 */
jsfc.StandardXYDataset.prototype.itemCount = function(seriesIndex) {
    return this.data.series[seriesIndex].items.length;
};

/**
 * Returns the key for an item in a series.
 * 
 * @param {!number} seriesIndex  the series index.
 * @param {!number} itemIndex  the item index.
 * @returns {!string} The item key.
 */
jsfc.StandardXYDataset.prototype.itemKey = function(seriesIndex, itemIndex) {
    return this.data.series[seriesIndex].items[itemIndex].key;  
};

/**
 * Returns the index of the item in the specified series that has the specified
 * item key.
 * 
 * @param {!string} seriesKey  the series key.
 * @param {!string} itemKey  the item key.
 * @returns {!number} The item index.
 */
jsfc.StandardXYDataset.prototype.itemIndex = function(seriesKey, itemKey) {
    jsfc.Args.require(itemKey, "itemKey");
    var seriesIndex = this.seriesIndex(seriesKey);
    var i = this._index.items[seriesIndex].get(itemKey);
    if (i >= 0) {
        return i;
    }
    return -1;
};

/**
 * Returns the x-value for an item in a series.
 * 
 * @param {!number} seriesIndex  the series index.
 * @param {!number} itemIndex  the item index.
 * 
 * @returns {!number} The x-value.
 */
jsfc.StandardXYDataset.prototype.x = function(seriesIndex, itemIndex) {
    return this.data.series[seriesIndex].items[itemIndex].x; 
};

/**
 * Returns the y-value for an item in a series.
 * 
 * @param {!number} seriesIndex  the series index.
 * @param {!number} itemIndex  the item index.
 * 
 * @returns {number} The y-value.
 */
jsfc.StandardXYDataset.prototype.y = function(seriesIndex, itemIndex) {
    return this.data.series[seriesIndex].items[itemIndex].y;     
};

/**
 * Returns one item from a series.  The return value is an object with the form
 * {"x": x, "y": y, "key": key}.
 * 
 * @param {!number} seriesIndex  the series index.
 * @param {!number} itemIndex  the item index.
 * @returns {Object} A data item.
 */
jsfc.StandardXYDataset.prototype.item = function(seriesIndex, itemIndex) {
    return this.data.series[seriesIndex].items[itemIndex];  
};

/**
 * Returns an item based on the series and item keys.
 * 
 * @param {!string} seriesKey  the series key.
 * @param {!string} itemKey  the item key.
 * @returns {Object}
 */
jsfc.StandardXYDataset.prototype.itemByKey = function(seriesKey, itemKey) {
    var seriesIndex = this.seriesIndex(seriesKey);
    var items = this.data.series[seriesIndex].items;
    for (var i = 0; i < items.length; i++) {
        if (items[i].key === itemKey) {
            return items[i];
        }
    }
    return null;
};

/**
 * Returns the item key for an item.  All items will have a key that is unique
 * within the series (either auto-generated or explicitly set).
 * 
 * @param {!number} seriesIndex
 * @param {!number} itemIndex
 * @returns {string}
 */
jsfc.StandardXYDataset.prototype.getItemKey = function(seriesIndex, itemIndex) {
    return this.item(seriesIndex, itemIndex).key;
};

/**
 * Generates a new (and unique) item key for the specified series.
 * 
 * @param {!number} seriesIndex  the series index.
 * 
 * @returns {!string}
 */
jsfc.StandardXYDataset.prototype.generateItemKey = function(seriesIndex) {
    // for a series that is not yet created, we can use 0 for the itemKey
    if (seriesIndex < 0) {
        return "0";
    }
    var map = this._index.items[seriesIndex];
    var candidate = map.get("_nextFreeKey_");
    while (map.contains("" + candidate)) {
        candidate++;
        map.put("_nextFreeKey_", candidate);
    }
    return "" + candidate;
};

/**
 * Returns the data items for the specified series.  This method provides 
 * direct access to the data for a series - if you update this array directly, 
 * dataset listeners will not receive notification of the change.
 * 
 * @param {!number} seriesIndex  the series index.
 * 
 * @returns {Array} An array of the data items.
 */
jsfc.StandardXYDataset.prototype.items = function(seriesIndex) {
    return this.data.series[seriesIndex].items;
};

/**
 * Returns a new array containing all the (x, y) items in the dataset.
 * 
 * @returns {Array} An array of data items.
 */
jsfc.StandardXYDataset.prototype.allItems = function() {
    var result = [];
    for (var s = 0; s < this.data.series.length; s++) {
        result.push(this.items(s));
    }
    return result;
};

/**
 * Adds an item to the specified series (if the series does not already exist,
 * it will be created).  The new item will have an auto-generated item key.
 * 
 * @param {!string} seriesKey  the series key.
 * @param {!number} x  the x-value.
 * @param {number|null} y  the y-value.
 * @param {boolean} [notify]  notify listeners? 
 * 
 * @returns {jsfc.XYDataset} This dataset for method call chaining.
 */
jsfc.StandardXYDataset.prototype.add = function(seriesKey, x, y, notify) {
    jsfc.Args.requireNumber(x, "x");
    var s = this.seriesIndex(seriesKey);
    if (s < 0) {
        this.addSeries(seriesKey);
        s = this.data.series.length - 1;
    }
    var itemKey = this.generateItemKey(s);
    // this code matches what is found in addByKey() but since we know this
    // is a new data item, and we already know the series index, it is faster 
    // to add it directly
    var items = this.data.series[s].items;
    items.push({"x": x, "y": y, "key": itemKey});
    this._index.items[s].put(itemKey, items.length - 1);
    this.properties.series[s].maps.push(null);
    if (notify !== false) {
        this.notifyListeners();
    }
    return this;    
};

/**
 * Adds an item to the dataset with the specified seriesKey and itemKey.  If the
 * series does not already exist it will be created.  If the series contains
 * an item with the specified key, the values for that item will be updated,
 * otherwise a new item will be created in the series.
 * 
 * @param {!string} seriesKey  the series key.
 * @param {!string} itemKey  the item key.
 * @param {!number} x  the x-value.
 * @param {number} y  the y-value.
 * @param {boolean} [notify]  notify listeners?
 * @returns {jsfc.XYDataset} This dataset (for chaining method calls).
 */
jsfc.StandardXYDataset.prototype.addByKey = function(seriesKey, itemKey, x, y, 
        notify) {
    jsfc.Args.requireString(seriesKey, "seriesKey");
    var s = this.seriesIndex(seriesKey);
    if (s < 0) {
        this.addSeries(seriesKey);
        s = this.data.series.length - 1;
    }
    var item = this.itemByKey(seriesKey, itemKey);
    if (item) {
        item.x = x;
        item.y = y;
    } else {
        var items = this.data.series[s].items;
        items.push({"x": x, "y": y, "key": itemKey});
        this._index.items[s].put(itemKey, items.length - 1);
        this.properties.series[s].maps.push(null);
    }
    if (notify !== false) {
        this.notifyListeners();
    }
    return this;    
};

/**
 * Removes an item from one series in the dataset and sends a change event to 
 * all registered listeners.
 * 
 * @param {!number} seriesIndex  the series key.
 * @param {!number} itemIndex  the item index.
 * @param {boolean} [notify]  notify listeners?
 * @returns {jsfc.XYDataset} This dataset (for chaining method calls).
 */
jsfc.StandardXYDataset.prototype.remove = function(seriesIndex, itemIndex, 
        notify) {
    // TODO when an item is removed, any selections that point to it should
    // be updated accordingly
    var removedItemKey = this.itemKey(seriesIndex, itemIndex);
    this.data.series[seriesIndex].items.splice(itemIndex, 1);
    this.properties.series[seriesIndex].maps.splice(itemIndex, 1);
    // update the index of itemKeys --> item indices
    this._index.items[seriesIndex].remove(removedItemKey);
    for (var i = itemIndex; i < this.itemCount(seriesIndex); i++) {
        this._index.items[seriesIndex].put(this.itemKey(seriesIndex, i), i);
    }
    if (notify !== false) {
        this.notifyListeners();
    }
    return this;
};

/**
 * Removes an item from one series in the dataset and sends a change 
 * notification to all registered listeners.
 * 
 * @param {!string} seriesKey  the series key.
 * @param {!string} itemKey  the item key.
 * @param {boolean} [notify]  notify listeners? (optional, defaults to true).
 * @returns {undefined}
 */
jsfc.StandardXYDataset.prototype.removeByKey = function(seriesKey, itemKey, 
        notify) {
    var seriesIndex = this.seriesIndex(seriesKey);
    var itemIndex = this.itemIndex(seriesKey, itemKey);
    this.remove(seriesIndex, itemIndex, notify);
};

/**
 * Adds a new empty series with the specified key.
 * 
 * @param {!string} seriesKey  the series key.
 * 
 * @returns {jsfc.XYDataset} This dataset (for chaining method calls).
 */
jsfc.StandardXYDataset.prototype.addSeries = function(seriesKey) {
    if (!(typeof seriesKey === 'string')) {
        throw new Error("The 'seriesKey' must be a string.");
    }
    if (this._index.series.contains(seriesKey)) {
        throw new Error("Duplicate key '" + seriesKey);
    }
    this.data.series.push({ "seriesKey": seriesKey, "items": [] });
    this._index.series.put(seriesKey, this.data.series.length - 1);
    var itemKeys = new jsfc.Map();
    itemKeys.put("_nextFreeKey_", 0); // hint for the next free key
    this._index.items.push(itemKeys); // map for itemKeys --> item index
    this.properties.series.push({ "seriesKey": seriesKey, 
            "seriesProperties": null, "maps": [] });
    return this;
};

/**
 * Removes the series with the specified ID and sends a change event to 
 * registered listeners.
 * 
 * @param {!string} seriesKey  the series key.
 * @returns {jsfc.XYDataset} This dataset (for chaining method calls).
 */
jsfc.StandardXYDataset.prototype.removeSeries = function(seriesKey, notify) {
    if (!(typeof seriesKey === 'string')) {
        throw new Error("The 'seriesKey' must be a string.");
    }
    // TODO : when a series is removed, any selections that point to the series
    // should be updated accordingly
    var s = this.seriesIndex(seriesKey);
    if (s >= 0) {
        this.data.series.splice(s, 1);
        this.properties.series.splice(s, 1);
        // update the index of series keys to indices for every series affected
        this._index.series.remove(seriesKey);
        this._index.items.splice(s, 1);
        for (var i = s; i < this.seriesCount(); i++) {
            var key = this.seriesKey(i);
            this._index.series.put(key, i);
        }
        if (notify !== false) {
            this.notifyListeners();
        }
    } else {
        throw new Error("No series with that key. " + seriesKey);
    }
    return this;
};

/**
 * The bounds for the data values.  This method returns an array in the form
 * [xmin, xmax, ymin, ymax].
 * 
 * @returns {Array} An array containing the dataset bounds.
 */
jsfc.StandardXYDataset.prototype.bounds = function() {
    var xmin = Number.POSITIVE_INFINITY;
    var xmax = Number.NEGATIVE_INFINITY;
    var ymin = Number.POSITIVE_INFINITY;
    var ymax = Number.NEGATIVE_INFINITY;
    for (var s = 0; s < this.seriesCount(); s++) {
        for (var i = 0; i < this.itemCount(s); i++) {
            var xyitem = this.item(s, i);
            xmin = Math.min(xmin, xyitem.x);
            xmax = Math.max(xmax, xyitem.x);
            ymin = Math.min(ymin, xyitem.y);
            ymax = Math.max(ymax, xyitem.y);
        }
    }
    return [xmin, xmax, ymin, ymax];
};

/**
 * Returns [xmin, xmax] where xmin is the lowest x-value in the dataset and
 * xmax is this highest x-value in the dataset.  If the dataset is empty,
 * this method returns [POSITIVE_INFINITIY, NEGATIVE_INFINITY] (maybe we'll
 * change this).
 * If only a single point exists (xmin == xmax), adds ±10% padding.
 *
 * @returns {Array}
 */
jsfc.StandardXYDataset.prototype.xbounds = function() {
    var xmin = Number.POSITIVE_INFINITY;
    var xmax = Number.NEGATIVE_INFINITY;
    for (var s = 0; s < this.seriesCount(); s++) {
        for (var i = 0; i < this.itemCount(s); i++) {
            var x = this.x(s, i);
            xmin = Math.min(xmin, x);
            xmax = Math.max(xmax, x);
        }
    }

    // Handle single point case (max == min)
    if (xmin === xmax) {
        var padding = Math.abs(xmin) * 0.1; // 10% of the value
        if (padding === 0) {
            padding = 0.5; // Use fixed padding if value is 0
        }
        return [xmin - padding, xmax + padding];
    }

    return [xmin, xmax];
};

/**
 * Returns [ymin, ymax] where ymin is the lowest y-value in the dataset and
 * xmax is this highest y-value in the dataset.  If the dataset is empty,
 * this method returns [POSITIVE_INFINITIY, NEGATIVE_INFINITY] (maybe we'll
 * change this).
 * If only a single point exists (ymin == ymax), adds ±10% padding.
 *
 * @returns {Array}
 */
jsfc.StandardXYDataset.prototype.ybounds = function() {
    var ymin = Number.POSITIVE_INFINITY;
    var ymax = Number.NEGATIVE_INFINITY;
    for (var s = 0; s < this.seriesCount(); s++) {
        for (var i = 0; i < this.itemCount(s); i++) {
            var y = this.y(s, i);
            ymin = Math.min(ymin, y);
            ymax = Math.max(ymax, y);
        }
    }

    // Handle single point case (max == min)
    if (ymin === ymax) {
        var padding = Math.abs(ymin) * 0.1; // 10% of the value
        if (padding === 0) {
            padding = 0.5; // Use fixed padding if value is 0
        }
        return [ymin - padding, ymax + padding];
    }

    return [ymin, ymax];
};

/**
 * Returns the value of a property for the dataset.
 * 
 * @param {!string} key  the property key.
 * @returns {*} The property value.
 */
jsfc.StandardXYDataset.prototype.getProperty = function(key) {
    var map = this.properties.dataset;
    if (map) {
        return map.get(key);
    }
    return undefined;
};

/**
 * Sets the value of a property for the dataset.
 * 
 * @param {!string} key  the property key.
 * @param {*} value  the property value.
 * @param {boolean} [notify]  notify listeners? (defaults to true).
 */
jsfc.StandardXYDataset.prototype.setProperty = function(key, value, notify) {
    if (!this.properties.dataset) {
        this.properties.dataset = new jsfc.Map();
    }
    if (value !== null) {
        this.properties.dataset.put(key, value);
    } else {
        this.properties.dataset.remove(key);
    }
    
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns an array containing all the keys of the properties defined for
 * this dataset.
 * 
 * @returns {Array}
 */
jsfc.StandardXYDataset.prototype.getPropertyKeys = function() {
    if (this.properties.dataset) {
        return this.properties.dataset.keys();
    }
    return [];
};

/**
 * Clears all the dataset-level properties and sends a change notification
 * to registered listeners (unless 'notify' is set to false).
 * 
 * @param {boolean} [notify]  notify listeners? (defaults to true).
 * @returns {jsfc.StandardXYDataset} This dataset for chaining method calls.
 */
jsfc.StandardXYDataset.prototype.clearProperties = function(notify) {
    this.properties.dataset = null;
    if (notify !== false) {
        this.notifyListeners();
    }
    return this;
};

/**
 * Returns the keys for the properties defined for a series.
 * 
 * @param {!string} seriesKey  the series key.
 * @returns {Array} The property keys.
 */
jsfc.StandardXYDataset.prototype.getSeriesPropertyKeys = function(seriesKey) {
    var seriesIndex = this.seriesIndex(seriesKey);
    var map = this.properties.series[seriesIndex].seriesProperties;
    if (map) {
        return map.keys();
    } else {
        return [];
    }
};

/**
 * Returns the value of a property for a series.
 * 
 * @param {!string} seriesKey  the series key.
 * @param {!string} propertyKey  the property key.
 * @returns {*} The property value.
 */
jsfc.StandardXYDataset.prototype.getSeriesProperty = function(seriesKey, 
        propertyKey) {
    var seriesIndex = this.seriesIndex(seriesKey);
    var map = this.properties.series[seriesIndex].seriesProperties;            
    if (map) {
        return map.get(propertyKey);
    } else {
        return undefined;
    }
};

/**
 * Sets the value of a property for the specified series.
 * 
 * @param {!string} seriesKey  the series key.
 * @param {!string} propertyKey  the property key.
 * @param {*} value  the property value.
 * @returns {undefined}
 */
jsfc.StandardXYDataset.prototype.setSeriesProperty = function(seriesKey, 
        propertyKey, value) {
    var seriesIndex = this.seriesIndex(seriesKey);
    var map = this.properties.series[seriesIndex].seriesProperties;            
    if (!map) {
        map = new jsfc.Map();
        this.properties.series[seriesIndex].seriesProperties = map;
    } 
    map.put(propertyKey, value);
};

/**
 * Clears all the series-level properties for the specified series.
 * 
 * @param {!string} seriesKey  the series key.
 * @returns {undefined}
 */
jsfc.StandardXYDataset.prototype.clearSeriesProperties = function(seriesKey) {
    var seriesIndex = this.seriesIndex(seriesKey);
    this.properties.series[seriesIndex].seriesProperties = null;
};

/**
 * Returns a property for the specified data item.
 * 
 * @param {!string} seriesKey  the series key.
 * @param {!string} itemKey  the item key.
 * @param {!string} propertyKey  the property key.
 * @returns {*} The property value.
 */
jsfc.StandardXYDataset.prototype.getItemProperty = function(seriesKey, 
        itemKey, propertyKey) {
    var seriesIndex = this.seriesIndex(seriesKey);
    var itemIndex = this.itemIndex(seriesKey, itemKey);
    return this.getItemPropertyByIndex(seriesIndex, itemIndex, propertyKey);
};

/**
 * Sets a property for the specified data item.
 * 
 * @param {!string} seriesKey  the series key.
 * @param {!string} itemKey  the item key.
 * @param {!string} propertyKey  the property key.
 * @param {*} value  the property value.
 * @param {boolean} [notify]  notify listeners? (optional, defaults to true).
 * @returns {undefined}
 */
jsfc.StandardXYDataset.prototype.setItemProperty = function(seriesKey, 
        itemKey, propertyKey, value, notify) {
    var seriesIndex = this.seriesIndex(seriesKey);
    var itemIndex = this.itemIndex(seriesKey, itemKey);
    this.setItemPropertyByIndex(seriesIndex, itemIndex, propertyKey, value, 
            notify);
};

/**
 * Returns a property for the specified data item.  See also the
 * getItemProperty() method where keys rather than indices are used to 
 * specify the data item.
 * 
 * @param {!number} seriesIndex  the series index.
 * @param {!number} itemIndex  the item index.
 * @param {!string} propertyKey  the property key.
 * @returns {*} The property value.
 */
jsfc.StandardXYDataset.prototype.getItemPropertyByIndex = function(seriesIndex, 
        itemIndex, propertyKey) {
    var map = this.properties.series[seriesIndex].maps[itemIndex];
    if (map) {
        return map.get(propertyKey);
    }
    return undefined;
};

/**
 * Sets a property for the specified data item.
 * 
 * @param {!number} seriesIndex  the series index.
 * @param {!number} itemIndex  the item index.
 * @param {!string} propertyKey  the property key.
 * @param {*} value  the property value.
 * @param {boolean} [notify]  notify listeners? (optional, defaults to true).
 * @returns {undefined}
 */
jsfc.StandardXYDataset.prototype.setItemPropertyByIndex = function(seriesIndex, 
        itemIndex, propertyKey, value, notify) {
    var map = this.properties.series[seriesIndex].maps[itemIndex];
    if (!map) {
        map = new jsfc.Map();
        this.properties.series[seriesIndex].maps[itemIndex] = map;
    }
    map.put(propertyKey, value);
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Clears all properties for one item.
 * 
 * @param {!string} seriesKey  the series key.
 * @param {!string} itemKey  the item key.
 * @returns {undefined}
 */
jsfc.StandardXYDataset.prototype.clearItemProperties = function(seriesKey, 
        itemKey) {
    var seriesIndex = this.seriesIndex(seriesKey);
    var itemIndex = this.itemIndex(seriesKey, itemKey);
    this.properties.series[seriesIndex].maps[itemIndex] = null;
};

/**
 * Marks an item as selected within a selection with the specified ID.
 * 
 * @param {!string} selectionId  the selection id.
 * @param {!string} seriesKey  the series key.
 * @param {!Object} itemKey  the item key.
 * @param {boolean} [notify]  notify listeners? (defaults to true).
 * 
 * @returns {jsfc.XYDataset} This dataset (for chaining method calls).
 */
jsfc.StandardXYDataset.prototype.select = function(selectionId, seriesKey, 
        itemKey, notify) {
    var selection;
    var selectionIndex = this._indexOfSelection(selectionId);
    if (selectionIndex < 0) { // no selection with that id
        selection = {"id": selectionId, "items": []};
        this.selections.push(selection);
    } else {
        selection = this.selections[selectionIndex];
    }
    var i = jsfc.Utils.findInArray(selection.items, function(item) {
        return (item.seriesKey === seriesKey && item.itemKey === itemKey); 
    });
    if (i < 0) {
        selection.items.push({"seriesKey": seriesKey, "itemKey": itemKey});
    }
    if (notify !== false) {
        this.notifyListeners();
    }
    return this;
};

/**
 * Unselects the specified item, returning true if the item was previously 
 * selected and false otherwise (in other words, the return value is true if
 * there is a state change). 
 * 
 * @param {!string} selectionId  the ID for the set of selected items.
 * @param {!string} seriesKey  the series key.
 * @param {!Object} itemKey  the item key.
 * @param {boolean} [notify]  notify listeners? (defaults to true).
 * 
 * @returns {jsfc.XYDataset} This dataset (for chaining method calls).
 */
jsfc.StandardXYDataset.prototype.unselect = function(selectionId, seriesKey, 
        itemKey, notify) {
    var selectionIndex = this._indexOfSelection(selectionId);
    if (selectionIndex >= 0) {
        var selection = this.selections[selectionIndex];
        var i = jsfc.Utils.findInArray(selection.items, function(obj, i) {
            return (obj.seriesKey === seriesKey && obj.itemKey === itemKey); 
        });
        if (i >= 0) {
            selection.items.splice(i, 1);
        }
    } 
    if (notify !== false) {
        this.notifyListeners();
    }
    return this;
};

/**
 * Returns true if the specified item is selected (for the given selectionId) 
 * and false otherwise.
 * 
 * @param {!string} selectionId  the selection ID.
 * @param {!string} seriesKey  the series key.
 * @param {!string} itemKey  the item key.
 * 
 * @returns {!boolean} The selection state.
 */
jsfc.StandardXYDataset.prototype.isSelected = function(selectionId, seriesKey, 
        itemKey) {
    var selection;
    var selectionIndex = this._indexOfSelection(selectionId);
    if (selectionIndex < 0) {
        return false;
    } else {
        selection = this.selections[selectionIndex];
    }
    return (jsfc.Utils.findInArray(selection.items, function(obj) {
        return (obj.seriesKey === seriesKey && obj.itemKey === itemKey); 
    }) >= 0); 
};

/**
 * Clears any items from the selection with the specified id.
 * 
 * @param {!string} selectionId  the selection it.
 * @param {boolean} [notify]  notify listeners? (defaults to true).
 * @returns {jsfc.XYDataset} This dataset (for chaining method calls).
 */
jsfc.StandardXYDataset.prototype.clearSelection = function(selectionId, 
        notify) {
    var selectionIndex = this._indexOfSelection(selectionId);
    if (selectionIndex >= 0) {
        this.selections.splice(selectionIndex, 1);
    }
    if (notify !== false) {
        this.notifyListeners();
    }
    return this;
};

/**
 * Returns the index of the selection with the specified ID, or -1 if there is 
 * no such selection.
 * 
 * @param {string} selectionId  the selection ID.
 * @returns {number} The selection index.
 */
jsfc.StandardXYDataset.prototype._indexOfSelection = function(selectionId) {
    return jsfc.Utils.findInArray(this.selections, function(item) {
        return item.id === selectionId;
    });
};

/**
 * Registers a listener to receive notification of changes to the dataset. The
 * listener must have a 'datasetChanged(KeyedValuesDataset)' method.
 * 
 * @param {Function} listener  the listener object.
 * @returns {jsfc.XYDataset} This dataset (for chaining method calls).
 */
jsfc.StandardXYDataset.prototype.addListener = function(listener) {
    this._listeners.push(listener);
    return this;
};

/**
 * Removes a listener so that it will no longer receive notification of changes
 * to this dataset.
 * 
 * @param {Function} listener the listener.
 * @returns {jsfc.XYDataset} This dataset (for chaining method calls).
 */
jsfc.StandardXYDataset.prototype.removeListener = function(listener) {
    var i = this._listeners.indexOf(listener);
    if (i >= 0) {
        this._listeners.splice(i, 1);
    }
    return this;
};

/**
 * Notifies listeners that the dataset has changed.
 * @returns {jsfc.XYDataset} This dataset (for chaining method calls).
 */
jsfc.StandardXYDataset.prototype.notifyListeners = function() {
    for (var i = 0; i < this._listeners.length; i++) {
        this._listeners[i](this);
    }
    return this;
};

/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * A collection of utility functions for working with datasets.
 * @namespace
 */
jsfc.XYDatasetUtils = {};

/**
 * Returns the number of data items in the dataset.
 * 
 * @param {!jsfc.XYDataset} dataset  the dataset.
 * 
 * @returns {!number}
 */
jsfc.XYDatasetUtils.itemCount = function(dataset) {
    var result = 0;
    for (var s = 0; s < dataset.seriesCount(); s++) {
        result += dataset.itemCount(s);
    }
    return result;
};

/**
 * Returns [ymin, ymax] where ymin is the smallest value appearing in the
 * dataset and ymax is the largest value.  If the dataset doesn't contain any
 * data, this method will return [POSITIVE_INFINITY, NEGATIVE_INFINITY].
 * If only a single point exists (ymin == ymax), adds ±10% padding.
 *
 * @param {jsfc.XYDataset} dataset  the source dataset.
 * @param {number} [baseline]  the baseline value.
 *
 * @returns {Array} The y-value range.
 */
jsfc.XYDatasetUtils.ybounds = function(dataset, baseline) {
    var ymin = baseline ? baseline : Number.POSITIVE_INFINITY;
    var ymax = baseline ? baseline : Number.NEGATIVE_INFINITY;
    for (var s = 0; s < dataset.seriesCount(); s++) {
        for (var i = 0; i < dataset.itemCount(s); i++) {
            var y = dataset.y(s, i);
            ymin = Math.min(ymin, y);
            ymax = Math.max(ymax, y);
        }
    }

    // Handle single point case (max == min)
    if (ymin === ymax) {
        var padding = Math.abs(ymin) * 0.1; // 10% of the value
        if (padding === 0) {
            padding = 0.5; // Use fixed padding if value is 0
        }
        return [ymin - padding, ymax + padding];
    }

    return [ymin, ymax];
};/* 
 * Copyright (C) 2014 Object Refinery Limited and KNIME.com AG
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * Creates a new (empty) dataset instance.
 * @constructor
 * @implements {jsfc.Values2DDataset}
 * @classdesc A dataset that is a two-dimensional table where each column is 
 *     identified by a unique key, each row is identified by a unique key, and
 *     each element (identified by a (rowKey, columnKey) pair) contains a 
 *     numeric value (possibly null).  Such a table can be used to create
 *     bar and stacked-bar charts, where each row represents a data series and
 *     the columns represent the items within the data series.
 *     <p>A typical dataset will serialise to JSON format as follows:</p>
 *     <blockquote>{"data":{"columnKeys":["C1","C2","C3"],"rows":[{"key":"R1","values":[1.1,2.2,3.3]},{"key":"R2","values":[4.4,6.6,null]}]},"selections":[{"id":"hilite","items":[{"rowKey":"R2","columnKey":"C1"},{"rowKey":"R2","columnKey":"C2"}]},{"id":"selection","items":[{"rowKey":"R1","columnKey":"C1"}]}],"_listeners":[]}</blockquote>
 */
jsfc.KeyedValues2DDataset = function() {
    if (!(this instanceof jsfc.KeyedValues2DDataset)) {
        return new jsfc.KeyedValues2DDataset();
    }
    this.data = { "columnKeys": [], "rows": []};
    // the 'dataset' properties will be stored in a jsfc.Map, for the column
    // properties there will be one entry in the array per column, and for
    // the row properties there will be one entry per row (either null or a
    // jsfc.Map)
    this.properties = { "dataset": null, "columns": [], "rows": [] };
    this.selections = [];
    this._rowKeyToIndexMap = new jsfc.Map();
    this._columnKeyToIndexMap = new jsfc.Map();
    this._listeners = [];
};

/**
 * Returns the number of rows in the dataset.
 * @returns {!number} The row count.
 */
jsfc.KeyedValues2DDataset.prototype.rowCount = function() {
    return this.data.rows.length;
};

/**
 * Returns the number of columns in the dataset.
 * @returns {!number} The column count.
 */
jsfc.KeyedValues2DDataset.prototype.columnCount = function() {
    return this.data.columnKeys.length; 
};

/**
 * Returns true if the dataset is empty, and false otherwise.  Note that a 
 * dataset that contains all null values or all zero values is not considered
 * empty - it is required that the dataset contains zero rows and zero columns
 * to be considered empty.
 * 
 * @returns {boolean} A boolean.
 */
jsfc.KeyedValues2DDataset.prototype.isEmpty = function() {
    if (!this.data.hasOwnProperty("columnKeys")) {
        return true;
    }
    return (this.data.columnKeys.length === 0 && this.data.rows.length === 0);
};

/**
 * Adds a value to the dataset for the specified cell identified by the row
 * and column keys.  If necessary, a new row and/or column will be added to the
 * dataset.
 * 
 * @param {!string} rowKey  the row key.
 * @param {!string} columnKey  the column key.
 * @param {number} value  the value.
 * @param {boolean} [notify]  notify listeners? (the default is true).
 * @returns {jsfc.KeyedValues2DDataset} This dataset for chaining method calls.
 */
jsfc.KeyedValues2DDataset.prototype.add = function(rowKey, columnKey, value, 
        notify) {
    if (this.isEmpty()) {
        this.data.columnKeys.push(columnKey);
        this._columnKeyToIndexMap.put(columnKey, 0);
        this.data.rows.push({"key": rowKey, "values": [value]});
        this.properties.columns.push(null);
        this.properties.rows.push({"key": rowKey, "rowProperties": null, 
            "maps": [null]});
        this._rowKeyToIndexMap.put(rowKey, 0);
        return this;
    }
    var columnIndex = this.columnIndex(columnKey);
    if (columnIndex < 0) {
        // add the column key and insert a null data item in all existing rows
        var i = this.data.columnKeys.push(columnKey);
        this._columnKeyToIndexMap.put(columnKey, i - 1);
        this.properties.columns.push(null);
        var rowCount = this.data.rows.length;
        for (var r = 0; r < rowCount; r++) {
            this.data.rows[r].values.push(null);
            this.properties.rows[r].maps.push(null);
        }
        columnIndex = this.columnCount() - 1;
    }
    var rowIndex = this.rowIndex(rowKey);
    if (rowIndex < 0) {
        var rowData = new Array(this.columnCount());
        rowData[columnIndex] = value;
        var i = this.data.rows.push({"key": rowKey, "values": rowData});
        this._rowKeyToIndexMap.put(rowKey, i - 1);
        var rowItemProperties = new Array(this.columnCount());
        this.properties.rows.push({"key": rowKey, "maps": rowItemProperties});
    } else {
        // update an existing data item
        this.data.rows[rowIndex].values[columnIndex] = value;
    }
    if (notify !== false) {
        this.notifyListeners();
    }
    return this;
};

/**
 * Inserts a new row in the dataset, containing undefined values, at the 
 * specified index and assigns the supplied rowKey.
 * 
 * @param {!string} rowKey  the row key (should be a key that does not already
 *         appear in the list of row keys for the dataset).
 * @param {boolean} [notify]  notify listeners? (defaults to true).
 * @returns {undefined}
 */
jsfc.KeyedValues2DDataset.prototype.insertRow = function(rowKey, rowIndex, 
        notify) {
    if (this.rowIndex(rowKey) >= 0) {
        throw new Error("The 'rowKey' (" + rowKey 
                + ") already exists in the dataset.");
    }
    var items = jsfc.Utils.makeArrayOf(undefined, this.columnCount());
    this.data.rows.splice(rowIndex, 0, {"key": rowKey, "values": items});
    this._rowKeyToIndexMap = this._buildKeyMap(this.rowKeys());
    if (notify !== false) {
        this.notifyListeners();
    }
};
        
/**
 * Parses the supplied JSON-format string to populate the 'data' attribute
 * for this dataset.
 * 
 * @param {string} jsonStr  a string in JSON format.
 * @param {boolean} [notify]  notify listeners (optional, defaults to true).
 * 
 * @returns {jsfc.KeyedValues2DDataset} This dataset (for chaining method 
 *         calls).
 */
jsfc.KeyedValues2DDataset.prototype.parse = function(jsonStr, notify) {
    this.load(JSON.parse(jsonStr));
    if (notify !== false) {
        this.notifyListeners();
    }
    return this;
};

/**
 * Loads the supplied data object into the dataset.  The object must be either
 * an empty object {} or an object with properties "columnKeys" (an array of 
 * strings) and "rows" (an array of row objects, where each row object has a 
 * "key" attribute (a string that is the unique key identifying the row, and a 
 * "values" array containing the data values (there should be the same number 
 * of values as there are columns in the dataset - data values can be null.
 * 
 * @param {*} data  the data object.
 * @param {boolean} [notify]  notify listeners? (optional, defaults to true).
 * 
 * @returns {jsfc.KeyedValues2DDataset} This dataset (for chaining method 
 *         calls).
 */
jsfc.KeyedValues2DDataset.prototype.load = function(data, notify) {
    this.data = data;
    if (!this.data.hasOwnProperty("rows")) {
        this.data.rows = [];
    }
    if (!this.data.hasOwnProperty("columnKeys")) {
        this.data.columnKeys = [];
    }
    this._columnKeyToIndexMap = this._buildKeyMap(this.data.columnKeys);
    this._rowKeyToIndexMap = this._buildKeyMap(this.rowKeys());
    if (notify !== false) {
        this.notifyListeners();
    }
    return this;
};

jsfc.KeyedValues2DDataset.prototype._buildKeyMap = function(keys) {
    var map = new jsfc.Map();
    for (var i = 0; i < keys.length; i++) {
        map.put(keys[i], i);
    }
    return map;
};

/**
 * Returns the data value in the cell with the specified row and column indices.
 * 
 * @param {!number} r  the row index.
 * @param {!number} c  the column index.
 * @returns {number} The data value.
 */
jsfc.KeyedValues2DDataset.prototype.valueByIndex = function(r, c) {
    return this.data.rows[r].values[c];
};

/**
 * Returns the key for the row with the specified index.
 * 
 * @param {!number} r  the row index.
 * @returns {string} The row key.
 */
jsfc.KeyedValues2DDataset.prototype.rowKey = function(r) {
    return this.data.rows[r].key;
};

/**
 * Returns the index of the row with the specified key, or -1 if there is no
 * such row.
 * 
 * @param {!string} key  the row key.
 * @returns {number} The row index, or -1.
 */
jsfc.KeyedValues2DDataset.prototype.rowIndex = function(key) {
    var r = this._rowKeyToIndexMap.get(key);
    if (r !== undefined) {
        return r;
    }
    return -1;    
};

/**
 * Returns an array containing all the row keys for this dataset in the order
 * of their respective row indices.
 * 
 * @returns {Array} An array of row keys.
 */
jsfc.KeyedValues2DDataset.prototype.rowKeys = function() {
    return this.data.rows.map(function(d) { return d.key; }); 
};

/**
 * Returns the column key at the specified index.
 * 
 * @param {!number} c  the column index.
 * @returns The column key.
 */
jsfc.KeyedValues2DDataset.prototype.columnKey = function(c) {
    return this.data.columnKeys[c];  
};

/**
 * Returns the index of the column with the specified key, or -1 if there is no
 * such column.
 * 
 * @param {!string} key  the column key.
 * @returns {number} The column index, or -1.
 */
jsfc.KeyedValues2DDataset.prototype.columnIndex = function(key) {
    var c = this._columnKeyToIndexMap.get(key);
    if (c !== undefined) {
        return c;
    }
    return -1;    
};

/**
 * Returns an array containing all the column keys for this dataset.
 * 
 * @returns {Array} An array of column keys.
 */
jsfc.KeyedValues2DDataset.prototype.columnKeys = function() {
    return this.data.columnKeys.map(function(d) { return d; });
};

/**
 * Returns the value (possibly null) of the cell identified by the supplied
 * row and column keys.
 * 
 * @param {!string} rowKey  the row key.
 * @param {!string} columnKey  the column key.
 * @returns {number} The data value.
 */
jsfc.KeyedValues2DDataset.prototype.valueByKey = function(rowKey, columnKey) {
    var r = this.rowIndex(rowKey);
    var c = this.columnIndex(columnKey);
    return this.valueByIndex(r, c);
};

/**
 * Returns the value of a property for the dataset.
 * 
 * @param {!string} key  the property key.
 * @returns {*} The property value.
 */
jsfc.KeyedValues2DDataset.prototype.getProperty = function(key) {
    var map = this.properties.dataset;
    if (map) {
        return map.get(key);
    }
    return undefined;
};

/**
 * Sets the value of a property for the dataset.
 * 
 * @param {!string} key  the property key.
 * @param {*} value  the property value.
 * @param {boolean} [notify]  notify listeners? (defaults to true).
 */
jsfc.KeyedValues2DDataset.prototype.setProperty = function(key, value, notify) {
    if (!this.properties.dataset) {
        this.properties.dataset = new jsfc.Map();
    }
    if (value !== null) {
        this.properties.dataset.put(key, value);
    } else {
        this.properties.dataset.remove(key);
    }
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns an array containing all the keys of the properties defined for
 * this dataset.
 * 
 * @returns {Array}
 */
jsfc.KeyedValues2DDataset.prototype.getPropertyKeys = function() {
    if (this.properties.dataset) {
        return this.properties.dataset.keys();
    }
    return [];
};

/**
 * Clears all the dataset-level properties and sends a change notification
 * to registered listeners (unless 'notify' is set to false).
 * 
 * @param {boolean} [notify]  notify listeners? (defaults to true).
 * @returns {jsfc.KeyedValues2DDataset} This dataset for chaining method calls.
 */
jsfc.KeyedValues2DDataset.prototype.clearProperties = function(notify) {
    this.properties.dataset = null;
    if (notify !== false) {
        this.notifyListeners();
    }
    return this;
};

/**
 * Returns an array containing the keys for the properties (if any) defined
 * on the specified row.
 * 
 * @param {!string} rowKey  the row key.
 * @returns {Array} An array of keys.
 */
jsfc.KeyedValues2DDataset.prototype.getRowPropertyKeys = function(rowKey) {
    var r = this.rowIndex(rowKey);
    var map = this.properties.rows[r].rowProperties;
    if (map) {
        return map.keys();
    } else {
        return [];
    }
};

/**
 * Returns the value of a property for a row.
 * 
 * @param {!string} rowKey  the row key.
 * @param {!string} propertyKey  the property key.
 * @returns {*} The property value.
 */
jsfc.KeyedValues2DDataset.prototype.getRowProperty = function(rowKey, 
        propertyKey) {
    var r = this.rowIndex(rowKey);
    var map = this.properties.rows[r].rowProperties;
    if (map) {
        return map.get(propertyKey);
    } else {
        return undefined;
    }                
};

/**
 * Sets a property for a row and sends a change notification to all 
 * registered listeners (unless 'notify' is set to false).
 * 
 * @param {!string} rowKey  the row key.
 * @param {!string} propertyKey  the property key.
 * @param {*} value  the property value.
 * @param {boolean} [notify]  notify listeners? (defaults to true).
 * @returns {undefined}
 */
jsfc.KeyedValues2DDataset.prototype.setRowProperty = function(rowKey, 
        propertyKey, value, notify) {
    var r = this.rowIndex(rowKey);
    var map = this.properties.rows[r].rowProperties;
    if (!map) {
        map = new jsfc.Map();
        this.properties.rows[r].rowProperties = map;
    }
    map.put(propertyKey, value);
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Clears the row properties for the specified row and sends a change 
 * notification to registered listeners (unless 'notify' is set to false).
 * 
 * @param {!string} rowKey  the row key.
 * @param {boolean} [notify]  notify listeners? (defaults to true).
 * 
 * @returns {undefined}
 */
jsfc.KeyedValues2DDataset.prototype.clearRowProperties = function(rowKey, 
        notify) {
    var r = this.rowIndex(rowKey);
    this.properties.rows[r].rowProperties = null;    
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns an array containing all the keys for the properties defined for
 * the specified column.
 * 
 * @param {!string} columnKey  the column key.
 * @returns {Array} The property keys.
 */
jsfc.KeyedValues2DDataset.prototype.getColumnPropertyKeys = function(columnKey) {
    var c = this.columnIndex(columnKey);
    var map = this.properties.columns[c];
    if (map) {
        return map.keys();
    } else {
        return [];
    }
};

/**
 * Returns the value of a property defined for the specified column.
 * 
 * @param {!string} columnKey  the column key.
 * @param {!string} propertyKey  the property key.
 * @returns {*} The property value.
 */
jsfc.KeyedValues2DDataset.prototype.getColumnProperty = function(columnKey, 
        propertyKey) {
    var c = this.columnIndex(columnKey);
    var map = this.properties.columns[c];
    if (map) {
        return map.get(propertyKey);
    } else {
        return undefined;
    }
};

/**
 * Sets a property for a column and sends a change notification to registered
 * listeners (unless 'notify' is set to false).
 * 
 * @param {!string} columnKey  the column key.
 * @param {!string} propertyKey  the property key.
 * @param {*} value  the property value.
 * @param {boolean} [notify]  notify listeners? (defaults to true).
 * @returns {undefined}
 */
jsfc.KeyedValues2DDataset.prototype.setColumnProperty = function(columnKey, 
        propertyKey, value, notify) {
    var c = this.columnIndex(columnKey);
    var map = this.properties.columns[c];
    if (!map) {
        map = new jsfc.Map();
        this.properties.columns[c] = map;
    }
    map.put(propertyKey, value);
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Clears all the column properties for the specified column and sends a 
 * change notification to registered listeners (unless 'notify' is set to 
 * false).
 * 
 * @param {!string} columnKey  the column key.
 * @param {boolean} [notify]  notify listeners? (defaults to true).
 * @returns {undefined}
 */
jsfc.KeyedValues2DDataset.prototype.clearColumnProperties = function(columnKey,
        notify) {
    var c = this.columnIndex(columnKey);
    this.properties.columns[c] = null;      
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Returns a property for the specified data item.
 * 
 * @param {!string} rowKey  the row key.
 * @param {!string} columnKey  the column key.
 * @param {!string} propertyKey  the property key.
 * @returns {*} The property value.
 */
jsfc.KeyedValues2DDataset.prototype.getItemProperty = function(rowKey, 
        columnKey, propertyKey) {
    var r = this.rowIndex(rowKey);
    var c = this.columnIndex(columnKey);
    var map = this.properties.rows[r][c];
    if (map) {
        return map.get(propertyKey);
    }
};

/**
 * Sets a property for the specified data item and sends a change notification
 * to all registered listeners (unless 'notify' is set to false).
 * 
 * @param {!string} rowKey  the row key.
 * @param {!string} columnKey  the column key.
 * @param {!string} propertyKey  the property key.
 * @param {*} value  the property value.
 * @param {boolean} [notify]  notify listeners? (defaults to true).
 * @returns {undefined}
 */
jsfc.KeyedValues2DDataset.prototype.setItemProperty = function(rowKey, 
        columnKey, propertyKey, value, notify) {
    var r = this.rowIndex(rowKey);
    var c = this.columnIndex(columnKey);
    var map = this.properties.rows[r][c];
    if (!map) {
        map = new jsfc.Map();
        this.properties.rows[r][c] = map;
    }
    map.put(propertyKey, value);
};

/**
 * Returns the keys for the properties defined for a data item in the dataset.
 * 
 * @param {!string} rowKey  the row key.
 * @param {!string} columnKey  the column key.
 * @returns {Array} An array containing the property keys.
 */
jsfc.KeyedValues2DDataset.prototype.getItemPropertyKeys = function(rowKey, 
        columnKey) {
    var r = this.rowIndex(rowKey);
    var c = this.columnIndex(columnKey);
    var map = this.properties.rows[r][c];
    if (map) {
        return map.keys();
    } else {
        return [];
    }
};

/**
 * Clears all properties for one item and sends a change notification to
 * registered listeners (unless 'notify' is set to false).
 * 
 * @param {!string} rowKey  the row key.
 * @param {!string} columnKey  the column key.
 * @returns {undefined}
 */
jsfc.KeyedValues2DDataset.prototype.clearItemProperties = function(rowKey, 
        columnKey, notify) {
    var r = this.rowIndex(rowKey);
    var c = this.columnIndex(columnKey);
    this.properties.rows[r][c] = null;
    if (notify !== false) {
        this.notifyListeners();
    }
};

/**
 * Marks an item as selected within a selection with the specified ID.
 * 
 * @param {string} selectionId  the selection id.
 * @param {string} rowKey  the row key.
 * @param {string} columnKey  the column key.
 * 
 * @returns {jsfc.KeyedValues2DDataset} This dataset (for chaining method calls).
 */
jsfc.KeyedValues2DDataset.prototype.select = function(selectionId, rowKey, 
        columnKey) {
    var selection;
    var selectionIndex = this._indexOfSelection(selectionId);
    if (selectionIndex < 0) { // no selection with that id
        selection = {"id": selectionId, "items": []};
        this.selections.push(selection);
    } else {
        selection = this.selections[selectionIndex];
    }
    var i = jsfc.Utils.findInArray(selection.items, function(item) {
        return (item.rowKey === rowKey && item.columnKey === columnKey); 
    });
    if (i < 0) {
        selection.items.push({"rowKey": rowKey, "columnKey": columnKey});
    }
    return this;
};

/**
 * Resets the selection state of the specified item. 
 * 
 * @param {string} selectionId  the ID for the set of selected items.
 * @param {string} rowKey  the row key.
 * @param {string} columnKey  the column key.
 * 
 * @returns {jsfc.KeyedValues2DDataset} This dataset (for chaining method calls).
 */
jsfc.KeyedValues2DDataset.prototype.unselect = function(selectionId, rowKey, 
        columnKey) {
    var selectionIndex = this._indexOfSelection(selectionId);
    if (selectionIndex >= 0) {
        var selection = this.selections[selectionIndex];
        var i = jsfc.Utils.findInArray(selection.items, function(obj, i) {
            return (obj.rowKey === rowKey && obj.columnKey === columnKey); 
        });
        if (i >= 0) {
            selection.items.splice(i, 1);
        }
    } 
    return this;
};

/**
 * Returns true if the specified item is selected (for the given selectionId) 
 * and false otherwise.
 * 
 * @param {string} selectionId  the selection ID.
 * @param {string} rowKey  the row key.
 * @param {string} columnKey  the column key.
 * 
 * @returns {boolean} A boolean (the selection state).
 */
jsfc.KeyedValues2DDataset.prototype.isSelected = function(selectionId, rowKey, 
        columnKey) {
    var selection;
    var selectionIndex = this._indexOfSelection(selectionId);
    if (selectionIndex < 0) {
        return false;
    } else {
        selection = this.selections[selectionIndex];
    }
    return (jsfc.Utils.findInArray(selection.items, function(obj) {
        return (obj.rowKey === rowKey && obj.columnKey === columnKey); 
    }) >= 0); 
};

/**
 * Clears any items from the selection with the specified id.
 * 
 * @param {string} selectionId  the selection ID.
 * @returns {jsfc.KeyedValues2DDataset} This dataset (for chaining method calls).
 */
jsfc.KeyedValues2DDataset.prototype.clearSelection = function(selectionId) {
    var selectionIndex = this._indexOfSelection(selectionId);
    if (selectionIndex >= 0) {
        this.selections.splice(selectionIndex, 1);
    }
    return this;
};

/**
 * Returns the index of the selection with the specified ID, or -1 if there is 
 * no such selection.
 * 
 * @param {string} selectionId  the selection ID.
 * @returns {number} The selection index.
 */
jsfc.KeyedValues2DDataset.prototype._indexOfSelection = function(selectionId) {
    return jsfc.Utils.findInArray(this.selections, function(item) {
        return item.id === selectionId;
    });
};

/**
 * Registers a listener to receive notification of changes to the dataset.
 * @param {Object} listener  the listener.
 * @returns {jsfc.KeyedValues2DDataset} This dataset (for chaining method 
 *         calls).
 */
jsfc.KeyedValues2DDataset.prototype.addListener = function(listener) {
    this._listeners.push(listener);
    return this;
};

/**
 * Deregisters a listener so that it no longer receives notification of changes
 * to the dataset.
 * 
 * @param {Object} listener  the listener.
 * @returns {jsfc.KeyedValues2DDataset} This dataset (for chaining method 
 *         calls).
 */
jsfc.KeyedValues2DDataset.prototype.removeListener = function(listener) {
    var i = this._listeners.indexOf(listener);
    if (i >= 0) {
        this._listeners.splice(i, 1);
    }
    return this;
};

/**
 * Notifies all registered listeners that there has been a change to this 
 * dataset.
 * 
 * @returns {jsfc.KeyedValues2DDataset} This dataset (for chaining method 
 *         calls).
 */
jsfc.KeyedValues2DDataset.prototype.notifyListeners = function() {
    for (var i = 0; i < this._listeners.length; i++) {
        this._listeners[i].datasetChanged(this);
    }
    return this;
};

