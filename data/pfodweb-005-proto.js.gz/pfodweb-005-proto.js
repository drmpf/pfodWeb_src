/*
   resizeAndDimensions.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Resize and dimension-persistence methods for the DrawingViewer class.
// Assigned to DrawingViewer.prototype after the class is defined in pfodWeb.js.
//
// State read:    canvas, ctx, hasReceivedFirstResponse, touchState, redraw.redrawDrawingManager,
//                lastWindowWidth, lastWindowHeight (logical dims no longer
//                tracked here — a menu has zero or more drawing items, no
//                single logical dimension)
// State written: lastWindowWidth, lastWindowHeight
// Calls:         redraw.resizeCanvas(), redraw.performRedraw(), window.chartDisplay.handleResize()
// Called by:     constructor, responseHandlers:handleDwgResponse,
//                chartAndRawData:exitChartDisplay, drawingProcessing:redrawCanvas,
//                toolbarAndMenu:setupToolbarButtons, navigationAndQueue:queueInitialRequest,
//                responseHandlers:processMenuResponse, connectionSetup resize listener

Object.assign(DrawingViewer.prototype, {

  // Return the localStorage key used to save/load canvas dimensions.
  // Uses an iframe-specific key when running inside an iframe, otherwise a fixed main key.
  getDimensionStorageKey() {
    const isIframe = window.self !== window.top;
    const referrer = document.referrer;

    if (isIframe && referrer) {
      // Extract page name from referrer for iframe context
      const referrerPath = new URL(referrer).pathname;
      const pageName = referrerPath.split('/').pop().split('.')[0] || 'unknown';
      return `pfodWeb_dimensions_iframe_${pageName}`;
    } else {
      // Main window context
      return 'pfodWeb_dimensions_main';
    }
  },

  // Load previously saved canvas dimensions from localStorage.
  // Returns the saved dims object {windowWidth, windowHeight}, or null if
  // nothing is stored or the stored value is corrupt.
  loadPreviousDimensions() {
    try {
      const storageKey = this.getDimensionStorageKey();
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        const dims = JSON.parse(saved);
        console.log(`[DIMENSIONS] Loaded previous dimensions from ${storageKey}: window=${dims.windowWidth}x${dims.windowHeight}`);
        return dims;
      } else {
        console.log(`[DIMENSIONS] No previous dimensions found for ${storageKey}`);
        return null;
      }
    } catch (e) {
      console.log('[DIMENSIONS] Error loading dimensions:', e);
      return null;
    }
  },

  // Save current canvas dimensions to localStorage for future reloads.
  saveDimensions(windowWidth, windowHeight) {
    try {
      const dims = {
        windowWidth: windowWidth,
        windowHeight: windowHeight
      };
      const storageKey = this.getDimensionStorageKey();
      localStorage.setItem(storageKey, JSON.stringify(dims));
      console.log(`[DIMENSIONS] Saved dimensions to ${storageKey}: window=${windowWidth}x${windowHeight}`);
    } catch (e) {
      console.log('[DIMENSIONS] Error saving dimensions:', e);
    }
  },

  // Central resize dispatcher. Called on window resize events and after any layout change
  // (menu show/hide, chart enter/exit, drawing data arrival).
  // Delegates to the appropriate resize handler based on the current display mode,
  // and persists dimension changes to localStorage for the next session.
  handleResize() {
    console.log('[RESIZE] handleResize() called, className:', document.body.className, 'chartDisplay exists:', !!window.chartDisplay);

    // Check if in chart mode - use different resize handling
    if (document.body.className === 'chart-mode' && window.chartDisplay) {
      console.log('[RESIZE] In chart mode - delegating to ChartDisplay.handleResize()');
      window.chartDisplay.handleResize(this.chartCanvas);
      return;
    }

    console.log('[RESIZE] Not in chart mode - using drawing resize logic');

    // While waiting for the first device response, keep the blue initial screen.
    if (!this.hasReceivedFirstResponse) {
      console.log('[RESIZE] Waiting for first response - repainting initial screen');
      this.updateCanvasMessage('Requesting Main Menu ...');
      return;
    }

    // A menu has zero or more drawing items, each with its own logical
    // dimensions — there is no single "logical width/height" for the
    // screen.  Track only window size for change-detection here; per-item
    // canvas sizing is delegated to pfodMenuDisplay.handleMenuResize.
    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight - 40; // Subtract 40px for toolbar

    const windowChanged =
      this.lastWindowWidth !== windowWidth ||
      this.lastWindowHeight !== windowHeight;

    if (windowChanged) {
      console.log(`[DIMENSIONS] Window size changed - saving: window=${windowWidth}x${windowHeight}`);
      this.lastWindowWidth = windowWidth;
      this.lastWindowHeight = windowHeight;
      this.saveDimensions(windowWidth, windowHeight);
    }

    // Delegate resize to menu-mode handler (per-item canvases)
    if (document.body.className === 'menu-mode' && window.pfodMenuDisplay) {
      console.log('[RESIZE] In menu-mode - delegating resize to pfodMenuDisplay.handleMenuResize');
      window.pfodMenuDisplay.handleMenuResize(this.redraw);
    } else {
      console.log('[RESIZE] No resize action for current mode:', document.body.className);
    }
  },

  // Set the text on the blue message div.
  // Used for status messages while waiting for a device response.
  updateCanvasMessage(message) {
    const el = document.getElementById('canvas-message');
    if (el) el.textContent = message;
  },

  // Clear the text on the blue message div.
  clearCanvasMessage() {
    const el = document.getElementById('canvas-message');
    if (el) el.textContent = '';
  }

});
/*
   toolbarAndMenu.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Toolbar button setup, toolbar drop-down menu, and context menu methods
// for the DrawingViewer class.
// Assigned to DrawingViewer.prototype after the class is defined in pfodWeb.js.
//
// State read:    chartOnlyMode, commandStack, menuNavStack, currentRefreshCmd,
//                hasReceivedFirstResponse, currentChartInfo, currentChart
// State written: currentRefreshCmd, currentRefreshCmdType
// Calls:         chartAndRawData:exitChartDisplay, chartAndRawData:displayChart,
//                chartAndRawData:displayChartWithPlotNo,
//                resizeAndDimensions:updateCanvasMessage, resizeAndDimensions:handleResize,
//                navigationAndQueue:clearPendingQueue, navigationAndQueue:addToRequestQueue,
//                navigationAndQueue:versionedMenuCmd
// Called by:     connectionSetup:setupEventListeners (once at startup via setupToolbarButtons)

Object.assign(DrawingViewer.prototype, {

  // Sync the reload/freeze toolbar buttons to match the current display mode.
  // Called whenever the body class changes (entering/leaving chart-mode).
  updateRefreshButtonState() {
    const btnReload = document.getElementById('btn-reload');
    const btnFreeze = document.getElementById('btn-freeze');
    const btnFreezePrev = document.getElementById('btn-freeze-prev');
    const btnFreezeNext = document.getElementById('btn-freeze-next');

    const isChartMode = document.body.className === 'chart-mode';
    if (btnReload) btnReload.disabled = isChartMode;
    console.log('[TOOLBAR] Refresh button state updated: disabled=', isChartMode, 'mode=', document.body.className);

    // Sync freeze button visual state with chartDisplay.frozenStartRow
    const isFrozen = isChartMode && window.chartDisplay && window.chartDisplay.frozenStartRow !== null;
    if (btnFreeze) btnFreeze.classList.toggle('freeze-active', isFrozen);
    if (btnFreezePrev) btnFreezePrev.disabled = !isFrozen;
    if (btnFreezeNext) btnFreezeNext.disabled = !isFrozen;

    if (!isChartMode) {
      console.log('[TOOLBAR] Leaving chart-mode, chart polling will be stopped in exitChartDisplay()');
      window.chartDisplay.stopUpdatePolling();
    }
  },

  // Toggle freeze state: freeze the chart at the current display start row, or unfreeze.
  // While frozen, CSV data continues to accumulate but the chart is not redrawn by polling.
  // Left/right arrow buttons navigate the frozen window by half the current maxPoints.
  // Reachable only via the #btn-freeze click handler below, and that button
  // is CSS-hidden (.chart-only) outside chart-mode — so window.chartDisplay
  // and this.currentChartInfo are always already set by the time this runs.
  toggleFreezeChart() {
    const btnFreeze = document.getElementById('btn-freeze');
    const btnFreezePrev = document.getElementById('btn-freeze-prev');
    const btnFreezeNext = document.getElementById('btn-freeze-next');

    const allLines = window.csvCollector.getFieldCounts().includes(this.currentChartInfo.fieldCount)
      ? window.csvCollector.getCSVLines(this.currentChartInfo.fieldCount) : [];
    console.error('[FREEZE_DBG] toggleFreezeChart: fieldCount=', this.currentChartInfo.fieldCount,
      'allLines.length=', allLines.length, 'maxPoints=', this.currentChartInfo.maxPoints,
      'currently frozen=', window.chartDisplay.frozenStartRow !== null);

    if (window.chartDisplay.frozenStartRow === null) {
      // Freeze: lock start row, stop live updates.
      // Does NOT recreate the chart or touch axis configuration.
      window.chartDisplay.freezeChart(allLines, this.currentChartInfo.maxPoints);
      btnFreeze.classList.add('freeze-active');
      btnFreezePrev.disabled = false;
      btnFreezeNext.disabled = false;
    } else {
      // Unfreeze: reposition display to latest data and resume live updates.
      // Does NOT recreate the chart or touch axis configuration.
      window.chartDisplay.unfreezeChart();
      btnFreeze.classList.remove('freeze-active');
      btnFreezePrev.disabled = true;
      btnFreezeNext.disabled = true;
      // Trigger an immediate redraw at the latest data window.
      // updateMultiSubplotChart only replaces the dataset; it never touches axis constraints.
      window.chartDisplay.updateMultiSubplotChart(allLines);
    }
  },

  // Step the frozen display window by half a maxPoints window, in the given
  // direction (-1 = back, 1 = forward). Shared by the freeze-prev/freeze-next
  // toolbar buttons, which are only enabled while frozen (i.e. only reachable
  // after toggleFreezeChart's freeze branch has already run).
  shiftFrozenWindow(direction) {
    const allLines = window.csvCollector.getFieldCounts().includes(this.currentChartInfo.fieldCount)
      ? window.csvCollector.getCSVLines(this.currentChartInfo.fieldCount) : [];
    console.error('[FREEZE_DBG] shiftFrozenWindow: direction=', direction, 'fieldCount=', this.currentChartInfo.fieldCount,
      'allLines.length=', allLines.length, 'maxPoints=', this.currentChartInfo.maxPoints,
      'frozenStartRow(before)=', window.chartDisplay.frozenStartRow);
    window.chartDisplay.shiftFrozenRow(allLines, this.currentChartInfo.maxPoints, direction);
    window.chartDisplay.lastDataLineCount = 0;
    window.chartDisplay.updateMultiSubplotChart(allLines);
  },

  // Wire up click handlers for all toolbar buttons (back, reload, freeze, menu).
  setupToolbarButtons() {
    // Left arrow button - pop previous command from stack or request main menu if stack is empty
    const btnLeftArrow = document.getElementById('btn-left-arrow');
    if (btnLeftArrow) {
      // Disable button if in chart-only mode
      if (this.chartOnlyMode) {
        btnLeftArrow.disabled = true;
        console.log('[CHART_MODE] Left arrow button disabled in chart-only mode');
      }

      let backBtnDown = false;
      btnLeftArrow.addEventListener('pointerdown', () => { backBtnDown = true; });
      btnLeftArrow.addEventListener('pointercancel', () => { backBtnDown = false; });
      btnLeftArrow.addEventListener('pointerup', () => {
        if (!backBtnDown) return;
        backBtnDown = false;
        // Native `disabled` should already block pointer events on its own,
        // but is checked explicitly here too (matches the existing
        // chartOnlyMode guard just below) — e.g. dwgControlsPanelUI.js
        // disables this button while the Dwg Controls Panel is showing.
        if (btnLeftArrow.disabled) return;
        console.log('[TOOLBAR] Left arrow pointerup className=', document.body.className);

        // If in chart-only mode, prevent going back (button disabled)
        if (this.chartOnlyMode) {
          console.log('[CHART_MODE] Back button disabled in chart-only mode');
          return;
        }

        // Capture current mode before hide() changes the class
        const wasInMenuMode = document.body.className === 'menu-mode';
        const wasInInputMode = document.body.className === 'input-mode'
          || document.body.className === 'numeric-input-mode'
          || document.body.className === 'selection-mode'
          || document.body.className === 'chart-mode'
          || document.body.className === 'streaming-mode';

        // If in chart mode, stop polling immediately (regardless of back target)
        if (document.body.className === 'chart-mode') {
          console.log('[TOOLBAR] In chart mode - stopping chart polling immediately at', Date.now());
          this.exitChartDisplay();
          console.log('[TOOLBAR] exitChartDisplay completed at', Date.now(), 'className now=', document.body.className);
          // Show "Requesting Menu..." on the canvas while waiting for the back response.
          // exitChartDisplay() already called handleResize() so the canvas is at full message-mode dimensions.
          this.updateCanvasMessage('Requesting Menu ...');
        } else if (wasInMenuMode && window.pfodMenuDisplay) {
          // Exit menu-mode so the canvas is restored before the back response arrives
          console.log('[TOOLBAR] In menu-mode - hiding menu display before back navigation');
          window.pfodMenuDisplay.hide();
          this.redraw.clearMenuCanvases();
          // Resize canvas to full message-mode dimensions before drawing the message.
          this.handleResize();
          // Show "Requesting Menu..." on the canvas while waiting for the back response
          this.updateCanvasMessage('Requesting Menu ...');
        } else if (document.body.className === 'streaming-mode') {
          console.log('[TOOLBAR] In streaming-mode - exiting streaming display before back navigation');
          this.exitStreamingData();
          this.handleResize();
          this.updateCanvasMessage('Requesting Menu ...');
        } else if (document.body.className === 'input-mode' && window.pfodInputDisplay) {
          console.log('[TOOLBAR] In input-mode - hiding input display before back navigation');
          window.pfodInputDisplay.hide();
          this.handleResize();
          this.updateCanvasMessage('Requesting Menu ...');
        } else if (document.body.className === 'numeric-input-mode' && window.pfodNumericInputDisplay) {
          console.log('[TOOLBAR] In numeric-input-mode - hiding numeric input before back navigation');
          window.pfodNumericInputDisplay.hide();
          this.handleResize();
          this.updateCanvasMessage('Requesting Menu ...');
        } else {
          console.log('[TOOLBAR] Not in chart or menu mode, className=', document.body.className);
        }

        let cmdToSend;
        if (wasInInputMode) {
          // Input screen does NOT push to menuNavStack — resend top without popping
          if (this.menuNavStack.length > 0) {
            cmdToSend = this.versionedMenuCmd(this.menuNavStack[this.menuNavStack.length - 1]);
            console.log('[TOOLBAR] Input back - resending menu cmd:', cmdToSend);
          } else if (this.commandStack.length > 0) {
            cmdToSend = this.commandStack[this.commandStack.length - 1];
            console.log('[TOOLBAR] Input back - resending drawing cmd:', cmdToSend);
          } else {
            cmdToSend = '{.}';
            console.log('[TOOLBAR] Input back - no stacks, sending main menu');
          }
          // Stop any pending auto-refresh fire — the back response will
          // re-evaluate scheduleNextUpdate.  itemRefreshTimes entries are
          // preserved (they're per-drawing/menu cached state).
          if (this.updateTimer) { clearTimeout(this.updateTimer); this.updateTimer = null; }
          this.clearPendingQueue();
          this.addToRequestQueue(cmdToSend, null, null, 'back');
          return;
        } else if ((wasInMenuMode || document.body.className === 'message-mode') && this.menuNavStack.length > 0) {
          // Menu back: pop top if more than one entry, then use the new top.
          // If only one entry, keep it and use it for both refresh and back.
          // message-mode is the transient "Requesting Menu" overlay state left
          // by the menu hide() during nav (e.g. after the uncached-{;} error
          // fallback) — still source from menuNavStack here, NOT commandStack,
          // since menuNavStack is the source of truth for menu-nav history.
          if (this.menuNavStack.length > 1) {
            this.menuNavStack.pop();
            console.log('[TOOLBAR] Menu back - popped stack, now:', JSON.stringify(this.menuNavStack));
          } else {
            console.log('[TOOLBAR] Menu back - single entry, not popping:', JSON.stringify(this.menuNavStack));
          }
          cmdToSend = this.menuNavStack[this.menuNavStack.length - 1];
          console.log('[TOOLBAR] Menu back - sending:', cmdToSend);
        } else {
          // Canvas/drawing back: use existing command stack
          if (this.commandStack.length > 0) {
            cmdToSend = this.commandStack.pop();
            console.log('[TOOLBAR] Popped command from stack:', cmdToSend);
          } else {
            cmdToSend = '{.}';
            console.log('[TOOLBAR] Command stack is empty - using main menu command');
          }
          this.currentRefreshCmd = cmdToSend;
          this.currentRefreshCmdType = 'back';
        }

        // Stop any pending auto-refresh fire — the back response will
        // re-evaluate scheduleNextUpdate.  itemRefreshTimes entries are
        // preserved (they're per-drawing/menu cached state).
        if (this.updateTimer) { clearTimeout(this.updateTimer); this.updateTimer = null; }
        this.clearPendingQueue();

        // Show "Requesting Main Menu ..." when the back target is the main
        // menu (cmd is bare {.}).  Replaces the prior "Requesting Menu ..."
        // overlay set when the menu was hidden.  Done before version-stamping
        // so we test the bare cmd, not the {Vx:.} form.
        if (cmdToSend === '{.}') {
          this.updateCanvasMessage('Requesting Main Menu ...');
        }

        // Use versioned cmd for menu back if we have a cached version (like drawing refresh)
        if (wasInMenuMode) {
          cmdToSend = this.versionedMenuCmd(cmdToSend);
        }
        this.addToRequestQueue(cmdToSend, null, null, 'back');
        console.log('[TOOLBAR] Back navigation request queued');
      });
    }

    // Middle button (reload) - resend last command
    const btnReload = document.getElementById('btn-reload');
    if (btnReload) {
      btnReload.addEventListener('click', () => {
        // See btnLeftArrow's own pointerup guard comment above.
        if (btnReload.disabled) return;
        console.log('[TOOLBAR] Reload button clicked');
        // Stop any pending auto-refresh fire — the reload response will
        // re-evaluate scheduleNextUpdate.  itemRefreshTimes entries are
        // preserved (they're per-drawing/menu cached state).
        if (this.updateTimer) { clearTimeout(this.updateTimer); this.updateTimer = null; }
        this.clearPendingQueue();

        let cmdToSend;
        let reqType;
        if (this.menuNavStack.length > 0) {
          // We have menu-nav history — reload the current menu (top of stack).
          // Holds whether the menu is currently visible or we're in transient
          // message-mode after a back-nav error or similar.  Reply will be a
          // menu shape ({,...} or {;...}), so tag as menuRefresh for the
          // response shape validator.
          cmdToSend = this.versionedMenuCmd(this.menuNavStack[this.menuNavStack.length - 1]);
          reqType = 'menuRefresh';
          console.log('[TOOLBAR] Menu refresh - resending menu cmd:', cmdToSend, 'stack:', JSON.stringify(this.menuNavStack));
        } else if (!this.hasReceivedFirstResponse) {
          // No nav history yet (initial connection never returned a menu).
          // Re-issue the main-menu request — reply will be a {,} so tag as
          // mainMenu, NOT refresh, so the shape validator accepts it.
          cmdToSend = '{.}';
          reqType = 'mainMenu';
          console.log('[TOOLBAR] Initial reload - re-requesting main menu:', cmdToSend);
        } else {
          // Drawing / chart / other-display context — re-send the last cmd.
          // currentRefreshCmd MAY be a menu cmd here (menuCmdSet records all
          // cmds that returned a menu shape), in which case the reply will
          // be a menu — tag accordingly so the response shape validator
          // accepts it.  Otherwise it's a drawing refresh.
          cmdToSend = this.currentRefreshCmd !== null ? this.currentRefreshCmd : '{.}';
          const bareCmd = pfodStripMenuCmdVersion(cmdToSend);
          if (this.menuCmdSet && this.menuCmdSet.has(bareCmd)) {
            reqType = 'menuRefresh';
            console.log('[TOOLBAR] Reload (menu cmd) - sending:', cmdToSend);
          } else {
            reqType = 'refresh';
            console.log('[TOOLBAR] Sending refresh command:', cmdToSend);
          }
        }

        // Show the more specific "Requesting Main Menu ..." message whenever
        // the cmd is the bare main-menu request (with or without prior state).
        if (cmdToSend === '{.}') {
          this.updateCanvasMessage('Requesting Main Menu ...');
        }

        this.addToRequestQueue(cmdToSend, null, null, reqType);
      });
    }

    // Freeze button (chart-mode only) - toggle freeze/unfreeze
    const btnFreeze = document.getElementById('btn-freeze');
    if (btnFreeze) {
      btnFreeze.addEventListener('click', () => {
        console.log('[TOOLBAR] Freeze button clicked');
        this.toggleFreezeChart();
      });
    }

    // Freeze prev arrow - step back half a window
    const btnFreezePrev = document.getElementById('btn-freeze-prev');
    if (btnFreezePrev) {
      btnFreezePrev.addEventListener('click', () => this.shiftFrozenWindow(-1));
    }

    // Freeze next arrow - step forward half a window
    const btnFreezeNext = document.getElementById('btn-freeze-next');
    if (btnFreezeNext) {
      btnFreezeNext.addEventListener('click', () => this.shiftFrozenWindow(1));
    }

    // Right button (three dots) - show toolbar menu
    const btnMenu = document.getElementById('btn-menu');
    if (btnMenu) {
      btnMenu.addEventListener('click', (event) => {
        // See btnLeftArrow's own pointerup guard comment above.
        if (btnMenu.disabled) return;
        console.log('[TOOLBAR] Menu button clicked');
        this.showToolbarMenu(event);
      });
    }

    console.log('[TOOLBAR] Toolbar button listeners setup complete');
  },

  // Build and display the toolbar drop-down menu above the three-dots button.
  // Menu contents vary by current display mode (chart vs drawing).
  showToolbarMenu(event) {
    const menuTime = Date.now();
    console.log('[TOOLBAR_MENU] showToolbarMenu called at', menuTime, 'className=', document.body.className);

    const btnMenu = document.getElementById('btn-menu');
    if (!btnMenu) {
      console.error('[TOOLBAR_MENU] Menu button not found');
      return;
    }

    // Remove any existing menu
    const existing = document.getElementById('toolbar-menu');
    if (existing) {
      existing.remove();
    }

    // Create menu
    const menu = document.createElement('div');
    menu.id = 'toolbar-menu';
    menu.style.cssText = `
      position: fixed;
      background-color: white;
      border: 2px solid #333;
      border-radius: 4px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      z-index: 999999;
      min-width: 240px;
      padding: 4px 0;
      visibility: hidden;
    `;

    // Add menu item for raw data
    const item = document.createElement('div');
    item.style.cssText = `
      padding: 15px 24px;
      cursor: pointer;
      user-select: none;
      font-family: Arial, sans-serif;
      font-size: 21px;
      color: #000;
      white-space: nowrap;
    `;
    item.textContent = 'Raw Message Viewer';
    item.addEventListener('click', () => {
      console.log('[TOOLBAR_MENU] Raw Message Viewer clicked');
      if (window.rawMessageViewer) {
        window.rawMessageViewer.show();
        console.log('[TOOLBAR_MENU] Opened raw data viewer');
      }
      menu.remove();
    });
    item.addEventListener('mouseover', () => {
      item.style.backgroundColor = '#e8e8e8';
    });
    item.addEventListener('mouseout', () => {
      item.style.backgroundColor = 'transparent';
    });

    menu.appendChild(item);

    // Second menu item depends on current display mode:
    //   chart-mode -> "Open Chart Configuration" (opens the chart config side panel)
    //   any other mode (menu-mode, message-mode, rawdata-mode, etc.) -> "Chart" (switches to chart display)
    const secondItem = document.createElement('div');
    secondItem.style.cssText = `
      padding: 15px 24px;
      cursor: pointer;
      user-select: none;
      font-family: Arial, sans-serif;
      font-size: 21px;
      color: #000;
      white-space: nowrap;
    `;
    secondItem.addEventListener('mouseover', () => {
      secondItem.style.backgroundColor = '#e8e8e8';
    });
    secondItem.addEventListener('mouseout', () => {
      secondItem.style.backgroundColor = 'transparent';
    });

    if (document.body.className === 'chart-mode') {
      // Chart is currently showing - offer to open chart configuration panel
      secondItem.textContent = 'Open Chart Configuration';
      secondItem.addEventListener('click', () => {
        console.log('[TOOLBAR_MENU] Open Chart Configuration clicked');
        if (window.chartConfigViewer) {
          window.chartConfigViewer.show();
        }
        menu.remove();
      });
    } else {
      // Drawing is currently showing - offer to switch to chart display
      secondItem.textContent = 'Chart';
      secondItem.addEventListener('click', () => {
        const clickTime = Date.now();
        console.log('[TOOLBAR_MENU] Chart clicked at', clickTime);
        console.log('[TOOLBAR_MENU] className=', document.body.className);
        console.log('[TOOLBAR_MENU] drawingViewer=', drawingViewer ? 'exists' : 'undefined');

        // Ensure chartDisplay is initialized (in case Chart clicked before initialization completes)
        console.log('[TOOLBAR_MENU] Checking chartDisplay at', Date.now(), 'chartDisplay:', window.chartDisplay ? 'exists' : 'undefined');
        if (!window.chartDisplay) {
          console.log('[TOOLBAR_MENU] chartDisplay not initialized, creating now...');
          try {
            window.chartDisplay = new ChartDisplay();
            console.log('[TOOLBAR_MENU] chartDisplay created successfully');
          } catch (e) {
            console.error('[TOOLBAR_MENU] Failed to create chartDisplay:', e);
            menu.remove();
            return;
          }
        }

        // Cancel any armed auto-refresh timer — chart-mode has nothing to refresh,
        // and the mode-gate in scheduleNextUpdate keeps it disarmed until the user
        // returns to canvas/menu mode.
        if (this.updateTimer) { clearTimeout(this.updateTimer); this.updateTimer = null; }

        // Clear queued commands
        console.log('[TOOLBAR_MENU] Starting to clear queued commands at', Date.now(), 'elapsed:', Date.now() - clickTime, 'ms');
        drawingViewer.clearPendingQueue();
        console.log('[TOOLBAR_MENU] Finished clearing queued commands at', Date.now(), 'elapsed:', Date.now() - clickTime, 'ms');

        // Open chart display
        console.log('[TOOLBAR_MENU] Starting displayChart at', Date.now(), 'elapsed:', Date.now() - clickTime, 'ms');
        document.body.className = 'chart-mode';
        console.log('[CHART] Switched to chart-mode CSS');
        this.displayChart("Chart", "", 500);
        console.log('[TOOLBAR_MENU] Finished displayChart at', Date.now(), 'elapsed:', Date.now() - clickTime, 'ms');
        console.log('[TOOLBAR_MENU] After displayChart, className=', document.body.className);

        menu.remove();
        console.log('[TOOLBAR_MENU] Menu removed at', Date.now(), 'total elapsed:', Date.now() - clickTime, 'ms');
      });
    }

    menu.appendChild(secondItem);

    // Blank spacer item between the two mode-dependent items and Exit
    const spacerItem = document.createElement('div');
    spacerItem.style.cssText = `
      padding: 15px 24px;
      user-select: none;
    `;
    menu.appendChild(spacerItem);

    // Exit item — disconnects and returns to connection setup prompt
    const exitItem = document.createElement('div');
    exitItem.style.cssText = `
      padding: 15px 24px;
      cursor: pointer;
      user-select: none;
      font-family: Arial, sans-serif;
      font-size: 21px;
      color: #000;
      white-space: nowrap;
    `;
    exitItem.textContent = 'Exit';
    exitItem.addEventListener('mouseover', () => { exitItem.style.backgroundColor = '#e8e8e8'; });
    exitItem.addEventListener('mouseout',  () => { exitItem.style.backgroundColor = 'transparent'; });
    exitItem.addEventListener('click', () => {
      menu.remove();
      if (!drawingViewer) return;

      // Immediate visual ack: the queue still has to drain (any in-flight cmd
      // finishes, then {!} fires as a single attempt thanks to the no-retry
      // guard in each adapter's send(), then _exitToConnectionScreen reloads
      // the page).  The overlay tells the user their click was accepted while
      // that happens.  Style + spinner mirror ConnectionManager._showConnectingDialog.
      if (!document.getElementById('toolbar-closing-overlay')) {
        if (!document.getElementById('toolbar-closing-spinner-style')) {
          const style = document.createElement('style');
          style.id = 'toolbar-closing-spinner-style';
          style.textContent =
            '@keyframes toolbarClosingSpin { to { transform: rotate(360deg); } }';
          document.head.appendChild(style);
        }
        const overlay = document.createElement('div');
        overlay.id = 'toolbar-closing-overlay';
        overlay.style.cssText =
          'position:fixed; inset:0; background:rgba(0,0,0,0.4);' +
          ' z-index:10001; display:flex; align-items:center;' +
          ' justify-content:center; font-family:Arial,sans-serif;';
        const panel = document.createElement('div');
        panel.style.cssText =
          'background:white; border-radius:8px;' +
          ' box-shadow:0 8px 32px rgba(0,0,0,0.25);' +
          ' padding:24px 28px; min-width:240px; text-align:center;';
        const spinner = document.createElement('div');
        spinner.style.cssText =
          'width:36px; height:36px; margin:0 auto 14px;' +
          ' border:4px solid #e0e0e0; border-top-color:#4078ff;' +
          ' border-radius:50%;' +
          ' animation: toolbarClosingSpin 0.9s linear infinite;';
        panel.appendChild(spinner);
        const label = document.createElement('div');
        label.style.cssText = 'font-size:18px; font-weight:600; color:#222;';
        label.textContent = 'Closing Down …';
        panel.appendChild(label);
        overlay.appendChild(panel);
        document.body.appendChild(overlay);
      }

      if (drawingViewer.stopKeepAlivePolling) {
        drawingViewer.stopKeepAlivePolling();
      }
      // Queue {!} via addToRequestQueue — it clears pending items, sets exitPending,
      // and blocks all further enqueuing. processRequestQueue waits for any in-flight
      // cmd to complete first, then sends {!} (single attempt — see send() guard in
      // connectionManager.js) and transitions to the connection screen via
      // _exitToConnectionScreen, which window.location.replaces the page and so
      // destroys the overlay along with the rest of the in-memory state.
      drawingViewer.addToRequestQueue('{!}', null, null, 'exitAbort');
    });
    menu.appendChild(exitItem);

    document.body.appendChild(menu);

    // Get button position AFTER menu is in DOM
    const rect = btnMenu.getBoundingClientRect();
    console.log('[TOOLBAR_MENU] Button rect:', { left: rect.left, right: rect.right, top: rect.top, bottom: rect.bottom, width: rect.width });

    // Get menu dimensions
    const menuHeight = menu.offsetHeight;
    const menuWidth = menu.offsetWidth;
    console.log('[TOOLBAR_MENU] Menu dimensions:', { width: menuWidth, height: menuHeight });

    // Position menu ABOVE button
    // - Right edge of menu aligned with right edge of button
    // - Bottom of menu just above button top
    const menuLeft = rect.right - menuWidth;
    const menuTop = rect.top - menuHeight - 2;

    menu.style.left = Math.max(0, menuLeft) + 'px';  // Don't go off-screen left
    menu.style.top = Math.max(0, menuTop) + 'px';    // Don't go off-screen top
    menu.style.visibility = 'visible';

    console.log('[TOOLBAR_MENU] Menu positioned at left=' + Math.max(0, menuLeft) + 'px, top=' + Math.max(0, menuTop) + 'px');
    console.log('[TOOLBAR_MENU] Menu z-index: 999999');

    // Close menu on outside click
    const closeMenu = (e) => {
      if (!e.target.closest('#toolbar-menu') && e.target !== btnMenu) {
        console.log('[TOOLBAR_MENU] Closing menu (outside click)');
        menu.remove();
        document.removeEventListener('click', closeMenu);
      }
    };

    // Use slight delay to ensure event listeners are ready
    setTimeout(() => {
      document.addEventListener('click', closeMenu);
      console.log('[TOOLBAR_MENU] Close listener attached');
    }, 50);
  },

  // Create the right-click context menu element and wire up its handlers.
  setupContextMenu() {
    // Create context menu container
    const contextMenu = document.createElement('div');
    contextMenu.id = 'pfod-context-menu';
    contextMenu.style.cssText = `
      display: none;
      position: fixed;
      background-color: #2d2d30;
      border: 1px solid #555;
      border-radius: 4px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.3);
      z-index: 10000;
      min-width: 200px;
      font-family: 'Segoe UI', Arial, sans-serif;
      font-size: 12px;
    `;

    contextMenu.innerHTML = `
      <div class="pfod-context-menu-item" data-action="show-messages">
        <span style="color: #ce9178; margin-right: 8px;">📊</span>
        Show Raw Messages
        <span style="color: #858585; margin-left: auto; margin-left: 20px; font-size: 10px;">Ctrl+Shift+M</span>
      </div>
    `;

    // Add styles for menu items
    const style = document.createElement('style');
    style.textContent = `
      .pfod-context-menu-item {
        padding: 8px 12px;
        color: #d4d4d4;
        cursor: pointer;
        display: flex;
        align-items: center;
        user-select: none;
        transition: background-color 0.15s;
      }

      .pfod-context-menu-item:hover {
        background-color: #3e3e42;
      }

      .pfod-context-menu-item:active {
        background-color: #454545;
      }

      .pfod-context-menu-divider {
        height: 1px;
        background-color: #3e3e42;
        margin: 4px 0;
      }
    `;
    document.head.appendChild(style);
    document.body.appendChild(contextMenu);

    // Right-click context menu disabled - now only accessible via toolbar menu
    // canvas.addEventListener('contextmenu', (event) => {
    //   event.preventDefault();
    //   this.showContextMenu(event.clientX, event.clientY, contextMenu);
    // });

    // Close menu on document click
    document.addEventListener('click', (event) => {
      if (event.target.closest('#pfod-context-menu')) {
        return; // Don't close if clicking menu
      }
      contextMenu.style.display = 'none';
    });

    // Handle menu item clicks
    contextMenu.addEventListener('click', (event) => {
      const item = event.target.closest('.pfod-context-menu-item');
      if (!item) return;

      const action = item.dataset.action;
      contextMenu.style.display = 'none';

      switch (action) {
        case 'show-messages':
          if (window.rawMessageViewer) {
            window.rawMessageViewer.show();
            console.log('[CONTEXT_MENU] Opened message viewer');
          }
          break;
        case 'clear-messages':
          if (window.messageCollector) {
            window.messageCollector.clear();
            console.log('[CONTEXT_MENU] Cleared all messages');
          }
          break;
        case 'export-json':
          if (window.rawMessageViewer) {
            window.rawMessageViewer.exportJSON();
            console.log('[CONTEXT_MENU] Exported messages as JSON');
          }
          break;
        case 'export-csv':
          if (window.rawMessageViewer) {
            window.rawMessageViewer.exportCSV();
            console.log('[CONTEXT_MENU] Exported messages as CSV');
          }
          break;
      }
    });

    console.log('[CONTEXT_MENU] Context menu setup complete');
  },

  // Position and show the context menu div at screen coordinates (x, y).
  // Adjusts position to prevent the menu from extending off-screen.
  showContextMenu(x, y, menu) {
    menu.style.display = 'block';
    menu.style.left = x + 'px';
    menu.style.top = y + 'px';

    // Adjust if menu goes off-screen
    const rect = menu.getBoundingClientRect();
    if (rect.right > window.innerWidth) {
      menu.style.left = (window.innerWidth - rect.width - 10) + 'px';
    }
    if (rect.bottom > window.innerHeight) {
      menu.style.top = (window.innerHeight - rect.height - 10) + 'px';
    }

    console.log('[CONTEXT_MENU] Showing at', x, y);
  }

});
/*
   navigationAndQueue.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Request queue, menu/command navigation stacks, and scheduling helpers
// for the DrawingViewer class.
// Assigned to DrawingViewer.prototype after the class is defined in pfodWeb.js.
//
// State read:    chartOnlyMode, menuNavStack, menuCmdSet, menuCache, isUpdating, touchState,
//                requestQueue, sentRequest,
//                updateTimer, dataRefreshTimer, dataRefreshActive, _isProcessingQueue,
//                requestTracker, connectionManager.protocol, csvLoaded
// State written: menuNavStack, menuCmdSet, menuCache, requestQueue, _isProcessingQueue,
//                updateTimer, dataRefreshTimer, requestTracker, currentRefreshCmd,
//                currentRefreshCmdType, initialRequestQueued
// Calls:         resizeAndDimensions:updateCanvasMessage, chartAndRawData:openChartDirectly,
//                requestQueue:processRequestQueue,
//                keepAliveAndHttp:fetchRefresh [via updateTimer setTimeout]
// Called by:     all files — central hub for queue operations and scheduling
//
// QUEUE PRIORITY MODEL
// --------------------
// Mirrors java/QueuedCmdEmum.java + pfodAppState.java::sendMessageAndWait.
// Lower ordinal = higher priority (popped first by requestQueue.shift()).
// Overridable types replace an existing same-target queued entry in place
// (latest wins) — that's how repeated refresh / keepAlive / drag / partialSlider
// can never accumulate.  Non-overridable types are sorted-inserted by ordinal,
// so a 'back' or 'touch' always sits ahead of any pending refresh.
//
// Drawing-related request types — what they actually fetch:
//   menuItemDwg       The drawing referenced by ONE drawing item in the
//                     current menu.  A menu has zero or more drawing items
//                     (no concept of a single "main" drawing for a menu).
//                     One menuItemDwg request is queued per drawing item.
//   insertDwg         A child drawing referenced by an insertDwg primitive
//                     inside another drawing's item list.  Discovered during
//                     processDrawingData scan of a parent drawing's response.
//   refresh           Timer auto-refresh of a previously fetched menuItemDwg.
//   refresh-insertDwg Timer auto-refresh of a previously fetched insertDwg.
//   menuRefresh       Timer auto-refresh of the current menu (NOT a drawing).
//   mainMenu          Initial main-menu request after connection ({.}).

const RequestOrdinal = {
  exitAbort:           0,
  authentication:      1,
  back:                2,
  mainMenu:            2,
  menuItemDwg:         2,
  touch:               3,
  insertDwg:           4,
  drag:                5,
  partialSlider:       6,
  'refresh-insertDwg': 7,
  menuRefresh:         8,
  refresh:             9,
  dataRefresh:        10,
  keepAlive:          11,
};

const RequestOverridable = new Set([
  'drag',
  'partialSlider',
  'refresh-insertDwg',
  'menuRefresh',
  'refresh',
  'dataRefresh',
  'keepAlive',
]);

function ordinalOf(t)     { return RequestOrdinal[t] ?? 999; }
function isOverridable(t) { return RequestOverridable.has(t); }

Object.assign(DrawingViewer.prototype, {

  // Identity key for an overridable request — two queued requests collide iff
  // they have the same requestType AND the same _replaceKeyOf.  Each
  // overridable type names its own identity field; the singletons return ''
  // so all entries of that type collapse to one.
  //
  //   drag              → touchZoneInfo.cmd                    (one drag per touchzone)
  //   partialSlider     → cmd                                  (one slider per slider-cmd)
  //   refresh,
  //   refresh-insertDwg → loadCmd from cmd (via _extractCmdToken)
  //                                                            (one refresh per drawing — c2
  //                                                             and c4 are independent)
  //   menuRefresh,
  //   dataRefresh,
  //   keepAlive         → ''                                   (singletons — only one queued
  //                                                             globally at any time)
  _replaceKeyOf(req) {
    switch (req.requestType) {
      case 'drag':
        return req.touchZoneInfo ? req.touchZoneInfo.cmd : null;
      case 'partialSlider':
        return req.cmd;
      case 'refresh':
      case 'refresh-insertDwg':
        return this._extractCmdToken(req.cmd) || null;
      case 'menuRefresh':
      case 'dataRefresh':
      case 'keepAlive':
        return '';
      default:
        throw new Error(`_replaceKeyOf: requestType "${req.requestType}" is not overridable — extend RequestOverridable AND _replaceKeyOf together`);
    }
  },

  // Send initial {.} (or versioned equivalent) to request the main menu from the device.
  // Resets navigation state and seeds menuCmdSet from the menu cache for this connection.
  // In chart-only mode, opens the chart directly instead.
  queueInitialRequest() {
    // If in chart-only mode, skip the main menu request and open chart display directly
    if (this.chartOnlyMode) {
      console.log('[CHART_MODE] CHART ONLY MODE - Skipping main menu request, opening chart display');
      this.openChartDirectly();
      return;
    }

    // Clear exit block so the queue accepts commands for the new connection
    this.exitPending = false;

    // Reset menu navigation stack and known-menu-cmd set for the new connection
    this.menuNavStack = [];
    this.menuCmdSet = new Set();
    console.log('[MENU_NAV] Stack and menuCmdSet reset on new connection');

    // Initialise menu cache for this connection endpoint
    const connectionId = window.pfodConnectionManager ? window.pfodConnectionManager.getConnectionId() : 'unknown';
    this.menuCache = new PfodMenuCache(connectionId);
    console.log('[MENU_CACHE] Initialised for connection:', connectionId);

    // Restore menuCmdSet from any previously cached menu cmds for this connection
    const cachedMenuCmds = this.menuCache.getMenuCmds();
    for (const bareCmd of cachedMenuCmds) {
      this.menuCmdSet.add('{' + bareCmd + '}');
    }
    if (cachedMenuCmds.length > 0) {
      console.log('[MENU_NAV] Restored menuCmdSet from cache:', JSON.stringify([...this.menuCmdSet]));
    }

    // Use a versioned initial request if we have a cached main menu, otherwise plain {.}
    const cachedInitialVersion = this.menuCache.getMenuVersion('.');
    const startupCmd = cachedInitialVersion ? ('{' + cachedInitialVersion + ':.}') : '{.}';
    if (cachedInitialVersion) {
      console.log('[MENU_CACHE] Sending versioned initial request:', startupCmd);
    } else {
      console.log('Sending {.} request without version to get drawing name from server via session context');
    }
    console.log(`Queueing initial request with command: ${startupCmd}`);

    // Update canvas to show that we're requesting the main menu
    this.updateCanvasMessage('Requesting Main Menu ...');

    // Add to request queue with mainMenu type - not a drawing request
    const requestType = 'mainMenu';
    // Mark this as the initial request for special timeout handling
    this.initialRequestQueued = true;
    this.addToRequestQueue(startupCmd, null, null, requestType, true);
  },

  // Schedule the next auto-refresh timer.
  // Computes the soonest due time across all items with non-zero refresh rates
  // (menu reRequestMs and per-drawing refresh), using itemRefreshTimes for last-response timestamps.
  scheduleNextUpdate() {
    if (this.updateTimer) {
      clearTimeout(this.updateTimer);
      this.updateTimer = null;
    }

    const hasOpenDialog = window.pfodWebMouse.touchActionInputOpen;
    if (this.requestQueue.length > 0 || this.sentRequest || hasOpenDialog) {
      console.log('[REFRESH] Skipping schedule - busy');
      return;
    }

    const now = Date.now();
    let soonestNextDue = Infinity;

    // Per-item effective rate.  rate >= 250 used as-is.  rate > 0 but < 250
    // is clamped up to 250 ms (network/device floor).  rate === 0 means
    // "do not auto-refresh" — caller filters via the entry value being 0.
    const effectiveRate = (rate) => (rate >= 250 ? rate : 250);

    // itemRefreshTimes invariant: every item in dm.drawings (and 'menu'
    // when a menu is shown) MUST have an entry.  Value semantics:
    //   0      → no auto-refresh for this item.  Either no first response
    //            received yet, OR the last response carried rate 0 / no
    //            rate specified.  Either way, do not schedule.
    //   > 0    → last-response timestamp; item's rate is > 0; schedule.
    // A missing entry is a registration-path bug — throw so it surfaces.

    // Per-item nextDue.  When NOT overdue, fire at lastResp+rate.
    // When OVERDUE (lastResp+rate already past), fire at now+rate — i.e.
    // delay one full rate from now, NOT immediately.  This keeps a
    // minimum gap of `rate` between consecutive fires so missed cycles
    // don't bundle up into a burst of back-to-back refreshes.
    const itemNextDue = (lastResp, rate) => {
      const eff = effectiveRate(rate);
      const due = lastResp + eff;
      return due > now ? due : now + eff;
    };

    // Refreshes only apply in menu-mode — that's the only mode where menus
    // and their embedded drawings are rendered.  Chart, rawdata, streaming,
    // and input modes have nothing to refresh; skip scheduling so the timer
    // stays disarmed until the user returns to menu-mode.
    if (document.body.className === 'menu-mode') {
      if (!this.itemRefreshTimes.has('menu')) {
        throw new Error('[REFRESH] itemRefreshTimes has no entry for "menu" — registration path missed; must be initialised to null when the menu is first shown');
      }
      const lastResp = this.itemRefreshTimes.get('menu');
      if (lastResp > 0) {
        const menuRate = window.pfodMenuDisplay?._currentMenu?.header?.reRequestMs || 0;
        const nextDue = itemNextDue(lastResp, menuRate);
        if (nextDue < soonestNextDue) soonestNextDue = nextDue;
      }

      for (const dwgName of this.redraw.redrawDrawingManager.drawings) {
        if (!this.itemRefreshTimes.has(dwgName)) {
          throw new Error(`[REFRESH] itemRefreshTimes has no entry for "${dwgName}" — registration path missed; must be initialised to null when the drawing is added to dm.drawings`);
        }
        const lastResp = this.itemRefreshTimes.get(dwgName);
        if (lastResp > 0) {
          const rate = this.redraw.redrawDrawingManager.drawingsData[dwgName]?.data?.refresh || 0;
          const nextDue = itemNextDue(lastResp, rate);
          if (nextDue < soonestNextDue) soonestNextDue = nextDue;
        }
      }
    }

    // No eligible items (every entry is 0) — skip scheduling entirely.
    // Must not compute delay against Infinity (would give a bogus
    // setTimeout argument).
    if (soonestNextDue === Infinity) {
      console.log('[REFRESH] No auto-refresh items eligible — no timer scheduled');
      return;
    }

    // delay = soonestNextDue - now.  Always > 0 by construction
    // (itemNextDue returns now+rate when overdue, lastResp+rate otherwise
    // and lastResp+rate > now in that branch).
    const delay = soonestNextDue - now;
    console.log(`[REFRESH] Scheduling next update in ${delay}ms`);
    this.updateTimer = setTimeout(() => this.fetchRefresh(), delay);
  },

  /**
   * Schedule a dataRefresh (pfodWeb?cmd=) 1 second after the last send.
   * Direct-HTTP only. Cancelled and rescheduled whenever a non-dataRefresh request is queued.
   * When the timer fires it adds a 'dataRefresh' entry to the request queue.
   */
  scheduleDataRefresh() {
    // Direct-HTTP-only.  All other transports (native Serial / BLE +
    // the *ProxyConnection adapters that use SSE) deliver device bytes
    // via push — no need for the 1-second polling tax.  Gating on
    // protocol === 'http' is sharper than the previous capability
    // check (sendDataRefresh-defined-on-adapter) because the proxy
    // adapters used to inherit sendDataRefresh from HTTPConnection
    // and trip the check incorrectly.  The all-SSE refactor moved
    // the proxy adapters off HTTPConnection entirely, but keep the
    // protocol gate as defence-in-depth.
    if (!this.connectionManager
     || this.connectionManager.protocol !== 'http') return;
    if (this.csvLoaded) return;
    if (this.dataRefreshTimer) {
      clearTimeout(this.dataRefreshTimer);
    }
    this.dataRefreshTimer = setTimeout(() => {
      this.dataRefreshTimer = null;
      // Skip if anything else is queued or in-flight: a real cmd (touch,
      // menuRefresh, drawingRefresh, etc.) is already going to drain any
      // streaming bytes the device has accumulated, so an empty-cmd poll
      // is redundant.  When that cmd's response completes, scheduleData-
      // Refresh fires again and re-arms a fresh 1 s timer.
      if (this.requestQueue.length > 0 || this.sentRequest) {
        console.log('[DATAREFRESH] skipped — queue or sentRequest busy');
        return;
      }
      this.addToRequestQueue('', null, null, 'dataRefresh');
    }, 1000);
  },

  // Find an existing queue entry that an overridable req should replace.
  // Two requests collide iff same requestType AND same _replaceKeyOf().
  // See _replaceKeyOf for the per-type identity rules.
  _findExistingMatch(req) {
    const reqKey = this._replaceKeyOf(req);
    return this.requestQueue.findIndex(r =>
      r.requestType === req.requestType && this._replaceKeyOf(r) === reqKey);
  },

  // Insert a request into the queue using the ordinal/overridable model.
  // Overridable entries replace an existing same-target entry in place
  // (latest wins).  Non-overridable entries are sorted-inserted by ordinal
  // ascending, so requestQueue.shift() always returns the highest-priority
  // pending entry.
  addQueuedCommand(req) {
    const inOrd = ordinalOf(req.requestType);

    if (isOverridable(req.requestType)) {
      const matchIdx = this._findExistingMatch(req);
      if (matchIdx >= 0) {
        const old = this.requestQueue[matchIdx];
        console.info(`[QUEUE] Replace at idx=${matchIdx}: ${old.requestType}(${old.cmd}) <- ${req.requestType}(${req.cmd})`);
        this.requestQueue[matchIdx] = req;
        return true;
      }
    }

    for (let i = 0; i < this.requestQueue.length; i++) {
      if (ordinalOf(this.requestQueue[i].requestType) > inOrd) {
        this.requestQueue.splice(i, 0, req);
        console.info(`[QUEUE] Insert at idx=${i}: ${req.requestType}(${req.cmd}) ord=${inOrd}`);
        return true;
      }
    }
    this.requestQueue.push(req);
    console.info(`[QUEUE] Append at end: ${req.requestType}(${req.cmd}) ord=${inOrd}`);
    return true;
  },

  // Add a request to the queue using the ordinal/overridable priority model
  // (see top of file for the model description).  Hard drops are handled here;
  // ordering and dedup are delegated to addQueuedCommand.
  //
  // Parameters:
  //   cmd           - pfod command string to send
  //   options       - reserved (pass null)
  //   touchZoneInfo - touch zone descriptor (null if not a touch)
  //   requestType   - one of the keys in RequestOrdinal (above)
  //   isInitial     - true only for the very first request after connection
  //
  // The queued request object carries only cmd + requestType + bookkeeping —
  // no drawingName field.  All routing decisions re-derive the loadCmd from
  // cmd/requestType at the consumer:
  //   - Refresh dedup (_replaceKeyOf) uses _extractCmdToken(req.cmd).
  //   - Merged-update flag uses requestType.
  //   - Response-side data.name uses _extractCmdToken / _resolveLoadCmdFromRequest.
  addToRequestQueue(cmd, options, touchZoneInfo, requestType = 'unknown', isInitial = false) {
    console.info(`[QUEUE] Adding request "${cmd}" (type: ${requestType}, isInitial: ${isInitial})`);
    console.info(`[QUEUE] Queue length before add: ${this.requestQueue.length}, sentRequest: ${this.sentRequest ? this.sentRequest.cmd + '(' + this.sentRequest.requestType + ')#' + this.sentRequest._id : 'null'}`);

    // ----- Hard drops -----
    if (requestType === 'unknown') {
      console.info(`[QUEUE] Error: Unknown requestType`);
      return;
    }

    // {!} wipes the queue and blocks further additions
    if (requestType === 'exitAbort') {
      console.log(`[QUEUE_MUTATION] exitAbort - clearing entire queue (was length=${this.requestQueue.length}):`, JSON.stringify(this.requestQueue.map(r => `${r.cmd}(${r.requestType})`)));
      this.requestQueue = [];
      this.exitPending = true;
      // Mirror to the connectionManager so the adapter's retry loop can see
      // it without plumbing — used to abandon remaining retries on the
      // in-flight cmd as soon as its current attempt times out.
      if (this.connectionManager) this.connectionManager.exitPending = true;
    }
    if (this.exitPending && requestType !== 'exitAbort') {
      console.info(`[QUEUE] exitPending — ignoring new request (type: ${requestType})`);
      return;
    }

    // Block menu auto-refresh while the user has the pointer down on the menu.
    // menuMouseDown is set by pfodMenuDisplay's pointerdown/pointerup listeners on
    // the scroll area, covering HTML buttons, sliders, toggles, and dwg canvases.
    if (requestType === 'menuRefresh' && window.pfodMenuDisplay?.menuMouseDown) {
      console.info('[QUEUE] menuRefresh skipped — pointer is down in menu; rescheduling');
      this.scheduleNextUpdate();
      return;
    }

    // Drop a duplicate touch/drag/slider on the same target while one of the
    // same type is already in flight.  Mirrors Java's pfodAppState.java
    // :1156-1166 DWG_TOUCH/DOWN/CLICK guard.  Compare the menuItem identifier
    // parsed from each cmd (the leading [A-Za-z_]\w* token after "{"/"V<n>:"),
    // not request.drawingName — the cmd is the canonical identifier.
    if (this.sentRequest
        && this.sentRequest.requestType === requestType
        && (requestType === 'touch'
            || requestType === 'drag'
            || requestType === 'partialSlider')) {
      const inFlightTok = this._extractCmdToken(this.sentRequest.cmd);
      const newTok      = this._extractCmdToken(cmd);
      if (inFlightTok && inFlightTok === newTok) {
        console.info(`[QUEUE] Dropping ${requestType} for "${newTok}" (cmd=${cmd}) — same-type already in flight`);
        return;
      }
    }

    this.setProcessingQueue(true);

    // Tracker bookkeeping — key on the cmd-derived identifier so the tracker
    // reflects the touched item (touch) / loadCmd (insertDwg) regardless of
    // whatever drawingName was passed.
    if (requestType === 'touch') {
      const tok = this._extractCmdToken(cmd);
      if (tok) {
        this.requestTracker.touchRequests.add(tok);
        console.info(`[QUEUE] Tracking touch request for "${tok}"`);
      }
    } else if (requestType === 'insertDwg') {
      const tok = this._extractCmdToken(cmd);
      if (tok) {
        this.requestTracker.insertDwgRequests.add(tok);
        console.info(`[QUEUE] Tracking insertDwg request for "${tok}"`);
      }
    }

    // Insert via ordinal/overridable rules (replaces the old per-type filter blocks)
    const _reqId = ++this._nextRequestId;
    this.addQueuedCommand({
      cmd: cmd,
      touchZoneInfo: touchZoneInfo,
      requestType: requestType,
      isInitial: isInitial,
      _id: _reqId
    });
    console.log(`[REQ_ID] #${_reqId} = ${requestType} cmd="${cmd}"`);
    console.log(`[QUEUE_MUTATION] After add, queue (length=${this.requestQueue.length}):`, JSON.stringify(this.requestQueue.map(r => `${r.cmd}(${r.requestType})#${r._id}`)));

    this.processRequestQueue();
  },

  // Return true if cmd is the pfod empty-response '{}'.
  // Used to detect a device acknowledging a command with no new drawing data.
  isEmptyCmd(cmd) {
    if (!cmd) {
      return false
    }
    if (cmd.length < 2) {
      return false;
    }
    let cmd0 = cmd[0].trim();
    let cmd1 = cmd[1].trim();
    if ((cmd0 == '{') && (cmd1 == '}')) {
      console.log(`[DRAWING_DATA] Received empty cmd response `);
      return true; // Successfully handled - no drawing data to process
    }
    return false;
  },

  // Atomic helper methods for queue processing state
  isProcessingQueue() {
    return this._isProcessingQueue;
  },

  setProcessingQueue(value) {
    const oldValue = this._isProcessingQueue;
    this._isProcessingQueue = value;
    console.log(`[QUEUE_STATE] setProcessingQueue(${value}) - oldValue: ${oldValue}, newValue: ${value}`);
    return value;
  },

  trySetProcessingQueue(expectedValue, newValue) {
    if (this._isProcessingQueue === expectedValue) {
      this._isProcessingQueue = newValue;
      console.log(`[QUEUE_STATE] trySetProcessingQueue(${expectedValue}, ${newValue}) - success: true`);
      return true;
    } else {
      console.log(`[QUEUE_STATE] trySetProcessingQueue(${expectedValue}, ${newValue}) - success: false, current: ${this._isProcessingQueue}`);
      return false;
    }
  },

  // Return the versioned form of a menu command if a cached version exists, otherwise return cmd unchanged.
  // e.g. '{.}' → '{V6:.}' when the cache holds version V6 for the main menu.
  versionedMenuCmd(cmd) {
    if (!this.menuCache) return cmd;
    const bareCmd = cmd.slice(1, -1); // '{.}' → '.'
    const ver = this.menuCache.getMenuVersion(bareCmd);
    if (ver) {
      const versioned = '{' + ver + ':' + bareCmd + '}';
      console.log('[MENU_CACHE] versionedMenuCmd:', cmd, '→', versioned);
      return versioned;
    }
    return cmd;
  },

  /**
   * Push a command onto the menu navigation stack.
   * If the command is already present in the stack, all entries above it are removed
   * (circular reference prevention) and it becomes the top — no duplicate is added.
   * Matches the real Android app's own ActivityStack.cleanUpLoops (forward/
   * pfodAppBase/ActivitySupport/ActivityStack.java) — collapsing the stack
   * back to an existing occurrence of the same screen, rather than growing
   * it forever, is real client behaviour, not a bug.
   *
   * This correctly collapses a GENUINE loop (re-opening the exact same
   * screen from the exact same context) but relies on cmd bytes being
   * distinct per navigation context — a cmd handler whose meaning depends
   * on the device's current activeMenuPath (not encoded in the cmd string
   * itself) must embed enough of that context in the cmd it hands to
   * pushMenuNavCmd for two different contexts to never collide as the
   * "same" cmd (see deleteMenuItems.js's own path-prefixed 't' cmd for the
   * pattern to follow for any other level-dependent cmd).
   *
   * @param {string} cmd - The pfod command that produced a full menu response
   */
  pushMenuNavCmd(cmd) {
    const existingIndex = this.menuNavStack.indexOf(cmd);
    if (existingIndex !== -1) {
      // Command already in stack — trim everything above to break the loop
      this.menuNavStack.length = existingIndex + 1;
      console.log('[MENU_NAV] Circular ref removed - stack trimmed to:', JSON.stringify(this.menuNavStack));
      return;
    }
    this.menuNavStack.push(cmd);
    console.log('[MENU_NAV] Pushed:', cmd, '- stack:', JSON.stringify(this.menuNavStack));
  },

  // Update the drawing command navigation stack when a new drawing response arrives.
  // Skipped for refresh (no position change). For back navigation, currentRefreshCmd is
  // updated to the returned-to page without pushing to commandStack (moving backward).
  updateNavigationStack(request) {
    // Skip stack updates for refresh types — these don't change the navigation position
    if (request.requestType === 'refresh' || request.requestType === 'refresh-insertDwg' || request.requestType === 'menuRefresh') {
      console.log('[TOOLBAR] Skipping stack update for request type:', request.requestType);
      return;
    }
    // For back navigation update currentRefreshCmd to reflect where we returned to,
    // but don't push the old currentRefreshCmd to commandStack (we're moving backward).
    // Source the cmd from menuNavStack top (not request.cmd) so error-recovery
    // paths that pop the stack further (e.g. responseHandlers' uncached-{;}
    // fallback) are honoured here without each caller having to also write
    // currentRefreshCmd themselves.  In the success case top === bareCmd of
    // request.cmd, so versionedMenuCmd(top) produces the same value.
    if (request.requestType === 'back') {
      const top = this.menuNavStack.length > 0
        ? this.menuNavStack[this.menuNavStack.length - 1]
        : '{.}';
      this.currentRefreshCmd = this.versionedMenuCmd(top);
      this.currentRefreshCmdType = request.requestType;
      console.log('[TOOLBAR] Back navigation - updated currentRefreshCmd to:', this.currentRefreshCmd, '(menuNavStack top:', top + ')');
      return;
    }

    // Push current command to stack if different from top
    if (this.currentRefreshCmd) {
      if (this.commandStack.length === 0 || this.currentRefreshCmd !== this.commandStack[this.commandStack.length - 1]) {
        this.commandStack.push(this.currentRefreshCmd);
        console.log('[TOOLBAR] Pushed to stack (navigation):', this.currentRefreshCmd);
      }
    }
    // Update current command to the new display
    this.currentRefreshCmd = request.cmd;
    this.currentRefreshCmdType = request.requestType;
    console.log('[TOOLBAR] Updated currentRefreshCmd (navigation):', this.currentRefreshCmd, 'type:', request.requestType);
  },

  // Clear all pending requests from queue (keeps sentRequest intact).
  // Called before sending a back/refresh command to discard queued stale requests.
  clearPendingQueue() {
    const clearTime = Date.now();
    const queueLength = this.requestQueue.length;
    console.info(`[QUEUE] Clearing queue at ${clearTime}, length=${queueLength}, sentRequest: ${this.sentRequest ? this.sentRequest.cmd + '(' + this.sentRequest.requestType + ')#' + this.sentRequest._id : 'null'}`);
    console.log(`[QUEUE_MUTATION] clearPendingQueue contents before clear (length=${queueLength}):`, JSON.stringify(this.requestQueue.map(r => `${r.cmd}(${r.requestType})#${r._id}`)));
    this.requestQueue = [];
    console.info(`[QUEUE] Cleared ${queueLength} pending requests at ${Date.now()}, elapsed: ${Date.now() - clearTime}ms`);
  }

});
/*
   chartAndRawData.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Chart display, raw-data text display, and their enter/exit helpers for the DrawingViewer class.
// Assigned to DrawingViewer.prototype after the class is defined in pfodWeb.js.
//
// State read:    chartCommand, canvas, currentChartInfo, currentChart,
//                rawDataScrollLocked, rawDataPollingInterval, connectionManager,
//                sentRequest, csvLoaded
// State written: rawDataScrollLocked, rawDataPollingInterval, currentChart, currentChartInfo,
//                sentRequest
// Calls:         navigationAndQueue:scheduleDataRefresh, navigationAndQueue:addToRequestQueue,
//                toolbarAndMenu:updateRefreshButtonState, resizeAndDimensions:handleResize,
//                requestQueue:processRequestQueue [via setTimeout after exitChartDisplay]
// Called by:     navigationAndQueue:queueInitialRequest, toolbarAndMenu:setupToolbarButtons,
//                responseHandlers:handleNonDwgResponse

// currentChartInfo has no storage of its own on DrawingViewer — see the
// window.currentChartInfo holder and matching ChartDisplay.prototype accessor
// defined at the end of chartDisplay.js. This alias makes
// `this.currentChartInfo` / `drawingViewer.currentChartInfo` reads and writes
// transparently forward to that single holder, so the two classes'
// currentChartInfo can no longer drift apart the way they used to (one
// updating while the other stayed stale, e.g. on the touchZone->chart-response
// path).
Object.defineProperty(DrawingViewer.prototype, 'currentChartInfo', {
  get() { return window.currentChartInfo; },
  set(value) { window.currentChartInfo = value; }
});

// Same treatment for the rendered jsfc.Chart object — see the matching
// window.currentChart holder and ChartDisplay.prototype accessor at the end
// of chartDisplay.js.
Object.defineProperty(DrawingViewer.prototype, 'currentChart', {
  get() { return window.currentChart; },
  set(value) { window.currentChart = value; }
});

Object.assign(DrawingViewer.prototype, {

  // Open chart display directly without requesting main menu.
  // Used in chart-only mode (?chartOnly URL param).
  // Applies a ?chart= URL command if present, otherwise opens an empty chart.
  openChartDirectly() {
    console.log('[CHART_MODE] Opening chart display directly');
    // If a chart command was passed via URL ?chart= param, apply it via messageViewer
    if (this.chartCommand && window.chartConfigViewer) {
      try {
        console.log('[CHART_MODE] Applying chart command from URL:', this.chartCommand);
        window.chartConfigViewer.applyChartCommand(this.chartCommand);
        this.scheduleDataRefresh();
        return;
      } catch (e) {
        console.error('[CHART_MODE] Failed to apply chart command from URL, using default:', e);
      }
    }
    // Default: open empty chart
    this.displayChart("Chart", "", 500);
    // Start HTTP data-refresh polling to collect streaming CSV data
    this.scheduleDataRefresh();
  },

  // Switch to rawdata-mode CSS, create (or reuse) the raw-data display panel,
  // append rawData text, auto-scroll, and start polling for new data.
  //
  // Parameters:
  //   chartTitle - title shown in the panel header
  //   rawData    - text string to append to the display
  displayRawDataText(chartTitle, rawData) {
    // console.log('[RAW_DATA] displayRawDataText called - title:', chartTitle, 'data length:', rawData.length);

    // Switch to raw data display CSS mode
    document.body.className = 'rawdata-mode';
    // console.log('[RAW_DATA] Switched to rawdata-mode CSS');

    // Update refresh button state (disabled in chart-mode)
    this.updateRefreshButtonState();

    // Get canvas wrapper (contains just the canvas)
    const canvasWrapper = document.getElementById('canvas-wrapper');
    if (!canvasWrapper) {
      console.error('[RAW_DATA] Canvas wrapper not found');
      return;
    }

    // Create or get raw data display element
    let rawDataDisplay = document.getElementById('raw-data-text-display');
    if (!rawDataDisplay) {
      // console.log('[RAW_DATA] Creating new raw data display');
      rawDataDisplay = document.createElement('div');
      rawDataDisplay.id = 'raw-data-text-display';
      rawDataDisplay.style.cssText = `
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        background-color: white;
        overflow: hidden;
        box-sizing: border-box;
      `;

      // Create title bar with lock scroll button
      const titleBar = document.createElement('div');
      titleBar.id = 'raw-data-title-bar';
      titleBar.style.cssText = `
        background-color: #333;
        color: white;
        padding: 8px 10px;
        font-weight: bold;
        flex-shrink: 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
        height: 32px;
        box-sizing: border-box;
      `;

      const titleText = document.createElement('span');
      titleText.textContent = chartTitle || 'Raw Data';

      const lockButton = document.createElement('button');
      lockButton.id = 'raw-data-lock-scroll-btn';
      lockButton.textContent = '🔓 Scroll';
      lockButton.style.cssText = `
        background-color: #555;
        color: white;
        border: 1px solid #777;
        padding: 4px 8px;
        border-radius: 3px;
        cursor: pointer;
        font-size: 12px;
      `;

      let scrollLocked = false;
      lockButton.addEventListener('click', () => {
        scrollLocked = !scrollLocked;
        lockButton.textContent = scrollLocked ? '🔒 Locked' : '🔓 Scroll';
        lockButton.style.backgroundColor = scrollLocked ? '#a00' : '#555';
        this.rawDataScrollLocked = scrollLocked;
      });

      const saveButton = document.createElement('button');
      saveButton.id = 'raw-data-save-btn';
      saveButton.textContent = '💾 Save';
      saveButton.style.cssText = `
        background-color: #0066cc;
        color: white;
        border: 1px solid #0044aa;
        padding: 4px 8px;
        margin-left: 8px;
        border-radius: 3px;
        cursor: pointer;
        font-size: 12px;
      `;

      saveButton.addEventListener('click', () => {
        // Get all raw data
        const textContent = document.getElementById('raw-data-text-content');
        if (!textContent) {
          console.error('[RAW_DATA] Text content element not found for save');
          return;
        }

        const rawDataText = textContent.textContent;

        // Create blob and download
        const blob = new Blob([rawDataText], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `rawdata_${new Date().toISOString().replace(/[:.]/g, '-')}.txt`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        console.log('[RAW_DATA] Saved raw data to file:', link.download);
      });

      titleBar.appendChild(titleText);
      titleBar.appendChild(lockButton);
      titleBar.appendChild(saveButton);

      // Create scrolling text area - THIS is where scrollbar appears
      const textArea = document.createElement('div');
      textArea.id = 'raw-data-text-content';
      textArea.style.cssText = `
        flex: 1;
        overflow-y: auto;
        overflow-x: auto;
        padding: 10px;
        font-family: monospace;
        white-space: pre;
        background-color: white;
        color: #333;
        box-sizing: border-box;
        min-height: 0;
      `;

      rawDataDisplay.appendChild(titleBar);
      rawDataDisplay.appendChild(textArea);

      // console.log('[RAW_DATA] Raw data display structure created - layout: titleBar + scrollable textArea');

      // Initialize scroll lock state
      this.rawDataScrollLocked = false;
    } else {
      // Display already exists - update the title
      const titleBar = rawDataDisplay.querySelector('#raw-data-title-bar');
      if (titleBar) {
        const titleText = titleBar.querySelector('span');
        if (titleText) {
          titleText.textContent = chartTitle || 'Raw Data';
        }
      }
    }

    // Insert raw data display - do not use innerHTML='' which would destroy #menu-container
    if (rawDataDisplay.parentNode !== canvasWrapper) {
      canvasWrapper.insertBefore(rawDataDisplay, document.getElementById('menu-container'));
    }

    // Append new data to text content (not replace)
    const textContent = document.getElementById('raw-data-text-content');
    if (textContent) {
      // console.log('[RAW_DATA] Found text content element, appending', rawData.length, 'chars');
      // Append new data directly without adding separator newline
      textContent.textContent += rawData;
      // console.log('[RAW_DATA] Data appended, new length:', textContent.textContent.length);

      // Mark that we've displayed data up to this point
      if (window.rawDataCollector) {
        window.rawDataCollector.markDisplayedUpTo();
      }

      // Auto-scroll to bottom unless scroll is locked
      if (!this.rawDataScrollLocked) {
        textContent.scrollTop = textContent.scrollHeight;
        // console.log('[RAW_DATA] Auto-scrolled to bottom');
      } else {
        // console.log('[RAW_DATA] Scroll is locked, not auto-scrolling');
      }

      // Start polling for new data to append continuously
      this.startRawDataPolling();
    } else {
      console.error('[RAW_DATA] Text content element not found!');
    }
  },

  /**
   * Exit raw data display and restore canvas
   */
  exitRawDataDisplay() {
    // console.log('[RAW_DATA] Exiting raw data display');

    // Switch back to message display CSS mode
    document.body.className = 'message-mode';

    // Update refresh button state
    this.updateRefreshButtonState();

    const canvasWrapper = document.getElementById('canvas-wrapper');
    const rawDataDisplay = document.getElementById('raw-data-text-display');
    if (rawDataDisplay) {
      // Remove only the raw data display element - do not use innerHTML='' which would destroy #menu-container
      canvasWrapper.removeChild(rawDataDisplay);
    }
    // Do NOT redraw here - drawing data not ready yet
    // The drawing will be redrawn when the queued drawing request response arrives

    // Stop polling for new data
    this.stopRawDataPolling();

    // Don't clear raw data collector - it must continue collecting independently
  },

  /**
   * Start polling for new raw data and appending to display
   */
  startRawDataPolling() {
    // Stop any existing polling
    this.stopRawDataPolling();

    // console.log('[RAW_DATA] Starting data polling');
    this.rawDataPollingInterval = setInterval(() => {
      // Check if raw data display still exists
      const textContent = document.getElementById('raw-data-text-content');
      if (!textContent) {
        // console.log('[RAW_DATA] Raw data display no longer exists, stopping polling');
        this.stopRawDataPolling();
        return;
      }

      // Get new data from collector
      if (window.rawDataCollector) {
        const newData = window.rawDataCollector.getNewData();
        if (newData.length > 0) {
          // console.log('[RAW_DATA] Polling found', newData.length, 'new chars, appending to display');
          textContent.textContent += newData;

          // Mark that we've displayed this data
          window.rawDataCollector.markDisplayedUpTo();

          // Auto-scroll to bottom unless scroll is locked
          if (!this.rawDataScrollLocked) {
            textContent.scrollTop = textContent.scrollHeight;
          }
        }
      }
    }, 100); // Poll every 100ms for new data
  },

  /**
   * Stop polling for new raw data
   */
  stopRawDataPolling() {
    if (this.rawDataPollingInterval) {
      clearInterval(this.rawDataPollingInterval);
      this.rawDataPollingInterval = null;
      // console.log('[RAW_DATA] Stopped data polling');
    }
  },

  /**
   * Open the Section 9 streaming raw data screen ({=[title]} response).
   * Shows all data accumulated in rawDataCollector so far, then polls for more.
   * Uses streaming-mode CSS and its own DOM element, independent of rawdata-mode.
   *
   * @param {string} title     - Optional title from the {= response
   * @param {string} initialData - Raw data collected up to this point
   */
  displayStreamingData(title, initialData) {
    document.body.className = 'streaming-mode';
    this.updateRefreshButtonState();

    const canvasWrapper = document.getElementById('canvas-wrapper');
    if (!canvasWrapper) return;

    // Extract only <bg …> tags for background colour; leave all other format codes
    // (colour, size, bold…) in the text so pfodSetFormattedText can render them inline.
    // Using parsePfodFormatCodes on the whole string strips <+N> from the leading codes
    // but leaves the matching </+N> closing tag orphaned, which then renders as literal text.
    const rawTitle = title || '';
    let promptBgColor = '#000000';
    const promptText = rawTitle.replace(/<bg ([^>]*)>/g, (match) => {
      const hex = window.parsePfodFormatCodes ? window.parsePfodFormatCodes(match).bgColor : null;
      if (hex) promptBgColor = hex;
      return '';
    });

    let panel = document.getElementById('streaming-data-display');
    if (!panel) {
      panel = document.createElement('div');
      panel.id = 'streaming-data-display';
      panel.style.cssText = 'width:100%;height:100%;display:flex;flex-direction:column;background-color:white;overflow:hidden;box-sizing:border-box;';

      // Controls bar at top (Scroll/Save buttons)
      const controlsBar = document.createElement('div');
      controlsBar.id = 'streaming-data-controls';
      controlsBar.style.cssText = 'background-color:#333;padding:4px 8px;flex-shrink:0;display:flex;justify-content:flex-end;align-items:center;height:30px;box-sizing:border-box;';

      const lockButton = document.createElement('button');
      lockButton.id = 'streaming-lock-btn';
      lockButton.textContent = 'Scrolling';
      lockButton.style.cssText = 'background-color:#007700;color:white;border:1px solid #005500;padding:3px 8px;border-radius:3px;cursor:pointer;font-size:12px;';
      let scrollLocked = false;
      lockButton.addEventListener('click', () => {
        scrollLocked = !scrollLocked;
        lockButton.textContent = scrollLocked ? 'Locked' : 'Scrolling';
        lockButton.style.backgroundColor = scrollLocked ? '#a00' : '#007700';
        this.streamingScrollLocked = scrollLocked;
      });

      const saveButton = document.createElement('button');
      saveButton.textContent = 'Save';
      saveButton.style.cssText = 'background-color:#0066cc;color:white;border:1px solid #0044aa;padding:3px 8px;margin-left:6px;border-radius:3px;cursor:pointer;font-size:12px;';
      saveButton.addEventListener('click', () => {
        const content = document.getElementById('streaming-data-content');
        if (!content) return;
        const blob = new Blob([content.textContent], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'streaming_' + new Date().toISOString().replace(/[:.]/g, '-') + '.txt';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      });

      controlsBar.appendChild(lockButton);
      controlsBar.appendChild(saveButton);

      // Layout/sizing for #streaming-data-content lives in pfodCommon.css
      const content = document.createElement('div');
      content.id = 'streaming-data-content';

      // Prompt bar at bottom — sizing in pfodCommon.css (matches #menu-prompt)
      const promptEl = document.createElement('div');
      promptEl.id = 'streaming-data-prompt';

      panel.appendChild(controlsBar);
      panel.appendChild(content);
      panel.appendChild(promptEl);
      this.streamingScrollLocked = false;
    }

    // Insert panel into DOM before formatting so getElementById works on first open
    if (panel.parentNode !== canvasWrapper) {
      canvasWrapper.insertBefore(panel, document.getElementById('menu-container'));
    }

    // Apply/update prompt and content formatting every time (title may change on re-open)
    const contrastHex = xtermColorToHex(getBlackWhite(promptBgColor));
    const promptEl = document.getElementById('streaming-data-prompt');
    if (promptEl) {
      promptEl.innerHTML = '';
      promptEl.removeAttribute('style');
      promptEl.style.backgroundColor = promptBgColor;
      if (promptText) {
        if (window.pfodSetFormattedText) {
          window.pfodSetFormattedText(promptEl, promptText, contrastHex);
        } else {
          promptEl.textContent = promptText;
        }
        promptEl.style.color = contrastHex;
      }
    }

    // Content area always black background with white text; only the prompt area is coloured
    const content = document.getElementById('streaming-data-content');
    if (content) {
      content.style.backgroundColor = 'black';
      content.style.color = 'white';
      content.textContent = initialData;
      if (window.rawDataCollector) window.rawDataCollector.markDisplayedUpTo();
      if (!this.streamingScrollLocked) content.scrollTop = content.scrollHeight;
      this.startStreamingPolling();
    }
  },

  /**
   * Exit streaming raw data display and restore message-mode.
   */
  exitStreamingData() {
    // Idempotent cleanup: always remove the panel if present and stop polling,
    // but only flip CSS back to message-mode when we're leaving streaming-mode
    // (callers may invoke this defensively from chart-mode/menu-mode/etc to
    //  scrub any leftover panel without disturbing the current display class).
    this.stopStreamingPolling();
    const canvasWrapper = document.getElementById('canvas-wrapper');
    const panel = document.getElementById('streaming-data-display');
    if (panel && canvasWrapper) canvasWrapper.removeChild(panel);
    if (document.body.className === 'streaming-mode') {
      document.body.className = 'message-mode';
      this.updateRefreshButtonState();
    }
  },

  /**
   * Start polling rawDataCollector for new data and appending to the streaming screen.
   */
  startStreamingPolling() {
    this.stopStreamingPolling();
    this.streamingPollingInterval = setInterval(() => {
      const content = document.getElementById('streaming-data-content');
      if (!content) { this.stopStreamingPolling(); return; }
      if (window.rawDataCollector) {
        const newData = window.rawDataCollector.getNewData();
        if (newData.length > 0) {
          content.textContent += newData;
          window.rawDataCollector.markDisplayedUpTo();
          if (!this.streamingScrollLocked) content.scrollTop = content.scrollHeight;
        }
      }
    }, 100);
  },

  /**
   * Stop the streaming data polling interval.
   */
  stopStreamingPolling() {
    if (this.streamingPollingInterval) {
      clearInterval(this.streamingPollingInterval);
      this.streamingPollingInterval = null;
    }
  },

  /**
   * Display chart using CSV data with the largest field count.
   * Used by toolbar menu and initial timeout fallback.
   * Creates chartInfo compatible with displayChartWithPlotNo.
   *
   * @param {string} title  - Chart title
   * @param {string} unused - Unused parameter (kept for compatibility)
   * @param {number} limit  - Maximum CSV lines to display
   */
  displayChart(title, unused, limit = 500) {
    if (!window.csvCollector) {
      console.error('[CHART] CSV collector not available');
      return;
    }

    // Get all available field counts and pick the largest
    const fieldCounts = window.csvCollector.getFieldCounts();
    let maxFieldCount;
    let isDummy;

    if (!fieldCounts || fieldCounts.length === 0) {
      // No CSV data available yet - create a default single field to display empty chart
      console.warn('[CHART] No CSV data available, creating default single-field chart');
      maxFieldCount = 1;
      isDummy = true; // Mark as dummy since no real data
    } else {
      maxFieldCount = Math.max(...fieldCounts.map(f => parseInt(f)));
      console.log('[CHART] displayChart - available field counts:', fieldCounts, 'using max:', maxFieldCount);
      isDummy = false; // Real data from csvCollector
    }

    // Create generic field labels (field1, field2, etc.) based on CSV field count
    // These will be used as fallback when no explicit labels from chart response
    const allLabels = Array.from({length: maxFieldCount}, (_, i) => `field${i + 1}`);
    const nonBlankLabels = allLabels; // All are non-blank in this case

    // Determine if we're using count as X-axis (single field case)
    const useCountFlag = maxFieldCount === 1;
    const xAxisFieldLabel = useCountFlag ? 'Count' : allLabels[0];

    // Create fieldSpecs for all fields except first (which is X-axis)
    // For single-field case: X-axis is count, so Y-fields include field1
    // For multi-field case: X-axis is field1, so Y-fields are field2, field3, etc.
    let yFieldLabels;
    let fieldSpecs;

    if (useCountFlag) {
      // Single field: use it as Y-axis (count is implicit X-axis)
      yFieldLabels = allLabels; // All fields are Y-series when using count
      fieldSpecs = allLabels.map((label, idx) => ({
        label: label,
        plotNo: null,
        index: idx
      }));
    } else {
      // Multiple fields: first is X-axis, rest are Y-series
      yFieldLabels = allLabels.slice(1);
      fieldSpecs = allLabels.slice(1).map((label, idx) => ({
        label: label,
        plotNo: null,
        index: idx + 1
      }));
    }

    // Create chartInfo in legacy mode format (no plotNo specified)
    // This matches what parseChartLabelsWithPlotNo returns for legacy single-subplot mode
    // isDummy=true if no field counts available, false if data exists
    window.currentChartInfo = {
      title: title,
      maxPoints: limit,
      allLabels: allLabels,
      nonBlankLabels: nonBlankLabels,
      fieldCount: maxFieldCount,
      hasPlotNo: false,
      useCountFlag: useCountFlag,
      useCountAsXAxis: useCountFlag, // Use count as X-axis for single-field case
      xAxisFieldIndex: useCountFlag ? -1 : 0, // -1 means use count
      xAxisFieldLabel: xAxisFieldLabel,
      isDummy, // true if default chart (no data), false if real data from csvCollector
      subplots: [{
        plotNo: 1,
        fieldSpecs: fieldSpecs,
        fieldLabels: yFieldLabels
      }]
    };

    this.displayChartWithPlotNo();
  },

  /**
   * Display chart with optional plotNo support for multi-subplot mode.
   * Handles both multi-subplot mode (hasPlotNo=true) and legacy single-subplot mode (hasPlotNo=false).
   * Always uses the multi-subplot infrastructure even for single-subplot charts.
   *
   * Reads the chart to display from window.currentChartInfo (the single
   * holder for the currently displayed chart) — callers set that before
   * calling this, rather than threading the same chartInfo through as an
   * argument as well.
   */
  displayChartWithPlotNo() {
    const startTime = Date.now();
    const chartInfo = this.currentChartInfo;
    const limit = chartInfo.maxPoints;
    console.log('[CHART] displayChartWithPlotNo called - title:', chartInfo.title, 'hasPlotNo:', chartInfo.hasPlotNo, 'limit:', limit);

    if (!window.chartDisplay) {
      console.error('[CHART] ChartDisplay not available');
      return;
    }

    // If we're entering the chart from the streaming raw-data screen (toolbar
    // "..." → Chart), tear down the streaming panel first so it isn't left
    // orphaned in canvas-wrapper to bleed through after we leave chart-mode.
    if (document.getElementById('streaming-data-display')) {
      this.exitStreamingData();
    }

    // Switch to chart display CSS mode
    console.log('[CHART] Switching to chart-mode CSS');
    document.body.className = 'chart-mode';

    // Update refresh button state
    this.updateRefreshButtonState();

    const canvasWrapper = document.getElementById('canvas-wrapper');
    if (!canvasWrapper) {
      console.error('[CHART] Canvas wrapper not found');
      return;
    }

    try {
      const fieldCount = chartInfo.fieldCount;
      console.log('[CHART] fieldCount=', fieldCount, 'hasPlotNo=', chartInfo.hasPlotNo);

      // Load CSV data
      const csvLines = window.chartDisplay.loadCSVData(fieldCount);
      console.log('[CHART] Loaded', csvLines.length, 'CSV lines for', fieldCount, 'fields');

      // Always reset chartDisplay's canvas-size cache on every chart entry —
      // a fresh canvas defaults to 300×150 and resizeCanvasToFitSpace will
      // short-circuit ("dimensions unchanged, skipping") if the cache still
      // holds the previous chart's wrapper-matched dimensions.  Must run
      // before the resize call further down, regardless of whether the
      // previous chartCanvas reference survived.
      if (window.chartDisplay) {
        window.chartDisplay.lastCanvasWidth = 0;
        window.chartDisplay.lastCanvasHeight = 0;
      }

      // Remove ALL orphan canvas children from canvas-wrapper, not just
      // this.chartCanvas — when chart is opened via touchZone-response from a
      // dwg, this.chartCanvas can lose reference to the actual rendered canvas
      // (the dwg's canvas-wrapper layout differs from menu-mode layout) and a
      // single `this.chartCanvas.remove()` then leaves a sibling canvas behind
      // that double-renders on re-render (e.g. Freeze).
      const existingCanvases = canvasWrapper.querySelectorAll(':scope > canvas');
      if (existingCanvases.length > 0) {
        console.log('[CHART] Removing', existingCanvases.length, 'orphan canvas(es) from canvas-wrapper');
        existingCanvases.forEach(c => c.remove());
      }
      this.chartCanvas = null;

      // Create a fresh canvas for this chart session and insert into canvas-wrapper
      this.chartCanvas = document.createElement('canvas');
      canvasWrapper.insertBefore(this.chartCanvas, document.getElementById('menu-container'));

      // Resize canvas BEFORE creating chart
      console.log('[CHART] Resizing canvas');
      window.chartDisplay.resizeCanvasToFitSpace(this.chartCanvas);

      let parseResult = null;

      // Parse CSV data only if we have data
      if (csvLines.length > 0) {
        console.log('[CHART] Parsing CSV data with parseCSVToDatasetWithPlotNo');
        parseResult = window.chartDisplay.parseCSVToDatasetWithPlotNo(csvLines, chartInfo, limit);

        if (!parseResult) {
          console.warn('[CHART] Failed to parse CSV data, will display as empty chart');
          parseResult = null; // Fall through to empty chart creation
        }
      } else {
        console.warn('[CHART] No CSV data available, will display empty chart');
      }

      // Create chart with or without data
      // createAndDisplayMultiSubplotChart handles both: parseResult=null for empty, or populated parseResult
      console.log('[CHART] Creating chart with createAndDisplayMultiSubplotChart (hasData:', parseResult !== null, ')');
      const chart = window.chartDisplay.createAndDisplayMultiSubplotChart(chartInfo.title, chartInfo, parseResult, this.chartCanvas);

      if (!chart) {
        console.error('[CHART] Failed to create chart');
        return;
      }

      // If Chart Config panel is open, refresh it to reflect the new chart
      if (window.chartConfigViewer && window.chartConfigViewer.isVisible) {
        window.chartConfigViewer.populate();
      }

      // Auto-open Chart Config if flagged (e.g. by Load CSV to Plot)
      if (window._autoOpenChartConfig && window.chartConfigViewer) {
        window._autoOpenChartConfig = false;
        window.chartConfigViewer.show();
      }

      // Attach the transparent overlay canvas that drives the crosshair + tooltip.
      window.chartDisplay.attachCrosshairOverlay(this.chartCanvas);

      // Start polling for chart updates - even if chart is empty, so new data gets displayed when available
      console.log('[CHART] Starting update polling');
      window.chartDisplay.startMultiSubplotUpdatePolling();

      console.log('[CHART] Chart display complete, total elapsed:', Date.now() - startTime, 'ms');

    } catch (error) {
      console.error('[CHART] Error displaying chart:', error);
    }
  },

  /**
   * Exit chart display and restore canvas.
   * Stops polling, clears chart state, restores message-mode CSS,
   * and re-inserts the drawing canvas before #menu-container.
   */
  exitChartDisplay() {
    const exitTime = Date.now();
    console.log('[CHART] Exiting chart display at', exitTime, 'current className=', document.body.className);

    // NOTE: we deliberately do NOT clear this.sentRequest here.
    //
    // Every queued request is sent via `await connectionManager.send()`, and
    // each send is bounded by an AbortController response-timeout + retry
    // budget — so the await ALWAYS settles (resolves with a response, or
    // rejects after retries are exhausted).  Both the success path and the
    // catch path clear sentRequest through the normal queue flow.  There is
    // therefore no such thing as a permanently "stuck" sentRequest.
    //
    // The old "clear stuck sentRequest" hack here nulled sentRequest while a
    // fetch was still in flight.  On back-from-chart that let the queued
    // {V1:.} fire a SECOND concurrent fetch before the in-flight one's
    // response arrived — two HTTP requests racing broke the pfod
    // request/response pairing and intermittently lost the menu redisplay
    // on Chrome/Android.  Leaving sentRequest alone keeps the queue's
    // one-request-at-a-time invariant: the in-flight request drains
    // naturally, then processRequestQueue sends the queued back cmd.

    // Stop chart polling and clear chart state. Reachable only while
    // body.className === 'chart-mode' (every caller gates on that), which
    // guarantees window.chartDisplay exists. clear() resets currentChart
    // (the canvas it was bound to is about to be torn down) but deliberately
    // leaves currentChartInfo alone — that's the chart's parsed spec (data),
    // not display state, so it should still reflect the last-displayed chart
    // if the user reopens Chart Config or the chart itself from outside
    // chart-mode.
    console.log('[CHART] Stopping chart polling and clearing...');
    window.chartDisplay.clear(); // This calls stopUpdatePolling() internally
    console.log('[CHART] Chart cleared');

    // Close Chart Config panel — it is only valid while in chart mode
    if (window.chartConfigViewer && window.chartConfigViewer.isVisible) {
      window.chartConfigViewer.hide();
    }

    // Remove ALL canvas children of #canvas-wrapper BEFORE switching modes.
    // this.chartCanvas can lose its reference to the actual rendered canvas
    // (same pattern as displayChartWithPlotNo's orphan-canvas issue) so a
    // single `this.chartCanvas.remove()` is not enough — a sibling canvas
    // can survive and show through under the now-visible #canvas-message
    // ("Requesting Menu ..."), producing the half-blue / half-plot split.
    const canvasWrapper = document.getElementById('canvas-wrapper');
    if (canvasWrapper) {
      const existingCanvases = canvasWrapper.querySelectorAll(':scope > canvas');
      if (existingCanvases.length > 0) {
        console.log('[CHART] exitChartDisplay: removing', existingCanvases.length, 'canvas(es) from canvas-wrapper');
        existingCanvases.forEach(c => c.remove());
      }
    }
    this.chartCanvas = null;

    // Switch back to message display CSS mode
    console.log('[CHART] Switching back to message-mode CSS');
    document.body.className = 'message-mode';
    console.log('[CHART] Switched back to message-mode CSS');

    // Update refresh button state
    this.updateRefreshButtonState();

    // Resize canvas to recalculate all coordinates for the restored drawing
    console.log('[CHART] Starting handleResize after restore at', Date.now(), 'elapsed:', Date.now() - exitTime, 'ms');
    this.handleResize();
    console.log('[CHART] Finished handleResize after restore at', Date.now(), 'elapsed:', Date.now() - exitTime, 'ms');

    // Force re-engage serial connection if it's disconnected
    if (this.connectionManager && this.connectionManager.protocol === 'serial') {
      const isConnected = this.connectionManager.isConnected();
      if (!isConnected) {
        console.log('[CHART] Serial connection lost - attempting force re-engage');
        // Use setTimeout to allow async operation without blocking
        setTimeout(async () => {
          const reengaged = await this.connectionManager.forceReengageSerial();
          if (reengaged) {
            console.log('[CHART] Serial port successfully re-engaged');
          } else {
            console.warn('[CHART] Failed to re-engage serial port');
          }
        }, 10);
      }
    }

    // Trigger queue processing in case {.} was added to queue while in chart mode
    console.log('[CHART] Triggering processRequestQueue after chart exit');
    setTimeout(() => {
      this.processRequestQueue();
    }, 20);

    console.log('[CHART] Canvas restored, exitChartDisplay complete at', Date.now(), 'elapsed:', Date.now() - exitTime, 'ms');
    console.log('[CHART] className after exit=', document.body.className);
  }

});
/*
   drawingProcessing.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// processDrawingData() wrapper, handleInsertDwg(), and helpers that operate on
// the live redrawDrawingManager after a drawing response arrives.
// Also includes redrawCanvas() and processPendingResponses() which bridge the
// response handler and the request queue.
// Assigned to DrawingViewer.prototype after the class is defined in pfodWeb.js.
//
// State read:    touchState, pendingResponseQueue, requestQueue, sentRequest,
//                redraw.redrawDrawingManager, drawingDataProcessor, touchZonesByCmd
// State written: pendingResponseQueue, requestQueue, sentRequest,
//                redraw.redrawDrawingManager, touchState.wasDown
// Calls:         resizeAndDimensions:handleResize, navigationAndQueue:isEmptyCmd,
//                navigationAndQueue:addToRequestQueue, navigationAndQueue:scheduleNextUpdate,
//                responseHandlers:handleNonDwgResponse, responseHandlers:handleDwgResponse,
//                drawingMerger.mergeAllDrawings, redraw.performRedraw,
//                requestQueue:processRequestQueue, keepAlive:scheduleNextKeepAlive
// Called by:     responseHandlers:handleDwgResponse [processDrawingData],
//                requestQueue:processRequestQueue [via handleDwgResponse/handleNonDwgResponse],
//                pfodWebMouse [processPendingResponses on mouse-up]

Object.assign(DrawingViewer.prototype, {

  // Trigger a canvas redraw after non-touchAction state changes.
  // TouchAction redraws are handled directly by pfodWebMouse calling
  // redraw.redrawForTouchAction(); this method handles all other redraws.
  redrawCanvas() {
    console.info(`[QUEUE] redrawCanvas isDown: ${this.touchState.isDown}`);
    if (!this.touchState.isDown) {
      if (this.touchState.wasDown) {
        this.touchState.wasDown = this.touchState.isDown;
      }
      // Redraw no longer needs access to drawingManager or requestQueue
      // Data is managed locally in redraw
    }

    // Redraw the canvas with what we have
    // Note: TouchAction redraws are now handled directly by pfodWebMouse calling redraw.redrawForTouchAction()
    // This method only handles normal redraws
    this.handleResize();
  },

  // Drain the pendingResponseQueue that accumulates drawing responses while the mouse
  // button is held down (touch-action in progress).
  // After draining, runs the merger and redraw once for the whole batch and
  // reschedules the request queue.
  processPendingResponses() {
    if (this.pendingResponseQueue.length === 0) {
      console.info(`[QUEUE] No pending responses to process - ensuring refresh timer is restarted`);
      this.scheduleNextUpdate();
      return;
    }

    console.info(`[QUEUE] Processing ${this.pendingResponseQueue.length} pending responses after mouse release`);
    const hadPendingResponses = this.pendingResponseQueue.length > 0;
    // Track whether any pending response targeted a per-drawing raw
    // collection (drawingName !== null).  If yes, we must rebuild allXXX
    // via the merger.  If every response was a merged update (drawingName
    // === null), the writes already landed in allXXX[menuDwg] and a
    // re-merge would clobber them.
    let needsReMerge = false;

    // Process responses in order of receipt
    while (this.pendingResponseQueue.length > 0) {
      const pendingResponse = this.pendingResponseQueue.shift();
      const request = pendingResponse.request;
      const data = pendingResponse.data;

      console.info(`[QUEUE] Processing queued response for "${request.cmd}"`);

      // Restore-on-response (touch only): clean up the optimistic
      // touchAction edit FIRST, then process the response as normal below —
      // whatever it turns out to be (empty, dwg update, new menu, ...).
      // Calls the exact same _restoreTouchActionForRequest()
      // (requestQueue.js) processRequestQueue's own "mouse is up" branch
      // calls — not a re-implementation — so there is exactly one place
      // that decides whether/what to restore. A response that arrives
      // while the mouse is STILL down takes processRequestQueue's OTHER
      // branch instead — queued into pendingResponseQueue rather than
      // processed immediately — and is drained here once mouse-up calls
      // processPendingResponses(). This loop was previously missing this
      // call entirely, so any touch whose response arrives before the
      // physical mouse-up (routine for a fast/local connection, rare but
      // possible for a real device) never got undone.
      this._restoreTouchActionForRequest(request);

      // Check for empty command response {} - skip processing
      const isEmptyResponse = this.isEmptyCmd(data.cmd);
      if (isEmptyResponse) {
        console.info(`[QUEUE] Pending response is empty command {} - skipping processing`);
        continue;
      }

      // Detect response type for logging
      let responseType = request.requestType;
      if (data.pfodDrawing === 'start' || data.pfodDrawing === 'update') {
        responseType = 'dwgUpdate';
      } else if (data.cmd && data.cmd[0]) {
        if (data.cmd[0].startsWith('{,') || data.cmd[0].startsWith('{;')) {
          responseType = 'mainMenu';
        } else if (data.cmd[0].startsWith('{=')) {
          responseType = 'rawData';
        } else if (data.cmd[0].startsWith('{+')) {
          responseType = 'dwgUpdate';
        }
      }

      // Check if this is a valid dwg update:
      // 1. {+ response (full or partial dwg update), OR
      // 2. pfodDrawing: 'start' or 'update' (direct drawing format)
      const isFullOrPartialDwgUpdate = (data.cmd && data.cmd.length > 0 && data.cmd[0].startsWith('{+')) || (data.pfodDrawing === 'start') || (data.pfodDrawing === 'update');
      const isDwgUpdate = isFullOrPartialDwgUpdate;

      if (!isDwgUpdate) {
        console.info(`[QUEUE] Pending response is NOT a current dwg update (${responseType}) - handling as non-dwg response (isFullOrPartial=${isFullOrPartialDwgUpdate})`);
        // Handle the non-dwg response (checks flag, restores backup, redraws, and processes based on type)
        this.handleNonDwgResponse(data, request, request.requestType);
        // Skip normal processing for non-dwg responses
        continue;
      }

      // Handle valid dwg response through dedicated method
      if (this.handleDwgResponse(data, request)) {
        console.info(`[QUEUE] Successfully processed dwg response from pending queue`);
        // Drain insertDwg items collected during this response's scan, the
        // same way requestQueue.processRequestQueue does for the live path.
        // Mouse is still down here so sentRequest is whatever the live
        // queue has (or null between requests); either way, queueing
        // synchronously through handleInsertDwg lands items in the queue
        // before the post-batch redraw and tail processRequestQueue.
        const pendingInserts = (data && data._pendingInserts) || [];
        if (pendingInserts.length > 0) {
          console.info(`[QUEUE] Queueing ${pendingInserts.length} deferred insertDwg item(s) from pending response for "${request.cmd}"`);
          for (const item of pendingInserts) {
            this.handleInsertDwg(item);
          }
        }
        // Per-drawing raw responses require a re-merge — that includes
        // source-routed touch responses (applied to the source dwg's raw
        // collections).  Only touch-style responses WITHOUT a source dwg
        // landed straight in allXXX[menuDwg]; re-merge would clobber them.
        const rt = request.requestType;
        const isMergedUpdate = (rt === 'touch' || rt === 'drag' || rt === 'partialSlider')
                            && !this._touchSourceDwg(request);
        if (!isMergedUpdate) needsReMerge = true;
      } else {
        // Error was already logged in handleDwgResponse
        console.info(`[QUEUE] Failed to process dwg response from pending queue`);
      }
    }

    console.info(`[QUEUE] Finished processing all pending responses`);

    // Re-merge (only if any response targeted per-drawing raw) and redraw
    // once for the whole batch.
    if (hadPendingResponses) {
      if (!this.touchState.isDown) {
        // Clear sentRequest if still set so queue can continue processing insertDwg requests
        if (this.sentRequest) {
          console.info(`[QUEUE] Clearing sentRequest "${this.sentRequest.cmd}" to allow queue processing`);
          console.log(`[SENTREQUEST] CLEARED: "${this.sentRequest.cmd}" (${this.sentRequest.requestType}) - after processing pending responses`);
          this.sentRequest = null;
        }
        if (needsReMerge) {
          const merger = new window.DrawingMerger(this.redraw.redrawDrawingManager);
          merger.mergeAllDrawings();
        }
        // Persist per-menuDwg merged cache for each drawing item the
        // current menu shows — runs whether or not we re-merged, since the
        // merged-update path (touchAction / null drawingName) also mutates
        // allXXX[menuDwg] directly.
        if (typeof getConnectionIdentifier === 'function') {
          try {
            const connectionId = getConnectionIdentifier(this.connectionManager);
            const dwgItems = (window.pfodMenuDisplay && window.pfodMenuDisplay._currentMenu && window.pfodMenuDisplay._currentMenu.drawingItems) || [];
            for (const dwgItem of dwgItems) {
              if (dwgItem.loadCmd) {
                this.redraw.redrawDrawingManager.saveMenuDwgMergedToStorage(dwgItem.loadCmd, connectionId);
              }
            }
          } catch (e) {
            console.info('[QUEUE] Could not save menuDwg merged cache (pending batch):', e.message);
          }
        }
        // Same deferral rule as the live path — see shouldDeferRedraw()
        // in requestQueue.js.
        if (this.shouldDeferRedraw()) {
          console.log(`[REDRAW] Deferred redraw (pending batch) - mouseDown=${this.touchState.isDown}`);
        } else {
          this.redraw.performRedraw();
        }
      }
    }
    setTimeout(() => {
      this.processRequestQueue();
      // Ensure rescheduling after mouse up if queue is empty and no request in flight
      if (this.requestQueue.length === 0 && !this.sentRequest) {
        this.scheduleNextUpdate();
      }
      // Reschedule keepAlive polling after processing pending responses (1 second delay)
      this.scheduleNextKeepAlive();
    }, 10);
  },

  // Thin wrapper: delegate drawing-data processing to DrawingDataProcessor,
  // targeting the live redrawDrawingManager.
  //
  // Parameters:
  //   data        - parsed response object from the device
  //   savedData   - previously cached drawing data (may be null)
  //   requestType - queue entry type string (e.g. 'menuItemDwg', 'refresh', 'insertDwg')
  processDrawingData(data, savedData, requestType = 'unknown') {
    return this.drawingDataProcessor.processDrawingData(data, this.redraw.redrawDrawingManager, savedData, requestType);
  },

  // Handle an insertDwg item: register the named drawing in the live DrawingManager
  // and enqueue a network request to fetch its content.
  //
  // Returns an object describing the outcome (error, alreadyInList, or newlyAdded).
  //
  // Parameters:
  //   item - insertDwg item object with drawingName, xOffset, yOffset, transform
  handleInsertDwg(item) {
    const drawingName = item.drawingName;
    const xOffset = parseFloat(item.xOffset || 0);
    const yOffset = parseFloat(item.yOffset || 0);

    console.log(`[INSERT_DWG] Handling insertDwg for drawing "${drawingName}" with offset (${xOffset}, ${yOffset})`);

    // Verify this is a valid insertDwg item
    if (!item.type || (item.type !== 'insertDwg' && item.type.toLowerCase() !== 'insertdwg')) {
      console.error(`[INSERT_DWG] Invalid item type: ${item.type}. Expected 'insertDwg'`);
      console.log(`[INSERT_DWG] Full item:`, JSON.stringify(item));
    }

    if (!drawingName) {
      console.error('[INSERT_DWG] InsertDwg item missing drawingName:', item);
      return { error: 'Missing drawing name', item: item };
    }

    const dm = this.redraw.redrawDrawingManager;
    dm.ensureItemCollections(drawingName);

    // (Cycle detection lives in DrawingMerger.mergeAllDrawings — it walks
    // the parent/child graph and short-circuits any cycles with a logged
    // error.  No drawings[0]-based guard here.)

    const connectionId = (typeof getConnectionIdentifier === 'function')
      ? getConnectionIdentifier(this.connectionManager) : null;

    // If we don't already have full state in memory, try to hydrate from
    // the per-drawing cache.  loadDrawingDataFromStorage atomically restores
    // .data + the five raw collections (and registers the drawing in
    // dm.drawings), so a non-null .data afterwards reliably implies the
    // raw collections are populated too.
    const hasState = !!dm.drawingsData[drawingName]?.data;
    let cacheLoaded = false;
    if (!hasState && connectionId) {
      const entry = dm.loadDrawingDataFromStorage(drawingName, connectionId);
      if (entry) {
        cacheLoaded = true;
        console.log(`[INSERT_DWG] Hydrated "${drawingName}" from per-drawing cache (version="${entry.version}")`);
      }
    }

    // If still not registered (no in-memory state and no cache hit), create
    // a placeholder entry so the request queue / merger has somewhere to
    // attach the response.
    if (!dm.drawings.includes(drawingName)) {
      // The parent is the drawing whose response contained this insertDwg
      // item — set by the scan in drawingDataProcessor.js as
      // item.parentDrawingName (= the response's drawing name).
      dm.addInsertedDrawing(
        drawingName,
        xOffset,
        yOffset,
        item.transform || { x: 0, y: 0, scale: 1.0 },
        item.parentDrawingName
      );
      console.log(`[INSERT_DWG] Created placeholder entry for "${drawingName}" with parent "${item.parentDrawingName}"`);
    }

    // Maintain itemRefreshTimes invariant: every entry in dm.drawings has an
    // entry.  Both branches above (cache-hydration via loadDrawingDataFromStorage
    // and addInsertedDrawing) can register the drawing without touching
    // itemRefreshTimes.  null = no response yet (or rate==0); the response
    // stamp in _stampRefreshTimeAfterResponse updates to Date.now() when
    // the rate is > 0.
    if (!this.itemRefreshTimes.has(drawingName)) {
      this.itemRefreshTimes.set(drawingName, null);
    }

    // Always queue a verify request — handleInsertDwg only fires from the
    // scan in processDrawingData, which runs after a parent drawing's
    // response was just received.  Every such scan is effectively a
    // refresh of the children: the parent has new authoritative state, so
    // each insertDwg target must be re-verified to keep the merged tree
    // current.  The version-stamped request is cheap — device replies
    //   {+}            no change at this version
    //   {+|item ...}   partial update at this version (apply items)
    //   {+x`y…Vnew}    new version, full replacement
    // Re-entrancy dedup only: skip when this drawing is already pending or
    // currently in flight (e.g. duplicate insertDwg within one response).
    // Once the in-flight cycle clears, future scans / auto-refresh timers
    // are free to re-verify.
    // Check if a request for this drawing is already pending or in flight.
    // Match on cmd-derived identifier, not request.drawingName:
    //   - drawing-fetch entries (menuItemDwg/insertDwg/refresh/refresh-insertDwg):
    //     cmd token IS the loadCmd, simple compare.
    //   - touch-style entries: cmd token is the menuItemCmd; resolve to loadCmd
    //     via menu-items lookup before comparing.
    const matchesDrawing = (req) => {
      if (!req || !req.cmd) return false;
      const tok = this._extractCmdToken(req.cmd);
      if (tok === drawingName) return true; // drawing-fetch entry
      // touch-style entry: resolve menuItemCmd → loadCmd
      const resolved = this._resolveLoadCmdFromRequest(req);
      return resolved === drawingName;
    };
    const alreadyQueued = this.requestQueue.some(matchesDrawing)
        || (this.sentRequest && matchesDrawing(this.sentRequest));
    if (alreadyQueued) {
      console.log(`[INSERT_DWG] "${drawingName}" already pending or in flight — not duplicating`);
      return {
        drawingName: drawingName,
        dataAvailable: hasState || cacheLoaded,
        alreadyInList: true
      };
    }

    const version = dm.drawingsData[drawingName]?.data?.version || null;
    const cmd = version ? `{${version}:${drawingName}}` : `{${drawingName}}`;

    // If the request that triggered this insertDwg was itself a refresh,
    // tag the child fetch as refresh-insertDwg so refresh-batch logic in the
    // queue treats it as part of the same batch.
    const triggeringType = this.sentRequest ? this.sentRequest.requestType : null;
    const requestType = (triggeringType === 'refresh' || triggeringType === 'refresh-insertDwg')
      ? 'refresh-insertDwg' : 'insertDwg';
    console.warn(`[INSERT_DWG] Queuing verify "${cmd}" (type=${requestType}, cacheLoaded=${cacheLoaded})`);
    this.addToRequestQueue(cmd, null, null, requestType);

    return {
      drawingName: drawingName,
      dataAvailable: cacheLoaded,
      newlyAdded: !cacheLoaded
    };
  },

  // Remove an inserted drawing and its touch zones from the live DrawingManager,
  // then recursively remove any child drawings it inserted.
  // Also cancels any queued or in-flight requests for the drawing.
  //
  // Parameters:
  //   drawingName - name of the inserted drawing to remove
  removeInsertedDrawing(drawingName) {
    if (!drawingName) {
      console.error('No drawing name provided to removeInsertedDrawing');
      return;
    }

    console.log(`[REMOVE_DWG] Removing inserted drawing: ${drawingName}`);

    // Match queue entries against `drawingName` via cmd-derived identifier.
    // For drawing-fetch entries the cmd token IS the loadCmd; for touch-style
    // entries the cmd token is the menuItemCmd, so resolve via menu-items.
    const matchesDrawing = (req) => {
      if (!req || !req.cmd) return false;
      const tok = this._extractCmdToken(req.cmd);
      if (tok === drawingName) return true;
      const resolved = this._resolveLoadCmdFromRequest(req);
      return resolved === drawingName;
    };

    // Remove any pending requests for this drawing from the queue
    const initialQueueLength = this.requestQueue.length;
    console.log(`[QUEUE_MUTATION] removeInsertedDrawing("${drawingName}") - queue before filter (length=${initialQueueLength}):`, JSON.stringify(this.requestQueue.map(r => `${r.cmd}(${r.requestType})`)));
    this.requestQueue = this.requestQueue.filter(request => !matchesDrawing(request));
    let removedCount = initialQueueLength - this.requestQueue.length;
    if (removedCount > 0) {
      console.log(`[QUEUE_MUTATION] removeInsertedDrawing - filtered out ${removedCount} request(s); queue now (length=${this.requestQueue.length}):`, JSON.stringify(this.requestQueue.map(r => `${r.cmd}(${r.requestType})`)));
    }

    // Also check and clear if the currently sent request is for this drawing
    if (this.sentRequest && matchesDrawing(this.sentRequest)) {
      console.log(`[REMOVE_DWG] Clearing in-flight request for ${drawingName}`);
      console.log(`[SENTREQUEST] CLEARED: "${drawingName}" (${this.sentRequest.requestType}) at ${new Date().toISOString()}`);
      this.sentRequest = null;
      removedCount++;
    }

    if (removedCount > 0) {
      console.log(`[REMOVE_DWG] Removed ${removedCount} request(s) for ${drawingName} (${initialQueueLength - this.requestQueue.length} from queue, ${this.sentRequest ? 0 : (removedCount - (initialQueueLength - this.requestQueue.length))} in-flight)`);
    }

    // First identify any child drawings that have this drawing as their parent
    const childDrawings = this.redraw.redrawDrawingManager.getChildDrawings(drawingName);

    // Recursively remove all child drawings first
    childDrawings.forEach(childName => {
      console.log(`[REMOVE_DWG] Removing child drawing ${childName} of ${drawingName}`);
      this.removeInsertedDrawing(childName);
    });

    // Remove associated touchZones (if touchZonesByCmd is available)
    if (typeof this.touchZonesByCmd !== 'undefined') {
      this.removeTouchZonesByDrawing(drawingName);
    }

    // Remove the drawing using the manager
    this.redraw.redrawDrawingManager.removeInsertedDrawing(drawingName);

    console.log(`[REMOVE_DWG] Completed removal of inserted drawing: ${drawingName}`);
  },

  // Remove all touch zones registered under a specific drawing name from touchZonesByCmd.
  //
  // Parameters:
  //   drawingName - parent drawing whose touch zones should be cleared
  removeTouchZonesByDrawing(drawingName) {
    if (!drawingName) {
      console.error('No drawing name provided to removeTouchZonesByDrawing');
      return;
    }

    console.log(`Removing touchZones for drawing: ${drawingName}`);

    // Create a new array of keys to remove
    const keysToRemove = [];

    // Find all touchZones belonging to this drawing
    for (const cmd in this.touchZonesByCmd) {
      const touchZone = this.touchZonesByCmd[cmd];
      if (touchZone.parentDrawingName === drawingName) {
        keysToRemove.push(cmd);
        console.log(`Marked touchZone for removal: cmd=${cmd}, drawing=${drawingName}`);
      }
    }

    // Remove identified touchZones
    keysToRemove.forEach(cmd => {
      delete this.touchZonesByCmd[cmd];
      console.log(`Removed touchZone: cmd=${cmd}`);
    });

    console.log(`Removed ${keysToRemove.length} touchZones for drawing: ${drawingName}`);
  }

});
/*
   keepAliveAndHttp.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Message-viewer / collector initialisation and the drawing auto-refresh timer.
// Assigned to DrawingViewer.prototype after the class is defined in pfodWeb.js.
//
// State read:    touchState, requestQueue, sentRequest, isUpdating,
//                redraw.redrawDrawingManager
// State written: isUpdating
// Calls:         navigationAndQueue:scheduleNextUpdate, navigationAndQueue:addToRequestQueue
// Called by:     constructor [initializeMessageViewer],
//                navigationAndQueue:scheduleNextUpdate [via updateTimer → fetchRefresh],
//                chartAndRawData:openChartDirectly [via scheduleDataRefresh]

Object.assign(DrawingViewer.prototype, {

  // Create and wire up all data-collector singletons (MessageCollector, CSVCollector,
  // RawDataCollector, ChartDisplay) and the UI panels that consume them
  // (RawMessageViewer, ChartConfigViewer).
  initializeMessageViewer() {
    try {
      // Create message collector if not already created
      if (!window.messageCollector) {
        window.messageCollector = new MessageCollector(500);
        ConnectionManager.setMessageCollector(window.messageCollector);
        console.log('[PFODWEB_DEBUG] Message collector created and set on ConnectionManager');
      }

      // Create CSV collector if not already created
      if (!window.csvCollector) {
        window.csvCollector = new CSVCollector();
        ConnectionManager.setCSVCollector(window.csvCollector);
        console.log('[PFODWEB_DEBUG] CSV collector created and set on ConnectionManager');
      }

      // Create raw data collector if not already created
      console.log('[PFODWEB_DEBUG] Checking rawDataCollector - exists?', !!window.rawDataCollector, 'RawDataCollector class exists?', typeof RawDataCollector);
      if (!window.rawDataCollector) {
        try {
          console.log('[PFODWEB_DEBUG] Creating RawDataCollector instance...');
          window.rawDataCollector = new RawDataCollector();
          console.log('[PFODWEB_DEBUG] RawDataCollector instance created successfully');
          ConnectionManager.setRawDataCollector(window.rawDataCollector);
          console.log('[PFODWEB_DEBUG] Raw data collector created and set on ConnectionManager');
        } catch (e) {
          console.error('[PFODWEB_DEBUG] Error creating RawDataCollector:', e);
        }
      } else {
        console.log('[PFODWEB_DEBUG] RawDataCollector already exists, not creating new instance');
      }

      // Create chart display if not already created
      if (!window.chartDisplay) {
        try {
          console.log('[PFODWEB_DEBUG] Creating ChartDisplay instance...');
          window.chartDisplay = new ChartDisplay();
          console.log('[PFODWEB_DEBUG] ChartDisplay instance created successfully');
        } catch (e) {
          console.error('[PFODWEB_DEBUG] Error creating ChartDisplay:', e);
        }
      } else {
        console.log('[PFODWEB_DEBUG] ChartDisplay already exists, not creating new instance');
      }

      // Create raw message viewer
      window.rawMessageViewer = new RawMessageViewer(window.messageCollector, 'side-panel');
      window.rawMessageViewer.initialize();
      console.log('[PFODWEB_DEBUG] Raw message viewer initialized');

      // Create chart config viewer (shares the same side-panel container)
      window.chartConfigViewer = new ChartConfigViewer('side-panel');
      window.chartConfigViewer.initialize();
      console.log('[PFODWEB_DEBUG] Chart config viewer initialized');

      // Keyboard shortcut disabled - now only accessible via toolbar menu
      // // Add a keyboard shortcut to toggle the viewer (Ctrl+Shift+M)
      // document.addEventListener('keydown', (event) => {
      //   if (event.ctrlKey && event.shiftKey && event.key === 'M') {
      //     event.preventDefault();
      //     if (window.rawMessageViewer) {
      //       window.rawMessageViewer.toggle();
      //     }
      //   }
      // });
      console.log('[PFODWEB_DEBUG] Keyboard shortcut Ctrl+Shift+M disabled - access via toolbar menu');
    } catch (error) {
      console.error('[PFODWEB_DEBUG] Error initializing message viewer:', error);
    }
  },

  // Drive the periodic drawing auto-refresh cycle.
  // Called by the refresh timer (set in scheduleNextUpdate). Checks all guard conditions
  // before queueing the drawing update request(s), then re-arms the timer.
  async fetchRefresh() {
    console.log(`[REFRESH] Refresh timer fired at ${new Date().toISOString()}`);

    // Check if a touchActionInput dialog is currently open
    if (window.pfodWebMouse.touchActionInputOpen) {
      console.log(`[REFRESH] Blocking refresh cycle - touchActionInput dialog is open`);
      this.scheduleNextUpdate(); // Reschedule for later
      return;
    }

    // Bypass list: types that should NOT defer the timer-fired refresh.
    //   menuRefresh / refresh / refresh-insertDwg — already part of an
    //     ongoing refresh batch; firing the next timer alongside is fine.
    //   dataRefresh — passive empty-cmd poll that completes in ~tens of ms;
    //     queueing the menuRefresh behind it is correct.  Without this,
    //     dataRefresh and a same-cadence menuRefresh race every cycle and
    //     dataRefresh tends to win, starving menu refreshes.
    // Bare `insertDwg` is *not* on the list — it is queued only by a non-
    // refresh parent (drawingProcessing tags refresh-context cascades as
    // `refresh-insertDwg` instead), so seeing one in flight means a user
    // cascade is mid-flight and the timer refresh should defer.
    const isRefreshType = (t) => t === 'menuRefresh' || t === 'refresh'
                              || t === 'refresh-insertDwg' || t === 'dataRefresh';
    const hasUserRequests = this.requestQueue.some(req => !isRefreshType(req.requestType));
    if (hasUserRequests) {
      console.log(`[REFRESH] Blocking refresh cycle - user requests in queue`);
      this.scheduleNextUpdate(); // Reschedule for later
      return;
    }

    if (this.sentRequest && !isRefreshType(this.sentRequest.requestType)) {
      console.log(`[REFRESH] Blocking refresh cycle - user request in flight (${this.sentRequest.requestType})`);
      this.scheduleNextUpdate(); // Reschedule for later
      return;
    }

    // Refreshes only apply in menu-mode.  Defense-in-depth match for the
    // gate in scheduleNextUpdate — even if a stale timer fires in chart /
    // rawdata / streaming / input mode, queue nothing.  Reschedule (gated)
    // so the timer re-arms once the user returns to menu-mode.
    if (document.body.className !== 'menu-mode') {
      console.log(`[REFRESH] Skipping refresh cycle - mode is "${document.body.className}", not menu-mode`);
      this.scheduleNextUpdate();
      return;
    }

    try {
      console.log(`[UPDATE] Starting update cycle at ${new Date().toISOString()}`);
      const now = Date.now();

      // Queue menu re-request if due (itemRefreshTimes['menu'] updated when menu response received)
      const menuRate = window.pfodMenuDisplay?._currentMenu?.header?.reRequestMs;
      if (menuRate > 0) {
        const nextDue = (this.itemRefreshTimes.get('menu') ?? 0) + menuRate;
        if (nextDue <= now) {
          const menuCmd = this.menuNavStack.length > 0
            ? this.versionedMenuCmd(this.menuNavStack[this.menuNavStack.length - 1])
            : '{.}';
          console.log(`[UPDATE] Menu due for refresh - queueing "${menuCmd}"`);
          this.addToRequestQueue(menuCmd, null, null, 'menuRefresh');
        }
      }

      // Queue per-drawing re-requests if due (itemRefreshTimes[dwgName] updated when each response is processed)
      for (const dwgName of this.redraw.redrawDrawingManager.drawings) {
        const rate = this.redraw.redrawDrawingManager.drawingsData[dwgName]?.data?.refresh;
        if (rate > 0) {
          const nextDue = (this.itemRefreshTimes.get(dwgName) ?? 0) + rate;
          if (nextDue <= now) {
            console.log(`[UPDATE] Drawing "${dwgName}" due for refresh`);
            await this.queueDrawingUpdate(dwgName);
          }
        }
      }

      this.scheduleNextUpdate();
      console.log(`[UPDATE] Update cycle queued at ${new Date().toISOString()}`);
    } catch (error) {
      console.error('[UPDATE] Failed to update:', error);
      this.scheduleNextUpdate();
    }
  },

  // Queue a versioned refresh request for a single drawing (main or inserted).
  // Uses the cached version from localStorage when available.
  async queueDrawingUpdate(drawingName) {
    try {
      console.log(`[QUEUE_DWG] Preparing fetch for drawing "${drawingName}" at ${new Date().toISOString()}`);

      // Defend against null/empty drawingName — would otherwise build the
      // garbage cmd '{null}' or '{}' and send it to the device.  If this
      // fires, the upstream cause is a null entry in
      // redrawDrawingManager.drawings (likely a 'start' response with a null
      // routing key derived from the request cmd — see handleDwgResponse).
      if (!drawingName) {
        console.error(`[QUEUE_DWG] Refusing to queue update for null/empty drawingName`);
        return;
      }

      // Use the per-connection per-drawing cache via getStoredVersion.
      // The legacy `${drawingName}_version` localStorage key no longer
      // exists — the cache is now keyed `pfodWeb_dwg_<connId>_<drawingName>`.
      const connectionId = (typeof getConnectionIdentifier === 'function')
        ? getConnectionIdentifier(this.connectionManager) : null;
      const storedVersion = this.redraw.redrawDrawingManager.getStoredVersion(drawingName, connectionId);
      const cmd = storedVersion
        ? '{' + storedVersion + ':' + drawingName + '}'
        : '{' + drawingName + '}';
      if (storedVersion) {
        console.log(`[QUEUE_DWG] Using stored version "${storedVersion}" for "${drawingName}"`);
      } else {
        console.log(`[QUEUE_DWG] No stored version for "${drawingName}" - requesting fresh data (dwg:start)`);
      }

      console.log(`[QUEUE_DWG] Constructed command: "${cmd}"`);

      /**
      // Use /pfodWeb endpoint with cmd parameter in {drawingName} format
      let endpoint = `/pfodWeb?cmd=${encodeURIComponent('{' + drawingName + '}')}`;

      // Add version query parameter if available and valid AND there's corresponding data
      if (savedVersion !== null && savedData) {
        endpoint += `&version=${encodeURIComponent(savedVersion)}`;
        console.log(`[QUEUE_DWG] Using saved version "${savedVersion}" for "${drawingName}"`);
      } else {
        if (savedVersion !== null && !savedData) {
          console.log(`[QUEUE_DWG] Found valid version "${savedVersion}" without data for "${drawingName}" - keeping version but requesting full drawing data`);
          // Don't remove the version - it's valid (including empty string), just request fresh data
        } else {
          console.log(`[QUEUE_DWG] No saved version for "${drawingName}", requesting full drawing data`);
        }
      }
      **/
      // Add to the request queue
      this.addToRequestQueue(cmd, null, null, 'refresh');
      console.log(`[QUEUE_DWG] Added "${drawingName}" to request queue`);
    } catch (error) {
      console.error(`[QUEUE_DWG] Failed to queue drawing "${drawingName}":`, error);
    }
  }

});
/*
   responseHandlers.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Response handler methods for the DrawingViewer class.
// Assigned to DrawingViewer.prototype after the class is defined in pfodWeb.js.
// Depends on global functions: pfodStripMenuCmdVersion (pfodMenuCache.js),
//   pfodParseMenu (pfodMenuParser.js), TouchZoneFilters (pfodWebMouse.js).
// Exports: _exitToConnectionScreen (shared exit flow, also called by requestQueue.js)
//
// State read:    redraw.redrawDrawingManager, menuCmdSet, menuCache, sentRequest, requestQueue,
//                touchState, currentIdentifier, canvas,
//                canvasContainer, isUpdating, updateTimer
// State written: currentIdentifier, menuCmdSet, isUpdating, updateTimer,
//                redraw.redrawDrawingManager (via processDrawingData)
// Calls:         resizeAndDimensions:handleResize, drawingProcessing:redrawCanvas,
//                drawingProcessing:processDrawingData,
//                navigationAndQueue:addToRequestQueue, navigationAndQueue:pushMenuNavCmd,
//                navigationAndQueue:updateNavigationStack,
//                chartAndRawData:exitChartDisplay, chartAndRawData:exitRawDataDisplay,
//                chartAndRawData:displayChartWithPlotNo, chartAndRawData:displayRawDataText,
//                connectionSetup:showNoConnectionAlert
// Called by:     requestQueue:processRequestQueue,
//                drawingProcessing:processPendingResponses

// ============================================================================
// Response shape classification and validation
// ----------------------------------------------------------------------------
// Each pfod response carries a leading shape token in data.cmd[0]:
//   {,...   full menu       {;...  menu update
//   {+...   drawing start    {+|... drawing update
//   {=...   raw / chart data
//   {?...   single select    {*...  multi  select
//   {!...   text input       {#...  numeric input
//   {}      empty ack (any whitespace between braces is treated identically)
//
// classifyResponseShape(data) returns one of those tokens.
// AllowedResponseShapes maps each requestType to the response shapes it
// can legitimately produce.  If a response shape isn't in the allow-list
// for the request that's currently sentRequest, it almost certainly
// means a stale response from a prior (lost / replaced) cmd is being
// matched to the wrong request — log [QUEUE_MISMATCH] and drop instead
// of corrupting state (e.g. pushing null into drawings[]).
// requestTypes marked 'any' (touch/drag/partialSlider/etc.) can validly
// return any shape so are not constrained.
// ============================================================================

function classifyResponseShape(data) {
  if (!data || !data.cmd || !data.cmd[0]) return 'unknown';
  const head = data.cmd[0];
  const cmd  = data.cmd;
  // Empty: '{' followed by optional whitespace then '}' — {}, { }, {  }, etc.
  // Two delivery shapes:
  //   single element: cmd[0] = "{}" / "{ }" / "{   }"
  //   split on the trailing '}' delimiter: cmd[0] = "{" (or "{ "), cmd[1] = "}"
  if (/^\{\s*\}\s*$/.test(head)) return 'empty';
  if (cmd.length >= 2 && /^\{\s*$/.test(head) && /^\s*\}/.test(cmd[1])) return 'empty';
  if (head.startsWith('{,'))  return 'menu-full';
  if (head.startsWith('{;'))  return 'menu-update';
  if (head.startsWith('{+|')) return 'dwg-update';
  if (head.startsWith('{+'))  return 'dwg-start';
  if (head.startsWith('{='))  return 'data';
  if (head.startsWith('{!'))  return 'text-input';
  if (head.startsWith('{#'))  return 'numeric-input';
  if (head.startsWith('{?'))  return 'single-select';
  if (head.startsWith('{*'))  return 'multi-select';
  return 'unknown';
}

const AllowedResponseShapes = {
  // mainMenu / back / menuRefresh: must return a menu (or empty).  A drawing
  // payload here is the misattribution case (stale {+...} from a previous
  // lost/replaced cmd).
  mainMenu:           ['menu-full', 'menu-update', 'empty'],
  back:               ['menu-full', 'menu-update', 'empty'],
  menuRefresh:        ['menu-full', 'menu-update', 'empty'],

  // Drawing fetches: drawing payloads only.
  menuItemDwg:        ['dwg-start', 'dwg-update', 'empty'],
  refresh:            ['dwg-start', 'dwg-update', 'empty'],
  'refresh-insertDwg':['dwg-start', 'dwg-update', 'empty'],
  insertDwg:          ['dwg-start', 'dwg-update', 'empty'],

  // keepAlive / dataRefresh: empty ack only.
  keepAlive:          ['empty'],
  dataRefresh:        ['empty'],

  // Open: device may legitimately respond with anything to a touch /
  // partialSlider / drag / authentication / exitAbort / unknown request.
  authentication:     'any',
  exitAbort:          'any',
  touch:              'any',
  input:              'any',
  drag:               'any',
  partialSlider:      'any',
  unknown:            'any',
};

function isResponseShapeValidFor(request, data) {
  const shape = classifyResponseShape(data);
  const allowed = AllowedResponseShapes[request.requestType];
  if (allowed === 'any' || !allowed) return { ok: true, shape, allowed: 'any' };
  return { ok: allowed.includes(shape), shape, allowed };
}

// Apply the `~C` ("clear collected data") plot option.  Called SYNCHRONOUSLY
// by the connection-layer byte boundary (via the queue-bound Option-B
// callback) the instant a {=..~C..} command that IS a valid response to the
// pending request is consumed — BEFORE the OUTSIDE bytes that follow it are
// fed to the collectors — so the clear drops only data that preceded the
// marker, never the new plot/stream data that arrives right after it.
//
// Reuses the authoritative parsers (chartDisplay.parseChartLabelsWithPlotNo
// for the field-spec chart form, and the streaming-title `~C` scan that the
// streaming branch below uses) — no second, drift-prone parser.  `data` is
// the parsed { cmd:[...] } object.
function applyClearOption(data) {
  if (!data || !data.cmd || !data.cmd.length ||
      typeof data.cmd[0] !== 'string' || !data.cmd[0].startsWith('{=')) return;
  let chartInfo = null;
  if (window.chartDisplay && typeof window.chartDisplay.parseChartLabelsWithPlotNo === 'function') {
    try { chartInfo = window.chartDisplay.parseChartLabelsWithPlotNo(data.cmd); }
    catch (e) { chartInfo = null; }
  }
  if (chartInfo) {
    if (chartInfo.clearData && window.csvCollector) {
      console.log('[STREAM] {=..~C..} chart marker — clearing csvCollector at the command boundary');
      window.csvCollector.clear();
    }
    return;
  }
  // Section-9 streaming raw-data form {=[title][~C]} — same title `~C` scan
  // as the streaming branch in handleNonDwgResponse.
  const m = data.cmd[0];
  const s = m.indexOf('=');
  let e = m.indexOf('}');
  if (e === -1) e = m.length;
  const parts = (s !== -1 ? m.substring(s + 1, e) : '').split('~');
  let clear = false;
  for (let i = 1; i < parts.length; i++) { if (parts[i].trim() === 'C') clear = true; }
  if (clear && window.rawDataCollector) {
    console.log('[STREAM] {=..~C..} streaming marker — clearing rawDataCollector at the command boundary');
    window.rawDataCollector.clear();
  }
}

Object.assign(DrawingViewer.prototype, {

  // Validate an incoming response against the in-flight request.
  // Returns true when the response should continue normal processing.
  // Returns false (after logging an error) when it must be dropped.
  //
  // Two gates:
  //   1. in-flight check: any {...} response received when sentRequest is
  //      null is unsolicited (or stale after a timeout) and is dropped.
  //   2. shape check: data.cmd[0] is classified and compared against
  //      AllowedResponseShapes[request.requestType].  Mismatch → drop as
  //      QUEUE_MISMATCH.
  validateResponseAgainstRequest(data, request) {
    if (!this.sentRequest) {
      console.error(`[QUEUE_MISMATCH] Response received with no in-flight cmd (sentRequest=null) — ignoring.  Raw head: ${(data && data.cmd && data.cmd[0]) || '<empty>'}`);
      return false;
    }
    const shapeCheck = isResponseShapeValidFor(request, data);
    if (!shapeCheck.ok) {
      console.error(`[QUEUE_MISMATCH] Response shape "${shapeCheck.shape}" does not match request type "${request.requestType}" (cmd="${request.cmd}"); allowed=${JSON.stringify(shapeCheck.allowed)}`);
      console.error(`[QUEUE_MISMATCH] Dropping response. Raw head: ${(data && data.cmd && data.cmd[0]) || '<empty>'}`);
      return false;
    }
    return true;
  },

  // Extract the leading identifier from a request cmd, after stripping "{"
  // and any "V<n>:" version prefix.  This is the cmd's leading identifier:
  //   - For drawing-fetch types (menuItemDwg/insertDwg/refresh/refresh-insertDwg)
  //     the cmd is "{<loadCmd>}" or "{V<n>:<loadCmd>}" — token IS the loadCmd,
  //     i.e. the ENTIRE remaining body (a dwg-designer loadCmd is
  //     DWG_PREVIEW_KEY_PREFIX + a DwgLibrary dwg name, which is free text —
  //     spaces and other non-word characters are legal and must survive here
  //     intact, since drawingsData/etc are keyed by this exact string
  //     elsewhere — e.g. menuData.drawingItems[].loadCmd — and a mismatch
  //     silently orphans the fetched content under the wrong key).
  //   - For touch-style cmds the cmd is "{<menuItemCmd>~..." — token is the
  //     menuItemCmd (NOT the loadCmd; use _resolveLoadCmdFromRequest for that).
  // Stops only at a genuine wire delimiter (~ ` | }), never at a plain
  // "non-word" character — those delimiters are the only real terminators
  // in either case.
  // Returns "" if the cmd body is empty at this point (e.g. "{.}", "{ }").
  _extractCmdToken(cmd) {
    if (!cmd || cmd[0] !== '{') return '';
    let body = cmd.slice(1);
    const colon = body.indexOf(':');
    if (colon > 0 && /^[A-Za-z0-9_]+$/.test(body.slice(0, colon))) {
      body = body.slice(colon + 1);
    }
    const m = body.match(/^([^~`|}]*)/);
    return m && m[1] ? m[1] : '';
  },

  // Resolve the dwg loadCmd from a request's cmd by parsing the leading
  // identifier (the menuItemCmd) and looking up the matching dwg/dwg-label
  // menu item in _currentMenu.items.  Returns null if the cmd has no
  // identifier or no matching dwg item is found (e.g. menu button click
  // or input submit, where the cmd targets a non-dwg item).
  _resolveLoadCmdFromRequest(request) {
    const menuItemCmd = this._extractCmdToken(request && request.cmd);
    if (!menuItemCmd) return null;
    const items = window.pfodMenuDisplay?._currentMenu?.items || [];
    const item = items.find(i => i.cmd === menuItemCmd
                              && (i.type === 'dwg' || i.type === 'dwg-label'));
    return item ? item.loadCmd : null;
  },

  // The source dwg of a touch-style request — the drawing that owns the
  // touched zone, carried on the request as touchZoneInfo.sourceDwgName by
  // handleTouchZoneActivation.  The response's dwg update is applied to this
  // drawing's per-drawing-raw collections and re-merged, so the new state
  // survives later re-merges.  Returns null for requests with no zone behind
  // them (touchActionInput submits, menu item presses) — those keep the
  // legacy direct-to-merged write.
  _touchSourceDwg(request) {
    return (request && request.touchZoneInfo && request.touchZoneInfo.sourceDwgName) || null;
  },

  // Handle an empty {} response.  Empty replies carry no payload but DO
  // count as "we got a response" — stamp itemRefreshTimes for the target
  // (menu, drawing, or — for touch/drag/partialSlider — resolved via menu
  // item lookup).  Also re-attach mouse listeners on the visible menu's
  // drawing canvases since empty replies skip the normal dwg re-render
  // path that re-registers listeners.
  //
  // Stamp targets by cmd type:
  //   mainMenu / back / menuRefresh           → STAMP 'menu' from header.reRequestMs
  //   menuItemDwg / insertDwg /
  //     refresh / refresh-insertDwg           → STAMP loadCmd from cmd token in
  //                                             drawingsData[loadCmd].data.refresh
  //   touch / drag / partialSlider            → STAMP loadCmd resolved from cmd's
  //                                             menuItem if the item has a loadCmd,
  //                                             else STAMP 'menu'
  //   keepAlive / dataRefresh                 → no stamp (no item to track)
  handleEmptyResponse(request, data) {
    console.info(`[QUEUE] Received empty command response {} - acknowledging without processing`);

    const reqType = request.requestType;

    // Input screen submission (text/numeric/selection) with {} response:
    // device says "no change" — re-request nav-stack top (same as Java's onBackPressed()).
    // Only input screens do this; menu {} stays on current screen.
    if (reqType === 'input') {
      const navCmd = this.menuNavStack.length > 0
        ? this.versionedMenuCmd(this.menuNavStack[this.menuNavStack.length - 1])
        : '{.}';
      if (this.updateTimer) { clearTimeout(this.updateTimer); this.updateTimer = null; }
      this.clearPendingQueue();
      this.addToRequestQueue(navCmd, null, null, 'back');
      return;
    }

    const isMenuCmd     = (reqType === 'mainMenu' || reqType === 'back' || reqType === 'menuRefresh');
    const isDrawingCmd  = (reqType === 'menuItemDwg' || reqType === 'insertDwg'
                        || reqType === 'refresh'    || reqType === 'refresh-insertDwg');
    const isTouchLike   = (reqType === 'touch' || reqType === 'drag'
                        || reqType === 'partialSlider' || reqType === 'unknown');

    if (isMenuCmd) {
      const menuRate = window.pfodMenuDisplay?._currentMenu?.header?.reRequestMs || 0;
      this.itemRefreshTimes.set('menu', menuRate > 0 ? Date.now() : null);
    } else if (isDrawingCmd) {
      // Drawing-fetch cmd: cmd token IS the loadCmd (e.g. "{V1:c2}" → "c2").
      const loadCmd = this._extractCmdToken(request.cmd);
      if (loadCmd) {
        const rate = this.redraw.redrawDrawingManager.drawingsData[loadCmd]?.data?.refresh || 0;
        this.itemRefreshTimes.set(loadCmd, rate > 0 ? Date.now() : null);
      }
    } else if (isTouchLike) {
      const loadCmd = this._resolveLoadCmdFromRequest(request);
      if (loadCmd) {
        const rate = this.redraw.redrawDrawingManager.drawingsData[loadCmd]?.data?.refresh || 0;
        this.itemRefreshTimes.set(loadCmd, rate > 0 ? Date.now() : null);
      } else {
        const menuRate = window.pfodMenuDisplay?._currentMenu?.header?.reRequestMs || 0;
        this.itemRefreshTimes.set('menu', menuRate > 0 ? Date.now() : null);
      }
    }
    // keepAlive / dataRefresh: no stamp.

    // Re-attach mouse listeners for drawing canvases in the current menu.
    // {} responses skip the normal response path that re-registers listeners
    // after a drawing refresh, so we must do it here.
    if (document.body.className === 'menu-mode'
        && window.pfodMenuDisplay
        && window.pfodMenuDisplay._currentMenu
        && window.pfodWebMouse) {
      for (const dwgItem of (window.pfodMenuDisplay._currentMenu.drawingItems || [])) {
        const entry = window.pfodMenuDisplay.getMenuCanvas(dwgItem.loadCmd);
        if (entry) {
          window.pfodWebMouse.setupMenuCanvasListeners(entry.canvas, dwgItem.loadCmd, dwgItem.cmd, this);
        }
      }
    }
  },

  // Process a pfod menu response: {,} new menu or {;} update.
  // For {;}: load cached base, apply update on top, display.
  // For {,}: cache the menu and display it.
  processMenuResponse(data, request) {
    let cmd;
    if (data.cmd) {
      cmd = data.cmd;
    } else {
      console.info('[QUEUE] No cmd field in server response ', JSON.stringify(data));
      return false;
    }
    const msgType = cmd[0];
    if (!(msgType.startsWith("{,") || msgType.startsWith("{;"))) {
      console.info('[QUEUE] Not a menu response ', JSON.stringify(data));
      return false;
    }

    const menuData = window.pfodParseMenu ? window.pfodParseMenu(cmd.slice()) : null;
    if (!menuData) return false;

    const reqCmd = pfodStripMenuCmdVersion(request ? request.cmd : '{.}');
    const bareCmd = reqCmd.slice(1, -1);
    const reqType = request ? request.requestType : 'menuItemDwg';
    const self = this;

    if (menuData.header.isUpdate) {
      // {;} update.  Three routes — pick by whether reqCmd targets a
      // *different* cached menu than the currently-displayed one:
      //   (a) Navigate forward to a cached submenu.  Fires when the user
      //       clicks a menu button whose cmd is cached (versioned-hit) and
      //       the device replies with {;} — reqCmd != currentMenuCmd AND
      //       there's a cached parsed menu for reqCmd.  Display switches
      //       to that cached menu with the update applied on top.
      //   (b) In-place update to the displayed menu.  Fires for refreshes
      //       (reqCmd == currentMenuCmd) and for touch-on-dwg responses
      //       where reqCmd is a touch sub-cmd with no cache entry of its
      //       own — the {;} update is for the menu the user is looking at.
      //   (c) Navigate from cache (back arrow case).  Toolbar pre-pops the
      //       nav stack and pre-hides the menu before sending {V:l}, so by
      //       the time we get the {;} reply currentMenuCmd already equals
      //       reqCmd and isVisible() is false.  Fall through to render the
      //       cached menu with the update applied.
      const currentMenuCmd = this.menuNavStack.length > 0
          ? this.menuNavStack[this.menuNavStack.length - 1] : '{.}';
      const currentBareCmd = currentMenuCmd.slice(1, -1);
      const baseMenuDataForReqCmd = this.menuCache ? this.menuCache.getParsedMenu(bareCmd) : null;
      const isForwardNavigation = baseMenuDataForReqCmd && (reqCmd !== currentMenuCmd);

      if (isForwardNavigation) {
        console.log('[MENU_CACHE] {;} response is forward-nav to cached submenu "' + bareCmd + '" - showing from cache with update applied');
        this._navigateToMenu(baseMenuDataForReqCmd, menuData, reqCmd, reqType, request, self);
      } else if (window.pfodMenuDisplay.isVisible()) {
        console.info('[QUEUE] {;} in-place update to visible menu - merging');
        window.pfodMenuDisplay.update(menuData);
        // Stamp 'menu' last-response.  {; can update header.reRequestMs
        // (pfodMenuDisplay.update applies non-null values); read the merged
        // effective rate from _currentMenu.  rate>0 → Date.now(); rate==0 → null.
        {
          const menuRate = window.pfodMenuDisplay?._currentMenu?.header?.reRequestMs || 0;
          this.itemRefreshTimes.set('menu', menuRate > 0 ? Date.now() : null);
        }
        // Keep cache in sync with the latest merged state so back-navigation shows current values
        if (this.menuCache) {
          this.menuCache.updateParsedMenu(currentBareCmd, window.pfodMenuDisplay._currentMenu);
        }
        this.handleResize();
        // Re-attach mouse listeners to the fresh canvases created by update()/show()
        if (window.pfodMenuDisplay._currentMenu && window.pfodMenuDisplay._currentMenu.hasDrawing && window.pfodWebMouse) {
          for (const dwgItem of window.pfodMenuDisplay._currentMenu.drawingItems) {
            const entry = window.pfodMenuDisplay.getMenuCanvas(dwgItem.loadCmd);
            if (entry) {
              window.pfodWebMouse.setupMenuCanvasListeners(entry.canvas, dwgItem.loadCmd, dwgItem.cmd, self);
            }
          }
        }
        // Re-request drawing items so drawings stay in sync with the {;} update.
        // Fires for every in-place menu update (menuRefresh, refresh, touch sub-cmd
        // returning {;}) — matching the back-arrow path in _navigateToMenu, which
        // queues drawing fetches unconditionally.  Driven only by whether the
        // current menu has drawings, not by reqType.
        if (window.pfodMenuDisplay._currentMenu && window.pfodMenuDisplay._currentMenu.hasDrawing) {
          const connectionId = (typeof getConnectionIdentifier === 'function')
            ? getConnectionIdentifier(this.connectionManager) : null;
          for (const dwgItem of window.pfodMenuDisplay._currentMenu.drawingItems) {
            const drawingName = dwgItem.loadCmd;
            this.currentIdentifier = dwgItem.cmd;
            // Hydrate per-drawing state from cache (if any) before building
            // the verify cmd so its version reflects the cached entry.
            if (connectionId && !this.redraw.redrawDrawingManager.drawingsData[drawingName]?.data) {
              this.redraw.redrawDrawingManager.loadDrawingDataFromStorage(drawingName, connectionId);
            }
            const storedVersion = this.redraw.redrawDrawingManager.getStoredVersion(drawingName, connectionId);
            const drawingCmd = storedVersion
              ? '{' + storedVersion + ':' + drawingName + '}'
              : '{' + drawingName + '}';
            if (!this.redraw.redrawDrawingManager.drawings.includes(drawingName)) {
              this.redraw.redrawDrawingManager.drawings.push(drawingName);
            }
            // Maintain itemRefreshTimes invariant: every entry in dm.drawings
            // has an entry.  null = no response yet (or rate==0); the response
            // stamp in _stampRefreshTimeAfterResponse updates to Date.now()
            // when the rate is > 0.
            if (!this.itemRefreshTimes.has(drawingName)) {
              this.itemRefreshTimes.set(drawingName, null);
            }
            console.info('[QUEUE] Refresh: re-requesting drawing "' + drawingName + '" cmd=' + drawingCmd);
            this.addToRequestQueue(drawingCmd, request.options, null, 'refresh');
          }
        }
      } else if (baseMenuDataForReqCmd) {
        // Menu hidden + reqCmd matches currentMenuCmd (back-arrow case).
        // Toolbar pre-popped the nav stack and pre-hid the visible menu
        // before sending the request; render the cached menu with the
        // update applied.
        console.log('[MENU_CACHE] {;} response (back navigation) - showing cached menu "' + bareCmd + '" with update applied');
        this._navigateToMenu(baseMenuDataForReqCmd, menuData, reqCmd, reqType, request, self);
      } else {
        // Back-nav arrived for a menu the toolbar pre-hid, but we have no
        // cached parsed copy of it (typical cause: that menu's prior {,}
        // response was unversioned and therefore not persisted).  Pop the
        // failed back target off menuNavStack so the next back / reload
        // targets the menu BEFORE it, and surface the error.  Stay in the
        // transient message-mode (the "Requesting Menu" overlay) — user
        // retries via toolbar back/reload.
        console.info(`[QUEUE] {;} response for "${reqCmd}" but no cached parsed menu — popping nav stack and showing error`);
        if (this.menuNavStack.length > 1) {
          const popped = this.menuNavStack.pop();
          console.log(`[MENU_NAV] Popped failed back target "${popped}" — stack now: ${JSON.stringify(this.menuNavStack)}`);
        }
        const newTop = this.menuNavStack.length > 0
          ? this.menuNavStack[this.menuNavStack.length - 1]
          : '{.}';
        pfodAlert(
          `Cannot navigate back to "${reqCmd}"\nthe device returned an update for a menu that was not cached.\n\n` +
          `Use the toolbar's back arrow or reload button to retry\nthey now target "${newTop}".`,
          () => {} // no-op; pfodAlert needs a non-null callback to render the Close button
        );
      }
      return true;
    }

    // {,} full new menu — record cmd, cache it, and display. ANY cmd
    // whose response is a full menu gets recorded/pushed here, regardless
    // of requestType — matches the real pfodApp/device protocol model
    // (a client may legitimately re-request any cmd at any later time;
    // it's the device's job to answer correctly from its own state, not
    // the client's job to avoid ever re-asking). A handler whose response
    // has a real side effect (e.g. addMenuItem.js's {ks`<idx>} picker
    // submit, which creates a new item) MUST be idempotent against being
    // re-invoked with the exact same rawCmd later — see that file's own
    // state._addMenuItemHistory for how it does that at the state level
    // (mirrors DesignerMsgProcessor.java's per-level cmdOverrideMapsList,
    // which rewrites a resent "ks" create-item cmd to the edit-item cmd
    // instead of preventing the resend), rather than trying to prevent
    // the resend from happening here.
    this.menuCmdSet.add(reqCmd);
    console.log('[MENU_NAV] Recorded menu cmd:', reqCmd, '- known set:', JSON.stringify([...this.menuCmdSet]));
    if (this.menuCache) {
      if (!menuData.header.version) {
        // Unversioned {,} response — evict only this menu's entry.
        // Versioning is per-menu (the device decides per response), so an
        // unversioned response for one cmd doesn't imply the other cached
        // menus are stale; leave them alone.  Next cycle re-requests this
        // menu unversioned.
        this.menuCache.removeMenu(bareCmd);
        console.log('[MENU_CACHE] {, response has no version - evicted "' + bareCmd + '" from cache');
      } else {
        this.menuCache.storeMenu(bareCmd, cmd.slice(), menuData.header.version);
        this.menuCache.updateParsedMenu(bareCmd, menuData);
      }
    }
    this._navigateToMenu(menuData, null, reqCmd, reqType, request, self);
    return true;
  },

  // Show a menu (or navigate to one from cache), optionally applying a pending {;} update after show.
  // Handles nav stack push, mode transition out of menu-mode, canvas registration, and drawing requests.
  _navigateToMenu(menuData, pendingUpdate, reqCmd, reqType, request, self) {
    // Push onto navigation stack unless this is a refresh or back navigation
    if (reqType !== 'refresh' && reqType !== 'back' && this.menuCmdSet.has(reqCmd)) {
      this.pushMenuNavCmd(reqCmd);
    }

    // Exit menu-mode first so the old menu's canvases are restored before show() creates new ones
    if (document.body.className === 'menu-mode' && window.pfodMenuDisplay) {
      window.pfodMenuDisplay.hide();
      this.redraw.clearMenuCanvases();
    }

    // Cancel pending refresh timer for the menu we're leaving.  keepAliveTimer
    // (raw-data polling) stays untouched — it's on a separate timer chain in
    // keepAlive.js, gated by protocol not mode.
    if (this.updateTimer) {
      clearTimeout(this.updateTimer);
      this.updateTimer = null;
    }
    // Don't remove existing drawings here: a {;} menu update can't remove
    // items (only hide/disable them), and a {,} full menu re-uses any dwg
    // items that survive into the new menu.  Drawings in dm.drawings keep
    // their drawingsData / per-drawing-raw collections so handleMenuResize
    // (called below after show()) finds existing canvas dimensions instead
    // of falling back to the placeholder size — that's what caused the
    // per-refresh size flash.  A drawing's dimensions only change when a
    // fresh {+`w`h start arrives for it; until then the previous size is
    // displayed.

    // Pre-load per-drawing caches BEFORE show()/handleResize so the very first
    // handleMenuResize call finds drawingsData and sizes canvases with the
    // correct aspect ratio.  Without this pre-load, the first paint runs with
    // the wide placeholder canvas dimensions while the cached drawing's items
    // get rendered at distorted non-uniform scale, producing a "jumbled"
    // flash before the next resize snaps to the correct size.  Lines below
    // (in the drawingItems loop after show()) still call loadDrawingDataFromStorage
    // defensively but become no-ops once data is already present.
    if (menuData.hasDrawing) {
      const preloadConnId = (typeof getConnectionIdentifier === 'function')
        ? getConnectionIdentifier(this.connectionManager) : null;
      if (preloadConnId) {
        for (const dwgItem of menuData.drawingItems) {
          const drawingName = dwgItem && dwgItem.loadCmd;
          if (!drawingName) continue;
          if (!this.redraw.redrawDrawingManager.drawingsData[drawingName]?.data) {
            this.redraw.redrawDrawingManager.loadDrawingDataFromStorage(drawingName, preloadConnId);
          }
          this.redraw.redrawDrawingManager.loadMenuDwgMergedFromStorage(drawingName, preloadConnId);
        }
      }
    }

    window.pfodMenuDisplay.show(menuData, function(clickedCmd) {
      // Designer connection's "Create/Edit Dwg" main-menu button: switch
      // into the Dwg Controls Panel's full-bleed custom UI mode directly,
      // client-side — same pattern as the toolbar's own Chart button
      // (toolbarAndMenu.js). Gated on protocol==='designer' so this cmd
      // byte can't be misinterpreted on a real device's own menu. The
      // {f} request below still goes out unchanged and resolves to a
      // harmless PFOD_EMPTY ack (see dwgDesigner/dwgControlsPanel.js).
      if (clickedCmd === DWG_CONTROLS_PANEL_CMD && self.protocol === 'designer'
          && window.designerDwgPanel) {
        window.designerDwgPanel.show();
      }
      // Send versioned request if this is a known menu cmd with a cached version
      let fullCmd = '{' + clickedCmd + '}';
      if (self.menuCache && self.menuCmdSet.has(fullCmd)) {
        const ver = self.menuCache.getMenuVersion(clickedCmd);
        if (ver) {
          fullCmd = '{' + ver + ':' + clickedCmd + '}';
          console.log('[MENU_CACHE] Using versioned cmd for button click:', fullCmd);
        }
      }
      console.log(`[MENU] Item clicked: cmd="${clickedCmd}" sending="${fullCmd}"`);
      self.addToRequestQueue(fullCmd, null, null, 'touch');
    });
    this.handleResize();

    // Apply any pending {;} flag/header update on top of the freshly shown menu
    if (pendingUpdate) {
      window.pfodMenuDisplay.update(pendingUpdate);
      this.handleResize();
    }

    // Register per-item canvases with redraw so drawings render into menu wrappers,
    // and wire mouse/touch events so touch zones on menu drawings send commands.
    if (window.pfodMenuDisplay) {
      this.redraw.clearMenuCanvases();
      for (const dwgItem of (menuData.drawingItems || [])) {
        const entry = window.pfodMenuDisplay.getMenuCanvas(dwgItem.loadCmd);
        if (entry) {
          this.redraw.setMenuCanvas(dwgItem.loadCmd, entry.canvas, entry.ctx);
          if (window.pfodWebMouse) {
            window.pfodWebMouse.setupMenuCanvasListeners(entry.canvas, dwgItem.loadCmd, dwgItem.cmd, this);
          }
        }
      }
    }

    // Stamp 'menu' last-response.  Read the effective rate from _currentMenu
    // (post-show / post-update) so we honour the "missing rate in an update
    // means no change" rule — pfodMenuDisplay.update() preserves the previous
    // reRequestMs when the new menuData carries null.  rate>0 → Date.now();
    // rate==0 → null (no auto-refresh for this menu).
    {
      const menuRate = window.pfodMenuDisplay?._currentMenu?.header?.reRequestMs || 0;
      this.itemRefreshTimes.set('menu', menuRate > 0 ? Date.now() : null);
    }

    // A menu can contain zero or more drawing items.  Each drawing item
    // references its own drawing — there is no single "main" drawing
    // for a menu.  Queue one menuItemDwg fetch per drawing item, hydrating
    // per-drawing state and per-menuDwg merged state from cache (if any)
    // so the canvas can render the cached merged tree immediately while
    // the verify request is in flight.
    if (menuData.hasDrawing) {
      const connectionId = (typeof getConnectionIdentifier === 'function')
        ? getConnectionIdentifier(this.connectionManager) : null;
      for (const dwgItem of menuData.drawingItems) {
        if (!dwgItem.loadCmd) {
          throw new Error(`[QUEUE] Menu drawing item has no loadCmd — cannot determine drawing to fetch. dwgItem=${JSON.stringify(dwgItem)}`);
        }
        const drawingName = dwgItem.loadCmd;
        this.currentIdentifier = dwgItem.cmd;
        console.info(`[QUEUE] Menu contains drawing item - queuing drawing request for "${drawingName}", identifier="${this.currentIdentifier}"`);

        if (connectionId && !this.redraw.redrawDrawingManager.drawingsData[drawingName]?.data) {
          this.redraw.redrawDrawingManager.loadDrawingDataFromStorage(drawingName, connectionId);
        }
        if (connectionId) {
          this.redraw.redrawDrawingManager.loadMenuDwgMergedFromStorage(drawingName, connectionId);
        }

        const storedVersion = this.redraw.redrawDrawingManager.getStoredVersion(drawingName, connectionId);
        const drawingCmd = storedVersion
          ? '{' + storedVersion + ':' + drawingName + '}'
          : '{' + drawingName + '}';
        if (!this.redraw.redrawDrawingManager.drawings.includes(drawingName)) {
          this.redraw.redrawDrawingManager.drawings.push(drawingName);
        }
        // Maintain itemRefreshTimes invariant: every entry in dm.drawings
        // has an entry.  null = no response yet (or rate==0); the response
        // stamp updates to Date.now() when rate is > 0.
        if (!this.itemRefreshTimes.has(drawingName)) {
          this.itemRefreshTimes.set(drawingName, null);
        }
        this.addToRequestQueue(drawingCmd, request ? request.options : null, null, 'menuItemDwg');
      }
    }
  },

  /**
   * Handle valid dwg update responses ({+...}, or partial updates).
   * Updates the live redrawDrawingManager's per-drawing raw collections in
   * place.  The caller (requestQueue.processRequestQueue or
   * drawingProcessing.processPendingResponses) is responsible for running
   * the merger and performRedraw once the batch settles, so multi-response
   * batches don't trigger N redraws.
   */
  handleDwgResponse(data, request) {
    console.info('[QUEUE] Handling dwg response');

    // Check if this DRAG response should be discarded due to newer drag requests in queue
    if (request.touchZoneInfo && request.touchZoneInfo.filter === TouchZoneFilters.DRAG) {
      const cmd = request.touchZoneInfo.cmd;
      const hasNewerDragRequest = this.requestQueue.some(queuedRequest =>
        queuedRequest.touchZoneInfo &&
        queuedRequest.touchZoneInfo.filter === TouchZoneFilters.DRAG &&
        queuedRequest.touchZoneInfo.cmd === cmd
      );

      if (hasNewerDragRequest) {
        console.info(`[QUEUE] Discarding DRAG response for cmd="${cmd}" - newer request exists in queue`);
        return false; // Discard this response
      }
    }

    try {
      if (document.body.className === 'input-mode' && window.pfodInputDisplay) {
        console.info('[QUEUE] Exiting input-mode before processing drawing response');
        window.pfodInputDisplay.hide();
      }
      if (document.body.className === 'numeric-input-mode' && window.pfodNumericInputDisplay) {
        console.info('[QUEUE] Exiting numeric-input-mode before processing drawing response');
        window.pfodNumericInputDisplay.hide();
      }
      if (document.body.className === 'selection-mode' && window.pfodSelectionDisplay) {
        console.info('[QUEUE] Exiting selection-mode before processing drawing response');
        window.pfodSelectionDisplay.hide();
      }
      console.info(`[QUEUE] Processing ${request.requestType} response for "${request.cmd}"`);

      // Derive data.name (the routing key for processDrawingData →
      // drawingsData[name] / unindexedItems[name] / etc.) from the request cmd.
      // The cmd is the authoritative source:
      //   - drawing-fetch types (menuItemDwg/insertDwg/refresh/refresh-insertDwg):
      //     cmd is "{<loadCmd>}" or "{V<n>:<loadCmd>}" — extract token directly.
      //   - touch-style types (touch/drag/partialSlider/unknown): cmd is
      //     "{<menuItemCmd>~..." — look up menu item to get its loadCmd.
      //     A {+ response targets allXXX[loadCmd] so the menu-items lookup is
      //     mandatory; for non-dwg menu items (e.g. menu button click) the
      //     lookup returns null and the resulting null data.name signals the
      //     merged-update path or is handled by downstream guards.
      //   - menu types (mainMenu/back/menuRefresh) shouldn't reach here at all
      //     (handleNonDwgResponse path) so leave the fall-back as null.
      const reqType = request.requestType;
      if (reqType === 'menuItemDwg' || reqType === 'insertDwg'
       || reqType === 'refresh'    || reqType === 'refresh-insertDwg') {
        data.name = this._extractCmdToken(request.cmd) || null;
      } else if (reqType === 'touch' || reqType === 'drag'
              || reqType === 'partialSlider' || reqType === 'unknown') {
        // Apply the response to the source dwg (the drawing owning the
        // touched zone, carried on the request) so the update lands in that
        // drawing's per-drawing-raw collections and survives later
        // re-merges.  Requests without a source dwg fall back to the
        // menuItemDwg and the legacy direct-to-merged write.
        const sourceDwg = this._touchSourceDwg(request);
        data.name = sourceDwg || this._resolveLoadCmdFromRequest(request);
        data._sourceDwgRouted = !!sourceDwg;
      } else {
        data.name = null;
      }

      this.processDrawingData(data, null, request.requestType);
      return true;
    } catch (error) {
      console.info(`[QUEUE] Error processing dwg response:`, error);
      console.info(`[QUEUE] Error stack:`, error.stack);

      // Additional diagnostics for debugging — derive the loadCmd from the
      // request cmd via the same helpers the response router uses.
      const dwgName = this._resolveLoadCmdFromRequest(request)
                   || this._extractCmdToken(request.cmd)
                   || " ";
      const dm = this.redraw.redrawDrawingManager;
      console.info(`[QUEUE] Debugging state for "${dwgName}":`);
      console.log(`- Registered drawings: ${JSON.stringify(dm.drawings)}`);
      console.log(`- Drawing in drawings array: ${dm.drawings.includes(dwgName)}`);
      console.log(`- Drawing in drawingsData: ${dm.drawingsData[dwgName] ? 'yes' : 'no'}`);
      console.log(`- unindexedItems collection exists: ${dm.unindexedItems[dwgName] ? 'yes' : 'no'}`);
      console.log(`- indexedItems collection exists: ${dm.indexedItems[dwgName] ? 'yes' : 'no'}`);
      console.log(`- touchZonesByCmd collection exists: ${dm.touchZonesByCmd[dwgName] ? 'yes' : 'no'}`);

      // Try to fix any missing collections
      if (dwgName !== " " && (!dm.unindexedItems[dwgName] || !dm.indexedItems[dwgName])) {
        console.info(`[QUEUE] Attempting to fix missing collections for "${dwgName}"`);
        dm.ensureItemCollections(dwgName);
      }

      // Show the no-connection alert when the failure is on the very
      // first request after connection (request.isInitial is set in
      // queueInitialRequest) — at that point there's nothing on screen
      // to keep, so the alert is the right user feedback.  For inserted
      // / refresh / later requests, just log and continue.
      const isInitial = request.isInitial === true;

      if (isInitial) {
        // Show alert dialog with Close button that reloads page
        console.log(`[ALERT] Triggering No Connection alert for initial request "${request.cmd}"`);
        console.log(`[ALERT] Error message: ${error.message}`);
        console.log(`[ALERT] Error name: ${error.name}`);
        this.showNoConnectionAlert();
      } else {
        // For inserted drawings, just log the error but continue processing
        console.info(`[QUEUE] ERROR: Failed to load inserted drawing "${dwgName}" - continuing without it`);
      }
      return false;
    }
  },

  /**
   * Handle non-dwg update responses (responses that are not {}, {+...}, or partial updates)
   * Only restores from backup if currently displaying dwg, then clears flag
   * Processes based on response type
   */
  handleNonDwgResponse(data, request, requestType) {
    console.info('[QUEUE] Handling non-dwg response');

    // Handle menu responses
    if (data.cmd && data.cmd[0] && (data.cmd[0].startsWith('{,') || data.cmd[0].startsWith('{;'))) {
      console.info('[QUEUE] Processing menu response');

      // Exit other display modes before processing a new menu response
      if (document.body.className === 'chart-mode') {
        console.info('[QUEUE] Exiting chart display before processing menu response');
        this.exitChartDisplay();
      }
      if (document.body.className === 'rawdata-mode') {
        console.info('[QUEUE] Exiting raw data display before processing menu response');
        this.exitRawDataDisplay();
      }
      // exitStreamingData is idempotent — call it whenever a streaming panel exists,
      // not only when className==='streaming-mode'.  This catches the case where the
      // panel was left in the DOM by an intermediate chart-mode (toolbar "..."→Chart
      // from streaming) and is still visible when the menu tries to show.
      if (document.getElementById('streaming-data-display')) {
        console.info('[QUEUE] Cleaning up leftover streaming panel before processing menu response');
        this.exitStreamingData();
      }
      if (document.body.className === 'input-mode' && window.pfodInputDisplay) {
        console.info('[QUEUE] Exiting input-mode before processing menu response');
        window.pfodInputDisplay.hide();
      }
      if (document.body.className === 'numeric-input-mode' && window.pfodNumericInputDisplay) {
        console.info('[QUEUE] Exiting numeric-input-mode before processing menu response');
        window.pfodNumericInputDisplay.hide();
      }
      if (document.body.className === 'selection-mode' && window.pfodSelectionDisplay) {
        console.info('[QUEUE] Exiting selection-mode before processing menu response');
        window.pfodSelectionDisplay.hide();
      }
      // For {,} responses, hide the current menu before processMenuResponse shows the new one.
      // For {;} responses, _navigateToMenu handles the hide when needed (cache-valid path).
      const isMenuUpdate = data.cmd[0].startsWith('{;');
      if (document.body.className === 'menu-mode' && window.pfodMenuDisplay && !isMenuUpdate) {
        console.info('[QUEUE] Exiting previous menu-mode before processing new menu response');
        window.pfodMenuDisplay.hide();
        this.redraw.clearMenuCanvases();
      }

      var result = this.processMenuResponse(data, request);
      if (result) {
        // Menu responses represent navigation to a new display
        // updateNavigationStack will skip refresh, refresh-insertDwg, and back requests internally
        this.updateNavigationStack(this.sentRequest);
        return; // menu was handled
      }
    }

    // Handle specific response types
    if (data.cmd && data.cmd[0] && data.cmd[0].startsWith('{=')) {
      // Exit menu-mode before switching to chart/rawdata display so the canvas is
      // restored to #canvas-wrapper before chartDisplay tries to resize and render it.
      if (document.body.className === 'menu-mode' && window.pfodMenuDisplay) {
        console.info('[QUEUE] Exiting menu-mode before processing chart/rawdata response');
        window.pfodMenuDisplay.hide();
        this.redraw.clearMenuCanvases();
      }
      console.info('[QUEUE] Processing response - checking for chart vs raw data');
      console.info('[QUEUE] Full data.cmd array:', data.cmd);
      console.info('[QUEUE] window.chartDisplay exists:', !!window.chartDisplay);

      // Try to parse as chart format (with pipe-delimited labels and optional plotNo)
      let chartInfo = null;
      if (window.chartDisplay) {
        console.info('[QUEUE] Calling parseChartLabelsWithPlotNo with entire cmd array');
        chartInfo = window.chartDisplay.parseChartLabelsWithPlotNo(data.cmd);
        console.info('[QUEUE] parseChartLabelsWithPlotNo returned:', chartInfo);
      } else {
        console.info('[QUEUE] WARNING: window.chartDisplay is not defined! Type:', typeof window.chartDisplay);
      }

      if (chartInfo) {
        // This is a chart response
        console.info('[QUEUE] Processing chart response:', chartInfo);

        // ~C clear is applied SYNCHRONOUSLY at the connection-layer byte
        // boundary (applyClearOption, via the Option-B callback) the moment
        // this {=..~C..} command is consumed — BEFORE the CSV that follows it
        // in the same stream is collected.  Doing it here (async, after the
        // whole response was already collected) is what wiped the new data.

        this.updateNavigationStack(this.sentRequest);
        window.currentChartInfo = chartInfo;
        this.displayChartWithPlotNo();
      } else {
        // Section 9 streaming raw data response: {=[<title>]}
        console.info('[QUEUE] Processing streaming raw data response');

        // Title is between '=' and '}'.  Tilde-separated trailing parts are
        // plot options (single-letter flags).  We support ~C (clear) here;
        // others are silently ignored to match the chart-format behaviour.
        const msgType = data.cmd[0];
        const startIdx = msgType.indexOf('=');
        let endIdx = msgType.indexOf('}');
        if (endIdx === -1) endIdx = msgType.length;
        const fullTitle = startIdx !== -1 ? msgType.substring(startIdx + 1, endIdx) : '';
        const titleParts = fullTitle.split('~');
        const streamTitle = (titleParts[0] || '').trim();
        let streamClearData = false;
        for (let i = 1; i < titleParts.length; i++) {
          const part = titleParts[i].trim();
          if (part === 'C') streamClearData = true;
          // any other single-letter or multi-letter option is silently ignored
        }

        // ~C clear is applied SYNCHRONOUSLY at the connection-layer byte
        // boundary (applyClearOption, via the Option-B callback) the moment
        // this {=..~C..} command is consumed — BEFORE the raw data that
        // follows it in the same stream is collected.  (streamClearData is
        // still parsed above for any future display use.)

        // Show all raw data accumulated so far; polling appends new data as it arrives
        const initialData = window.rawDataCollector ? window.rawDataCollector.getRawDataWithoutClearing() : '';
        this.updateNavigationStack(this.sentRequest);
        this.displayStreamingData(streamTitle, initialData);
      }
      return true;
    }

    // Add handlers for other non-dwg response types here as needed

    // Handle string input screen (Section 10: {'cmd[`maxLen][~prompt][|initialText]})
    if (data.cmd && data.cmd[0] && data.cmd[0].startsWith("{'")) {
      console.info('[QUEUE] Processing string input response');
      const inputData = PfodInputDisplay.parse(data.cmd);
      window.pfodInputDisplay.show(
        inputData,
        (cmd, text) => {
          // onSubmit: send the text cmd — device response determines next screen.
          this.clearPendingQueue();
          this.addToRequestQueue('{' + cmd + '~' + text + '}', null, null, 'input');
          window.pfodInputDisplay.hide();
          this.handleResize();
          this.updateCanvasMessage('Requesting ...');
        }
      );
      return true;
    }

    // Handle numeric input screen (Section 11: {#cmd[~prompt]`current[`max[`min]][~units[~scale[~offset]]})
    if (data.cmd && data.cmd[0] && data.cmd[0].startsWith('{#')) {
      console.info('[QUEUE] Processing numeric input response');
      const inputData = PfodNumericInputDisplay.parse(data.cmd);
      window.pfodNumericInputDisplay.show(
        inputData,
        (cmd, intValue) => {
          // onSubmit: send the numeric cmd — device response determines next screen.
          this.clearPendingQueue();
          this.addToRequestQueue('{' + cmd + '`' + intValue + '}', null, null, 'input');
          window.pfodNumericInputDisplay.hide();
          this.handleResize();
          this.updateCanvasMessage('Requesting ...');
        }
      );
      return true;
    }

    // Handle single/multi selection screens (Sections 12 & 13)
    const _isSingle = data.cmd && data.cmd[0] && data.cmd[0].startsWith('{?');
    const _isMulti  = data.cmd && data.cmd[0] && data.cmd[0].startsWith('{*');
    if (_isSingle || _isMulti) {
      console.info('[QUEUE] Processing', _isMulti ? 'multi' : 'single', 'selection response');
      const inputData = _isMulti
        ? PfodSelectionDisplay.parseMulti(data.cmd)
        : PfodSelectionDisplay.parseSingle(data.cmd);
      window.pfodSelectionDisplay.show(
        inputData,
        (cmd, isMulti, sortedIndices) => {
          // Build response string per pfod spec — device response determines next screen.
          let response;
          if (!isMulti) {
            response = '{' + cmd + '`' + sortedIndices[0] + '}';
          } else if (sortedIndices.length === 0) {
            response = '{' + cmd + '}';
          } else {
            response = '{' + cmd;
            for (let i = 0; i < sortedIndices.length; i++) response += '`' + sortedIndices[i];
            response += '}';
          }
          this.clearPendingQueue();
          this.addToRequestQueue(response, null, null, 'input');
          window.pfodSelectionDisplay.hide();
          this.handleResize();
          this.updateCanvasMessage('Requesting ...');
        }
      );
      return true;
    }

    // {!msg} — device forces connection close and shows a message to the user.
    // Displays the message then runs the shared exit flow on dismiss.
    if (data.cmd && data.cmd[0] && data.cmd[0].startsWith('{!')) {
      const msg = data.cmd[0].slice(2);
      console.info('[QUEUE] Close-connection response received:', msg);
      document.body.className = 'message-mode';
      pfodAlert(msg, () => {
        this._exitToConnectionScreen();
      });
      return true;
    }

    // {<} — device requests back navigation (same as toolbar back button)
    if (data.cmd && data.cmd[0] === '{<') {
      console.log('[RESPONSE] Received {<} - navigating back');
      const wasInMenuMode = document.body.className === 'menu-mode';

      if (wasInMenuMode && window.pfodMenuDisplay) {
        window.pfodMenuDisplay.hide();
        this.redraw.clearMenuCanvases();
      } else if (document.body.className === 'input-mode' && window.pfodInputDisplay) {
        window.pfodInputDisplay.hide();
      } else if (document.body.className === 'numeric-input-mode' && window.pfodNumericInputDisplay) {
        window.pfodNumericInputDisplay.hide();
      } else if (document.body.className === 'selection-mode' && window.pfodSelectionDisplay) {
        window.pfodSelectionDisplay.hide();
      } else if (document.body.className === 'chart-mode') {
        this.exitChartDisplay();
      }
      this.handleResize();
      this.updateCanvasMessage('Requesting Menu ...');

      let cmdToSend;
      if (wasInMenuMode && this.menuNavStack.length > 0) {
        if (this.menuNavStack.length > 1) {
          this.menuNavStack.pop();
        }
        cmdToSend = this.versionedMenuCmd(this.menuNavStack[this.menuNavStack.length - 1]);
      } else if (this.commandStack.length > 0) {
        cmdToSend = this.commandStack.pop();
      } else {
        cmdToSend = '{.}';
      }
      // Stop any pending auto-refresh fire — the back response will
      // re-evaluate scheduleNextUpdate.  itemRefreshTimes entries are
      // preserved (they're per-drawing/menu cached state).
      if (this.updateTimer) { clearTimeout(this.updateTimer); this.updateTimer = null; }
      this.clearPendingQueue();
      this.addToRequestQueue(cmdToSend, null, null, 'back');
      return true;
    }

    // {<<} — device requests home navigation (clear stacks, send {.})
    if (data.cmd && data.cmd[0] === '{<<') {
      console.log('[RESPONSE] Received {<<} - navigating to main menu');

      if (document.body.className === 'menu-mode' && window.pfodMenuDisplay) {
        window.pfodMenuDisplay.hide();
        this.redraw.clearMenuCanvases();
      } else if (document.body.className === 'input-mode' && window.pfodInputDisplay) {
        window.pfodInputDisplay.hide();
      } else if (document.body.className === 'numeric-input-mode' && window.pfodNumericInputDisplay) {
        window.pfodNumericInputDisplay.hide();
      } else if (document.body.className === 'selection-mode' && window.pfodSelectionDisplay) {
        window.pfodSelectionDisplay.hide();
      } else if (document.body.className === 'chart-mode') {
        this.exitChartDisplay();
      }
      this.handleResize();
      this.updateCanvasMessage('Requesting Main Menu ...');

      this.menuNavStack = [];
      this.commandStack = [];
      // Stop any pending auto-refresh fire — the mainMenu response will
      // re-evaluate scheduleNextUpdate.  itemRefreshTimes entries are
      // preserved (they're per-drawing/menu cached state).
      if (this.updateTimer) { clearTimeout(this.updateTimer); this.updateTimer = null; }
      this.clearPendingQueue();
      // Use the versioned form when the cache has a stored version for the
      // main menu — same as back-arrow / reload / queueInitialRequest paths.
      // Plain {.} would force the device to resend the full menu unnecessarily.
      this.addToRequestQueue(this.versionedMenuCmd('{.}'), null, null, 'mainMenu');
      return true;
    }

    // Add handlers for other non-dwg response types here as needed
    return false;
  },

  // Handle drawing error (not found, etc) - instance method for multi-viewer support
  handleDrawingError(errorData) {
    console.error(`Drawing error: ${errorData.error} - ${errorData.message}`);

    // Completely remove any canvas container that might interfere
    if (this.canvasContainer) {
      this.canvasContainer.style.display = 'none';
    }

    // Create a brand new error message div directly in the body
    // First, remove any existing error message
    const existingError = document.getElementById('error-message');
    if (existingError) {
      document.body.removeChild(existingError);
    }

    // Create the new error element
    const errorMessageElement = document.createElement('div');
    errorMessageElement.id = 'error-message';

    // Apply inline styles directly
    errorMessageElement.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: white;
            z-index: 999999;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 20px;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
            color: #333;
            text-align: center;
        `;

    // Set the HTML content
    errorMessageElement.innerHTML = `
            <div style="
                background-color: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 4px 8px rgba(0,0,0,0.1);
                max-width: 80%;
                margin: 0 auto;
                text-align: center;
            ">
                <h2 style="
                    color: #d32f2f;
                    margin-bottom: 20px;
                    font-size: 28px;
                    font-weight: bold;
                ">Drawing Error</h2>
                <p style="
                    font-size: 20px;
                    margin-bottom: 20px;
                    color: #333;
                ">${errorData.message}</p>
                <p style="
                    font-size: 18px;
                    margin-bottom: 30px;
                    color: #666;
                ">Please check the drawing name and try again.</p>
            </div>
        `;

    // Add to the document body
    document.body.appendChild(errorMessageElement);

    // For debugging
    console.log('Error message created and added to body');

    // Disable updates
    this.isUpdating = false;
    if (this.updateTimer) {
      clearTimeout(this.updateTimer);
      this.updateTimer = null;
    }

    // Log to console
    console.warn("ERROR DISPLAYED TO USER:", errorData.message);

    // Try to adjust the page title to indicate the error
    document.title = "Error: Drawing Not Found";
  },

  // Shared exit flow used by both Path A ({!} sent by user) and Path B ({!<message>} from device).
  // Stops polling, clears the queue, disconnects, and returns to the connection screen.
  _exitToConnectionScreen() {
    this.stopKeepAlivePolling();
    this.clearPendingQueue();
    if (this.connectionManager) {
      this.connectionManager.disconnect().catch(() => {});
      // The reload below (window.location.replace) fires beforeunload,
      // which would otherwise call connectionManager.disconnect() again —
      // resending {!} a second time for no reason since it was just sent
      // on the line above. Flag so beforeunload skips its own disconnect()
      // call (connectionSetup.js) for this reload specifically — the
      // alert's Close-button reload doesn't set this, since it does NOT
      // disconnect() ahead of time the way this function does, and still
      // needs beforeunload's disconnect() to run for it.
      window._pfodAlreadyDisconnected = true;
    }
    // Full page reload — clears all JS state, DOM, and accumulated event listeners.
    // Keep ?targetIP in the URL so the connection prompt's prefillFormFromURL()
    // fills the IP on reload (auto-connect is opt-in via ?autoConnect, which
    // is stripped below so exit always returns to the prompt for cache-clear /
    // chart-only choice / IP edit).
    const url = new URL(window.location.href);
    // Strip 'autoConnect' so reload shows the prompt instead of immediately
    // re-connecting.  autoConnect is a one-shot opt-in for the current
    // session — once the user has exited, they're back to manual confirm.
    url.searchParams.delete('autoConnect');
    // Strip 'chart' unless we're in chart-only mode — outside chart-only the
    // user may have been on any menu/drawing when they hit Exit, and persisting
    // a stale chart= would re-open the chart-only flow on next reconnect.  In
    // chart-only mode chart= is the entire point of the URL; keep it so reload
    // reopens it.
    if (!this.chartOnlyMode) {
      url.searchParams.delete('chart');
    }

    // The reload re-requests this exact origin.  Only check pfodProxy
    // first when it's actually serving this page (_pageServedByProxy()) —
    // a file:// (or other static-server) load reloads straight from disk/
    // that server regardless of pfodProxy, so there's nothing to check.
    // When it IS serving this page and isn't actually there any more
    // (pfodProxy only ever stops when the user closes it directly — see
    // spawn_idle_logger() in main.rs, which just logs idleness rather than
    // acting on it), the browser would otherwise show its own unfriendly
    // "can't connect" error instead of landing back on the connection
    // prompt; fail soft with our own message instead.
    if (!_pageServedByProxy()) {
      window.location.replace(url.toString());
      return;
    }
    const port = window.location.port;
    _pingProxy(port).then((available) => {
      if (available) {
        window.location.replace(url.toString());
      } else {
        // The reload that would normally clear toolbarAndMenu.js's
        // "Closing Down …" spinner (toolbar-closing-overlay) isn't
        // happening — remove it directly so the page doesn't sit frozen
        // behind the alert with no way back.
        const closingOverlay = document.getElementById('toolbar-closing-overlay');
        if (closingOverlay) closingOverlay.remove();
        // The reload that would normally land on `url` (stripped of
        // autoConnect/chart, reflecting the connection just exited) isn't
        // happening either — update just the address bar to match, with no
        // navigation, so it doesn't keep showing whatever was there before
        // Exit was clicked (e.g. a stale HTTP ?targetIP= from an earlier
        // connection in this same tab, when the one just exited was Serial).
        history.replaceState(null, '', url.toString());
        pfodAlert(_proxyUnreachableMsg('127.0.0.1:' + port));
      }
    });
  }

});
/*
   keepAlive.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// KeepAlive polling methods for the DrawingViewer class.
// Assigned to DrawingViewer.prototype after the class is defined in pfodWeb.js.
// Sends periodic { } commands on Serial/BLE connections to collect rawData.
//
// State read:    csvLoaded, connectionManager.protocol, keepAliveActive, keepAliveTimer,
//                keepAliveInterval, requestQueue, sentRequest
// State written: keepAliveActive, keepAliveTimer
// Calls:         navigationAndQueue:addToRequestQueue
// Called by:     connectionSetup:setupEventListeners [startKeepAlivePolling after connect],
//                drawingProcessing:processPendingResponses [scheduleNextKeepAlive],
//                requestQueue:processRequestQueue [scheduleNextKeepAlive after each response]

Object.assign(DrawingViewer.prototype, {

  /**
   * Start keepAlive polling for TCP/IP Socket connections.
   *
   * Sends `{ }` (open brace, space, close brace) every N seconds while
   * the connection is idle, where N is the value the user picked from
   * the connection-prompt KeepAlive dropdown (0/5/10/20/30 — 0 means
   * disabled).  pfod treats `{ }` as a no-op cmd: the device acks
   * without changing menu state, which both prevents NAT pinholes
   * from expiring and keeps the device's own session alive.
   *
   * The timer is reset on every cmd / refresh / menuRefresh / touch
   * response (via scheduleNextKeepAlive() called from
   * requestQueue.js) but **not** on a dataRefresh response (the
   * dataRefresh branch in requestQueue early-returns before the
   * keepAlive reset call).
   *
   * Only fires for TCP/IP — HTTP has dataRefresh, Serial/BLE have a
   * continuous byte stream so a protocol-level keepAlive is redundant.
   */
  startKeepAlivePolling() {
    // Never start keepAlive when CSV was loaded - no server connection exists
    if (this.csvLoaded) {
      console.log('[KEEPALIVE] Not starting - CSV loaded mode (no server connection)');
      return;
    }

    // KeepAlive is TCP/IP-Socket-only — see method docstring for rationale.
    if (this.connectionManager.protocol !== 'tcp') {
      console.log(`[KEEPALIVE] Not starting - protocol is "${this.connectionManager.protocol}", keepAlive is TCP-only`);
      return;
    }

    // Read user-configured interval (0 = disabled).
    const sec = (typeof this.connectionManager.getKeepAliveSec === 'function')
      ? this.connectionManager.getKeepAliveSec() : 0;
    if (sec === 0) {
      console.log('[KEEPALIVE] Not starting - keepAliveSec=0 (disabled)');
      return;
    }
    this.keepAliveInterval = sec * 1000;

    // Already active - don't start again
    if (this.keepAliveActive) {
      console.log('[KEEPALIVE] Already active - not starting again');
      return;
    }

    console.log(`[KEEPALIVE] Starting keepAlive polling at ${sec}s interval`);
    this.keepAliveActive = true;
    this.scheduleNextKeepAlive();
  },

  /**
   * Stop keepAlive polling
   */
  stopKeepAlivePolling() {
    if (this.keepAliveTimer) {
      clearTimeout(this.keepAliveTimer);
      this.keepAliveTimer = null;
    }
    this.keepAliveActive = false;
    console.log('[KEEPALIVE] Stopped keepAlive polling');
  },

  /**
   * Schedule the next keepAlive command.
   *
   * Called from requestQueue.processRequestQueue() after every
   * non-dataRefresh response — that's how the timer resets when real
   * traffic flows.  The dataRefresh branch in requestQueue.js
   * early-returns before this call, so dataRefresh responses do
   * **not** reset the keepAlive countdown (that would prevent it from
   * ever firing while datapolling is active).
   */
  scheduleNextKeepAlive() {
    // Only TCP/IP arms this timer (mirrors startKeepAlivePolling's gate).
    if (this.connectionManager && this.connectionManager.protocol !== 'tcp') {
      return;
    }
    if (!this.keepAliveActive) {
      return;
    }

    // Clear any existing timer
    if (this.keepAliveTimer) {
      clearTimeout(this.keepAliveTimer);
      this.keepAliveTimer = null;
    }

    // Schedule next keepAlive after the configured interval.  The
    // interval was set from getKeepAliveSec() in startKeepAlivePolling.
    this.keepAliveTimer = setTimeout(() => {
      this.sendKeepAlive();
    }, this.keepAliveInterval);
  },

  /**
   * Send a keepAlive command { } to collect rawData
   * Independent of menu/drawing refresh settings
   * Only sends if request queue is empty
   */
  sendKeepAlive() {
    if (!this.keepAliveActive) {
      return;
    }

    // Don't add keepAlive if queue is not empty - there's already a request pending
    if (this.requestQueue.length > 0) {
      console.log('[KEEPALIVE] Skipping - requestQueue not empty (length=' + this.requestQueue.length + ')');
      // Schedule next attempt - the response from queued request will trigger reschedule
      this.scheduleNextKeepAlive();
      return;
    }

    // Also skip if there's already a request in flight
    if (this.sentRequest) {
      console.log('[KEEPALIVE] Skipping - request already in flight: ' + this.sentRequest.requestType);
      // Schedule next attempt
      this.scheduleNextKeepAlive();
      return;
    }

    console.log('[KEEPALIVE] Sending keepAlive command { }');

    // Send keepAlive command through queue
    // Use special requestType 'keepAlive' so we can track it
    this.addToRequestQueue('{ }', {}, null, 'keepAlive', false);
  }

});
/*
   requestQueue.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Request queue processor — dequeues, sends, and dispatches responses.
// Assigned to DrawingViewer.prototype after the class is defined in pfodWeb.js.
//
// State read:    requestQueue, sentRequest, touchState, pendingResponseQueue,
//                hasReceivedFirstResponse, jsonErrorAlertShown, connectionManager, dataRefreshActive,
//                _isProcessingQueue
// State written: requestQueue, sentRequest, pendingResponseQueue, hasReceivedFirstResponse,
//                jsonErrorAlertShown, dataRefreshActive,
//                redraw.redrawDrawingManager (via handleDwgResponse + merger)
// Calls:         navigationAndQueue:setProcessingQueue, navigationAndQueue:scheduleNextUpdate,
//                navigationAndQueue:scheduleDataRefresh, navigationAndQueue:isEmptyCmd,
//                drawingProcessing:redrawCanvas,
//                drawingMerger.mergeAllDrawings, redraw.performRedraw,
//                responseHandlers:handleNonDwgResponse, responseHandlers:handleDwgResponse,
//                resizeAndDimensions:updateCanvasMessage, resizeAndDimensions:clearCanvasMessage,
//                keepAlive:scheduleNextKeepAlive
// Called by:     navigationAndQueue:addToRequestQueue,
//                drawingProcessing:processPendingResponses,
//                chartAndRawData:exitChartDisplay [via setTimeout]
//
// Response shape classification, AllowedResponseShapes table, and
// isResponseShapeValidFor / validateResponseAgainstRequest live in
// responseHandlers.js — those are response-handling concerns, not queue
// mechanics.  This file uses validateResponseAgainstRequest via the
// DrawingViewer prototype.

Object.assign(DrawingViewer.prototype, {

  // Returns true when the post-response repaint should be deferred:
  // while the mouse is down, or while a real (non-refresh) request is
  // still outstanding (in flight or queued) — e.g. a button cmd whose
  // response will set the final state.  Routine refresh responses
  // repaint immediately as they arrive.
  shouldDeferRedraw() {
    if (this.touchState.isDown) {
      return true;
    }
    const isNonRefreshType = r =>
        r.requestType !== 'refresh' && r.requestType !== 'refresh-insertDwg';
    return (this.sentRequest && isNonRefreshType(this.sentRequest)) ||
           this.requestQueue.some(isNonRefreshType);
  },

  // Undo the optimistic touchAction edits made to allXXX[dwgName] during a
  // touch — copies the mousedown-time backup (window.pfodWebMouse.
  // touchActionBackups, made by pfodWebMouse.js's handleMouseDown via
  // redraw.makeBackup()) back over the live merged collections, then
  // repaints and clears the backup (a fresh one is built on the next
  // touch). Extracted from processRequestQueue's own inline
  // [TOUCH_RESTORE] handling below so dwgDesigner/dwgControlsPanelUI.js's
  // dwg preview — which reaches this via the exact same
  // addToRequestQueue -> processRequestQueue -> connectionManager.send
  // path any real menu touch uses, not a separate re-implementation —
  // ends up here too, for free.
  //
  // The repaint uses document.body.className as performRedrawInMode's
  // mode argument (rather than a hardcoded 'menu-mode') so this works
  // whichever mode dwgName's canvas actually lives in: harmless/redundant
  // for a real menu-mode touch (executeTouchAction already repainted via
  // redrawWithWorkingCopy when it ran), and exactly the repaint the dwg
  // preview needs after this restore, since its own empty-response cycle
  // otherwise short-circuits through handleEmptyResponse with no redraw
  // (requestQueue.js's own comment there: "should be acknowledged but not
  // trigger any screen refresh").
  //
  // @param {string} dwgName — already-resolved menuDwg loadCmd (the real
  //        call site below resolves this via _resolveLoadCmdFromRequest;
  //        the preview already knows its own key directly)
  _restoreTouchActionBackup(dwgName) {
    const backup = window.pfodWebMouse && window.pfodWebMouse.touchActionBackups;
    if (!backup) return;
    const live = this.redraw && this.redraw.redrawDrawingManager;
    const fields = ['allTouchZonesByCmd', 'allTouchActionsByCmd',
                    'allTouchActionInputsByCmd', 'allUnindexedItems',
                    'allIndexedItemsByNumber'];
    for (const f of fields) {
      const snap = JSON.parse(JSON.stringify((backup[f] && backup[f][dwgName]) ||
                                              (f === 'allUnindexedItems' ? [] : {})));
      if (live && live[f]) live[f][dwgName] = snap;
    }
    console.log(`[TOUCH_RESTORE] Restored allXXX["${dwgName}"] on live from backup before applying touch response`);
    window.pfodWebMouse.touchActionBackups = null;
    if (this.redraw) this.redraw.performRedrawInMode(document.body.className, dwgName);
  },

  // Resolve + restore the touchAction backup for a completed 'touch'
  // request, if there is one to restore. Shared by both places a
  // touch's response gets processed: processRequestQueue's own "mouse is
  // up" branch below, and processPendingResponses (drawingProcessing.js)
  // draining responses that arrived while the mouse was still down. Both
  // call this — not a copy of it — so the touch/backup-exists guard and
  // the dwg resolution live in exactly one place.
  //
  // @param {object} request — the completed request (cmd/requestType)
  _restoreTouchActionForRequest(request) {
    if (request.requestType !== 'touch'
        || typeof window === 'undefined'
        || !window.pfodWebMouse
        || !window.pfodWebMouse.touchActionBackups) {
      return;
    }
    const dwg = this._resolveLoadCmdFromRequest(request);
    if (dwg) this._restoreTouchActionBackup(dwg);
  },

  // Process the request queue
  async processRequestQueue() {
    // Safety check: ensure requestQueue is initialized
    if (!this.requestQueue) {
      console.info('[QUEUE] Error: requestQueue is undefined. Aborting queue processing.');
      return;
    }
    //if (this.sentRequest) {
    //  console.info(`[QUEUE] processRequestQueue have sentRequest, queue length: ${this.requestQueue.length}`);
    //} else {
    //  console.info(`[QUEUE] processRequestQueue no sentRequest, queue length: ${this.requestQueue.length}`);
    //}
    // Try to atomically set processing state from false to true
//    if (!this.trySetProcessingQueue(false, true)) {
//      console.info(`[QUEUE] Already processing queue - skipping`);
//      return;
//    }

    // Return early if there's already a request in flight or queue is empty.
    // On drain (no sentRequest, queue empty), arm the next refresh timer
    // directly — no setTimeout race.  Mirrors Java pfodAppState.java's pattern
    // of having the receive path restart the refresh timer.
    if (this.sentRequest || this.requestQueue.length === 0) {
      if (this.sentRequest) {
        this.setProcessingQueue(true);
      } else {
        this.setProcessingQueue(false);
        if (document.body.className === 'menu-mode') {
          this.redrawCanvas();
        } else {
          console.info('[QUEUE] Not in menu-mode - skipping final redraw. Current mode:', document.body.className);
        }
        this.scheduleNextUpdate();
      }
      return;
    }

    console.info(`[QUEUE] processRequestQueue current queue is:`, JSON.stringify(this.requestQueue, null, 2));

 //    this.setProcessingQueue(true); // have non-zero queue length
    // Remove the request from queue and move it to sentRequest
    const request = this.requestQueue.shift();
    console.info(`[QUEUE] PROCESSING: "${request.cmd}" (${request.requestType})#${request._id} - moved from queue to sentRequest`);
    console.info(`[QUEUE] after shift, remaining queue length=${this.requestQueue.length}, contents:`, JSON.stringify(this.requestQueue.map(r => `${r.cmd}(${r.requestType})#${r._id}`)));
    this.sentRequest = request;
    console.log(`[SENTREQUEST] ASSIGNED: "${request.cmd}" (${request.requestType})#${request._id} at ${new Date().toISOString()}`);
    console.info(`[QUEUE] sentRequest is:`, JSON.stringify(this.sentRequest, null, 2));

    // Handle dataRefresh: send pfodWeb?cmd= (no dedup) to collect streaming CSV data.
    // Does not go through the normal pfod response pipeline.  IMPORTANT:
    // dataRefresh must NOT cancel updateTimer (the menu/drawing refresh
    // timer).  Both fire on a 1 s cadence; if dataRefresh cancels the
    // menu-refresh timer at send time, the menu-refresh request never
    // gets a chance to dispatch — every cycle the dataRefresh sneaks in
    // first and kills it, then scheduleNextUpdate re-arms it for another
    // 1 s, and the dataRefresh fires first again.  Result: device only
    // sees empty-cmd polls, no `\<refresh>` menu refreshes ever go out.
    if (request.requestType === 'dataRefresh') {
      this.dataRefreshActive = true; // Set synchronously before first await
      let dataRefreshError = null;
      try {
        // Gate on adapter capability so SerialProxyConnection (which
        // inherits sendDataRefresh from HTTPConnection but reports
        // protocol='serial') gets datapolling too.  Native Web Serial /
        // BLE adapters don't have sendDataRefresh and are skipped.
        if (this.connectionManager.adapter
         && typeof this.connectionManager.adapter.sendDataRefresh === 'function') {
          await this.connectionManager.adapter.sendDataRefresh();
        }
      } catch (error) {
        console.warn('[DATAREFRESH] Error during dataRefresh:', error.message);
        dataRefreshError = error;
      }
      this.dataRefreshActive = false;
      console.log(`[SENTREQUEST] CLEARED: "${request.cmd}" (${request.requestType}) - dataRefresh complete at ${new Date().toISOString()}`);
      this.sentRequest = null;
      if (dataRefreshError) {
        // Network failure or HTTP error during polling (distinct from {.} getting no pfod
        // response — here the connection itself is down).  Stop polling and alert.
        // Polling restarts automatically when any subsequent cmd response is received.
        pfodAlert(
          `Connection lost — device stopped responding during data polling.\n\n` +
          `${dataRefreshError.message}\n\n` +
          `You can:\n` +
          `• Click "Close" to dismiss this alert\n` +
          `• Use the pfodWeb toolbar's reload button to reconnect\n` +
          `• Use the pfodWeb toolbar's back button to go back`,
          () => { console.log('[DATAREFRESH] User closed connection-lost alert'); }
        );
        // Do not reschedule — polling stopped; restarts on next successful cmd response
      } else {
        this.scheduleDataRefresh();
      }
      this.processRequestQueue();
      return;
    }

    // Cancel any pending menu-refresh timer at SEND time for non-dataRefresh
    // requests.  Mirrors Java's sendMessage -> cancelRefreshTimer
    // (pfodAppState.java:614): the response we're about to receive will
    // bring updated menu / drawing state, so the refresh timer is re-armed
    // by scheduleNextUpdate after that response is fully applied.
    if (this.updateTimer) {
      clearTimeout(this.updateTimer);
      this.updateTimer = null;
      console.log('[REFRESH] Cancelled refresh timer at send time');
    }

    try {
      // Track the touchZone filter and cmd for this request being sent
      if (request.touchZoneInfo) {
        if (!this.sentRequests) {
          this.sentRequests = [];
        }
        this.sentRequests.push({
          cmd: request.touchZoneInfo.cmd,
          filter: request.touchZoneInfo.filter,
          timestamp: Date.now()
        });
        console.info(`[QUEUE] Tracking sent request: cmd="${request.touchZoneInfo.cmd}", filter="${request.touchZoneInfo.filter}"`);
      }
      // Use ConnectionManager to send command
      console.info(`[QUEUE] Sending command: ${request.cmd}`);

      // Option B: hand the connection a tiny interface bound to THIS request.
      // The byte boundary (connectionManager.processReadBuffer) invokes these
      // synchronously when a complete {..} is consumed, to decide
      // raw-vs-valid-response and to apply ~C BEFORE the OUTSIDE bytes that
      // follow the command are collected.  isResponseShapeValidFor /
      // applyClearOption are free functions in responseHandlers.js (same
      // bundle scope).  The byte boundary additionally gates on a pending
      // responseResolve, so "a request is in flight" is guaranteed here.
      const _req = request;
      const respCallbacks = {
        isValidResponse: (json) => {
          let d;
          try { d = JSON.parse(json); } catch (e) { return false; }
          try { return !!isResponseShapeValidFor(_req, d).ok; }
          catch (e) { return false; }
        },
        applyClearOption: (json) => {
          let d;
          try { d = JSON.parse(json); } catch (e) { return; }
          applyClearOption(d);
        },
        // Called by HTTPConnection.sendOnce() on receipt of any HTTP response body
        // (even empty/non-pfod) — signals the connection is live and starts CSV polling.
        onAnyResponseReceived: () => this.scheduleDataRefresh()
      };

      // exitAbort: skip the generic send() below entirely — the shared exit
      // flow's own connectionManager.disconnect() call (see
      // _exitToConnectionScreen() in responseHandlers.js) already sends {!}
      // itself (fire-and-forget, its own dedup char, keepalive so it
      // survives the reload that follows). Calling send('{!}') here too
      // would just be a second, redundant {!} to the device.
      if (request.requestType === 'exitAbort') {
        console.log(`[SENTREQUEST] CLEARED: "${request.cmd}" (${request.requestType}) - exitAbort at ${new Date().toISOString()}`);
        this.sentRequest = null;
        this._exitToConnectionScreen();
        return;
      }

      const responseText = await this.connectionManager.send(request.cmd, respCallbacks);

      // Schedule dataRefresh 1 second after this send completes (HTTP only)
      this.scheduleDataRefresh();

      // Create response-like object for compatibility with existing code
      const response = {
        ok: true,
        status: 200,
        text: async () => responseText
      };

      console.info(`[QUEUE] Received response for "${request.cmd}": status ${response.status}, queue length: ${this.requestQueue.length}`);
      console.warn(`[QUEUE] Response JSON for "${request.cmd}":`, responseText);

      if (!response.ok) {
        throw new Error(`Server returned ${response.status} for cmd "${request.cmd}"`);
      }

      // Log the raw JSON that we already have
      console.info(`[QUEUE] Received raw JSON data for "${request.cmd}":`);
      console.info(responseText);

      // (No discardResponse path: under the ordinal/overridable model, higher-
      // priority cmds replace lower-priority queued ones at queue time, so
      // racing refresh responses simply complete and are harmless — touch
      // backups protect optimistic state from stale refresh data.)
      // Don't clear sentRequest here - will be cleared after processing is complete

      // Track request type for logging purposes
      let lastRequest = request.requestType;

      /***
      // Prefilter JSON to fix newlines in strings before parsing
      // prehaps add this back later to catch all control chars
      function prefilterJSON(jsonString) {
        let result = '';
        let inString = false;
        let escaping = false;

        for (let i = 0; i < jsonString.length; i++) {
          const char = jsonString[i];

          if (escaping) {
            result += char;
            escaping = false;
            continue;
          }

          if (char === '\\') {
            result += char;
            escaping = true;
            continue;
          }

          if (char === '"') {
            inString = !inString;
            result += char;
            continue;
          }

          if (inString && char === '\n') {
            result += '\\n';  // Replace literal newline with escaped newline
          } else {
            result += char;
          }
        }

        return result;
      }

      // Parse the JSON for processing
      const cleanedResponseText = prefilterJSON(responseText);
      const data = JSON.parse(cleanedResponseText);
      console.info('[QUEUE] parsedText ', JSON.stringify(data,null,2));
      **/
      // Parse JSON response — all protocols (HTTP, Serial, BLE) now deliver {"cmd":[...]} format.
      // csvCollector and rawDataCollector are fed by processIncoming() in the connection layer
      // before this point, so no rawData extraction is needed here.
      let data = null;
      let jsonParseError = null;
      try {
        data = JSON.parse(responseText);
      } catch (parseError) {
        console.error(`[PARSE_ERROR] Failed to parse JSON response for "${request.cmd}"`);
        console.error(`[PARSE_ERROR] Error message: ${parseError.message}`);
        console.error(`[PARSE_ERROR] Response length: ${responseText.length} bytes`);
        console.error(`[PARSE_ERROR] Raw response text:`, responseText);
        jsonParseError = parseError;
      }

      // If JSON parsing failed, re-throw so the outer catch can show the alert
      if (jsonParseError) {
        throw jsonParseError;
      }

      // Delegate response validation to responseHandlers.  Two gates:
      //   - in-flight: response received with no sentRequest is unsolicited / stale
      //   - shape:     data.cmd[0] must match the cmd type's AllowedResponseShapes
      // Mismatches almost always mean a stale response from a previous cmd
      // (whose request was lost/replaced/timed-out) is now being matched to
      // a different sentRequest.  Drop it rather than feed it through
      // processing, which would otherwise corrupt state (e.g.
      // setDrawingData(null, ...) → drawings[null] → '{null}' refresh loop).
      if (!this.validateResponseAgainstRequest(data, request)) {
        console.log(`[SENTREQUEST] CLEARED: "${request.cmd}" (${request.requestType}) - response validation failed at ${new Date().toISOString()}`);
        this.sentRequest = null;
        this.scheduleNextKeepAlive();
        this.processRequestQueue();
        return;
      }

      // Cache response if it has a version.  PfodMenuCache scopes
      // entries by connectionId, so designer-vs-real-device entries
      // stay separate per design name automatically.
      if (typeof cacheResponse === 'function') {
        cacheResponse(data, request, this.connectionManager);
      }

      // Show loading message only on initial load, not during refresh cycles to prevent flashing
      if (!this.hasReceivedFirstResponse) {
        this.updateCanvasMessage('Loading Drawing ...');
      }

      // Mark that we've received the first successful response
      if (!this.hasReceivedFirstResponse) {
        this.hasReceivedFirstResponse = true;
        console.log('[RESPONSE] First successful response received, hasReceivedFirstResponse set to true');
      }
      this.jsonErrorAlertShown = false; // Reset so future JSON errors are reported again

      // Handle the response data
      if (this.touchState.isDown) {
        // Mouse is down - queue the response to prevent flashing
        console.info(`[QUEUE] Mouse is down (touchState.isDown=${this.touchState.isDown}) - queuing response for "${request.cmd}" to prevent flashing`);
        // Remove the processed request from the queue first
//         this.sentRequest = null;
//         this.requestQueue.shift();
         console.info(`[QUEUE] after isDown sentRequest the current queue is:`, JSON.stringify(this.requestQueue, null, 2));


        // For DRAG responses, keep only the latest one
        if (request.touchZoneInfo && request.touchZoneInfo.filter === TouchZoneFilters.DRAG) {
          const cmd = request.touchZoneInfo.cmd;
          // Remove any existing DRAG response for the same cmd
          this.pendingResponseQueue = this.pendingResponseQueue.filter(pendingResponse =>
            !(pendingResponse.request.touchZoneInfo &&
              pendingResponse.request.touchZoneInfo.filter === TouchZoneFilters.DRAG &&
              pendingResponse.request.touchZoneInfo.cmd === cmd)
          );
          console.info(`[QUEUE] Keeping only latest DRAG response for cmd="${cmd}"`);
        }

        // Add this response to the pending queue
        this.pendingResponseQueue.push({
          request: request,
          data: data
        });
        console.info(`[QUEUE] Added to pending queue. Total pending responses: ${this.pendingResponseQueue.length}`);
      } else {
        // Mouse is up - process immediately

        // Restore-on-response (touch only): undo the optimistic touchAction
        // edits made to allXXX[menuDwg] during the touch.  Per the data
        // model, touchActions modify ONLY the menuDwg's merged collections;
        // the device's reply will re-apply real changes via the merge that
        // follows.  Backup is cleared in either case — a fresh one is built
        // on the next touch.
        this._restoreTouchActionForRequest(request);

        console.info(`[QUEUE] Processing data for cmd "${request.cmd}" (type: ${request.requestType})`);

        // Detect response type for logging
        if (data.pfodDrawing === 'start' || data.pfodDrawing === 'update') {
          lastRequest = 'dwgUpdate';
        } else if (data.cmd && data.cmd[0]) {
          if (data.cmd[0].startsWith('{,') || data.cmd[0].startsWith('{;')) {
            lastRequest = 'mainMenu';
          } else if (data.cmd[0].startsWith('{=')) {
            lastRequest = 'rawData';
          } else if (data.cmd[0].startsWith('{+')) {
            lastRequest = 'dwgUpdate';
          } else if (this.isEmptyCmd(data.cmd)) {
            lastRequest = 'empty';
          }
        }

        // Check for empty command response {} - typically from keepAlive { }
        // Empty responses should be acknowledged but not trigger any screen refresh or processing
        const isEmptyResponse = this.isEmptyCmd(data.cmd);
        if (isEmptyResponse) {
          // Delegate empty {} handling (cmd-type-aware itemRefreshTimes
          // stamping + mouse-listener re-attach) to responseHandlers.
          this.handleEmptyResponse(request, data);
          // Clear sentRequest and continue queue processing.
          console.log(`[SENTREQUEST] CLEARED: "${request.cmd}" (${request.requestType}) - empty response at ${new Date().toISOString()}`);
          this.sentRequest = null;
          this.scheduleNextKeepAlive();
          this.processRequestQueue();
          return;
        }

        // Check if this is a valid dwg update:
        // 1. {+ response (full or partial dwg update), OR
        // 2. pfodDrawing: 'start' or 'update' (direct drawing format)
        const isFullOrPartialDwgUpdate = (data.cmd && data.cmd.length > 0 && data.cmd[0].startsWith('{+')) || (data.pfodDrawing === 'start') || (data.pfodDrawing === 'update');
        const isDwgUpdate = isFullOrPartialDwgUpdate;

        // If not a valid dwg update, handle as non-dwg response (menu, raw data, etc.)
        if (!isDwgUpdate) {
          console.info(`[QUEUE] Response is NOT a valid dwg update (${lastRequest}) - handling as non-dwg response (isFullOrPartial=${isFullOrPartialDwgUpdate}, isEmpty=${isEmptyResponse})`);
          this.handleNonDwgResponse(data, request, request.requestType);
          // 'menu' itemRefreshTimes is stamped inside processMenuResponse /
          // _navigateToMenu using the just-merged _currentMenu.header.reRequestMs.
          // Clear the sent request and continue processing
          console.info(`[QUEUE] COMPLETED: ${lastRequest} response - clearing sentRequest (was ${this.sentRequest ? this.sentRequest.cmd + '(' + this.sentRequest.requestType + ')#' + this.sentRequest._id : 'null'}; local request was ${request.cmd}(${request.requestType})#${request._id})`);
          this.sentRequest = null;
          // Reschedule keepAlive polling after response (1 second delay)
          this.scheduleNextKeepAlive();
          this.processRequestQueue();
          return;
        }

        // Handle valid dwg response through dedicated method
        if (this.handleDwgResponse(data, request)) {
          // Drain insertDwg items collected during this response's
          // processDrawingData scan, BEFORE clearing sentRequest.  Each
          // handleInsertDwg → addToRequestQueue → processRequestQueue
          // chain early-skips because sentRequest is still set, so items
          // pile into the queue without triggering timer schedules or
          // pulling a new request mid-stream.  After sentRequest is
          // cleared below, the tail processRequestQueue() pulls the first
          // queued insert.  Each subsequent insert's own response will
          // run its own scan and queue its own children the same way.
          const pendingInserts = (data && data._pendingInserts) || [];
          if (pendingInserts.length > 0) {
            console.info(`[QUEUE] Queueing ${pendingInserts.length} deferred insertDwg item(s) from "${request.cmd}" before clearing sentRequest`);
            for (const item of pendingInserts) {
              this.handleInsertDwg(item);
            }
          }

          // Drawing itemRefreshTimes is stamped inside processDrawingData for
          // 'start' responses (which carry the refresh field); 'update' and
          // empty responses leave the timestamp alone.

          // Clear the sent request and continue processing
          console.info(`[QUEUE] COMPLETED: ${lastRequest} response - clearing sentRequest (was ${this.sentRequest ? this.sentRequest.cmd + '(' + this.sentRequest.requestType + ')#' + this.sentRequest._id : 'null'}; local request was ${request.cmd}(${request.requestType})#${request._id})`);
          this.sentRequest = null;
          // Decide whether to re-merge.  Only touch-style responses WITHOUT
          // a source dwg landed straight in allXXX[menuDwg] (legacy merged
          // write) and must NOT be re-merged — re-running mergeAllDrawings
          // would rebuild allXXX from the per-drawing raw collections and
          // clobber the update.  Everything else (drawing-fetch types AND
          // source-routed touch responses) updated per-drawing raw
          // collections, so rebuild allXXX to pick up the new state.
          const rt = request.requestType;
          const isMergedUpdate = (rt === 'touch' || rt === 'drag' || rt === 'partialSlider')
                              && !this._touchSourceDwg(request);
          if (!isMergedUpdate) {
            const merger = new window.DrawingMerger(this.redraw.redrawDrawingManager);
            merger.mergeAllDrawings();
          }
          // Persist per-menuDwg merged cache for each drawing item the
          // current menu shows.  Both branches change allXXX[menuDwg]:
          //   - per-drawing-raw response: merger ran above, allXXX rebuilt.
          //   - merged-update response: processDrawingData wrote items
          //     straight into allXXX[menuDwg].
          // Either way the cache must reflect the new merged state.
          if (typeof getConnectionIdentifier === 'function') {
            try {
              const connectionId = getConnectionIdentifier(this.connectionManager);
              const dwgItems = (window.pfodMenuDisplay && window.pfodMenuDisplay._currentMenu && window.pfodMenuDisplay._currentMenu.drawingItems) || [];
              for (const dwgItem of dwgItems) {
                if (dwgItem.loadCmd) {
                  this.redraw.redrawDrawingManager.saveMenuDwgMergedToStorage(dwgItem.loadCmd, connectionId);
                }
              }
            } catch (e) {
              console.info('[QUEUE] Could not save menuDwg merged cache:', e.message);
            }
          }
          if (this.shouldDeferRedraw()) {
            console.log(`[REDRAW] Deferred redraw - mouseDown=${this.touchState.isDown}`);
          } else {
            this.redraw.performRedraw();
          }
          // Reschedule keepAlive polling after response (1 second delay)
          this.scheduleNextKeepAlive();
          this.processRequestQueue();
          return;
        } else {
          // Error was already handled in handleDwgResponse
          // Clear the failed request and continue processing
          console.log(`[SENTREQUEST] CLEARED: "${request.cmd}" (${request.requestType}) at ${new Date().toISOString()}`);
          this.sentRequest = null;
          // Reschedule keepAlive polling after response (1 second delay)
          this.scheduleNextKeepAlive();

          // For inserted drawings, if we're at the end of the queue, proceed with redraw (only if in menu-mode)
          if (this.requestQueue.length === 0 && !this.sentRequest) {
            console.info(`[QUEUE] Queue empty after failed request. Drawing with available data.`);
            this.setProcessingQueue(false);
            if (document.body.className === 'menu-mode') {
              this.redrawCanvas();
            } else {
              console.info('[QUEUE] Not in menu-mode - skipping redraw after failed request. Current mode:', document.body.className);
            }
            // Resume update scheduling after failed request cleanup
            this.scheduleNextUpdate();
          }

          // Continue processing queue
          setTimeout(() => {
            if (this.sentRequest || this.requestQueue.length !== 0) {
              this.processRequestQueue();
            }
          }, 10);
          return;
        }
      }

      // Per-response merge+redraw fires above (in the dwg-response branch).

    } catch (error) {
      // Catch any errors from JSON parsing or other non-handler logic
      console.info(`[QUEUE] Error processing request "${request.cmd}":`, error);
      console.info(`[QUEUE] Error stack:`, error.stack);

      // Check if this is a retry exhaustion error (timeout or no response after retries)
      const isRetryExhausted = error.message && (
        error.message.includes('All') && error.message.includes('attempts exhausted') ||
        error.message.includes('timeout') ||
        error.message.includes('device may not be responding')
      );

      // Check if this is a JSON parsing error
      const isJSONError = error instanceof SyntaxError;

      // HTTP response was received but contained no pfod {..} command — connection is alive,
      // device just doesn't send pfod (e.g. CSV-only).  Polling continues for this case.
      const isNoPfodInResponse = error.code === 'NO_PFOD_IN_RESPONSE';

      // pfodProxy's BLE cached-connect backoff (ble.rs's ensure_open) —
      // a short, expected, self-clearing cooldown after a recent BLE
      // connect failure, not a real problem the user can act on. The
      // underlying reconnect keeps retrying on its own regardless of
      // whether we alert, so just log and let it keep trying quietly.
      const isBleRetryBackoff = error.message && /recent connection failure, retry in \d+s/i.test(error.message);

      // Clear canvas message on timeout
      if (isRetryExhausted) {
        this.clearCanvasMessage();
      }

      // Network/HTTP failures mean the connection itself is down — stop data polling.
      // NO_PFOD_IN_RESPONSE means the connection works (device responded), so leave polling alone.
      if (!isNoPfodInResponse && this.dataRefreshTimer) {
        clearTimeout(this.dataRefreshTimer);
        this.dataRefreshTimer = null;
      }

      // Display alert to user for all errors
      const isInitialMainMenu = request.isInitial && request.requestType === 'mainMenu';
      if (isBleRetryBackoff) {
        console.info('[QUEUE] BLE retry backoff active — suppressing connection alert, will keep retrying');
      } else if (isRetryExhausted && this.exitPending) {
        // User clicked Exit while the cmd was retrying — the retry was abandoned
        // mid-way by the adapter (or hit its last attempt) and we are about to send {!}
        // and tear down.  Suppress the "Connection failed" modal so it can't block the
        // Closing Down overlay / _exitToConnectionScreen reload.
        console.info('[QUEUE] Retry exhausted but exitPending — suppressing Connection-failed alert');
      } else if (isRetryExhausted) {
        const maxRetries = this.connectionManager.getMaxRetries();
        const totalAttempts = maxRetries + 1;
        const isSerialTimeout = /serial response timeout/i.test(error.message);

        pfodAlert(
          `Connection failed after ${totalAttempts} attempts.\n\n` +
          `${error.message}\n` +
          (isSerialTimeout ? `Check Baud Rates match.\n` : ``) +
          `\nYou can:\n` +
          `• Click "Close" to dismiss this alert\n` +
          `• Use the pfodWeb toolbar's reload button to try again\n` +
          `• Use the pfodWeb toolbar's back button to go back` +
          (isInitialMainMenu
            ? `\n\nIf just plotting streaming CSV data use the \u22ee menu to open the Chart display`
            : ``),
          () => {
            // Optional callback after user closes the alert
            console.info('[QUEUE] User closed retry failure alert');
          }
        );
      } else if (isJSONError) {
        // JSON parsing error - only show once across retries; reset on next successful response
        if (!this.jsonErrorAlertShown) {
          this.jsonErrorAlertShown = true;
          pfodAlert(
          `Invalid response format - failed to parse data.\n\n` +
          `${error.message}\n\n` +
          `You can:\n` +
          `• Click "Close" to dismiss this alert\n` +
          `• Use the pfodWeb toolbar's reload button to try again\n` +
          `• Use the pfodWeb toolbar's back button to go back` +
          (isInitialMainMenu
            ? `\n\nIf just plotting streaming CSV data use the \u22ee menu to open the Chart display`
            : ``),
          () => {
            // Optional callback after user closes the alert
            console.info('[QUEUE] User closed JSON error alert');
          }
        );
        } // end if (!this.jsonErrorAlertShown)
      } else {
        // All other errors are connection issues.
        // Strip internal proxy noise ("cmd write failed (...): proxy returned NNN:\n"
        // and "open failed: ") so the user sees only the meaningful OS/device error.
        const rawMsg = error.message || '';
        const cleanMsg = rawMsg
          .replace(/^cmd write failed[^:]*:\s*(proxy returned \d+[^\n]*\n?)?/i, '')
          .replace(/^open failed:\s*/i, '')
          .trim() || rawMsg;
        const isNetworkError = /networkerror|failed to fetch|cannot reach/i.test(cleanMsg);
        const activeProtocol = window.pfodConnectionManager && window.pfodConnectionManager.protocol;
        let deviceHint;
        if (activeProtocol === 'http') {
          // Direct HTTP connection to the device — no pfodProxy involved.
          deviceHint = '• Check the device IP/port is correct and the device is powered on and connected';
        } else if (isNetworkError) {
          deviceHint = '• Check pfodProxy is running and the proxy port setting is correct';
        } else if (activeProtocol === 'serial') {
          deviceHint = '• Check COM port is not already in use elsewhere';
        } else {
          deviceHint = '• Check the pfodProxy port setting is correct';
        }
        pfodAlert(
          `Connection issue detected.\n\n` +
          `${cleanMsg}\n\n` +
          `You can:\n` +
          `${deviceHint}\n` +
          `• Click "Close" to dismiss this alert\n` +
          `• Use the pfodWeb toolbar's reload button to reconnect\n` +
          `• Use the pfodWeb toolbar's back button to go back`,
          () => {
            // Optional callback after user closes the alert
            console.info('[QUEUE] User closed connection issue alert');
          }
        );
      }

      // Clear the failed request
      console.log(`[SENTREQUEST] CLEARED: "${request.cmd}" (${request.requestType}) at ${new Date().toISOString()}`);
      this.sentRequest = null;

      // Continue processing queue if:
      //  - JSON errors (sometimes recovered by retry), OR
      //  - exitPending is set: {!} is sitting in the queue waiting to fire so
      //    _exitToConnectionScreen can reload — without this re-trigger the
      //    queue stalls after a retry-exhausted error and Exit locks up.
      if (isJSONError || this.exitPending) {
        setTimeout(() => {
          if (this.sentRequest || this.requestQueue.length !== 0) {
            this.processRequestQueue();
          }
        }, 10);
      }
    }
  }

});
/*
   connectionSetup.js
 * (c)2025 Forward Computing and Control Pty. Ltd.
 * NSW Australia, www.forward.com.au
 * This code is not warranted to be fit for any purpose. You may only use it at your own risk.
 * This generated code may be freely used for both private and commercial use
 * provided this copyright is maintained.
 */

// Connection-parameter extraction, HTTP endpoint helpers, drawing load,
// and all startup bootstrapping for DrawingViewer.
// Instance methods are assigned to DrawingViewer.prototype after the class is
// defined in pfodWeb.js.
//
// State read:    protocol, targetIP, baudRate, connectionManager, canvas
// State written: (URL params and DOM only; no DrawingViewer instance state written)
// Calls:         toolbarAndMenu:setupToolbarButtons, toolbarAndMenu:setupContextMenu,
//                navigationAndQueue:queueInitialRequest, navigationAndQueue:addToRequestQueue,
//                keepAlive:startKeepAlivePolling, resizeAndDimensions:handleResize
// Called by:     constructor [setupEventListeners], page-load globals (DOMContentLoaded)
// NOTE: Must be last in bundle — window.DrawingViewer is exported here after all
//       Object.assign patches from the other module files have been applied.
// Globals (loadScript, initializeApp, event listeners, etc.) run at module load time.
//
// IMPORTANT: This file must be the LAST entry in both bundle script lists so that
// window.DrawingViewer is exported only after every Object.assign patch is applied.

Object.assign(DrawingViewer.prototype, {

  // Return the connection protocol inferred from URL parameters.
  // Checks for ?serial, ?ble, or ?targetIP; defaults to 'http'.
  extractProtocol() {
    console.log(`[PROTOCOL] Extracting protocol from URL parameters`);
    console.log(`[PROTOCOL] window.location.search: ${window.location.search}`);

    // Infer protocol from parameter presence
    const urlParams = new URLSearchParams(window.location.search);

    // Check for protocol-specific parameters
    if (urlParams.has('serial')) {
      console.log(`[PROTOCOL] Found 'serial' parameter - using Serial protocol`);
      return 'serial';
    } else if (urlParams.has('ble')) {
      console.log(`[PROTOCOL] Found 'ble' parameter - using BLE protocol`);
      return 'ble';
    } else if (urlParams.has('targetIP')) {
      console.log(`[PROTOCOL] Found 'targetIP' parameter - using HTTP protocol`);
      return 'http';
    }

    // Default to HTTP if not specified
    console.log(`[PROTOCOL] No protocol-specific parameters found, defaulting to 'http'`);
    return 'http';
  },

  // Return the target IP/hostname from the ?targetIP URL param.
  // Returns null if no valid address is found.
  extractTargetIP() {
    console.log(`[TARGET_IP] Extracting target IP from URL`);
    console.log(`[TARGET_IP] window.location.search: ${window.location.search}`);

    // Extract from URL parameters (e.g., ?targetIP=192.168.1.100 or ?targetIP=djpetrica.go.ro:49890)
    const urlParams = new URLSearchParams(window.location.search);
    const targetIP = urlParams.get('targetIP');
    console.log(`[TARGET_IP] URL parameter targetIP: ${targetIP}`);

    if (targetIP) {
      // Use shared validation function that supports both IP addresses and domain names
      if (isValidIPAddress(targetIP)) {
        console.log(`[TARGET_IP] Valid target found: ${targetIP}`);
        return targetIP;
      } else {
        console.log(`[TARGET_IP] Invalid IP address or domain format: ${targetIP}`);
      }
    }

    console.log(`[TARGET_IP] No valid target IP found, returning null`);
    return null;
  },

  // Return the baud rate from the ?serial=<baud> or ?baudRate=<baud> URL param.
  // Accepts only known valid rates; defaults to 115200.
  extractBaudRate() {
    console.log(`[BAUD_RATE] Extracting baud rate from URL parameters`);
    console.log(`[BAUD_RATE] window.location.search: ${window.location.search}`);

    // Extract from URL parameters - can be ?serial=115200 or standalone ?baudRate=115200
    const urlParams = new URLSearchParams(window.location.search);

    // First check if serial parameter has a value (e.g., ?serial=115200)
    const serialValue = urlParams.get('serial');
    console.log(`[BAUD_RATE] URL parameter serial: ${serialValue}`);

    if (serialValue && serialValue !== '') {
      // Parse and validate baud rate from serial parameter value
      const parsedBaudRate = parseInt(serialValue, 10);
      const validBaudRates = [9600, 19200, 38400, 57600, 74880, 115200];

      if (validBaudRates.includes(parsedBaudRate)) {
        console.log(`[BAUD_RATE] Valid baud rate found in serial parameter: ${parsedBaudRate}`);
        return parsedBaudRate;
      } else {
        console.log(`[BAUD_RATE] Invalid baud rate in serial parameter: ${serialValue}, defaulting to 115200`);
      }
    }

    // Fallback to baudRate parameter (for backwards compatibility)
    const baudRate = urlParams.get('baudRate');
    console.log(`[BAUD_RATE] URL parameter baudRate: ${baudRate}`);

    if (baudRate) {
      // Parse and validate baud rate
      const parsedBaudRate = parseInt(baudRate, 10);
      const validBaudRates = [9600, 19200, 38400, 57600, 74880, 115200];

      if (validBaudRates.includes(parsedBaudRate)) {
        console.log(`[BAUD_RATE] Valid baud rate found: ${parsedBaudRate}`);
        return parsedBaudRate;
      } else {
        console.log(`[BAUD_RATE] Invalid baud rate: ${baudRate}, defaulting to 9600`);
      }
    }

    // Default to 115200 if not specified or invalid
    console.log(`[BAUD_RATE] No valid baud rate found, defaulting to 115200`);
    return 115200;
  },

  // Build an absolute URL for path using this.targetIP.
  // Falls back to a relative path when targetIP is not set.
  buildEndpoint(path) {
    console.log(`[ENDPOINT] buildEndpoint called with path: ${path}, targetIP: ${this.targetIP}`);
    if (this.targetIP) {
      const fullEndpoint = `http://${this.targetIP}${path}`;
      console.log(`[ENDPOINT] Built full endpoint: ${fullEndpoint}`);
      return fullEndpoint;
    }
    console.log(`[ENDPOINT] No targetIP, returning relative path: ${path}`);
    return path; // Fallback to relative URL
  },

  // Return a fetch options object with CORS/credentials settings appropriate for
  // the current targetIP (cross-origin when set, same-origin otherwise).
  buildFetchOptions(additionalHeaders = {}) {
    return {
      headers: {
        'Accept': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        ...additionalHeaders
      },
      mode: this.targetIP ? 'cors' : 'same-origin',
      credentials: this.targetIP ? 'omit' : 'same-origin',
      cache: 'no-cache'
    };
  },

  // Wire up canvas mouse/touch listeners (via pfodWebMouse) and toolbar button listeners.
  setupEventListeners() {
    // Mouse and touch event handling is now in pfodWebMouse.js
    if (typeof window.pfodWebMouse !== 'undefined') {
      window.pfodWebMouse.setupEventListeners(this);
    } else {
      console.error('pfodWebMouse.js not loaded - mouse events will not work');
    }

    // Setup toolbar button listeners
    this.setupToolbarButtons();

    // Context menu disabled - raw data now only accessible via toolbar menu
    // this.setupContextMenu();
  },

  // (Removed: loadDrawing() — assumed a single privileged main drawing
  // for the connection.  Initial flow is queueInitialRequest -> mainMenu
  // request -> menu response which queues one menuItemDwg per drawing
  // item via responseHandlers.processMenuResponse.)


  // Build a human-readable connection description (protocol, address, baud rate).
  // Used by showNoConnectionAlert() to display connection details to the user.
  getConnectionInfoMessage() {
    let connectionInfo = '';

    console.log('[CONNECTION_INFO] Protocol:', this.protocol);
    console.log('[CONNECTION_INFO] Adapter:', this.connectionManager?.adapter);

    if (this.protocol === 'http' && this.targetIP) {
      connectionInfo = `HTTP to ${this.targetIP}`;
    } else if (this.protocol === 'serial') {
      const portName = this.connectionManager?.adapter?.portName || 'COM?';
      connectionInfo = `Serial: ${portName} @ ${this.baudRate} baud`;
    } else if (this.protocol === 'ble') {
      // Try multiple ways to get device name
      let deviceName = this.connectionManager?.adapter?.device?.name;
      if (!deviceName) {
        deviceName = this.connectionManager?.adapter?.deviceName;
      }
      if (!deviceName) {
        deviceName = 'Unknown Device';
      }
      connectionInfo = `BLE: ${deviceName}`;
    } else {
      connectionInfo = 'Unknown Connection';
    }

    console.log('[CONNECTION_INFO] Final message:', connectionInfo);
    return connectionInfo;
  },

  // Show a "No Connection" modal overlay after max retry attempts.
  // The Close button reloads the page so the user can reconnect.
  showNoConnectionAlert() {
    console.log('[ALERT] Showing No Connection alert after max retry attempts');

    // Create overlay
    const overlay = document.createElement('div');
    overlay.id = 'no-connection-overlay';
    overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
      z-index: 999998;
      display: flex;
      justify-content: center;
      align-items: center;
    `;

    // Create alert dialog
    const alertBox = document.createElement('div');
    alertBox.style.cssText = `
      background-color: white;
      padding: 30px 40px;
      border-radius: 10px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
      text-align: center;
      max-width: 500px;
      font-family: Arial, sans-serif;
    `;

    // Create message
    const message = document.createElement('p');
    message.textContent = 'No Connection';
    message.style.cssText = `
      font-size: 24px;
      font-weight: bold;
      margin: 0 0 15px 0;
      color: #d32f2f;
    `;

    // Create connection details
    const details = document.createElement('p');
    const connectionInfo = this.getConnectionInfoMessage();
    details.textContent = `Failed to connect to: ${connectionInfo}`;
    details.style.cssText = `
      font-size: 14px;
      margin: 0 0 20px 0;
      color: #666;
      font-family: monospace;
    `;

    // Create Close button
    const closeButton = document.createElement('button');
    closeButton.textContent = 'Close';
    closeButton.style.cssText = `
      background-color: #2196F3;
      color: white;
      border: none;
      padding: 10px 30px;
      font-size: 16px;
      border-radius: 5px;
      cursor: pointer;
      outline: none;
    `;

    // Make button respond to hover
    closeButton.onmouseover = () => {
      closeButton.style.backgroundColor = '#1976D2';
    };
    closeButton.onmouseout = () => {
      closeButton.style.backgroundColor = '#2196F3';
    };

    // Close button handler - reload page
    const reloadPage = () => {
      console.log('[ALERT] Close button clicked - reloading page');

      // Reloading re-requests this exact origin.  Only check pfodProxy
      // first when it's actually serving this page (_pageServedByProxy())
      // — see _exitToConnectionScreen() in responseHandlers.js for the
      // full rationale (a file://-loaded page reloads regardless of
      // pfodProxy, so there's nothing to check there).
      if (!_pageServedByProxy()) {
        window.location.reload();
        return;
      }
      const port = window.location.port;
      _pingProxy(port).then((available) => {
        if (available) {
          window.location.reload();
        } else {
          pfodAlert(_proxyUnreachableMsg('127.0.0.1:' + port));
        }
      });
    };

    closeButton.onclick = reloadPage;

    // Handle Enter key
    const handleKeyPress = (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        reloadPage();
      }
    };
    document.addEventListener('keydown', handleKeyPress);

    // Focus the button so Enter works immediately
    setTimeout(() => {
      closeButton.focus();
    }, 100);

    // Assemble dialog
    alertBox.appendChild(message);
    alertBox.appendChild(details);
    alertBox.appendChild(closeButton);
    overlay.appendChild(alertBox);
    document.body.appendChild(overlay);
  }

});

// =============================================================================
// Startup bootstrapping — globals, event listeners, app initialisation
// =============================================================================

// Dynamic script loader with retry on failure
function loadScript(src, maxRetries = 3, retryDelay = 500) {
  return new Promise((resolve, reject) => {
    let retryCount = 0;

    function attemptLoad() {
      const script = document.createElement('script');
      script.src = src;
      script.onload = resolve;
      script.onerror = () => {
        retryCount++;
        if (retryCount < maxRetries) {
          console.warn(`[PFODWEB] Failed to load ${src} (attempt ${retryCount}/${maxRetries}), retrying in ${retryDelay}ms...`);
          setTimeout(attemptLoad, retryDelay);
        } else {
          reject(new Error(`Failed to load ${src} after ${maxRetries} attempts`));
        }
      };
      document.head.appendChild(script);
    }

    attemptLoad();
  });
}

// Load all dependencies from bundles
//
// NOTE: This function is dead code in the current architecture — pfodWeb.js's
// startBootstrap() loads the bundles directly via its own BUNDLES array, and
// in standalone mode this function is overridden to a no-op by build-bundle.js.
// The list below is kept in sync with the actual bundle filenames produced by
// build_data.bat / build_data.sh for documentation and future-proofing.
async function loadDependencies() {
  const bundles = [
    './pfodweb-001-base.js',
    './pfodweb-002-charts.js',
    './pfodweb-003-render.js',
    './pfodweb-004-menu.js',
    './pfodweb-005-proto.js'
    // Note: pfodWeb.js is NOT included as a bundle — it's loaded directly by the HTML template.
  ];

  for (const bundle of bundles) {
    await loadScript(bundle);
  }

  // Make JS_VERSION available globally after dependencies are loaded
  if (typeof JS_VERSION !== 'undefined') {
    window.JS_VERSION = JS_VERSION;
    console.log('[PFODWEB_DEBUG] JS_VERSION loaded and made globally available:', JS_VERSION);
  } else {
    console.warn('[PFODWEB_DEBUG] Warning: JS_VERSION not defined after loading dependencies');
  }
}

// Global viewer instance
let drawingViewer = null;

// Track if bundles are already loaded (device mode only - not in standalone)
var bundlesLoaded = false;

// Main startup: load dependencies then initialise the app.
// In standalone mode loadDependencies is a no-op (overridden by build-bundle.js).
window.addEventListener('DOMContentLoaded', async () => {
  console.log('[PFODWEB_DEBUG] DOMContentLoaded event fired');

  console.log('[PFODWEB_DEBUG] URL when DOMContentLoaded:', window.location.href);
  console.log('[PFODWEB_DEBUG] Referrer when DOMContentLoaded:', document.referrer);

  // In standalone mode (window.pfodweb_standalone set by build-bundle.js): always load
  // (loadDependencies is overridden to do nothing, so it's safe to call)
  // In device mode: only load once to prevent flash on refresh
  if (window.pfodweb_standalone || !bundlesLoaded) {
    if (window.pfodweb_standalone) {
      console.log('[PFODWEB_DEBUG] Standalone mode detected, loading dependencies');
    } else {
      console.log('[PFODWEB_DEBUG] Loading bundles for first time');
    }
    await loadDependencies();
    bundlesLoaded = true;
  } else {
    console.log('[PFODWEB_DEBUG] Bundles already loaded, skipping reload on refresh');
  }
  await initializeApp();
});

window.addEventListener('resize', () => {
  console.log('[WINDOW_RESIZE] Resize event fired, drawingViewer exists:', !!drawingViewer, 'className:', document.body.className);
  if (drawingViewer) {
    drawingViewer.handleResize();
  } else {
    console.log('[WINDOW_RESIZE] drawingViewer not ready yet, ignoring resize');
  }
});

// Handle browser refresh button and navigation away.
//
// Deliberately NOT an async function, and disconnect() below isn't
// awaited. Browsers do not wait for an async beforeunload handler's
// returned Promise — they just invoke it and proceed with tearing down
// the page. An `await` yields control back to the event loop at a
// microtask boundary, and the page can finish unloading before that
// microtask resumes, silently skipping anything after the `await`.
// disconnect() fires its actual {!} send as a fire-and-forget
// keepalive:true fetch internally (see HTTPConnection/
// ProxyStreamConnection.sendAbort()) — keepalive is what lets it survive
// the unload; not awaiting it here is what lets it actually get
// *initiated* before the page is gone. (pfodProxy never shuts itself down
// — see spawn_idle_logger() in main.rs, which only logs idleness, never
// acts on it — so this {!} is the only thing that ever resets the
// device's dedup state on tab close; nothing else will.)
window.addEventListener('beforeunload', function(event) {
  // Store the current URL pattern
  localStorage.setItem('lastUrlPattern', window.location.pathname);

  // Clean up connection if it exists. Skipped when _exitToConnectionScreen()
  // (responseHandlers.js) already disconnected explicitly just before this
  // same reload — otherwise the device gets sent {!} a second time for
  // no reason, since this listener fires from that function's own
  // window.location.replace().
  if (drawingViewer && drawingViewer.connectionManager && !window._pfodAlreadyDisconnected) {
    console.log('[CLEANUP] Disconnecting before page unload...');
    drawingViewer.stopKeepAlivePolling();
    drawingViewer.connectionManager.disconnect().catch((error) => {
      console.error('[CLEANUP] Error during disconnect:', error);
    });
  }
});

// Handle returning from browser refresh
window.addEventListener('DOMContentLoaded', function() {
  const lastUrlPattern = localStorage.getItem('lastUrlPattern');
  if (lastUrlPattern && lastUrlPattern.includes('/update')) {
    // If we were on an update URL, register the drawing name so the
    // queue/cache lookups can find it.  Order is not significant —
    // every drawing carries equal weight; appending preserves
    // registration order without privileging position 0.
    const pathSegments = lastUrlPattern.split('/').filter(segment => segment.length > 0);
    if (pathSegments.length > 0) {
      const currentDrawingName = pathSegments[0];
      if (!this.redraw.redrawDrawingManager.drawings.includes(currentDrawingName)) {
        this.redraw.redrawDrawingManager.drawings.push(currentDrawingName);
      }
    }
  }
});

// Continue initialization after connection prompt submit.
// Called from the HTML connection prompt via window.continueInitialization.
function continueInitialization(connectionSettings) {
  console.log('[PFODWEB_DEBUG] continueInitialization() called after connection prompt', connectionSettings);

  // Always clean up any existing drawingViewer when navigating to this page
  // This handles the case where user goes back from this page and then navigates here again
  if (drawingViewer) {
    console.log('[PFODWEB_DEBUG] Cleaning up existing DrawingViewer from previous session');
    // Stop keepAlive polling before changing connection
    drawingViewer.stopKeepAlivePolling();
    if (drawingViewer.connectionManager) {
      drawingViewer.connectionManager.disconnect().catch(err => {
        console.error('[PFODWEB_DEBUG] Error disconnecting previous connection:', err);
      });
    }
    drawingViewer = null;
  }

  // Create the DrawingViewer instance with connection settings (includes chartOnly flag)
  const viewerOptions = connectionSettings || {};
  drawingViewer = new DrawingViewer(viewerOptions);

  // Make drawingViewer globally accessible for pfodWebMouse
  window.drawingViewer = drawingViewer;

  try {
    // Initialize the viewer - queue initial request to get drawing name from server
    drawingViewer.queueInitialRequest();

    // Redraw instance already created with canvas and context - no init needed
    // Data is managed locally in redraw

    // The drawing name will be extracted and drawing loaded via the request queue

    // TCP/IP Socket: arm the keepAlive timer so `{ }` pings fire when
    // the connection is idle (NAT pinhole + device-session keepalive).
    // The function self-gates on protocol and on keepAliveSec=0 so
    // calling it unconditionally for TCP is safe.  Other protocols
    // don't need it.
    if (connectionSettings && connectionSettings.protocol === 'tcp'
        && typeof drawingViewer.startKeepAlivePolling === 'function') {
      drawingViewer.startKeepAlivePolling();
    }
  } catch (error) {
    console.error('Failed to initialize application:', error);
    // Show error to user
    document.body.innerHTML = `<div style="padding: 20px; text-align: center; font-family: Arial;">
            <h2>Error Loading Drawing</h2>
            <p>Failed to get drawing name from server: ${error.message}</p>
        </div>`;
  }
}

// Validate an IPv4 address or domain name, with optional :port suffix.
// Accepts: 192.168.1.100, 192.168.1.100:8080, djpetrica.go.ro, djpetrica.go.ro:49890
function isValidIPAddress(ip) {
  if (!ip || typeof ip !== 'string') return false;

  // Extract host part (remove port if present)
  let hostPart = ip;
  if (ip.includes(':')) {
    const parts = ip.split(':');
    hostPart = parts[0];
    // Validate port if present
    const port = parseInt(parts[1], 10);
    if (isNaN(port) || port <= 0 || port > 65535) {
      return false;
    }
  }

  // Check if it's an IP address (IPv4)
  const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
  if (ipRegex.test(hostPart)) {
    const octetParts = hostPart.split('.');
    return octetParts.every(part => {
      const num = parseInt(part, 10);
      return num >= 0 && num <= 255;
    });
  }

  // Check if it's a valid domain name
  // Domain can contain letters, numbers, hyphens, and dots
  // Must not start or end with hyphen, must have at least one dot
  const domainRegex = /^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$/;
  return domainRegex.test(hostPart);
}

// Read URL parameters and either proceed directly (valid targetIP / designer mode)
// or show the connection prompt for the user to fill in.
// Guard against double-call: in standalone pfodWeb.html both pfodWeb.js and this file
// register DOMContentLoaded listeners that both call initializeApp().
async function initializeApp() {
  if (window.appInitialized) {
    console.log('[PFODWEB_DEBUG] initializeApp() already called - skipping duplicate call');
    return;
  }
  window.appInitialized = true;
  console.log('[PFODWEB_DEBUG] initializeApp() called');
  console.log('[PFODWEB_DEBUG] Current Version:', typeof window.JS_VERSION !== 'undefined' ? window.JS_VERSION : 'Unknown');
  console.log('[PFODWEB_DEBUG] Current URL:', window.location.href);
  console.log('[PFODWEB_DEBUG] Referrer:', document.referrer);
  console.log('[PFODWEB_DEBUG] Document ready state:', document.readyState);
  console.log('Initializing canvas drawing viewer');

  // Check if connection parameters are provided
  const urlParams = new URLSearchParams(window.location.search);

  // Check for protocol-specific parameters
  const hasTargetIP = urlParams.has('targetIP');
  const hasSerial = urlParams.has('serial');
  const hasBLE = urlParams.has('ble');
  const hasTcpIP = urlParams.has('tcpIP');
  const hasChartParam = urlParams.has('chart');
  const hasAutoConnect = urlParams.has('autoConnect');

  if (hasChartParam) {
    console.log('[PFODWEB_DEBUG] Chart parameter detected - will enable chart-only mode');
  }

  // ?autoConnect together with a valid ?targetIP triggers an immediate HTTP
  // connection (skipping the prompt).  autoConnect is NOT written back to the
  // URL by updateURLFromForm() and is stripped by _exitToConnectionScreen()
  // on page reload, so it acts as a one-shot opt-in for this session only —
  // exiting brings the user back to the prompt with the IP pre-filled.
  if (hasAutoConnect && hasTargetIP) {
    const targetIP = urlParams.get('targetIP');
    if (targetIP && targetIP.trim() !== '' && isValidIPAddress(targetIP)) {
      console.log('[PFODWEB_DEBUG] autoConnect + valid targetIP="' + targetIP + '" - connecting directly');
      document.getElementById('connection-prompt').style.display = 'none';
      const connectionSettings = { protocol: 'http', targetIP: targetIP };
      if (hasChartParam) {
        connectionSettings.chartOnly = true;
        connectionSettings.chartCommand = urlParams.get('chart');
      }
      // ConnectionManager is created inside continueInitialization via the
      // DrawingViewer constructor's URL-fallback path (no
      // window.pfodConnectionManager set here), so pass the settings
      // through; the URL-fallback path applies the 10-second HTTP timeout
      // that the auto-connect flow expects.
      continueInitialization(connectionSettings);
      return;
    }
    console.log('[PFODWEB_DEBUG] autoConnect present but targetIP invalid/empty — falling through to prompt');
  }

  // ?autoConnect for TCP / Serial / BLE — reuses the connect-button flow.
  // The prompt's connectWithPrompt() handler already knows how to build the
  // right connectionSettings for each protocol (with picker fall-throughs
  // for native Web Serial / Web Bluetooth, or proxy modes), so we just call
  // prefillFormFromURL() to populate the form fields from the URL params,
  // then trigger the same code path the user would by clicking Connect.
  //
  // Serial / BLE on the native "This browser" transport can never
  // auto-connect: their port / device selection is a live object obtained
  // under a user gesture and cannot be restored from the URL, so the
  // Connect button is still disabled here and the block below falls
  // through to showing the prompt for a manual pick.  Proxy Serial / BLE
  // and TCP all work fine because their selections are plain strings the
  // URL can carry and TCP only needs an SSE to the proxy.
  if (hasAutoConnect && (hasTcpIP || hasSerial || hasBLE)) {
    console.log('[PFODWEB_DEBUG] autoConnect (' +
      (hasTcpIP ? 'tcp' : hasSerial ? 'serial' : 'ble') +
      ') — prefilling form and clicking Connect');
    if (typeof prefillFormFromURL === 'function') {
      try { prefillFormFromURL(); }
      catch (e) { console.warn('[PFODWEB_DEBUG] autoConnect prefill threw:', e); }
    }
    const connectBtn = document.getElementById('connect-button');
    if (connectBtn && !connectBtn.disabled) {
      connectBtn.click();
      return;
    }
    console.log('[PFODWEB_DEBUG] autoConnect — connect button missing or disabled, showing prompt');
  }

  // If targetIP is provided (without autoConnect), ALWAYS show the connection
  // prompt with HTTP pre-selected and the IP / port pre-filled.  This gives
  // the user a chance to clear cache or tick "Chart Only Mode" before
  // connecting.  The prompt's prefillFormFromURL() (DOMContentLoaded) already
  // handles HTTP radio + IP value + chart-only checkbox from URL params; this
  // block just makes the prompt visible and focuses the IP field so an
  // invalid IP can be edited.
  if (hasTargetIP) {
    const targetIP = urlParams.get('targetIP');
    console.log('[PFODWEB_DEBUG] targetIP parameter found ("' + targetIP + '") - showing connection prompt for user confirmation');

    // Pre-select HTTP radio button (in case prefillFormFromURL hasn't run yet)
    document.getElementById('prompt-protocol-http').checked = true;
    if (typeof updatePromptUI === 'function') {
      updatePromptUI();
    }
    // Pre-fill the IP field (covers both valid and invalid values)
    const ipInput = document.getElementById('prompt-ip');
    if (ipInput) {
      ipInput.value = targetIP || '';
      ipInput.focus();
      ipInput.select();
    }
    if (typeof validateConnectButton === 'function') {
      validateConnectButton();
    }
    document.getElementById('connection-prompt').style.display = 'flex';
    return;
  }

  // If serial parameter is in URL, show connection prompt with Serial section pre-selected
  if (hasSerial) {
    console.log('[PFODWEB_DEBUG] Serial parameter found - showing Serial connection prompt');
    // Pre-select Serial radio button
    document.getElementById('prompt-protocol-serial').checked = true;
    // Update UI to show Serial settings
    if (typeof updatePromptUI === 'function') {
      updatePromptUI();
    }
    // If serial has a value, try to pre-fill the baud rate
    const baudRate = urlParams.get('serial');
    if (baudRate && baudRate !== '') {
      const baudSelect = document.getElementById('prompt-baud');
      // Try to set the value - if invalid, it won't match any option
      baudSelect.value = baudRate;
      // If the value didn't match any option, the select will have an empty value
      console.log('[PFODWEB_DEBUG] Set baud rate to:', baudRate, 'Actual value:', baudSelect.value);
    }
    // Fill in the COM port selection (if the bookmarked URL has one) only
    // after the Serial radio above is already selected -- _serialPortState
    // and the "Select COM Port" label are Serial-specific, so this has to
    // follow the protocol selection, not precede it. Just updates the
    // label/state directly -- does NOT call updateURLFromForm(), so it
    // can't clobber a ?chart=<command> already in the URL.
    //
    // Skipped entirely on the native Web Serial transport: there the browser
    // hands the page a SerialPort object rather than a port name, so a ?com=
    // left over from an earlier pfodProxy session names nothing this
    // connection could open -- restoring it would light up Connect for a
    // selection that does not exist.
    const comParam = urlParams.get('com');
    const serialViaProxy = (typeof _serialTransport !== 'function') || _serialTransport() === 'proxy';
    if (comParam && serialViaProxy && typeof _serialPortState !== 'undefined') {
      _serialPortState.path  = comParam;
      _serialPortState.label = comParam;
      if (typeof _updateSerialPortDisplay === 'function') {
        _updateSerialPortDisplay();
      }
    }
    // Validate the connect button state after pre-filling
    if (typeof validateConnectButton === 'function') {
      validateConnectButton();
    }
    document.getElementById('connection-prompt').style.display = 'flex';
    return;
  }

  // If ble parameter is in URL, show connection prompt with BLE section pre-selected
  if (hasBLE) {
    console.log('[PFODWEB_DEBUG] BLE parameter found - showing BLE connection prompt');
    // Pre-select BLE radio button
    document.getElementById('prompt-protocol-ble').checked = true;
    // Update UI to show BLE settings
    if (typeof updatePromptUI === 'function') {
      updatePromptUI();
    }
    // Fill in the BLE device selection (if the bookmarked URL has one) only
    // after the BLE radio above is already selected -- same ordering
    // reason, and same "doesn't touch the URL" property, as the
    // Serial/com restoration above.  Also skipped on the native Web
    // Bluetooth transport, for the same non-restorable-handle reason.
    const bleParam = urlParams.get('ble');
    const bleViaProxy = (typeof _bleTransport !== 'function') || _bleTransport() === 'proxy';
    if (bleParam && bleViaProxy && typeof _bleDeviceState !== 'undefined') {
      _bleDeviceState.address = bleParam;
      _bleDeviceState.name    = urlParams.get('bleName') || null;
      if (typeof _updateBleDeviceDisplay === 'function') {
        _updateBleDeviceDisplay();
      }
    }
    document.getElementById('connection-prompt').style.display = 'flex';
    return;
  }

  // If tcpIP parameter is in URL, show connection prompt with TCP section pre-selected.
  // Mirrors the Serial / BLE / Designer pattern so Exit / reload always returns
  // the user to the picker with every protocol still selectable (they can either
  // click Connect to use the previously-chosen protocol or switch).
  if (hasTcpIP) {
    console.log('[PFODWEB_DEBUG] tcpIP parameter found - showing TCP connection prompt');
    document.getElementById('prompt-protocol-tcp').checked = true;
    if (typeof updatePromptUI === 'function') {
      updatePromptUI();
    }
    // The actual tcpIP / keepAlive values are pre-filled by prefillFormFromURL
    // on DOMContentLoaded — nothing extra to do here.
    if (typeof validateConnectButton === 'function') {
      validateConnectButton();
    }
    document.getElementById('connection-prompt').style.display = 'flex';
    return;
  }

  // If designer parameter is in URL, show connection prompt with Designer
  // pre-selected (NOT auto-connect).  Exit / reload should bring the user
  // back to the full picker so they can confirm or switch protocols; auto-
  // connect would prevent that.  Matches the BLE / Serial / TCP pattern
  // above.
  if (urlParams.has('designer')) {
    console.log('[PFODWEB_DEBUG] Designer parameter found - showing prompt with Designer pre-selected');
    document.getElementById('prompt-protocol-designer').checked = true;
    if (typeof updatePromptUI === 'function') {
      updatePromptUI();
    }
    if (typeof validateConnectButton === 'function') {
      validateConnectButton();
    }
    document.getElementById('connection-prompt').style.display = 'flex';
    return;
  }

  // No parameters - show connection prompt with HTTP pre-selected (default)
  console.log('[PFODWEB_DEBUG] No connection parameters - showing connection prompt');
  // Validate the connect button state (HTTP is selected by default, so button should be enabled)
  if (typeof validateConnectButton === 'function') {
    validateConnectButton();
  }
  document.getElementById('connection-prompt').style.display = 'flex';
  // Focus on IP address field for immediate input
  // Use setTimeout to ensure focus happens after display is set
  setTimeout(() => {
    document.getElementById('prompt-ip').focus();
  }, 0);
}

// Make continueInitialization available globally so connection prompt can call it
window.continueInitialization = continueInitialization;

// Export the fully-patched DrawingViewer class for browser use.
// Must be the last statement so all Object.assign patches from every module
// file have already been applied before this runs.
window.DrawingViewer = DrawingViewer;
